﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	public class SaleViewModel
	{
		// Наименование товара
		public string Title { get; set; }
		
		// Цена закупки
		public int PurchasePrice { get; set; }

		// Цена продажи
		public int SalePrice { get; set; }

		// дата продажи
		public DateTime SellDate { get; set; }
	}
}
