﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _2ADO.NET.Controllers;

namespace _2ADO.NET.Classes
{
    class App
    {
        QueriesController queriesController;

        public App()
        {
            queriesController = new QueriesController();
        }

        public void Query1()
        {
            Console.WriteLine("\t1 Хранимая процедура " +
                "\n\tВыбирает информацию о 3 - комнатных квартирах, расположенных нa" +
                "\n\tулице «Садовая». Значения задавать параметрами запроса\n");
            queriesController.Query01("Садовая",3);
            Console.ReadKey();
        }
        public void Query2()
        {
            Console.WriteLine("\t2 Хранимая процедура " +
                "\n\tВыбирает информацию о риэлторах, фамилия которых начинается с" +
                "\n\tбуквы «И» и процент вознаграждения больше 10%. Значения задавать параметрами запроса\n");
            queriesController.Query02("И",10);
            Console.ReadKey();
        }
        public void Query3()
        {
            Console.WriteLine("\t3 Хранимая процедура " +
                "\n\tВыбирает информацию об 1-комнатных квартирах, цена на которые" +
                "\n\tнаходится в диапазоне от 900 000 руб. до 1000 000 руб. " +
                "\n\tЗначения задавать параметрами запроса\n");
            queriesController.Query03(1, 12000, 13400);
            Console.ReadKey();
        }
        public void Query4()
        {
            Console.WriteLine("\t4 Хранимая процедура " +
                "\n\tВыбирает информацию о квартирах с заданным числом комнат. " +
                "\n\tЗначения задавать параметрами запроса");
            queriesController.Query04(3);
            Console.ReadKey();
        }
        public void Query5()
        {
            Console.WriteLine("\t5 Хранимая процедура " +
                "\n\tВыбирает информацию обо всех 2-комнатных квартирах, площадь" +
                "\n\tкоторых есть значение из некоторого диапазона." +
                "\n\tЗначения задавать параметрами запроса\n");
            queriesController.Query05(2, 35, 45);
            Console.ReadKey();
        }
        public void Query6()
        {
            Console.WriteLine("\t6 Хранимая процедура " +
                "\n\tВычисляет для каждой оформленной сделки размер комиссионного" +
                "\n\tвознаграждения риэлтора. Включает поля Фамилия риэлтора, Имя " +
                "\n\tриэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные.");
            queriesController.Query06();
            Console.ReadKey();
        }
       
    }
}
