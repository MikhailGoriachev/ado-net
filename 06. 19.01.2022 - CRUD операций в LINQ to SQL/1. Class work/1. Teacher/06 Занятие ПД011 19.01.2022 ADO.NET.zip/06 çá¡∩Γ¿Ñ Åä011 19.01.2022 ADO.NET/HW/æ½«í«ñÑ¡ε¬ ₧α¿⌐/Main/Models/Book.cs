namespace Main.Models
{
	public sealed class Book
	{
		public string? Identifier { get; set; }
		public Author? Author { get; set; }
		public string? Title { get; set; }
		public int Published { get; set; }
		public decimal Price { get; set; }
	}
}