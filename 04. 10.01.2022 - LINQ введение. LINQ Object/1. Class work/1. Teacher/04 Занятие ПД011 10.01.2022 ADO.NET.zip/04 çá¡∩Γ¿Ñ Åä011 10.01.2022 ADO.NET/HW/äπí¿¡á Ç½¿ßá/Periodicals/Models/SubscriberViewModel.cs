﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Periodicals.Models {
    // модель подписчика для вывода данных 
    public class SubscriberViewModel {
        // ИД
        public int Id { get; set; }

        // Фамилия И.О.
        public string FullName { get; set; }

        // Серия и номер подписчика
        public string Passport { get; set; }

        // Адрес подписчика
        public string Address { get; set; }

        // вид издания
        public string PubType { get; set; }

        // наименование (название) издания
        public string Title { get; set; }

        public string ToTableRow => $"\t│ {Id,2} │ " +
                            $"{FullName,-18} │ " +
                            $"{Passport,-13} │ " +
                            $"{Address,-32} │ " +
                            $"{PubType,-11} │ " +
                            $"{Title,-20} │";

        public static string Header => "\t┌────┬────────────────────┬───────────────┬──────────────────────────────────┬─────────────┬──────────────────────┐\n" +
                                       "\t│ ИД │ Фамилия И.О.       │ Серия и номер │ Адрес подписчика                 │ Вид издания │ Наименование издания │\n" +
                                       "\t├────┼────────────────────┼───────────────┼──────────────────────────────────┼─────────────┼──────────────────────┤";

        public static string Footer => "\t└────┴────────────────────┴───────────────┴──────────────────────────────────┴─────────────┴──────────────────────┘";
    } // SubscriberViewModel
}
