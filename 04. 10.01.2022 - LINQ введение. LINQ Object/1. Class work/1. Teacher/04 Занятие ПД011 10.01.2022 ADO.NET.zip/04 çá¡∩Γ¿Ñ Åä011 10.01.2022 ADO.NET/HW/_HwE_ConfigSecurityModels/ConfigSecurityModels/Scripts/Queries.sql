﻿-- База данных «Учет подписки на периодические печатные издания»

-- создание представлений для удобства запросов

-- представление для подписчиков
drop view if exists ViewSubscribers;
go

create view ViewSubscribers as
    select
        Subscribers.Id        as SubscriberId
        , Subscribers.Surname
        , Subscribers.[Name]
        , Subscribers.Patronymic
        , Subscribers.Passport
        , Streets.Street
        , Subscribers.Building
        , Subscribers.Flat
    from
        Subscribers join Streets on Subscribers.IdStreet = Streets.Id;
go


-- представление для издания с расшифровкой
drop view if exists ViewPublications;
go

create view ViewPublications as
    select
        Publications.Id    as PublicationId
        , PubTypes.PubType
        , Publications.PubIndex
        , Publications.Title
        , Publications.Price
    from 
        Publications join PubTypes on Publications.IdPubType = PubTypes.Id;
go


-- представление для данных доставки
drop view if exists ViewDeliveries;
go

create view ViewDeliveries as
select
    Deliveries.Id as DeliveryId
    , ViewPublications.PubType
    , ViewPublications.PubIndex
    , ViewPublications.Title
    , ViewPublications.Price
    , ViewSubscribers.Surname
    , ViewSubscribers.[Name]
    , ViewSubscribers.Patronymic
    , ViewSubscribers.Passport
    , ViewSubscribers.Street
    , ViewSubscribers.Building
    , ViewSubscribers.Flat
    , Deliveries.DateStart
    , Deliveries.Duration
from
    Deliveries join ViewPublications on Deliveries.IdPublication = ViewPublications.PublicationId
               join ViewSubscribers on Deliveries.IdSubscriber = ViewSubscribers.Subscriberid;
go


-- Выполнение запросов по заданию

-- Запрос 1. Хранимая процедура	
-- Выбирает информацию о доступных для подписки изданиях заданного типа, 
-- стоимость 1 экземпляра для которых меньше заданной.
drop proc if exists Query01;
go

create proc Query01
    @pubType nvarchar(30) = N'журнал', 
    @price int = 250
as
select
    PublicationId
    , PubIndex
    , PubType
    , Title
    , Price
from 
    ViewPublications
where
    PubType = @pubType and Price < @price
go

declare @pubType nvarchar(30) = N'журнал', @price int = 250;
exec Query01;                  -- значения по умолчанию
exec Query01 @pubType, @price;  -- те же значения, но заданные явно
go

-- Запрос 2. Хранимая процедура	
-- Выбирает информацию о подписчиках, проживающих на заданной параметром улице
-- и номере дома, которые оформили подписку на издание с заданным параметром 
-- наименованием
drop proc if exists Query02;
go

create proc Query02
    @street nvarchar(30) = N'ул. Садовая', 
    @building nvarchar(10) = N'118', 
    @title nvarchar(80) = N'Юный техник'
as
select  -- с учетом вида издания
    DeliveryId
    , Surname
    , [Name]
    , Patronymic 
    , Passport
    , Street
    , Building
    , Flat 
    , PubType
    , Title
from
    ViewDeliveries
where
    Street = @street and Building = @building and Title = @title;
go

declare @street nvarchar(30) = N'ул. Садовая', @building nvarchar(10) = N'118', 
        @title nvarchar(80) = N'Юный техник';
exec Query02;
exec Query02 @street, @building, @title;
go


-- Запрос 3. Хранимая процедура	
-- Выбирает информацию об изданиях, для которых значение в поле 
-- Цена 1 экземпляра находится в заданном диапазоне значений
drop proc if exists Query03;
go

create proc Query03
    @loPrice int = 100, 
    @hiPrice int = 150
as
    select
        PublicationId
        , PubType
        , PubIndex
        , Title
        , Price
    from 
        ViewPublications
    where
        Price between @loPrice and @hiPrice;
go

declare @loPrice int = 100, @hiPrice int = 150;
exec Query03;
exec Query03 @loPrice, @hiPrice;
go


-- Запрос 4. Хранимая процедура	
-- Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный 
-- параметром тип издания
drop proc if exists Query04;
go

create proc Query04
    @pubType nvarchar(30) = N'газета'
as
    select
        DeliveryId
        , Surname
        , [Name]
        , Patronymic 
        , Passport
        , Street
        , Building
        , Flat 
        , PubType
        , Title
    from
        ViewDeliveries
    where
        PubType = @pubType;
go

declare @pubType nvarchar(30) = N'газета';
exec Query04;
exec Query04 @pubType;
go


-- Запрос 5. Хранимая процедура	
-- Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКИ информацию обо всех оформленных 
-- подписках, для которых срок подписки есть значение из некоторого диапазона. 
-- Нижняя и верхняя границы диапазона задаются при выполнении запроса
drop proc if exists Query05;
go

create proc Query05
    @loDuration int = 10, 
    @hiDuration int = 11
as
    select
        DeliveryId
        , Surname
        , [Name]
        , Patronymic 
        , Passport
        , Street
        , Building
        , Flat 
        , PubType
        , Title
        , Duration
        , DateStart
    from
        ViewDeliveries
    where
        Duration between @loDuration and @hiDuration;
go

declare @loDuration int = 10, @hiDuration int = 11;
exec Query05;
exec Query05 @loDuration, @hiDuration;
go


-- Запрос 6. Хранимая процедура	
-- Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС 
-- Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата 
-- начала подписки, Срок подписки, Стоимость подписки без НДС. Сортировка по 
-- полю Индекс издания
drop proc if exists Query06;
go

create proc Query06
as
    select
        DeliveryId
        , PubIndex
        , Title
        , Price
        , DateStart
        , Duration
        -- стоимость подписки с доставкой (1%) и без НДС 
        , 1.01 * (Price * Duration) as SubscribeCost
    from
        ViewDeliveries
    order by
        PubIndex;
go

exec Query06;
go


-- Запрос 7. Итоговый запрос. Хранимая процедура	
-- Выполняет группировку по полю Вид издания. Для каждого вида вычисляет 
-- максимальную и минимальную цену 1 экземпляра
drop proc if exists Query07;
go

create proc Query07
as
    select
        PubType
        , Count(PublicationId) as TotalPubType
        , Max(Price) as MaxPrice
        , Min(Price) as MinPrice
    from
        ViewPublications
    group by
        PubType;
go

exec Query07;
go


-- Запрос 8. Итоговый запрос с левым соединением. Хранимая процедура	
-- Выполняет группировку по полю Улица. Для всех улиц вычисляет количество 
-- подписчиков, проживающих на данной улице (итоги по полю Код получателя)
drop proc if exists Query08;
go

create proc Query08
as
    select
        Streets.Street
        , Count(Deliveries.IdSubscriber) as SubscriberAmount
    from
        Streets left join (Subscribers join Deliveries on Subscribers.Id = Deliveries.IdSubscriber)
            on Streets.Id = Subscribers.IdStreet
    group by
        Streets.Street;
go

exec Query08;
go


-- Запрос 9. Итоговый запрос с левым соединением. Хранимая процедура	
-- Для всех изданий выводит количество оформленных подписок
drop proc if exists Query09;
go

create proc Query09
as
select
    PubTypes.PubType
    , Count(ViewDeliveries.DeliveryId) as DeliveriesAmount
from
    PubTypes left join ViewDeliveries on PubTypes.PubType = ViewDeliveries.PubType
group by
    PubTypes.PubType;
go

exec Query09;
go
