﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqToSQL_WF_Shop_DB.Models
{
    public class SellersViewModel
    {
        //ФИО продавца
        public string SellerSNP
        {
            get;
            set;
        }

        //Процент от продаж
        public double Interest
        {
            get;
            set;
        }

        #region Конструкторы

        public SellersViewModel()
        {}

        public SellersViewModel(string seller, int interest)
        {
            SellerSNP = seller;
            Interest = interest;
        }
        #endregion

    }
}
