﻿using System;
using System.IO;
using Main.Controllers;
using Main.Models;
using Main.Utilities;
using Main.Utilities.Menu;
using Microsoft.Extensions.Configuration;


namespace Main
{
	public sealed class App : MenuWrapper
	{
		private readonly MainController _controller;


		public App()
		{
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Первый запрос", Query1),
				new MenuItem("Второй запрос", Query2),
				new MenuItem("Третий запрос", Query3),
				new MenuItem("Четвертый запрос", Query4),
				new MenuItem("Пятый запрос", Query5),
				new MenuItem("Шестой запрос", Query6),
				new MenuItem("Седьмой запрос", Query7),
				new MenuItem("Восьмой запрос", Query8),
				new MenuItem("Девятый запрос", Query9),
			});

			_controller = new(
				new ConfigurationBuilder()
					.SetBasePath(Directory.GetCurrentDirectory())
					.AddJsonFile(ApplicationConfig.JsonConfig, false)
					.Build()
					.GetConnectionString(ApplicationConfig.PublishingConnectionString)
			);
		}


		private void Query1()
		{
			decimal price = 1000;

			Console.WriteLine($@"
Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа, стоимость 1 экземпляра для которых меньше заданной ({price}).
Требуется модель для вывода данных – данные выборки помещать в коллекцию
");

			_controller.Query1(price);
		}


		private void Query2()
		{
			string street = "Praesent";
			string title = "ultrices a,";
			int house = 173;

			Console.WriteLine($@"
Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице({street}) и номере дома({house}), 
которые оформили подписку на издание с заданным параметром наименованием({title})
");

			_controller.Query2(street, title, house);
		}


		private void Query3()
		{
			var priceRange = new Range<decimal>(500, 1000);

			Console.WriteLine($@"
Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле
Цена 1 экземпляра находится в заданном диапазоне значений({priceRange})
");

			_controller.Query3(priceRange);
		}


		private void Query4()
		{
			int typeId = 1;

			Console.WriteLine($@"
Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания({typeId})
");

			_controller.Query4(typeId);
		}


		private void Query5()
		{
			var termRange = new Range<int>(3, 7);

			Console.WriteLine($@"
Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных подписках, для 
которых срок подписки есть значение из некоторого диапазона. 
Нижняя и верхняя границы диапазона задаются при выполнении запроса({termRange})
");

			_controller.Query5(termRange);
		}


		private void Query6()
		{
			Console.WriteLine(@"
Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки,
Срок подписки, Стоимость подписки без НДС. Сортировка по полю Индекс издания
");

			_controller.Query6();
		}


		private void Query7()
		{
			Console.WriteLine(@"
Выполняет группировку по полю Вид издания. 
Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
");

			_controller.Query7();
		}


		private void Query8()
		{
			Console.WriteLine(@"
Выполняет группировку по полю Улица. Для всех улиц вычисляет количество подписчиков,
проживающих на данной улице (итоги по полю Код получателя)
");

			_controller.Query8();
		}


		private void Query9()
		{
			Console.WriteLine(@"
Для всех изданий выводит количество оформленных подписок
");

			_controller.Query9();
		}
	}
}