﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_first
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Обработчик события нажатия кнопки AVG
        private void AVG_Click(object sender, RoutedEventArgs e)
        {
            // вычесляем AVG
            double res = MathTask.GetAVG(Convert.ToInt32(txtFirstNumb.Text), Convert.ToInt32(txtSecondNumb.Text), Convert.ToInt32(txtThirdNumb.Text));
            txbResult.Text = "Среднее арифметическое : " + res;
        }

        // Обработчик события нажатия кнопки AVG
        private void GVG_Click(object sender, RoutedEventArgs e)
        {
            // вычесляем AVG
            double res = MathTask.GetGVG(Convert.ToInt32(txtFirstNumb.Text), Convert.ToInt32(txtSecondNumb.Text), Convert.ToInt32(txtThirdNumb.Text));
            txbResult.Text = "Среднее геометрическое : " + res;
        }

        // Обработчик события нажатия кнопки AVG
        private void Root_Click(object sender, RoutedEventArgs e)
        {
            // вычесляем AVG
            List<double> res = MathTask.GetRoots(Convert.ToInt32(txtFirstNumb.Text), Convert.ToInt32(txtSecondNumb.Text), Convert.ToInt32(txtThirdNumb.Text));
            StringBuilder sb = new StringBuilder();
            sb.Append("Корни уровнения : ");
            foreach (var item in res)
            {
                sb.Append(item);
                sb.Append(", ");
            }
            txbResult.Text = sb.ToString();
        }


    }
}
