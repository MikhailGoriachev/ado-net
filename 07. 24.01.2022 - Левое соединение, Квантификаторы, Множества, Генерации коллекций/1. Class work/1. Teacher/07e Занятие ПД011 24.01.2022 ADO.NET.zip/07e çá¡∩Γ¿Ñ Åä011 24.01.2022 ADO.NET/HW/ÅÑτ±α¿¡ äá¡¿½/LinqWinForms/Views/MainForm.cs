﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LinqWinForms.Controllers;
using LinqWinForms.Views;

namespace LinqWinForms
{
    public partial class Form1 : Form
    {
        private QueryControllers _controllers;
        public Form1()
        {
            InitializeComponent();
            _controllers = new QueryControllers();
        }

        private void Query1_Click(object sender, EventArgs e)
        {
            DgvQuery1.DataSource = _controllers.Query1();
            DgvQuery2.DataSource = _controllers.Query2();
        }

        private void Load_Queries(object sender, EventArgs e)
        {
            DgvQuery1.DataSource = _controllers.Query1();
            DgvQuery2.DataSource = _controllers.Query2();
            DgvQuery3.DataSource = _controllers.Query3();
            DgvQuery4.DataSource = _controllers.Query4();
            DgvQuery5.DataSource = _controllers.Query5();
            DgvQuery6.DataSource = _controllers.Query6();
            DgvQuery7.DataSource = _controllers.Query7();
            DgvQuery8.DataSource = _controllers.Query8();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void About_Click(object sender, EventArgs e)
        {
            AboutForm form = new AboutForm();
            form.ShowDialog();
        }
    }
}
