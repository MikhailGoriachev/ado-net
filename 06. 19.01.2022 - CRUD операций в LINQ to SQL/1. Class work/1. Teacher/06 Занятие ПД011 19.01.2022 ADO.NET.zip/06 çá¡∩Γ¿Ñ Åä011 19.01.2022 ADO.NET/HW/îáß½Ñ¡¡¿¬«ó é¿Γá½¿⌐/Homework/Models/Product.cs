﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	// класс, представляющий товар (наименование, цена, количество, год выпуска) 
	public class Product
	{
		// наименование
		public string Name { get; set; }

		// цена
		public int Price { get; set; }

		// количество
		public int Amount { get; set; }

		// год выпуска
		public int YearMade { get; set; }

		public int Sum => Price * Amount;

		public override string ToString() => $"\t{Name}, цена: {Price}р., кол-во: {Amount}шт., год выпуска: {YearMade}";

		public static string Header() =>
			"  ┌──────────────────────┬────────────┬────────┬──────┐\n" +
			"  │        Название      │  Цена, руб │ Кол-во │ Год  │\n" +
			"  ├──────────────────────┼────────────┼────────┼──────┤\n";

		public static string Footer() =>
			"  └──────────────────────┴────────────┴────────┴──────┘\n";

		public string ToTableRow() =>
			$"  │ {Name,-20} │ {Price,10} │ {Amount,6} │ {YearMade,4} │";

		public static string[] names =
			{
				"Acura CDX", "Volvo V90", "Volvo C70", "Volkswagen Beetle", "Volkswagen CrossPolo", "Toyota Supra", "Toyota Tundra",
				"Toyota Prius", "Toyota Camry", "Suzuki Kizashi", "Subaru Traviq", "Subaru Legacy", "Ssang Yong Rodius",
				"Smart Fortwo", "Skoda Kodiaq", "Skoda Fabia", "Seat Leon", "Seat Ibiza", "Seat Ateca", "Rover 25", "Rolls-Royce Cullinan",
				"Renault Talisman", "Renault Symbol", "Porsche Cayenne", "Porsche Cayman", "Porsche Panamera", "Peugeot Landtrek",
				"Peugeot Partner", "Opel Insignia", "Opel Astra", "Opel Corsa", "Nissan Patrol", "Nissan Pathfinder",
				"Mitsubishi Lancer", "Mini Cooper", "Mazda RX-8", "Maybach 57 S", "Lexus LX"
			};

		public static Product Generate()
		{


			return new Product
			{
				Name = names[Utilities.GenerateInt(0, names.Length-1)],
				Amount = Utilities.GenerateInt(1,20),
				YearMade = Utilities.GenerateInt(2000, 2021),
				Price = Utilities.GenerateInt(400_000, 40_000_000)
			};
		}
	}
}
