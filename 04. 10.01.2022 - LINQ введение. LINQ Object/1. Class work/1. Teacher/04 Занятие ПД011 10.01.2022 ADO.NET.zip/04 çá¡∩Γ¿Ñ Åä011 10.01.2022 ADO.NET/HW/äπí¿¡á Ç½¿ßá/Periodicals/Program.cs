﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;  
using System.Configuration;  
using Periodicals.Helpers;
using Periodicals.Application;

namespace Periodicals
{
    class Program
    {
        static void Main(string[] args) {
            Console.SetWindowSize(130, 35);
            // Создание экземпляра класса приложения
            App app = new App(ConfigurationManager.ConnectionStrings["PublicationsConnection"].ConnectionString);


            Console.Title = "Задание на 10.01.2022";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Запрос 1. Информация о изданиях заданного типа, стоимость 1 экземпляра для которых меньше заданной" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Запрос 2. Информация о подписчиках, проживающих на заданной параметром улице и номере дома" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Запрос 3. Информация об изданиях, значение в поле Цена экземпляра находится в заданном диапазоне" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Запрос 4. Информация о подписчиках, подписавшихся на заданный параметром тип издания" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Запрос 5. Информация обо всех подписках, для которых срок подписки есть значение из некоторого диапазона" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Запрос 6. Вычислить для каждой оформленной подписки ее стоимость с доставкой и без НДС" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Запрос 7. Вычислить для каждого вида максимальную и минимальную цену 1 экземпляра" },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Запрос 8. Для всех улиц вычислить количество подписчиков, проживающих на данной улице" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Запрос 9. Для всех изданий вывести количество оформленных подписок" },
                // ------------------------------------------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Шифрование конфигурационного файла" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Расшифровка конфигурационного файла" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            
            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 10.01.2022");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Запрос 1. 
                        case ConsoleKey.Q:
                            app.ExecQuery01();
                            break;

                        // Запрос 2. 
                        case ConsoleKey.W:
                            app.ExecQuery02();
                            break;

                        // Запрос 3. 
                        case ConsoleKey.E:
                            app.ExecQuery03();
                            break;

                        // Запрос 4.
                        case ConsoleKey.R:
                            app.ExecQuery04();
                            break;

                        // Запрос 5.
                        case ConsoleKey.T:
                            app.ExecQuery05();
                            break;

                        // Запрос 6. 
                        case ConsoleKey.Y:
                            app.ExecQuery06();
                            break;

                        // Запрос 7. 
                        case ConsoleKey.U:
                            app.ExecQuery07();
                            break;

                        // Запрос 8. 
                        case ConsoleKey.I:
                            app.ExecQuery08();
                            break;

                        // Запрос 9. 
                        case ConsoleKey.O:
                            app.ExecQuery09();
                            break;

                        // Шифрование конфигурационного файла
                        case ConsoleKey.A:
                            app.ProtectFileConfig();
                            break;

                        // Расшифровка конфигурационного файла
                        case ConsoleKey.S:
                            app.UnprotectFileConfig();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
