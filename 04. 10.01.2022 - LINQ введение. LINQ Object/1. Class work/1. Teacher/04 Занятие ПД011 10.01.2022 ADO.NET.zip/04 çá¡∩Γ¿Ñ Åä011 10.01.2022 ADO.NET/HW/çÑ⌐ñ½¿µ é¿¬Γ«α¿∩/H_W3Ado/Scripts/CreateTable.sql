﻿ /*
 * База данных «Учет подписки на периодические печатные издания»
 *
 * База данных должна включать таблицы ИЗДАНИЯ, ПОДПИСЧИКИ, ДОСТАВКА, 
 * содержащие следующую информацию:
 *     • Фамилия подписчика
 *     • Имя подписчика
 *     • Отчество подписчика
 *     • Номер паспорта подписчика
 *     • Улица
 *     • Номер дома
 *     • Номер квартиры
 *     • Индекс издания по каталогу
 *     • Вид издания (газета, журнал, каталог, …)
 *     • Наименование (название) издания
 *     • Цена 1 экземпляра
 *     • Дата начала подписки
 *     • Срок подписки (количество месяцев)
 *
 */

-- при повторном запуске скрипта удаляем старые варианты таблиц, не разбирая пустые они или нет
-- таблицы удаляем в порядке, обратном порядку создания
drop table if exists Deliveries;
drop table if exists Subscribers;
drop table if exists Publications;
drop table if exists Streets;
drop table if exists TypesOfEdition;


-- таблица - название улиц
CREATE TABLE [dbo].[Streets]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [NameStreet] NVARCHAR(80) NOT NULL 
);
go


-- таблица - виды издания
CREATE TABLE [dbo].[TypesOfEdition]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [TypePublication] NVARCHAR(30) NOT NULL
);
go


-- таблица - издания
CREATE TABLE [dbo].[Publications]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IndexPublication] NVARCHAR(10) NOT NULL, 
    [IdTypePublication] INT NOT NULL, 
    [TitlePublication] NVARCHAR(70) NOT NULL, 
    [PricePublication] FLOAT NOT NULL,
    CONSTRAINT [CK_Publications_PricePublication] CHECK ([PricePublication]>(0)),
	CONSTRAINT [FK_Publications_TypesOfEdotion] FOREIGN KEY ([IdTypePublication]) REFERENCES [dbo].[TypesOfEdotion] ([Id])
);
go


-- таблица - подписчики
CREATE TABLE [dbo].[Subscribers]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Surname] NVARCHAR(50) NOT NULL, 
    [NameSubscriber] NVARCHAR(40) NOT NULL, 
    [Patronymic] NVARCHAR(60) NOT NULL, 
    [PassportNum] NVARCHAR(10) NOT NULL, 
    [IdStreet] INT NOT NULL, 
    [HouseNum] NVARCHAR(12) NOT NULL, 
    [ApartmentNum] NVARCHAR(12) NOT NULL,
	CONSTRAINT [FK_Subscribers_Streets] FOREIGN KEY ([IdStreet]) REFERENCES [dbo].[Streets] ([Id])
);
go


-- таблица - доставка
CREATE TABLE [dbo].[Delivery]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [IdSubscriber] INT NOT NULL, 
    [IdPublication] INT NOT NULL, 
    [DateSubscription] DATE NOT NULL, 
    [TerminSubscription] INT NOT NULL, 
    CONSTRAINT [CK_Delivery_TerminSubscription] CHECK ([TerminSubscription] <= 12),
	CONSTRAINT [FK_Delivery_Subscribers] FOREIGN KEY ([IdSubscriber]) REFERENCES [dbo].[Subscribers] ([Id]),
	CONSTRAINT [FK_Delivery_Publications] FOREIGN KEY ([IdPublication]) REFERENCES [dbo].[Publications] ([Id])
);
go


-- Создание представлений

-- создание представления для издания
drop view if exists ViewPublications;
go

create view ViewPublications as
select
    Publications.Id
    , Publications.IndexPublication
    , TypesOfEdotion.TypePublication
    , Publications.TitlePublication
    , Publications.PricePublication
from
    Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id;
go


-- создание представления для подписчиков
drop view if exists ViewSubscribers;
go

create view ViewSubscribers as
select
    Subscribers.Id
    , Subscribers.Surname
    , Subscribers.NameSubscriber
    , Subscribers.Patronymic
    , Subscribers.PassportNum
    , Streets.NameStreet
    , Subscribers.HouseNum
    , Subscribers.ApartmentNum
    , TypesOfEdotion.TypePublication
    , Publications.TitlePublication
from
   Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                      on Delivery.IdPublication = Publications.Id
            join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id)
                      on Delivery.IdSubscriber = Subscribers.Id;
go