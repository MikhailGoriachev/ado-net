﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
	public class Task3Controller
	{
		private List<Product> _products;
		private readonly int nProducts = 12;

		public Task3Controller()
		{
			_products = new();
			for (int i = 0; i < nProducts; i++)
				_products.Add(Product.Generate());
		}

		public void Show() => Show(_products, "Список товаров:");

		public static void Show(List<Product> products, string title = "")
		{
			Console.WriteLine($"\n  {title}\n");
			Console.Write(Product.Header());
			products.ForEach(x => Console.WriteLine(x.ToTableRow()));
			Console.Write(Product.Footer());
		}

		// Товары с заданным диапазоном цен
		public List<Product> Query01Ext(int lo, int hi) =>
			_products.Where(p => p.Price >= lo && p.Price <= hi).ToList();

		public List<Product> Query01Linq(int lo, int hi) => 
			(from p in _products
				where p.Price >= lo && p.Price <= hi
				select p).ToList();

		// Сумма товаров с заданным годом выпуска
		public int Query02Ext(int year) =>
			_products.Where(p => p.YearMade == year).Sum(p => p.Price * p.Amount);

		public int Query02Linq(int year) =>
			(from p in _products
				where p.YearMade == year
				select p.Price * p.Amount).Sum();

		// Сумма товаров с заданным наименованием
		public int Query03Ext(string name) =>
			_products.Where(p => p.Name.Contains(name)).Sum(p => p.Price * p.Amount);

		public int Query03Linq(string name) =>
			(from p in _products
				where p.Name.Contains(name)
			 select p.Price * p.Amount).Sum();

		// Наименование и год выпуска товаров с максимальным количеством
		public void Query04Ext()
		{
			int max = _products.Max(p => p.Amount);
			var result = 
				_products.Where(p => p.Amount == max)
					.Select(p => new {p.Name, p.YearMade})
					.ToList();

			result.ForEach(p => Console.WriteLine($"  {p}"));
		}

		public void Query04Linq()
		{
			int max = _products.Max(p => p.Amount);
			var result =
				(from p in _products
				where p.Amount == max
				select new {p.Name, p.YearMade})
				.ToList();

			result.ForEach(p => Console.WriteLine($"  {p}"));
		}

		// Товары, для которых произведение цены на количество находится в заданном диапазоне
		public List<Product> Query05Ext(int lo, int hi) =>
			_products.Where(p => p.Sum >= lo && p.Sum <= hi)
				.ToList();

		public List<Product> Query05Linq(int lo, int hi) =>
			(from p in _products
			 where p.Sum >= lo && p.Sum <= hi
			 select p)
				.ToList();
	}
}
