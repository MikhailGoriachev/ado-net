﻿using System;
using System.Collections.Generic;
using System.Linq;
using Main.Utilities;
using Main.Utilities.Menu;
using Palette = Main.Utilities.Palette;


namespace Main.Controllers
{
	public sealed class Task2Controller : MenuWrapper
	{
		private static readonly Func<double> ValueProvider = () => General.Rand.RealNextDouble(-10, 10);
		private static readonly double Tolerance = 0.5;
		private ICollection<double> _values;


		public Task2Controller() =>
			Menu = new("Вторая задача", new[]
			{
				new MenuItem("Вычисление количества элементов массива, со значениями в диапазоне от A до B", SelectBetween),
				new MenuItem("Вычисление количества элементов массива, равных 0", SelectZeros),
				new MenuItem("Вычисление суммы элементов массива, расположенных после первого максимального элемента", SumAfterFirstMax),
				new MenuItem("Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом",
					SumBeforeLastAbsMin)
			});


		private void ShowItems(Action<double, int>? color = null, int valuesPerRow = 6, int width = 12)
		{
			int itemsInRow = 0;
			int currentIndex = 0;

			foreach (var value in _values)
			{
				color?.Invoke(value, currentIndex);
				Console.Write($"{value:f1}".Center(12));
				Palette.Default.AsCurrent();

				if (++itemsInRow == valuesPerRow)
				{
					Console.WriteLine();
					itemsInRow = 0;
				}

				currentIndex++;
			}
		}


		private void CreateItems()
		{
			var size = General.Rand.Next(12, 28);

			_values = new List<double>().Fill(ValueProvider, size);
		}


		/// Вычисление количества элементов массива, со значениями в диапазоне от A до B
		private void SelectBetween()
		{
			CreateItems();
			ShowItems();
			Console.WriteLine("\n\n");

			var range = Range<double>.CreateWithRandom(ValueProvider);
			
			var inRangeCount = _values.Count(range.IsInRangeInclusive);
			Console.WriteLine($"Числа в диапазоне {range:f}, их количество: {inRangeCount}\n\n");

			ShowItems((d, _) =>
			{
				if (range.IsInRangeInclusive(d))
					Palette.Accent.AsCurrent();
			});
		}


		/// Вычисление количества элементов массива, равных 0
		private void SelectZeros()
		{
			CreateItems();
			ShowItems();
			Console.WriteLine("\n\n");

			var inRangeCount = _values.Count(d => d.Equals(0, Tolerance));
			Console.WriteLine($"Количество: {inRangeCount}, погрешность: {Tolerance}\n\n");

			ShowItems((d, _) =>
			{
				if (d.Equals(0, Tolerance))
					Palette.Accent.AsCurrent();
			});
		}


		/// Вычисление суммы элементов массива, расположенных после первого максимального элемента
		private void SumAfterFirstMax()
		{
			CreateItems();
			ShowItems();
			Console.WriteLine("\n\n");

			var (max, maxIndex) = _values
								  .Select((d, i) => (d, i))
								  .OrderByDescending(tuple => tuple.d)
								  .ThenBy(tuple => tuple.i)
								  .First();

			var sumAfter = _values
						   .SkipWhile((_, i) => i <= maxIndex)
						   .Sum();

			Console.WriteLine($"Первый максимальный: {max}, Сумма: {sumAfter}\n\n");

			ShowItems((_, i) =>
			{
				if (i == maxIndex)
					Palette.Accent.AsCurrent();
			});
		}


		/// Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом
		private void SumBeforeLastAbsMin()
		{
			CreateItems();
			ShowItems();
			Console.WriteLine("\n\n");

			var (min, minIndex) = _values
								  .Select((d, i) => (d, i))
								  .OrderBy(tuple => Math.Abs(tuple.d))
								  .ThenByDescending(tuple => tuple.i)
								  .First();

			var sumAfter = _values
						   .TakeWhile((_, i) => i < minIndex)
						   .Sum();

			Console.WriteLine($"Последний минимальный по модулю: {min}, Сумма: {sumAfter}\n\n");

			ShowItems((_, i) =>
			{
				if (i == minIndex)
					Palette.Accent.AsCurrent();
			});
		}
	}
}