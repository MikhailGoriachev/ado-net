﻿using System;
using Realestate.Controllers;

namespace Realestate.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        Task1Controller _task1Controller;
        Task2Controller _task2Controller;


        // конструктор с внедрением зависимостей
        public App(string connectingStringTask1, string connectingStringTask2) {
            _task1Controller = new Task1Controller(connectingStringTask1);
            _task2Controller = new Task2Controller(connectingStringTask2);
        } // App

    } // class App
}