﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketTrain_WPF_first.Utils
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        // объект для получения случайных чисел
        public static Random Random = new Random();

        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo) * Random.NextDouble();


        public static bool GetRandomState()
            => GetRandom(1, 100) % 2 == 0;

        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static int GetRandom(int lo, int hi)
            => Random.Next(lo, hi);

        // формирование случайных целых чисел в заданном диапазоне (lo, hi),
        // исключая указанное параметром exclude число
        public static int GetRandomExclude(int lo, int hi, int exclude)
        {
            int number = 0;
            do
                number = Random.Next(lo, hi);
            while (number == exclude);

            return number;
        } // GetRandomExclude

        // вспомогательный словарь для генерации случайного  типа вагона
        public static Dictionary<string, int> types = new Dictionary<string, int>{
            { "СВ", 2 },
            {"Купе", 4 },
            {"Плацкарт", 6 }
        };


    } // class Utils

}
