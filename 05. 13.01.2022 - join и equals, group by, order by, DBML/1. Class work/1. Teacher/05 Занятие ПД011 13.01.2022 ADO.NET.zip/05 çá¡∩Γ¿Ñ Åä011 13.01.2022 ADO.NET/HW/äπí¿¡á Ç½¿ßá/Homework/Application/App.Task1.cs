﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;

namespace Homework.Application
{
    /* 
    * Методы для решения задачи 3
    */
    internal partial class App {

        // Демонстрация работы расширяющего метода 
        public void ExecShowPercent() {
            Utils.ShowNavBarTask("    Демонстрация работы расширяющего метода");

            _goodsController.ShowPercent("Коллекция товаров:");
        } // ExecShowPercent

    } // App
}
