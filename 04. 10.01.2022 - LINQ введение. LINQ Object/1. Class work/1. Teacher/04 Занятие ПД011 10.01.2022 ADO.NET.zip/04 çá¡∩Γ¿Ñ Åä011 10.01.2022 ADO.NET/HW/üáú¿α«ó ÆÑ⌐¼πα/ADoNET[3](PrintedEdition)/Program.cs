﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;   // добавить сборку System.Configuration.dll

using ADoNET_3__PrintedEdition_.Application;
using ADoNET_3__PrintedEdition_.Helpers;

namespace ADoNET_3__PrintedEdition_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 10.01.2022";

            Console.SetWindowSize(150, 30);
            // строка подключения к БД - взята из свойств базы данных
            // Обозреватель серверов -> Свойства -> Строка подключения
            string connectingString = ConfigurationManager.ConnectionStrings["PeriodicalsConnectionSQLServer"].ConnectionString;


            // простейшее меню приложения
            List<MenuItem> menu = new List<MenuItem>(new[]{
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Запрос 1. Издания заданного типа, стоимость которых меньше заданной" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Запрос 2. Подписчики подписанные на издание с заданным наименованием живущие на заданной улице и номере дома" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Запрос 3. Издания, цена которых находится в заданном диапозоне" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Запрос 4. Подписчики подписанные на издания с заданным типом" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Запрос 5. Оформленные подписки, срок подписки которых входит в заданный диапозон" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Запрос 6. Стоимость каждой подписки с доставкой и без НДС. Сортировка по Индексу издания" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Запрос 7. Максимальная, средняя, минимальная цена для каждого типа издания. Группировка по Виду издания" },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Запрос 8. Количество подписчиков проживающих на каждой улице" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Запрос 9. Количество оформленных подписок для каждого издания" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Шифрование конфигурационного файла" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Расшифровывание конфигурационного файла" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            });

            // Создание экземпляра класса приложения
            App app = new App(connectingString);

            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 23.12.2021 - выполнение запросв в подключенном режиме");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {

                        // Запрос 1. Издания заданного типа, стоимость которых меньше заданной
                        case ConsoleKey.Q:
                            app.ExecQuery1();
                            break;

                        // Запрос 2. Подписчики подписанные на издание с заданным наименованием живущие на заданной улице и номере дома
                        case ConsoleKey.W:
                            app.ExecQuery2();
                            break;

                        // Запрос 3. Издания, цена которых находится в заданном диапозоне
                        case ConsoleKey.E:
                            app.ExecQuery3();
                            break;
                 
                        // Запрос 4. Подписчики подписанные на издания с заданным типом
                        case ConsoleKey.R:
                            app.ExecQuery4();
                            break;

                        // Запрос 5. Оформленные подписки, срок подписки которых входит в заданный диапозон
                        case ConsoleKey.T:
                            app.ExecQuery5();
                            break;

                        // Запрос 6. Стоимость каждой подписки с доставкой и без НДС. Сортировка по Индексу издания
                        case ConsoleKey.Y:
                            app.ExecQuery6();
                            break;

                        // Запрос 7. Максимальная, средняя, минимальная цена для каждого типа издания. Группировка по Виду издания
                        case ConsoleKey.U:
                            app.ExecQuery7();
                            break;

                        // Запрос 8. Количество подписчиков проживающих на каждой улице
                        case ConsoleKey.I:
                            app.ExecQuery8();
                            break;

                        // Запрос 9. Количество оформленных подписок для каждого издания
                        case ConsoleKey.O:
                            app.ExecQuery9();
                            break;

                        // Шифрование конфигурационного файла
                        case ConsoleKey.A:
                            app.ConfigurationEncryption();
                            break;

                        // Расшифровывание конфигурационного файла
                        case ConsoleKey.F:
                            app.ConfigurationDecryption();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex)
                {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, $"                                                                                        ", ConsoleColor.White);
                    Utils.WriteXY(20, 10, $"  ┌──────────────────────────────────────────────────────────────────────────────────┐  ", ConsoleColor.White);
                    Utils.WriteXY(20, 11, $"  │                                   Исключение.                                    │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  │ {ex.Message,-79}  │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 13, $"  │                                                                                  │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 14, $"  └──────────────────────────────────────────────────────────────────────────────────┘  ", ConsoleColor.White);
                    Utils.WriteXY(20, 15, $"                                                                                        ", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally
                {
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while


        }
    }
}