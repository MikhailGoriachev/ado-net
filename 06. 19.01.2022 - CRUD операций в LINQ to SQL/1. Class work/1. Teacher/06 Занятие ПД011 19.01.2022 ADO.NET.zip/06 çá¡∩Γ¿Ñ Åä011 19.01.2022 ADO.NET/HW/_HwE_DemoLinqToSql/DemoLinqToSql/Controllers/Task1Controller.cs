﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoLinqToSql.Helpers;
using DemoLinqToSql.Models;
using DemoLinqToSql.Models.Task1;

/*
 * Задача 1.
 * Даны две связанные коллекции – описание книг и авторов книг. Объект класса
 * Книга имеет следующие поля: идентификатор, идентификатор автора, название
 * книги, год издания, цена. Поля объекта класса Автор: идентификатор, фамилия
 * и инициалы, год рождения. Требуется реализовать запросы к коллекциям,
 * использовать два варианта – синтаксис запросов и синтаксис расширяющих
 * функций.  
 *     o Вывести все книги коллекции, выводить фамилии и инициалы автора
 *     o Вывести книги авторов, год рождения которых принадлежит заданном
 *       диапазону 
 *     o Вывести книги, в названии которых содержится заданная подстрока
 *       и цена не превышает заданного значения
 *     o Список авторов и количество их книг в коллекции
 *     o Средняя цена книг по годам издания
 *     o Список авторов по убыванию количества их книг в коллекции 
 *     o Средний возраст книг по авторам, выводить список с упорядочиванием
 *       фамилий и инициалов авторов по алфавиту
 */

namespace DemoLinqToSql.Controllers
{
    public class Task1Controller
    {
        // коллекции по задания
        private List<Author> _authors;
        private List<Book>   _books;
        

        public Task1Controller():this(Utils.GetAuthorsList(), Utils.GetBooksList()) {}

        public Task1Controller(List<Author> authors, List<Book> books) {
            _authors = authors;
            _books = books;
        } // Task1Controller


        // сформировать коллекцию с данными и книгах с расшифровкой поля автора 
        public List<BookViewModel> GetAllBooks() => _books
            .Join(_authors, b => b.IdAuthor, a=> a.Id, 
                (b, a) => new BookViewModel{
                    Id = b.Id, Author = a.FullName, 
                    Title = b.Title, PubYear = b.PubYear, Price = b.Price})
            .ToList();

        public void ShowAllBooks() =>
            ShowBooks("\n\n\n\n\tВсе книги коллекции с расшифровкой автора", GetAllBooks());

        // вывод коллекции книг с расшифровкой поля 
        public void ShowBooks(string capture, List<BookViewModel> listBookViewModels) {
            Console.WriteLine($"{capture}\n{BookViewModel.Header}");

            listBookViewModels.ForEach(b => Console.WriteLine($"\t{b.ToTableRow()}"));

            Console.WriteLine(BookViewModel.Footer);
        } // ShowBooks

    } // class Task1Controller
}
