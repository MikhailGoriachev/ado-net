﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TicketTrain_WPF_first.Controller;
using TicketTrain_WPF_first.Models;
using TicketTrain_WPF_first.Utils;
using TicketTrain_WPF_first.ViewModels;
using TicketTrain_WPF_first.Views;

namespace TicketTrain_WPF_first
{
    public partial class Form1 : Form
    {

        // поезд
        private TrainControl _trainControl;



        public Form1()
        {
            InitializeComponent();
            _trainControl = new TrainControl();


            DirectoryInfo dirInfo = new DirectoryInfo(_trainControl._serialiseDefaultPath);
            if (dirInfo.Exists)
            {
                _trainControl.DeserializeData(_trainControl.GetFileName());
            }

            BindToForm();
        }

        // пересобрать поезд
        private void recreateTrain(object sender, EventArgs e)
        {
            _trainControl = new TrainControl();

            BindToForm();
        }

        // привязка
        private void BindToForm()
        {
            // сформировать данные в TreeView
            FillTreeView(_trainControl.GetAll(), tvr_train);

            // загрузить данные вагона № 1 в DataGrid
            bns_view_trainticket.DataSource = _trainControl.SelectWhereNumber(1);
            Dgw_trainTicket.DataSource = bns_view_trainticket;
            tvr_train.Nodes[0].Expand();
            CheckAndSerialize();

            tss_lbl_infoAllWagonTrain.Text = _trainControl.AllWagonsCount.ToString();
            tss_lbl_infoAllSeatsTrain.Text = _trainControl.AllSeatCount().ToString() + "/" + _trainControl.AllSaleSeatCount().ToString();
            tss_pgb_seats.Maximum = _trainControl.AllSeatCount();
            tss_pgb_seats.Value = _trainControl.AllSaleSeatCount();
            label1.Text = "Поезд № " + _trainControl.Train.Number;

        }


        // сохранение и проверка директории
        private void CheckAndSerialize()
        {
            DirectoryInfo dirInfo = new DirectoryInfo(_trainControl._serialiseDefaultPath);
            if (!dirInfo.Exists)
            {
                dirInfo.Create();
            }
            _trainControl.SerializeData(_trainControl.GetFileName());


        } // 

        // сериализация в формате JSON
        private void Save_command(object sender, EventArgs e)
        {
            // вызов диалога сохранения файла

            Sfd_main.Title = "Сохранение результатов";
            Sfd_main.InitialDirectory = "..\\..\\";
            Sfd_main.Filter = "Файлы JSON(*.json)|*.json";
            Sfd_main.FilterIndex = 1;

            if (Sfd_main.ShowDialog() == DialogResult.OK)
            {
                _trainControl.SerializeData(Sfd_main.FileName);
            } // if

            // обновить привязку
            BindToForm();
        }

        // десериализация из формата JSON
        private void Open_command(object sender, EventArgs e)
        {
            // вызов диалога сохранения файла

            Ofd_main.Title = "Открыть ";
            Ofd_main.InitialDirectory = "../../";
            Ofd_main.Filter = "Файлы JSON(*.json)|*.json";
            Ofd_main.FilterIndex = 1;

            _trainControl.Clear();
            if (Ofd_main.ShowDialog() == DialogResult.OK)
            {
                _trainControl.DeserializeData(Ofd_main.FileName);
            } // if

            // обновить привязку
            BindToForm();

        }

        // заполнение элемента TreeView
        private void FillTreeView(List<TrainCar> wagons, TreeView treeView)
        {
            treeView.Nodes.Clear();

            // Корнем дерева является номер поезда

            var nodeTrain = new TreeNode("Поезд № " + _trainControl.Train.Number, 1, 1);
            nodeTrain.Tag = _trainControl.Train;
            treeView.Nodes.Add(nodeTrain);


            foreach (var wagon in wagons)
            {
                var nodeWagon = new TreeNode("Вагон № " + wagon.NumbTrainCar.ToString() + " " + "\'" + wagon.TypeTrainCar + "\'", 0, 0);
                nodeWagon.Tag = wagon;
                treeView.Nodes[0].Nodes.Add(nodeWagon);

                foreach (var compartment in wagon.Compartments)
                {
                    var nodeCoupe = new TreeNode("Купе № " + compartment.Numb.ToString());
                    nodeCoupe.Tag = compartment;
                    treeView.Nodes[0].LastNode.Nodes.Add(nodeCoupe);

                    foreach (var seat in compartment.Seats)
                    {
                        //treeView.Nodes[0].LastNode.LastNode.Nodes.Add(seat.Number.ToString());

                        var nodeSeat = new TreeNode("Место № " + seat.Number.ToString());
                        nodeSeat.Tag = seat;
                        treeView.Nodes[0].LastNode.LastNode.Nodes.Add(nodeSeat);
                    }

                }
            }

            //treeView.ExpandAll();
        } // FillTreeView

        // форматирование ячеек строки
        private void DgvCarriageView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // получить ссылку на коллекцию данных в блоке привязки
            List<TrainTicket> carriageViews = bns_view_trainticket.DataSource as List<TrainTicket>;

            switch (e.ColumnIndex)
            {
                // форматирвоание ячеек с номером вагона, номером места
                case 0:
                case 3:
                    e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    break;

                // форматирование ячейки с номером купе 
                case 2:
                    // e.Value = Utils.ToRoman(carriageViews[e.RowIndex].CompartmentNumber);
                    e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    break;

                // форматирование ячейки состояния места с учетом чередования строк
                case 4:



                    e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    break;
            } // switch
        } // DgvCarriageView_CellFormatting


        // выбор вагона
        private void selected_wagon(object sender, TreeViewEventArgs e)
        {

            if (e.Node.Level == 0)
                return;


            switch (e.Node.Level)
            {
                // поезд
                case 0:
                    return;

                // вагон
                case 1:

                    TrainCar a = (TrainCar)e.Node.Tag;

                    bns_view_trainticket.DataSource = _trainControl.SelectWhereNumber(a.NumbTrainCar);
                    Dgw_trainTicket.DataSource = bns_view_trainticket;

                    label1.Text = "Вагон № " + a.NumbTrainCar + ", тип вагона : " + a.TypeTrainCar + ", количество мест : " + a.GetSeatCount() + ", количестов проданых мест : " + a.GetSaleSeatCount();


                    break;


                default:
                    break;
            }



        }

        // добавить вагон
        private void AddWagon_command(object sender, EventArgs e)
        {
            AddWagonForm editform = new AddWagonForm();
            //_trainControl.AllWagonsCount

            if (editform.ShowDialog() != DialogResult.OK) return;

            _trainControl.AddWagon(editform.GetNewWagonType);

            BindToForm();


        }

        // удалить вагон
        private void Delete_Wagon_command(object sender, EventArgs e)
        {
            _trainControl.DeleteWagon((int)Dgw_trainTicket.Rows[0].Cells[0].Value);

            BindToForm();

        }

        //сортировка вагонов по убыванию количества проданных мест и перестройка дерева
        private void SortBySaleSeatDeck_command(object sender, EventArgs e)
        {
            _trainControl.OrederBySaleSeatsDecs();
            FillTreeView(_trainControl.Train.Wagons, tvr_train);
           

        }

        //сортировка поезда по возрастанию номеров вагонов и перестройка дерева
        private void SortByNumbWagon_command(object sender, EventArgs e)
        {
            _trainControl.OrederByNumbWagon();
            FillTreeView(_trainControl.Train.Wagons, tvr_train);


        }

        //•	сортировка поезда по убыванию номеров вагонов и перестройка дерева
        private void SortByNumbWagonDecs_command(object sender, EventArgs e)
        {
            _trainControl.OrederByNumbWagonDecs();
            FillTreeView(_trainControl.Train.Wagons, tvr_train);


        }

        // продажа места
        private void SaleSeat_command(object sender, EventArgs e)
        {
            if (Dgw_trainTicket.SelectedRows.Count <= 0) return;
            _trainControl.GetTicket(Convert.ToInt32(Dgw_trainTicket.SelectedRows[0].Cells[0].Value), Convert.ToInt32(Dgw_trainTicket.SelectedRows[0].Cells[3].Value));
            CheckAndSerialize();


            bns_view_trainticket.DataSource = _trainControl.SelectWhereNumber(Convert.ToInt32(Dgw_trainTicket.SelectedRows[0].Cells[0].Value));
            Dgw_trainTicket.DataSource = bns_view_trainticket;

        }

    }
}
