﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LINQIntro.Controllers;
using LINQIntro.Models;

namespace LINQIntro.App_Data
{
    public partial class App
    {
        private static Controller _controller;

        public static List<Product> List = new List<Product>()
        {
            new Product {Name = "Альбом для рисования", Price = 15, Number = 2000, YearOfManufacture = 2019},
            new Product {Name = "Картон", Price = 14, Number = 1000, YearOfManufacture = 2018},
            new Product {Name = "Кисть для рисования", Price = 20, Number = 600, YearOfManufacture = 2020},
            new Product {Name = "Клей карандаш", Price = 15, Number = 500, YearOfManufacture = 2021},
            new Product {Name = "Краски акварель", Price = 40, Number = 400, YearOfManufacture = 2022},
            new Product {Name = "Карандаш чернографический", Price = 8, Number = 600, YearOfManufacture = 2021},
            new Product {Name = "Пластилин", Price = 25, Number = 600, YearOfManufacture = 2021},
            new Product {Name = "Фломастеры", Price = 30, Number = 600, YearOfManufacture = 2020},
            new Product {Name = "Цветная бумага", Price = 15, Number = 1500, YearOfManufacture = 2020},
            new Product {Name = "Краски гуашь", Price = 50, Number = 200, YearOfManufacture = 2010},
            new Product {Name = "Ножницы", Price = 30, Number = 600, YearOfManufacture = 2016},
            new Product {Name = "Мелки восковые", Price = 20, Number = 600, YearOfManufacture = 2017}
        };



    }
}
