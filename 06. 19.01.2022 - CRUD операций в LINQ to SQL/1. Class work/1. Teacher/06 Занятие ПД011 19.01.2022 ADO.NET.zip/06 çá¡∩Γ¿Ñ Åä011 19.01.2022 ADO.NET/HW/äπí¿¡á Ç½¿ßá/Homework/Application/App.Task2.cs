﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;

namespace Homework.Application
{
    /* 
    * Методы для решения задачи 2
    */
    internal partial class App {

        // Информация о товарах, единица измерения которых «шт» (штуки) и цена закупки меньше 200 руб
        public void GoodsWhereUnit() {
            Utils.ShowNavBarTask("    Информация о товарах, единица измерения которых «шт» (штуки) и цена закупки меньше 200 руб.");

            _task2Controller.Query01A();
            _task2Controller.Query01B();
        } // GoodsWhereUnit

        // Информация о товарах, цена закупки которых больше 500 руб
        public void GoodsWherePrice() {
            Utils.ShowNavBarTask("    Информация о товарах, цена закупки которых больше 500 руб.");

            _task2Controller.Query02A();
            _task2Controller.Query02B();
        } // GoodsWherePrice

        // Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1800 руб
        public void GoodsWhereName() {
            Utils.ShowNavBarTask("    Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1800 руб");

            string good = "чехол защитный";

            Console.WriteLine($"\n\tЗаданное наименование: {good}");

            _task2Controller.Query03A(good);
            _task2Controller.Query03B(good);
        } // GoodsWhereName

        // Информация о продавцах с заданным значением процента комиссионных.
        public void SellerssWhereInterest() {
            Utils.ShowNavBarTask("    Информация о продавцах с заданным значением процента комиссионных.");

            double interest = 10d;

            Console.WriteLine($"\n\tЗаданное значение: {interest}");

            _task2Controller.Query04A(interest);
            _task2Controller.Query04B(interest);
        } // SellerssWhereInterest

        // Информация о фактах продажи, для которых цена продажи в заданном диапазоне
        public void SalesWherePriceInRange() {
            Utils.ShowNavBarTask("    Информация о фактах продажи, для которых цена продажи в заданном диапазоне.");

            int lo = Utils.Random.Next(500, 1000), hi = Utils.Random.Next(lo + 500, 3000);

            Console.WriteLine($"\n\tДиапазон: от {lo} до {hi}");

            _task2Controller.Query05A(lo, hi);
            _task2Controller.Query05B(lo, hi);
        } // SellerssWhereInterest

        // Вычислить прибыль от продажи за каждый проданный товар
        public void SalesProfit() {
            Utils.ShowNavBarTask("    Вычислить прибыль от продажи за каждый проданный товар.");

            _task2Controller.Query06A();
            _task2Controller.Query06B();
        } // SalesProfit

    } // App
}
