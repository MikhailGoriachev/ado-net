﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
    // 
    internal class QueryViewModel {
        // идентификатор
        public int Id { get; set; } // Id

        // фамилия и инициалы продавца/наименование товара
        public string Title { get; set; } // Title

        // сумма количество продаж
        public int SalesAmount{ get; set; } // SalesAmount

        // сумма продаж
        public int SalesTotal{ get; set; } // SalesTotal

    }
}
