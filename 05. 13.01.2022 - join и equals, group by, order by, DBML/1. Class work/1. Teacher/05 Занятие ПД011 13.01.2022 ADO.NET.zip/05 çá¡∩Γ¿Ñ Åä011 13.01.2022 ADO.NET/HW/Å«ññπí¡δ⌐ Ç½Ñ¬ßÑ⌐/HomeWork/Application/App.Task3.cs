﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Application
{
    public partial class App
    {
        // Демонстрация товаров с заданным диапазоном цен
        public void DemoTask3Query1()
        {

            double lo = Utils.GetRandom(10, 50) * 100;
            double hi = lo + Utils.GetRandom(0d, 100d) * 100;


            _task3Controller.Task1(lo, hi);


        }

        // Демонстрация суммы товаров с заданным годом выпуска
        public void DemoTask3Query2()
        {
            int year = Utils.GetRandom(2008, DateTime.Now.Year);
            _task3Controller.Task2(year);

        }


        // Демонстрация суммы товаров с заданным наименованием 
        public void DemoTask3Query3()
        {
            string name = _task3Controller.ListGoods[Utils.GetRandom(0, _task3Controller.ListGoods.Count)].Name;
            _task3Controller.Task3(name);

        }

        // Демонстрация наименование и год выпуска товаров с максимальным количеством
        public void DemoTask3Query4()
        {
            
            _task3Controller.Task4();

        }

        // Все товары, для которых произведение цены на количество находится в заданном диапазоне
        public void DemoTask3Query5()
        {

            _task3Controller.Task5(100000d, 300000d);

        }

    }
}
