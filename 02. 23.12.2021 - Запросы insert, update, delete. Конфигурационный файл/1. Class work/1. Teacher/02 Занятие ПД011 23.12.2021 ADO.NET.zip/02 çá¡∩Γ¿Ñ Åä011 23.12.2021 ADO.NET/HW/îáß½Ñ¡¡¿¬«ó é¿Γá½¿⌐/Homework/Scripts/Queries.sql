﻿-- База данных «Учет сделок с недвижимостью»

-- Вывод всех таблиц с рашифровкой полей связанных таблиц
select
    *
from
    Streets;
go


select
    *
from
    Persons;
go


-- таблица владельцев
select
    Owners.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Owners.Passport
from
    Owners join Persons on Owners.IdPerson = Persons.Id;
go


-- таблица риелторов
select
    Realtors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Realtors.[Percent]
from
    Realtors join Persons on Realtors.IdPerson = Persons.Id;
go


select
    Apartments.Id
    , Streets.Street
    , Apartments.Building
    , Apartments.Flat
    , Apartments.Area
    , Apartments.RoomNum
from
    Apartments join Streets on Apartments.IdStreet = Streets.Id;
go


-- предложения квартир

-- сделки

-- Выполнение запросов по заданию

-- Запрос  1. Запрос с параметрами	
-- Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, 
-- расположенных на улице «Садовая». Значения задавать параметрами запроса
declare @roomNum int = 3, @street nvarchar(30) =  N'ул. Садовая';

select
    Apartments.Id
    , Streets.Street
    , Apartments.Building
    , Apartments.Flat
    , Apartments.Area
    , Apartments.RoomNum
from
    Apartments join Streets on Apartments.IdStreet = Streets.Id
where
    Apartments.RoomNum = @roomNum and Streets.Street = @street;
go


-- Запрос  2. Запрос с параметрами	
-- Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах, фамилия которых 
-- начинается с буквы «И» и процент вознаграждения больше 10%. 
-- Значения задавать параметрами запроса
declare @surname nvarchar(60) =  N'И', @percent float = 10;

select
    Realtors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Realtors.[Percent]
from
    Realtors join Persons on Realtors.IdPerson = Persons.Id
where
    Persons.Surname like (@surname + N'%') and Realtors.[Percent] > @percent;
go


-- Запрос  3. Запрос с параметрами	
-- Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах, цена на
-- которые находится в диапазоне от 900 000 руб. до 1000 000 руб. 
-- Значения задавать параметрами запроса
declare @roomNum int = 1, @lo int =  900000, @hi int = 1000000;

select
    Apartments.Id
    , Streets.Street
    , Apartments.Building
    , Apartments.Flat
    , Apartments.Area
    , Apartments.RoomNum
    , Offers.Price
from
    Apartments join Streets on Apartments.IdStreet = Streets.Id
               join Offers on Apartments.Id = Offers.IdApartment
where
    Apartments.RoomNum = @roomNum and Offers.Price between @lo and @hi;
go


-- Запрос  4. Запрос с параметрами	
-- Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом комнат
-- Значения задавать параметрами запроса
declare @roomNum int = 1;

select
    Apartments.Id
    , Streets.Street
    , Apartments.Building
    , Apartments.Flat
    , Apartments.Area
    , Apartments.RoomNum
    , Offers.Price
from
    Apartments join Streets on Apartments.IdStreet = Streets.Id
               join Offers on Apartments.Id = Offers.IdApartment
where
    Apartments.RoomNum = @roomNum;
go


-- Запрос  5. Запрос с параметрами	
-- Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах, 
-- площадь которых есть значение из некоторого диапазона. 
-- Значения задавать параметрами запроса
declare @roomNum int = 2, @lo int = 80, @hi int = 120;

select
    Apartments.Id
    , Streets.Street
    , Apartments.Building
    , Apartments.Flat
    , Apartments.Area
    , Apartments.RoomNum
    , Offers.Price
from
    Apartments join Streets on Apartments.IdStreet = Streets.Id
               join Offers on Apartments.Id = Offers.IdApartment
where
    Apartments.RoomNum = @roomNum and Apartments.Area between @lo and @hi;
go


-- Запрос  6. Запрос с вычисляемыми полями	
-- Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения
-- риэлтора. Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, 
-- Дата сделки, Цена квартиры, Комиссионные. Сортировка по полю Дата сделки
select
    Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    , Deals.DealDate
    , Deals.DealPrice
    , Realtors.[Percent]
    , Deals.DealPrice * Realtors.[Percent] / 100 as Fee
from
    Deals join (Realtors join Persons on Realtors.IdPerson = Persons.Id) 
        on Deals.IdRealtor = Realtors.Id;
go


-- Запрос  7. Запрос на левое соединение	
-- Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму
-- сделок риэлтора. Упорядочить выборку по убыванию суммы сделок.
select
    -- данные риелтора - группа
    Realtors.Id
    , Persons.Surname
    , Persons.[Name]
    , Persons.Patronymic
    -- агрегатные функции
    , Count(Deals.IdOffer) as ClientTotal -- упрощение Deals.IdOffer это клиент
    , isnull(Sum(Deals.DealPrice), N'') as RealtorSum
from
    (Realtors join Persons on Realtors.IdPerson = Persons.Id)
        left join 
    Deals on Realtors.Id = Deals.IdRealtor
group by
    Realtors.Id, Persons.Surname, Persons.[Name], Persons.Patronymic;
go


-- Запрос  8. Запрос на левое соединение	
-- Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы 
-- сделки
select
    Streets.Street
    , Sum(Deals.DealPrice) as SumDeals
from
    Streets left join (Apartments join (Offers join Deals on Offers.Id = Deals.IdOffer) on Apartments.Id = Offers.IdApartment) 
        on Streets.Id = Apartments.IdStreet
group by
    Streets.Street;
go

-- Запрос  9. Запрос на левое соединение	
-- Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку 
-- по убыванию суммы сделки. Диапазон задавать параметрами запроса 
declare @from date = '10-01-2021', @to date = '10-31-2021';
select
    Streets.Street
    , COUNT(PeriodDeals.DealPrice) as Amount
    , SUM(PeriodDeals.DealPrice) as Total
from
    Streets left join 
        -- данные по сделкам за период извлекаем при помощи подзапроса, требуется назначить 
        -- псевдоним этому подзапросу
        (select Deals.DealDate, Deals.DealPrice, Apartments.IdStreet from (Deals join (Offers join Apartments on Offers.IdApartment = Apartments.Id) on Deals.IdOffer = Offers.Id)  
         where Deals.DealDate between @from and @to) PeriodDeals
    on Streets.Id = PeriodDeals.IdStreet
group by
    Streets.Street
order by
    Total desc;
go 


---- Запрос 10. Итоговый запрос	
---- Выполняет группировку по полю Количество комнат. Для каждой группы вычисляет
---- среднее значение по полю Цена квартиры
--select
--    Apartments.RoomNum
--    , Count(*) as TotalApartment
--    , Avg(Offers.Price) as AvgPrice
--from
--    Offers join Apartments on Offers.IdApartment = Apartments.Id
--group by
--    Apartments.RoomNum;
--go


---- Запрос 11. Итоговый запрос	
---- Выполняет группировку по полю Площадь квартиры. Для каждой группы вычисляет 
---- наибольшее и наименьшее значение по полю Цена квартиры
--select
--    Apartments.Area
--    , Count(*) as TotalApartment
--    , Min(Offers.Price) as MinPrice
--    , Max(Offers.Price) as MaxPrice
--from
--    Offers join Apartments on Offers.IdApartment = Apartments.Id
--group by
--    Apartments.Area;
--go


---- Запрос 12. Запрос на создание базовой таблицы	
---- Создает таблицу КВАРТИРЫ_3_КОМН, содержащую информацию о 3-комнатных квартирах
--declare @roomNum int = 3;
--drop table if exists Room_3_Apartments;

---- создание таблицы по заданию
--select
--    *
--    into Room_3_Apartments
--from
--    Apartments
--where
--    RoomNum = @roomNum;

---- тестоый вывод созданной таблицы
--select * from Room_3_Apartments;
--go
    

---- Запрос 13. Запрос на создание базовой таблицы	
---- Создает копию таблицы КВАРТИРЫ с именем КОПИЯ_КВАРТИРЫ
--drop table if exists Copy_Apartments;

---- создание таблицы по заданию
--select
--    *
--    into Copy_Apartments
--from
--    Apartments;

---- тестоый вывод созданной таблицы
--select * from Copy_Apartments;
--go


---- Запрос 14. Запрос на удаление	
---- Удаляет из таблицы КОПИЯ_КВАРТИРЫ записи, в которых значение в поле 
---- Цена квартиры больше 3 000 000 руб.
--declare @price int = 3000000;
--select 
--    Copy_Apartments.Id
--    , Offers.Price
--from 
--    Copy_Apartments join Offers on Copy_Apartments.Id = Offers.IdApartment 
--where
--    Offers.Price > @price;

---- удаление записей по заданию
--delete from 
--    Copy_Apartments
--where
--    Copy_Apartments.Id in (select Offers.IdApartment from Offers where Price > @price);
    
--select 
--    Copy_Apartments.Id
--    , Offers.Price
--from 
--    Copy_Apartments join Offers on Copy_Apartments.Id = Offers.IdApartment 
--where
--    Offers.Price > @price;
--go

---- Запрос 15. Запрос на обновление	
---- Увеличивает значение в поле Цена квартиры таблицы КОПИЯ_КВАРТИРЫ 
---- на 10 процентов для 1-комнатных квартир
--declare @percent int = 10, @roomNum int = 1;
--drop table if exists Copy_Offers;
--select * into Copy_Offers from Offers;

--select 
--    Copy_Apartments.Id
--    , Copy_Apartments.RoomNum
--    , Copy_Offers.Price
--from 
--    Copy_Apartments join Copy_Offers on Copy_Apartments.Id = Copy_Offers.IdApartment 
--where
--    Copy_Apartments.RoomNum = @roomNum;

---- модификация записей по заданию
--update 
--    Copy_Offers
--set
--    Price *=  (100. + @percent) / 100.
--from
--    Copy_Offers
--where
--    IdApartment = any (select Id from Copy_Apartments where RoomNum = @roomNum);

--select 
--    Copy_Apartments.Id
--    , Copy_Apartments.RoomNum
--    , Copy_Offers.Price
--from 
--    Copy_Apartments join Copy_Offers on Copy_Apartments.Id = Copy_Offers.IdApartment 
--where
--    Copy_Apartments.RoomNum = @roomNum;
--go