﻿-----------------		Создание представления к таблицу "Факты проката" (Rentals)   -----------------

--		Удаление представления ViewRentals если оно еще не создано
drop view if exists ViewRentals;
go

--		Создание представления ViewRentals
create view ViewRentals as
	select top (select COUNT(*) from Rentals)
		Rentals.Id 
		,Clients.Surname + N' ' + SUBSTRING(Clients.[Name],1,1) + N'. ' + SUBSTRING(Clients.Patronymic,1,1) + N'.' as Client
		,Clients.Passport
		,Brands.Brand        as BrandModelCar
		,Colors.Color
		,Cars.Plate  
		,Cars.YearMount      as YearMountCar
		,Rentals.DateStart   as DateStartRental
		,Rentals.Duration    as DurationRental
		,Cars.Rental		 as OneDayPriceRental
		,Cars.Rental * Rentals.Duration as RentalsPrice
	from
		Rentals  join (Cars join Brands on Cars.IdBrand = Brands.Id
					    join Colors on Cars.IdColor = Colors.Id) 
			      on Cars.Id = Rentals.IdCar
		     join Clients on Rentals.IdClient =Clients.Id
	order by Client; 
go



 -----------------		Создание представления к таблицу "Машины" (Cars)   -----------------
--		Удаление представления ViewCars если оно еще не создано
drop view if exists ViewCars;
go

--		Создание представления ViewCars
create view ViewCars as
	select top(select COUNT(*) from Cars) 
		 Cars.Id
		,Brands.Brand   as BrandModel
		,Colors.Color
		,Cars.Plate
		,Cars.YearMount
		,Cars.InsurancePay
		,Cars.Rental
	from
		Cars join Brands on Cars.IdBrand =  Brands.Id
			 join Colors on Cars.IdColor =  Colors.Id
	order by BrandModel;
go


 
