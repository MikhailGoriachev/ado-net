﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Homework.Application;

namespace Homework
{
	class Program
	{

		static void Main(string[] args)
		{
			new Utilities.ColorSet{ Foreground = ConsoleColor.Green, Background = ConsoleColor.Black }
				.SetToConsole();

			App app = new App();
			app.Run();
		}

	}
}
