﻿-------------------------------------- Задача 3 --------------------------------------

/* База данных «Прокат автомобилей» */

-- 1. Запрос к представлению. Хранимая процедура
--    Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
drop proc if exists Query01;
go

create proc Query01
    @plate nvarchar(12)
as
begin 
    select
        Id
        , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
              Substring(ClientPatronymic, 1, 1) + N'.' as Client
        , BrandModel
        , Plate
        , DateStart
        , Duration
    from
        ViewHires
    where
        Plate = @plate;
end;
go

-- вызов функции
exec dbo.Query01 N'О169РК';
exec dbo.Query01 N'Т315РК';
exec dbo.Query01 N'Т306РК';


-- 2. Запрос к представлению. Хранимая процедура	
--    Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
drop proc if exists Query02;
go

create proc Query02
    @brandModel nvarchar(30)
as
begin
    select
        Id
        , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
              Substring(ClientPatronymic, 1, 1) + N'.' as Client
        , BrandModel
        , Plate
        , DateStart
        , Duration
    from
        ViewHires
    where
        BrandModel = @brandModel;
end;
go

-- выполнение
exec dbo.Query02 N'Volkswagen Polo';
go

exec dbo.Query02 N'Skoda Fabia New';
go

exec dbo.Query02 N'Toyota Camry';
go


-- 3. Запрос к представлению. Хранимая процедура
--    Выбирает информацию об автомобиле с заданным госномером
drop proc if exists Query03;
go

create proc Query03
    @plate nvarchar(12)
as
begin 
    select
        Id 
        , BrandModel
        , Color
        , Plate
        , YearManuf
        , InsurValue
        , Rental
    from
        ViewCars
    where
        Plate = @plate;
end;
go

-- вызов функции
exec dbo.Query03 N'О169РК';
exec dbo.Query03 N'Т315РК';
exec dbo.Query03 N'Т306РК';


-- 4. Запрос с параметром Хранимая процедура	
--    Выбирает информацию о клиентах по серии и номеру паспорта
drop proc if exists Query04;
go

create proc Query04
    @passport nvarchar(15)
as
begin
    select
        Id 
        , Surname
        , [Name]
        , Patronymic
        , Passport
    from
        Clients
    where
        Passport = @passport;
end;
go

-- выполнение
exec dbo.Query04 N'11 21 121212';
go

exec dbo.Query04 N'12 21 187651';
go

exec dbo.Query04 N'09 19 002129';
go


-- 5. Запрос к представлению. Хранимая процедура	
--    Выбирает информацию обо всех зафиксированных фактах проката автомобилей 
--    в некоторый заданный интервал времени.
drop proc if exists Query05;
go

create proc Query05
    @from date,
    @to date
as
begin
    select
        Id
        , ClientSurname + N' ' + Substring(ClientName, 1, 1) + N'.' + 
              Substring(ClientPatronymic, 1, 1) + N'.' as Client
        , BrandModel
        , Plate
        , DateStart
        , Duration
    from
        ViewHires
    where
        DateStart between @from and @to;
end;
go

-- выполнение
exec dbo.Query05 '10-01-2021', '10-31-2021';
go

exec dbo.Query05 '09-01-2021', '09-30-2021';
go

exec dbo.Query05 '11-01-2021', '11-30-2021';
go

-- 6. Запрос к представлению. Хранимая процедура	
--    Вычисляет для каждого факта проката стоимость проката. 
--    Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
--    Сортировка по полю Дата проката

drop proc if exists Query06;
go

create proc Query06
as
begin 
    select top (select COUNT(*) from ViewHires)
        Id
        , DateStart
        , Plate
        , BrandModel
        , Rental                  as RentalPerDay
        , Duration
        , Rental * Duration as Price 
    from
        ViewHires
    order by
        ViewHires.DateStart ;
end;
go

-- вызов функции
exec dbo.Query06;


-- 7. Запрос с левым соединением. Хранимая процедура 	
--    Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
--    суммарное количество дней проката, упорядочивание по убыванию суммарного количества дней проката

drop proc if exists Query07;
go

create proc Query07
as
begin
    select
        Clients.Id
        , Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
              Substring(Clients.Patronymic, 1, 1) + N'.' as ClientFullName
        , Count(Hires.IdCar) as Amount
        , IsNull(Sum(Duration), 0) as TotalDuration
    from
        Clients left join Hires on Clients.Id = Hires.IdClient
    group by
        Clients.Id, Clients.Surname, Clients.[Name], Clients.Patronymic
    order by
        TotalDuration desc;
end;
go

-- выполнение
exec dbo.Query07;


-- 8. Итоговый запрос. Хранимая процедура	
--    Выбирает информацию о фактах проката автомобилей по госномеру: 
--    количество фактов проката, сумма за прокаты, суммарная длительность прокатов
drop proc if exists Query08;
go

create proc Query08
    @plate nvarchar(12)
as
begin 
    select
        Plate
        , Count(Plate)           as Total
        , Sum(Rental * Duration) as TotalRental
        , Sum(Duration)          as TotalDuration
    from  
        ViewHires
    where
        Plate = @plate
    Group by
        Plate;
end;
go

-- вызов функции
exec dbo.Query08 N'О169РК';
exec dbo.Query08 N'Т315РК';
exec dbo.Query08 N'Т306РК';