﻿using System;
using System.Configuration;
using Homework.Controllers;
using Homework.Helpers;

namespace Homework.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        Task1Controller _task1Controller;
        Task2Controller _task2Controller;


        // конструктор
        public App() {
            _task1Controller = new Task1Controller();
            _task2Controller = new Task2Controller();
        } // App

    } // class App
}