﻿
namespace Homework.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.TbcMain = new System.Windows.Forms.TabControl();
			this.TbcItem01 = new System.Windows.Forms.TabPage();
			this.label1 = new System.Windows.Forms.Label();
			this.DgvQuery01 = new System.Windows.Forms.DataGridView();
			this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.goodsPurchaseViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.TbcItem02 = new System.Windows.Forms.TabPage();
			this.label2 = new System.Windows.Forms.Label();
			this.DgvQuery02 = new System.Windows.Forms.DataGridView();
			this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.titleDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.priceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TbcItem03 = new System.Windows.Forms.TabPage();
			this.label4 = new System.Windows.Forms.Label();
			this.DgvQuery03 = new System.Windows.Forms.DataGridView();
			this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.titleDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.priceDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TbcItem04 = new System.Windows.Forms.TabPage();
			this.label5 = new System.Windows.Forms.Label();
			this.DgvQuery04 = new System.Windows.Forms.DataGridView();
			this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.surnameNPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.interestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.sellerViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.TbcItem05 = new System.Windows.Forms.TabPage();
			this.label6 = new System.Windows.Forms.Label();
			this.DgvQuery05 = new System.Windows.Forms.DataGridView();
			this.titleDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.purchasePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.salePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.sellDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.saleViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.TbcItem06 = new System.Windows.Forms.TabPage();
			this.label7 = new System.Windows.Forms.Label();
			this.DgvQuery06 = new System.Windows.Forms.DataGridView();
			this.sellDateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.titleDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.purchasePriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.sellPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.profitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.profitModelViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.TbcItem07 = new System.Windows.Forms.TabPage();
			this.label8 = new System.Windows.Forms.Label();
			this.DgvQuery07 = new System.Windows.Forms.DataGridView();
			this.titleDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.avgPurchasePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.salesAmountDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.query07ViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.TbcItem08 = new System.Windows.Forms.TabPage();
			this.label3 = new System.Windows.Forms.Label();
			this.DgvQuery08 = new System.Windows.Forms.DataGridView();
			this.surnameNPDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.avgSalePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.salesAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.query08ViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.MniMain = new System.Windows.Forms.MenuStrip();
			this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.TsbMain = new System.Windows.Forms.ToolStrip();
			this.TsbExit = new System.Windows.Forms.ToolStripButton();
			this.TsbAbout = new System.Windows.Forms.ToolStripButton();
			this.TbcMain.SuspendLayout();
			this.TbcItem01.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.goodsPurchaseViewModelBindingSource)).BeginInit();
			this.TbcItem02.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).BeginInit();
			this.TbcItem03.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery03)).BeginInit();
			this.TbcItem04.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sellerViewModelBindingSource)).BeginInit();
			this.TbcItem05.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource)).BeginInit();
			this.TbcItem06.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.profitModelViewBindingSource)).BeginInit();
			this.TbcItem07.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery07)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.query07ViewModelBindingSource)).BeginInit();
			this.TbcItem08.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery08)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.query08ViewModelBindingSource)).BeginInit();
			this.MniMain.SuspendLayout();
			this.TsbMain.SuspendLayout();
			this.SuspendLayout();
			// 
			// TbcMain
			// 
			this.TbcMain.Controls.Add(this.TbcItem01);
			this.TbcMain.Controls.Add(this.TbcItem02);
			this.TbcMain.Controls.Add(this.TbcItem03);
			this.TbcMain.Controls.Add(this.TbcItem04);
			this.TbcMain.Controls.Add(this.TbcItem05);
			this.TbcMain.Controls.Add(this.TbcItem06);
			this.TbcMain.Controls.Add(this.TbcItem07);
			this.TbcMain.Controls.Add(this.TbcItem08);
			this.TbcMain.Location = new System.Drawing.Point(0, 72);
			this.TbcMain.Name = "TbcMain";
			this.TbcMain.SelectedIndex = 0;
			this.TbcMain.Size = new System.Drawing.Size(814, 416);
			this.TbcMain.TabIndex = 0;
			// 
			// TbcItem01
			// 
			this.TbcItem01.Controls.Add(this.label1);
			this.TbcItem01.Controls.Add(this.DgvQuery01);
			this.TbcItem01.Location = new System.Drawing.Point(4, 26);
			this.TbcItem01.Name = "TbcItem01";
			this.TbcItem01.Padding = new System.Windows.Forms.Padding(3);
			this.TbcItem01.Size = new System.Drawing.Size(806, 386);
			this.TbcItem01.TabIndex = 0;
			this.TbcItem01.Text = "Запрос 1";
			this.TbcItem01.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(706, 19);
			this.label1.TabIndex = 1;
			this.label1.Text = "Tовары, единицей измерения которых является «шт» и цена закупки составляет меньше" +
    " 200 руб.:";
			// 
			// DgvQuery01
			// 
			this.DgvQuery01.AllowUserToAddRows = false;
			this.DgvQuery01.AllowUserToDeleteRows = false;
			this.DgvQuery01.AllowUserToResizeRows = false;
			this.DgvQuery01.AutoGenerateColumns = false;
			this.DgvQuery01.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery01.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery01.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.titleDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
			this.DgvQuery01.DataSource = this.goodsPurchaseViewModelBindingSource;
			this.DgvQuery01.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery01.Location = new System.Drawing.Point(3, 24);
			this.DgvQuery01.MultiSelect = false;
			this.DgvQuery01.Name = "DgvQuery01";
			this.DgvQuery01.ReadOnly = true;
			this.DgvQuery01.Size = new System.Drawing.Size(800, 359);
			this.DgvQuery01.TabIndex = 0;
			// 
			// idDataGridViewTextBoxColumn
			// 
			this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
			this.idDataGridViewTextBoxColumn.HeaderText = "Id";
			this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
			this.idDataGridViewTextBoxColumn.ReadOnly = true;
			this.idDataGridViewTextBoxColumn.Width = 46;
			// 
			// titleDataGridViewTextBoxColumn
			// 
			this.titleDataGridViewTextBoxColumn.DataPropertyName = "Title";
			this.titleDataGridViewTextBoxColumn.HeaderText = "Title";
			this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
			this.titleDataGridViewTextBoxColumn.ReadOnly = true;
			this.titleDataGridViewTextBoxColumn.Width = 59;
			// 
			// priceDataGridViewTextBoxColumn
			// 
			this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
			this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
			this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
			this.priceDataGridViewTextBoxColumn.ReadOnly = true;
			this.priceDataGridViewTextBoxColumn.Width = 63;
			// 
			// goodsPurchaseViewModelBindingSource
			// 
			this.goodsPurchaseViewModelBindingSource.DataSource = typeof(Homework.Models.GoodsPurchaseViewModel);
			// 
			// TbcItem02
			// 
			this.TbcItem02.Controls.Add(this.label2);
			this.TbcItem02.Controls.Add(this.DgvQuery02);
			this.TbcItem02.Location = new System.Drawing.Point(4, 26);
			this.TbcItem02.Name = "TbcItem02";
			this.TbcItem02.Padding = new System.Windows.Forms.Padding(3);
			this.TbcItem02.Size = new System.Drawing.Size(806, 386);
			this.TbcItem02.TabIndex = 1;
			this.TbcItem02.Text = "Запрос 2";
			this.TbcItem02.UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label2.Location = new System.Drawing.Point(0, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(488, 19);
			this.label2.TabIndex = 2;
			this.label2.Text = "Товары, цена закупки которых больше 500 руб. за единицу товара:";
			// 
			// DgvQuery02
			// 
			this.DgvQuery02.AllowUserToAddRows = false;
			this.DgvQuery02.AllowUserToDeleteRows = false;
			this.DgvQuery02.AllowUserToResizeRows = false;
			this.DgvQuery02.AutoGenerateColumns = false;
			this.DgvQuery02.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery02.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery02.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.titleDataGridViewTextBoxColumn1,
            this.priceDataGridViewTextBoxColumn1});
			this.DgvQuery02.DataSource = this.goodsPurchaseViewModelBindingSource;
			this.DgvQuery02.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery02.Location = new System.Drawing.Point(3, 24);
			this.DgvQuery02.MultiSelect = false;
			this.DgvQuery02.Name = "DgvQuery02";
			this.DgvQuery02.ReadOnly = true;
			this.DgvQuery02.Size = new System.Drawing.Size(800, 359);
			this.DgvQuery02.TabIndex = 1;
			// 
			// idDataGridViewTextBoxColumn1
			// 
			this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
			this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
			this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
			this.idDataGridViewTextBoxColumn1.ReadOnly = true;
			this.idDataGridViewTextBoxColumn1.Width = 46;
			// 
			// titleDataGridViewTextBoxColumn1
			// 
			this.titleDataGridViewTextBoxColumn1.DataPropertyName = "Title";
			this.titleDataGridViewTextBoxColumn1.HeaderText = "Title";
			this.titleDataGridViewTextBoxColumn1.Name = "titleDataGridViewTextBoxColumn1";
			this.titleDataGridViewTextBoxColumn1.ReadOnly = true;
			this.titleDataGridViewTextBoxColumn1.Width = 59;
			// 
			// priceDataGridViewTextBoxColumn1
			// 
			this.priceDataGridViewTextBoxColumn1.DataPropertyName = "Price";
			this.priceDataGridViewTextBoxColumn1.HeaderText = "Price";
			this.priceDataGridViewTextBoxColumn1.Name = "priceDataGridViewTextBoxColumn1";
			this.priceDataGridViewTextBoxColumn1.ReadOnly = true;
			this.priceDataGridViewTextBoxColumn1.Width = 63;
			// 
			// TbcItem03
			// 
			this.TbcItem03.Controls.Add(this.label4);
			this.TbcItem03.Controls.Add(this.DgvQuery03);
			this.TbcItem03.Location = new System.Drawing.Point(4, 26);
			this.TbcItem03.Name = "TbcItem03";
			this.TbcItem03.Size = new System.Drawing.Size(806, 386);
			this.TbcItem03.TabIndex = 2;
			this.TbcItem03.Text = "Запрос 3";
			this.TbcItem03.UseVisualStyleBackColor = true;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Dock = System.Windows.Forms.DockStyle.Top;
			this.label4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label4.Location = new System.Drawing.Point(0, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(598, 19);
			this.label4.TabIndex = 3;
			this.label4.Text = "Товары с заданным наименованием, для которых цена закупки меньше 1800 руб.:";
			// 
			// DgvQuery03
			// 
			this.DgvQuery03.AllowUserToAddRows = false;
			this.DgvQuery03.AllowUserToDeleteRows = false;
			this.DgvQuery03.AllowUserToResizeRows = false;
			this.DgvQuery03.AutoGenerateColumns = false;
			this.DgvQuery03.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery03.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery03.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery03.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.titleDataGridViewTextBoxColumn2,
            this.priceDataGridViewTextBoxColumn2});
			this.DgvQuery03.DataSource = this.goodsPurchaseViewModelBindingSource;
			this.DgvQuery03.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery03.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery03.MultiSelect = false;
			this.DgvQuery03.Name = "DgvQuery03";
			this.DgvQuery03.ReadOnly = true;
			this.DgvQuery03.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery03.TabIndex = 1;
			// 
			// idDataGridViewTextBoxColumn2
			// 
			this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
			this.idDataGridViewTextBoxColumn2.HeaderText = "Id";
			this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
			this.idDataGridViewTextBoxColumn2.ReadOnly = true;
			this.idDataGridViewTextBoxColumn2.Width = 46;
			// 
			// titleDataGridViewTextBoxColumn2
			// 
			this.titleDataGridViewTextBoxColumn2.DataPropertyName = "Title";
			this.titleDataGridViewTextBoxColumn2.HeaderText = "Title";
			this.titleDataGridViewTextBoxColumn2.Name = "titleDataGridViewTextBoxColumn2";
			this.titleDataGridViewTextBoxColumn2.ReadOnly = true;
			this.titleDataGridViewTextBoxColumn2.Width = 59;
			// 
			// priceDataGridViewTextBoxColumn2
			// 
			this.priceDataGridViewTextBoxColumn2.DataPropertyName = "Price";
			this.priceDataGridViewTextBoxColumn2.HeaderText = "Price";
			this.priceDataGridViewTextBoxColumn2.Name = "priceDataGridViewTextBoxColumn2";
			this.priceDataGridViewTextBoxColumn2.ReadOnly = true;
			this.priceDataGridViewTextBoxColumn2.Width = 63;
			// 
			// TbcItem04
			// 
			this.TbcItem04.Controls.Add(this.label5);
			this.TbcItem04.Controls.Add(this.DgvQuery04);
			this.TbcItem04.Location = new System.Drawing.Point(4, 26);
			this.TbcItem04.Name = "TbcItem04";
			this.TbcItem04.Size = new System.Drawing.Size(806, 386);
			this.TbcItem04.TabIndex = 3;
			this.TbcItem04.Text = "Запрос 4";
			this.TbcItem04.UseVisualStyleBackColor = true;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Dock = System.Windows.Forms.DockStyle.Top;
			this.label5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label5.Location = new System.Drawing.Point(0, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(436, 19);
			this.label5.TabIndex = 3;
			this.label5.Text = "Продавцы с заданным значением процента комиссионных:";
			// 
			// DgvQuery04
			// 
			this.DgvQuery04.AllowUserToAddRows = false;
			this.DgvQuery04.AllowUserToDeleteRows = false;
			this.DgvQuery04.AllowUserToResizeRows = false;
			this.DgvQuery04.AutoGenerateColumns = false;
			this.DgvQuery04.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery04.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery04.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery04.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.surnameNPDataGridViewTextBoxColumn,
            this.interestDataGridViewTextBoxColumn});
			this.DgvQuery04.DataSource = this.sellerViewModelBindingSource;
			this.DgvQuery04.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery04.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery04.MultiSelect = false;
			this.DgvQuery04.Name = "DgvQuery04";
			this.DgvQuery04.ReadOnly = true;
			this.DgvQuery04.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery04.TabIndex = 1;
			// 
			// idDataGridViewTextBoxColumn3
			// 
			this.idDataGridViewTextBoxColumn3.DataPropertyName = "Id";
			this.idDataGridViewTextBoxColumn3.HeaderText = "Id";
			this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
			this.idDataGridViewTextBoxColumn3.ReadOnly = true;
			this.idDataGridViewTextBoxColumn3.Width = 46;
			// 
			// surnameNPDataGridViewTextBoxColumn
			// 
			this.surnameNPDataGridViewTextBoxColumn.DataPropertyName = "SurnameNP";
			this.surnameNPDataGridViewTextBoxColumn.HeaderText = "SurnameNP";
			this.surnameNPDataGridViewTextBoxColumn.Name = "surnameNPDataGridViewTextBoxColumn";
			this.surnameNPDataGridViewTextBoxColumn.ReadOnly = true;
			this.surnameNPDataGridViewTextBoxColumn.Width = 106;
			// 
			// interestDataGridViewTextBoxColumn
			// 
			this.interestDataGridViewTextBoxColumn.DataPropertyName = "Interest";
			this.interestDataGridViewTextBoxColumn.HeaderText = "Interest";
			this.interestDataGridViewTextBoxColumn.Name = "interestDataGridViewTextBoxColumn";
			this.interestDataGridViewTextBoxColumn.ReadOnly = true;
			this.interestDataGridViewTextBoxColumn.Width = 81;
			// 
			// sellerViewModelBindingSource
			// 
			this.sellerViewModelBindingSource.DataSource = typeof(Homework.Models.SellerViewModel);
			// 
			// TbcItem05
			// 
			this.TbcItem05.Controls.Add(this.label6);
			this.TbcItem05.Controls.Add(this.DgvQuery05);
			this.TbcItem05.Location = new System.Drawing.Point(4, 26);
			this.TbcItem05.Name = "TbcItem05";
			this.TbcItem05.Size = new System.Drawing.Size(806, 386);
			this.TbcItem05.TabIndex = 4;
			this.TbcItem05.Text = "Запрос 5";
			this.TbcItem05.UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Dock = System.Windows.Forms.DockStyle.Top;
			this.label6.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label6.Location = new System.Drawing.Point(0, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(636, 19);
			this.label6.TabIndex = 3;
			this.label6.Text = "Все зафиксированные факты продажи товаров, с ценой продажи в заданных границах:";
			// 
			// DgvQuery05
			// 
			this.DgvQuery05.AllowUserToAddRows = false;
			this.DgvQuery05.AllowUserToDeleteRows = false;
			this.DgvQuery05.AllowUserToResizeRows = false;
			this.DgvQuery05.AutoGenerateColumns = false;
			this.DgvQuery05.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery05.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery05.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery05.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.titleDataGridViewTextBoxColumn3,
            this.purchasePriceDataGridViewTextBoxColumn,
            this.salePriceDataGridViewTextBoxColumn,
            this.sellDateDataGridViewTextBoxColumn});
			this.DgvQuery05.DataSource = this.saleViewModelBindingSource;
			this.DgvQuery05.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery05.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery05.MultiSelect = false;
			this.DgvQuery05.Name = "DgvQuery05";
			this.DgvQuery05.ReadOnly = true;
			this.DgvQuery05.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery05.TabIndex = 1;
			// 
			// titleDataGridViewTextBoxColumn3
			// 
			this.titleDataGridViewTextBoxColumn3.DataPropertyName = "Title";
			this.titleDataGridViewTextBoxColumn3.HeaderText = "Title";
			this.titleDataGridViewTextBoxColumn3.Name = "titleDataGridViewTextBoxColumn3";
			this.titleDataGridViewTextBoxColumn3.ReadOnly = true;
			this.titleDataGridViewTextBoxColumn3.Width = 59;
			// 
			// purchasePriceDataGridViewTextBoxColumn
			// 
			this.purchasePriceDataGridViewTextBoxColumn.DataPropertyName = "PurchasePrice";
			this.purchasePriceDataGridViewTextBoxColumn.HeaderText = "PurchasePrice";
			this.purchasePriceDataGridViewTextBoxColumn.Name = "purchasePriceDataGridViewTextBoxColumn";
			this.purchasePriceDataGridViewTextBoxColumn.ReadOnly = true;
			this.purchasePriceDataGridViewTextBoxColumn.Width = 118;
			// 
			// salePriceDataGridViewTextBoxColumn
			// 
			this.salePriceDataGridViewTextBoxColumn.DataPropertyName = "SalePrice";
			this.salePriceDataGridViewTextBoxColumn.HeaderText = "SalePrice";
			this.salePriceDataGridViewTextBoxColumn.Name = "salePriceDataGridViewTextBoxColumn";
			this.salePriceDataGridViewTextBoxColumn.ReadOnly = true;
			this.salePriceDataGridViewTextBoxColumn.Width = 87;
			// 
			// sellDateDataGridViewTextBoxColumn
			// 
			this.sellDateDataGridViewTextBoxColumn.DataPropertyName = "SellDate";
			this.sellDateDataGridViewTextBoxColumn.HeaderText = "SellDate";
			this.sellDateDataGridViewTextBoxColumn.Name = "sellDateDataGridViewTextBoxColumn";
			this.sellDateDataGridViewTextBoxColumn.ReadOnly = true;
			this.sellDateDataGridViewTextBoxColumn.Width = 83;
			// 
			// saleViewModelBindingSource
			// 
			this.saleViewModelBindingSource.DataSource = typeof(Homework.Models.SaleViewModel);
			// 
			// TbcItem06
			// 
			this.TbcItem06.Controls.Add(this.label7);
			this.TbcItem06.Controls.Add(this.DgvQuery06);
			this.TbcItem06.Location = new System.Drawing.Point(4, 26);
			this.TbcItem06.Name = "TbcItem06";
			this.TbcItem06.Size = new System.Drawing.Size(806, 386);
			this.TbcItem06.TabIndex = 5;
			this.TbcItem06.Text = "Запрос 6";
			this.TbcItem06.UseVisualStyleBackColor = true;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Dock = System.Windows.Forms.DockStyle.Top;
			this.label7.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label7.Location = new System.Drawing.Point(0, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(484, 19);
			this.label7.TabIndex = 3;
			this.label7.Text = "Товары, цена закупки которых больше 500 руб. за единицу товара";
			// 
			// DgvQuery06
			// 
			this.DgvQuery06.AllowUserToAddRows = false;
			this.DgvQuery06.AllowUserToDeleteRows = false;
			this.DgvQuery06.AllowUserToResizeRows = false;
			this.DgvQuery06.AutoGenerateColumns = false;
			this.DgvQuery06.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery06.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery06.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery06.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sellDateDataGridViewTextBoxColumn1,
            this.titleDataGridViewTextBoxColumn4,
            this.purchasePriceDataGridViewTextBoxColumn1,
            this.sellPriceDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn,
            this.profitDataGridViewTextBoxColumn});
			this.DgvQuery06.DataSource = this.profitModelViewBindingSource;
			this.DgvQuery06.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery06.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery06.MultiSelect = false;
			this.DgvQuery06.Name = "DgvQuery06";
			this.DgvQuery06.ReadOnly = true;
			this.DgvQuery06.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery06.TabIndex = 1;
			// 
			// sellDateDataGridViewTextBoxColumn1
			// 
			this.sellDateDataGridViewTextBoxColumn1.DataPropertyName = "SellDate";
			this.sellDateDataGridViewTextBoxColumn1.HeaderText = "SellDate";
			this.sellDateDataGridViewTextBoxColumn1.Name = "sellDateDataGridViewTextBoxColumn1";
			this.sellDateDataGridViewTextBoxColumn1.ReadOnly = true;
			this.sellDateDataGridViewTextBoxColumn1.Width = 83;
			// 
			// titleDataGridViewTextBoxColumn4
			// 
			this.titleDataGridViewTextBoxColumn4.DataPropertyName = "Title";
			this.titleDataGridViewTextBoxColumn4.HeaderText = "Title";
			this.titleDataGridViewTextBoxColumn4.Name = "titleDataGridViewTextBoxColumn4";
			this.titleDataGridViewTextBoxColumn4.ReadOnly = true;
			this.titleDataGridViewTextBoxColumn4.Width = 59;
			// 
			// purchasePriceDataGridViewTextBoxColumn1
			// 
			this.purchasePriceDataGridViewTextBoxColumn1.DataPropertyName = "PurchasePrice";
			this.purchasePriceDataGridViewTextBoxColumn1.HeaderText = "PurchasePrice";
			this.purchasePriceDataGridViewTextBoxColumn1.Name = "purchasePriceDataGridViewTextBoxColumn1";
			this.purchasePriceDataGridViewTextBoxColumn1.ReadOnly = true;
			this.purchasePriceDataGridViewTextBoxColumn1.Width = 118;
			// 
			// sellPriceDataGridViewTextBoxColumn
			// 
			this.sellPriceDataGridViewTextBoxColumn.DataPropertyName = "SellPrice";
			this.sellPriceDataGridViewTextBoxColumn.HeaderText = "SellPrice";
			this.sellPriceDataGridViewTextBoxColumn.Name = "sellPriceDataGridViewTextBoxColumn";
			this.sellPriceDataGridViewTextBoxColumn.ReadOnly = true;
			this.sellPriceDataGridViewTextBoxColumn.Width = 83;
			// 
			// amountDataGridViewTextBoxColumn
			// 
			this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
			this.amountDataGridViewTextBoxColumn.HeaderText = "Amount";
			this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
			this.amountDataGridViewTextBoxColumn.ReadOnly = true;
			this.amountDataGridViewTextBoxColumn.Width = 84;
			// 
			// profitDataGridViewTextBoxColumn
			// 
			this.profitDataGridViewTextBoxColumn.DataPropertyName = "Profit";
			this.profitDataGridViewTextBoxColumn.HeaderText = "Profit";
			this.profitDataGridViewTextBoxColumn.Name = "profitDataGridViewTextBoxColumn";
			this.profitDataGridViewTextBoxColumn.ReadOnly = true;
			this.profitDataGridViewTextBoxColumn.Width = 67;
			// 
			// profitModelViewBindingSource
			// 
			this.profitModelViewBindingSource.DataSource = typeof(Homework.Models.ProfitModelView);
			// 
			// TbcItem07
			// 
			this.TbcItem07.Controls.Add(this.label8);
			this.TbcItem07.Controls.Add(this.DgvQuery07);
			this.TbcItem07.Location = new System.Drawing.Point(4, 26);
			this.TbcItem07.Name = "TbcItem07";
			this.TbcItem07.Size = new System.Drawing.Size(806, 386);
			this.TbcItem07.TabIndex = 6;
			this.TbcItem07.Text = "Запрос 7";
			this.TbcItem07.UseVisualStyleBackColor = true;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Dock = System.Windows.Forms.DockStyle.Top;
			this.label8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label8.Location = new System.Drawing.Point(0, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(585, 19);
			this.label8.TabIndex = 3;
			this.label8.Text = "Cредняя цена закупки товара для каждого наименования и количество закупок:";
			// 
			// DgvQuery07
			// 
			this.DgvQuery07.AllowUserToAddRows = false;
			this.DgvQuery07.AllowUserToDeleteRows = false;
			this.DgvQuery07.AllowUserToResizeRows = false;
			this.DgvQuery07.AutoGenerateColumns = false;
			this.DgvQuery07.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery07.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery07.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery07.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.titleDataGridViewTextBoxColumn5,
            this.avgPurchasePriceDataGridViewTextBoxColumn,
            this.salesAmountDataGridViewTextBoxColumn1});
			this.DgvQuery07.DataSource = this.query07ViewModelBindingSource;
			this.DgvQuery07.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery07.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery07.MultiSelect = false;
			this.DgvQuery07.Name = "DgvQuery07";
			this.DgvQuery07.ReadOnly = true;
			this.DgvQuery07.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery07.TabIndex = 1;
			// 
			// titleDataGridViewTextBoxColumn5
			// 
			this.titleDataGridViewTextBoxColumn5.DataPropertyName = "Title";
			this.titleDataGridViewTextBoxColumn5.HeaderText = "Title";
			this.titleDataGridViewTextBoxColumn5.Name = "titleDataGridViewTextBoxColumn5";
			this.titleDataGridViewTextBoxColumn5.ReadOnly = true;
			this.titleDataGridViewTextBoxColumn5.Width = 59;
			// 
			// avgPurchasePriceDataGridViewTextBoxColumn
			// 
			this.avgPurchasePriceDataGridViewTextBoxColumn.DataPropertyName = "AvgPurchasePrice";
			this.avgPurchasePriceDataGridViewTextBoxColumn.HeaderText = "AvgPurchasePrice";
			this.avgPurchasePriceDataGridViewTextBoxColumn.Name = "avgPurchasePriceDataGridViewTextBoxColumn";
			this.avgPurchasePriceDataGridViewTextBoxColumn.ReadOnly = true;
			this.avgPurchasePriceDataGridViewTextBoxColumn.Width = 142;
			// 
			// salesAmountDataGridViewTextBoxColumn1
			// 
			this.salesAmountDataGridViewTextBoxColumn1.DataPropertyName = "SalesAmount";
			this.salesAmountDataGridViewTextBoxColumn1.HeaderText = "SalesAmount";
			this.salesAmountDataGridViewTextBoxColumn1.Name = "salesAmountDataGridViewTextBoxColumn1";
			this.salesAmountDataGridViewTextBoxColumn1.ReadOnly = true;
			this.salesAmountDataGridViewTextBoxColumn1.Width = 114;
			// 
			// query07ViewModelBindingSource
			// 
			this.query07ViewModelBindingSource.DataSource = typeof(Homework.Models.Query07ViewModel);
			// 
			// TbcItem08
			// 
			this.TbcItem08.Controls.Add(this.label3);
			this.TbcItem08.Controls.Add(this.DgvQuery08);
			this.TbcItem08.Location = new System.Drawing.Point(4, 26);
			this.TbcItem08.Name = "TbcItem08";
			this.TbcItem08.Size = new System.Drawing.Size(806, 386);
			this.TbcItem08.TabIndex = 7;
			this.TbcItem08.Text = "Запрос 8";
			this.TbcItem08.UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Dock = System.Windows.Forms.DockStyle.Top;
			this.label3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label3.Location = new System.Drawing.Point(0, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(688, 19);
			this.label3.TabIndex = 3;
			this.label3.Text = "Среднее значение цены продажи единицы товара для каждого продавца, количество про" +
    "даж:";
			// 
			// DgvQuery08
			// 
			this.DgvQuery08.AllowUserToAddRows = false;
			this.DgvQuery08.AllowUserToDeleteRows = false;
			this.DgvQuery08.AllowUserToResizeRows = false;
			this.DgvQuery08.AutoGenerateColumns = false;
			this.DgvQuery08.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvQuery08.BackgroundColor = System.Drawing.SystemColors.Window;
			this.DgvQuery08.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvQuery08.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.surnameNPDataGridViewTextBoxColumn1,
            this.avgSalePriceDataGridViewTextBoxColumn,
            this.salesAmountDataGridViewTextBoxColumn});
			this.DgvQuery08.DataSource = this.query08ViewModelBindingSource;
			this.DgvQuery08.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.DgvQuery08.Location = new System.Drawing.Point(0, 24);
			this.DgvQuery08.MultiSelect = false;
			this.DgvQuery08.Name = "DgvQuery08";
			this.DgvQuery08.ReadOnly = true;
			this.DgvQuery08.Size = new System.Drawing.Size(806, 362);
			this.DgvQuery08.TabIndex = 2;
			// 
			// surnameNPDataGridViewTextBoxColumn1
			// 
			this.surnameNPDataGridViewTextBoxColumn1.DataPropertyName = "SurnameNP";
			this.surnameNPDataGridViewTextBoxColumn1.HeaderText = "SurnameNP";
			this.surnameNPDataGridViewTextBoxColumn1.Name = "surnameNPDataGridViewTextBoxColumn1";
			this.surnameNPDataGridViewTextBoxColumn1.ReadOnly = true;
			this.surnameNPDataGridViewTextBoxColumn1.Width = 106;
			// 
			// avgSalePriceDataGridViewTextBoxColumn
			// 
			this.avgSalePriceDataGridViewTextBoxColumn.DataPropertyName = "AvgSalePrice";
			this.avgSalePriceDataGridViewTextBoxColumn.HeaderText = "AvgSalePrice";
			this.avgSalePriceDataGridViewTextBoxColumn.Name = "avgSalePriceDataGridViewTextBoxColumn";
			this.avgSalePriceDataGridViewTextBoxColumn.ReadOnly = true;
			this.avgSalePriceDataGridViewTextBoxColumn.Width = 111;
			// 
			// salesAmountDataGridViewTextBoxColumn
			// 
			this.salesAmountDataGridViewTextBoxColumn.DataPropertyName = "SalesAmount";
			this.salesAmountDataGridViewTextBoxColumn.HeaderText = "SalesAmount";
			this.salesAmountDataGridViewTextBoxColumn.Name = "salesAmountDataGridViewTextBoxColumn";
			this.salesAmountDataGridViewTextBoxColumn.ReadOnly = true;
			this.salesAmountDataGridViewTextBoxColumn.Width = 114;
			// 
			// query08ViewModelBindingSource
			// 
			this.query08ViewModelBindingSource.DataSource = typeof(Homework.Models.Query08ViewModel);
			// 
			// MniMain
			// 
			this.MniMain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.MniMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniHelp});
			this.MniMain.Location = new System.Drawing.Point(0, 0);
			this.MniMain.Name = "MniMain";
			this.MniMain.Size = new System.Drawing.Size(814, 27);
			this.MniMain.TabIndex = 4;
			this.MniMain.Text = "menuStrip1";
			// 
			// MniFile
			// 
			this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator3,
            this.MniFileExit});
			this.MniFile.Name = "MniFile";
			this.MniFile.Size = new System.Drawing.Size(53, 23);
			this.MniFile.Text = "Файл";
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(115, 6);
			// 
			// MniFileExit
			// 
			this.MniFileExit.Image = global::Homework.Properties.Resources.exit;
			this.MniFileExit.Name = "MniFileExit";
			this.MniFileExit.Size = new System.Drawing.Size(118, 24);
			this.MniFileExit.Text = "Выход";
			this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// MniHelp
			// 
			this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
			this.MniHelp.Name = "MniHelp";
			this.MniHelp.Size = new System.Drawing.Size(74, 23);
			this.MniHelp.Text = "Справка";
			// 
			// MniHelpAbout
			// 
			this.MniHelpAbout.Name = "MniHelpAbout";
			this.MniHelpAbout.Size = new System.Drawing.Size(164, 24);
			this.MniHelpAbout.Text = "О программе";
			this.MniHelpAbout.Click += new System.EventHandler(this.AboutForm_Command);
			// 
			// TsbMain
			// 
			this.TsbMain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.TsbMain.ImageScalingSize = new System.Drawing.Size(32, 32);
			this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbExit,
            this.TsbAbout});
			this.TsbMain.Location = new System.Drawing.Point(0, 27);
			this.TsbMain.Name = "TsbMain";
			this.TsbMain.Size = new System.Drawing.Size(814, 39);
			this.TsbMain.TabIndex = 5;
			this.TsbMain.Text = "toolStrip1";
			// 
			// TsbExit
			// 
			this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbExit.Image = global::Homework.Properties.Resources.exit;
			this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbExit.Name = "TsbExit";
			this.TsbExit.Size = new System.Drawing.Size(36, 36);
			this.TsbExit.Text = "Выход";
			this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// TsbAbout
			// 
			this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbAbout.Image = global::Homework.Properties.Resources.about;
			this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbAbout.Name = "TsbAbout";
			this.TsbAbout.Size = new System.Drawing.Size(36, 36);
			this.TsbAbout.Text = "О программе";
			this.TsbAbout.Click += new System.EventHandler(this.AboutForm_Command);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.ClientSize = new System.Drawing.Size(814, 484);
			this.Controls.Add(this.TsbMain);
			this.Controls.Add(this.MniMain);
			this.Controls.Add(this.TbcMain);
			this.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашняя работа";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.TbcMain.ResumeLayout(false);
			this.TbcItem01.ResumeLayout(false);
			this.TbcItem01.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.goodsPurchaseViewModelBindingSource)).EndInit();
			this.TbcItem02.ResumeLayout(false);
			this.TbcItem02.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).EndInit();
			this.TbcItem03.ResumeLayout(false);
			this.TbcItem03.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery03)).EndInit();
			this.TbcItem04.ResumeLayout(false);
			this.TbcItem04.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sellerViewModelBindingSource)).EndInit();
			this.TbcItem05.ResumeLayout(false);
			this.TbcItem05.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource)).EndInit();
			this.TbcItem06.ResumeLayout(false);
			this.TbcItem06.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.profitModelViewBindingSource)).EndInit();
			this.TbcItem07.ResumeLayout(false);
			this.TbcItem07.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery07)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.query07ViewModelBindingSource)).EndInit();
			this.TbcItem08.ResumeLayout(false);
			this.TbcItem08.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvQuery08)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.query08ViewModelBindingSource)).EndInit();
			this.MniMain.ResumeLayout(false);
			this.MniMain.PerformLayout();
			this.TsbMain.ResumeLayout(false);
			this.TsbMain.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TabControl TbcMain;
		private System.Windows.Forms.TabPage TbcItem01;
		private System.Windows.Forms.TabPage TbcItem02;
		private System.Windows.Forms.TabPage TbcItem03;
		private System.Windows.Forms.TabPage TbcItem04;
		private System.Windows.Forms.TabPage TbcItem05;
		private System.Windows.Forms.TabPage TbcItem06;
		private System.Windows.Forms.TabPage TbcItem07;
		private System.Windows.Forms.MenuStrip MniMain;
		private System.Windows.Forms.ToolStripMenuItem MniFile;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripMenuItem MniFileExit;
		private System.Windows.Forms.ToolStripMenuItem MniHelp;
		private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
		private System.Windows.Forms.ToolStrip TsbMain;
		private System.Windows.Forms.ToolStripButton TsbExit;
		private System.Windows.Forms.ToolStripButton TsbAbout;
		private System.Windows.Forms.DataGridView DgvQuery01;
		private System.Windows.Forms.DataGridView DgvQuery02;
		private System.Windows.Forms.DataGridView DgvQuery03;
		private System.Windows.Forms.DataGridView DgvQuery04;
		private System.Windows.Forms.DataGridView DgvQuery05;
		private System.Windows.Forms.DataGridView DgvQuery06;
		private System.Windows.Forms.DataGridView DgvQuery07;
		private System.Windows.Forms.BindingSource goodsPurchaseViewModelBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TabPage TbcItem08;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.DataGridView DgvQuery08;
		private System.Windows.Forms.BindingSource sellerViewModelBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
		private System.Windows.Forms.DataGridViewTextBoxColumn surnameNPDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource saleViewModelBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn3;
		private System.Windows.Forms.DataGridViewTextBoxColumn purchasePriceDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn salePriceDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn sellDateDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource profitModelViewBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn sellDateDataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn4;
		private System.Windows.Forms.DataGridViewTextBoxColumn purchasePriceDataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn sellPriceDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn profitDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource query08ViewModelBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn surnameNPDataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn avgSalePriceDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn salesAmountDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource query07ViewModelBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn5;
		private System.Windows.Forms.DataGridViewTextBoxColumn avgPurchasePriceDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn salesAmountDataGridViewTextBoxColumn1;
	}
}
