﻿
drop table if exists Sales;
drop table if exists Purchases;
drop table if exists Sellers;
drop table if exists Goods;
drop table if exists Units;


create table dbo.Units
(
	Id		int				not null primary key identity (1,1), 
    Short	nvarchar(10)	not null, 
    Long	nvarchar(10)	not null
);
go

create table dbo.Goods
(
	Id		int				not null primary key identity (1,1), 
	[Name]	nvarchar(60)	not null,
);
go

create table dbo.Sellers
(
	Id			int			 not null primary key identity (1,1), 
	Surname		nvarchar(50) not null,
	[Name]		nvarchar(60) not null,
	Patronymic	nvarchar(50) not null,
	Interest	float		 not null
);
go

create table dbo.Purchases
(
	Id				int		not null primary key identity (1,1), 
	IdGood			int		not null,
	IdUnit			int		not null,
	PurchasePrice	int		not null,
	Amount			int		not null,
	PurchaseDate	date	not null,

	constraint CK_Purchases_PurchasePrice	check (PurchasePrice > 0),
	constraint CK_Purchases_Amount			check (Amount > 0),

	constraint FK_Purchases_Goods foreign key (IdGood) references dbo.Goods(Id),
	constraint FK_Purchases_Units  foreign key (IdUnit) references dbo.Units(Id)
);
go

create table dbo.Sales
(
	Id			int		not null primary key identity (1,1), 
	SellDate	date	not null,
	IdSeller	int		not null,
	IdPurchase	int		not null,
	Amount		int		not null,
	IdUnit		int		not null,
	Price		int		not null,

	constraint CK_Sales_Amount	check (Amount > 0),
	constraint CK_Sales_Price	check (Price > 0),

	constraint FK_Sales_Sellers foreign key (IdSeller) references dbo.Sellers(Id),
	constraint FK_Sales_Purchases foreign key (IdPurchase) references dbo.Purchases(Id),
	constraint FK_Sales_Units foreign key (IdUnit) references dbo.Units(Id)
);
go


