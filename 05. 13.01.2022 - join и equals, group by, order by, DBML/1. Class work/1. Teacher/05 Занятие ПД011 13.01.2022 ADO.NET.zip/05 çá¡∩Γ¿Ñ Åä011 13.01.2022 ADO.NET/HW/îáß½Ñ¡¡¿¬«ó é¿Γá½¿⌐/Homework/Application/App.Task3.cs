﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using Homework.Controllers;
using Homework.Models;

namespace Homework.Application
{
	internal partial class App
	{
		private void Task3Item1()
		{
			Utilities.ShowNavBar("  Товары с заданным диапазоном цен.");

			_task3Controller.Show();

			int lo = Utilities.GenerateInt(400_000, 19_999_999);
			int hi = Utilities.GenerateInt(20_000_000, 40_000_000);

			Console.WriteLine($"\n\n  Товары с диапазоном цен от {lo}р. до {hi}р.\n");

			Console.Write("  Расширяющие методы:");
			
			Task3Controller.Show(_task3Controller.Query01Ext(lo, hi));
			
			Console.Write("\n  LINQ:");
			Task3Controller.Show(_task3Controller.Query01Linq(lo, hi));

		}

		private void Task3Item2()
		{
			Utilities.ShowNavBar("  Сумма товаров с заданным годом выпуска.");

			_task3Controller.Show();

			int year = Utilities.GenerateInt(2000, 2021);

			Console.WriteLine($"\n  Сумма товаров с годом выпуска {year}.");

			Console.WriteLine($"\n\n  Расширяющие методы: {_task3Controller.Query02Ext(year)}");

			Console.WriteLine($"\n\n  LINQ: {_task3Controller.Query02Linq(year)}");
		}

		private void Task3Item3()
		{
			Utilities.ShowNavBar("  Сумма товаров с заданным наименованием.");

			_task3Controller.Show();

			string key = Product.names[Utilities.GenerateInt(0, Product.names.Length - 1)].Split(' ')[0];

			Console.WriteLine($"\n  Сумма товаров с наименованием, содержащим {key}.");

			Console.WriteLine($"\n\n  Расширяющие методы: {_task3Controller.Query03Ext(key)}");

			Console.WriteLine($"\n\n  LINQ: {_task3Controller.Query03Linq(key)}");
		}

		private void Task3Item4()
		{
			Utilities.ShowNavBar("  Наименование и год выпуска товаров с максимальным количеством.");

			_task3Controller.Show();

			Console.Write("\n  Cписок товоаров с максимальным количеством:\n\n");

			Console.Write($"  Расширяющие методы:\n");

			_task3Controller.Query04Ext();

			Console.Write($"\n  LINQ:\n");

			_task3Controller.Query04Linq();
		}

		private void Task3Item5()
		{
			Utilities.ShowNavBar("  Товары, для которых произведение цены на количество находится в заданном диапазоне.");

			_task3Controller.Show();

			int lo = Utilities.GenerateInt(10_00_000, 200_000_000);
			int hi = Utilities.GenerateInt(201_000_000, 400_000_000);

			Console.WriteLine($"\n\n  Товары с суммарной стоимостью в диапазоне {lo}р. до {hi}р.\n");

			Console.Write("  Расширяющие методы:");
			
			Task3Controller.Show(_task3Controller.Query05Ext(lo, hi));
			
			Console.Write("\n  LINQ:");
			Task3Controller.Show(_task3Controller.Query05Linq(lo, hi));

		}

	}
}