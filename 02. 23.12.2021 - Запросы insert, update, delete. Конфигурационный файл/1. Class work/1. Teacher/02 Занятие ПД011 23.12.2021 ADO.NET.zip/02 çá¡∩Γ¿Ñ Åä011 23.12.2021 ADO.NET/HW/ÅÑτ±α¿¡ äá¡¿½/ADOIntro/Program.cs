﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADOIntro
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 27.09.2021. ВВедение в ADO.NET ";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Информация о 3-комнатных квартирах на улице «Садовая»" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Информация о риэлторах с фамилиями на букву «И» и процентом вознаграждения больше 10%" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Информация об 1-комнатных квартирах с ценой в диапазоне от 900 000 руб. до 1000 000 руб" },
              //----------------------------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.R, Text = "Иинформация о квартирах с заданным числом комнат" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Информация обо всех 2-комнатных квартирах с площадью из диапазона" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Размер вознаграждения риэлтора.Поля Фамилия, Имя, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные.Сортировка по Дате сделки" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Для всех риэлторов -количество клиентов, и сумму сделок. Упорядочить выборку по убыванию суммы сделок." },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки" },
                //----------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.F, Text = "Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки. " },

                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" }     
           
            }; //MenuItem

            Application app = new Application();

            while(true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ВВедение в технологию ADO.NET");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с базой данных «Учет сделок с недвижимостью»", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch(key)
                    {
                        case ConsoleKey.Q:
                            app.Query1();
                            break;
                        case ConsoleKey.W:
                            app.Query2();
                            break;
                        case ConsoleKey.E:
                            app.Query3();
                            break;

                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;
                        default:
                            throw new Exception("Нет такой команды меню");
                    }// switch
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                }// try
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }// catch

            }//while 
        }
    }
}
