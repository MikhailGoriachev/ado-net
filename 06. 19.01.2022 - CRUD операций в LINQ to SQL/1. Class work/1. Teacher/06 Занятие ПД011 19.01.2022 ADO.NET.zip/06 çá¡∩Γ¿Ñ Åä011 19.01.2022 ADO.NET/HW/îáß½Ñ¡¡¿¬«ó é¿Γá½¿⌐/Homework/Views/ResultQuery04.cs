﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Views
{
	public class ResultQuery04
	{
		public string Fullname { get; set; }
		
		public int Amount { get; set; }

		public override string ToString() =>
			$"  {Fullname} - {Amount} книг";
	}
}
