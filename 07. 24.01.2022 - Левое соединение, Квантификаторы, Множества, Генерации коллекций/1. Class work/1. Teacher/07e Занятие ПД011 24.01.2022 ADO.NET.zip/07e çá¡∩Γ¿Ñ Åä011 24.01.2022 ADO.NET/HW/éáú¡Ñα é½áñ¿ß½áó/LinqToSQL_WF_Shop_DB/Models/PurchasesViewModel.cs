﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqToSQL_WF_Shop_DB.Models
{
    public class PurchasesViewModel
    {

        //Наименование товара
        public string GoodsName
        {
            get;
            set;
        }
        //Еденицы измерения закупки 
        public string UnitShort
        {
            get;
            set;
        }

        //Стоимость закупки 
        public int Price
        {
            get;
            set;
        }

        //Кол-во закуплено
        public int Amount
        {
            get;
            set;
        }
        //Дата покупки 
        public DateTime Date
        {
            get;
            set;
        }

        public PurchasesViewModel()
        {

        }

        public PurchasesViewModel(string goodsName, string unit, int price, int amount, DateTime date)
        {
            GoodsName = goodsName;
            UnitShort = unit;
            Price = price;
            Amount = amount;
            Date = date;
        }

        //Переопределяем tostring
        public override string ToString()
        => $"Название: {GoodsName} \r\n Стоимость: {Price} \r\n Единицы измерения: {UnitShort} \r\n Закуплено: {Amount}";

    }
}
