﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LinqIntro.Application;
using LinqIntro.Helpers;

namespace LinqIntro
{
    /*
     * Разработайте, пожалуйста, консольное приложение C# для решения следующих
     * задач (в объектном стиле – с созданием класса, объекта этого класса):
     *
     * Задача 1.
     * Для класса, представляющего товар (наименование, цена, количество, год
     * выпуска) разработать расширяющий метод, возвращающий процент скидки в
     * зависимости от возраста товара – до 3х лет скидка не представляется,
     * от 3х до 10 лет скидка 3%, свыше 10 лет – скидка 7%. Продемонстрировать
     * работу метода на коллекции из 12 товаров.
     *
     * Задача 2.
     * С использованием LINQ (создавайте 2 варианта запросов – в синтаксисе
     * LINQ и в синтаксисе расширяющих методов) выполнить обработки для
     * одномерного массива из n вещественных элементов:
     *     o Вычисление количества элементов массива, со значениями
     *       в диапазоне от A до B
     *     o Вычисление количества элементов массива, равных 0
     *     o Вычисление суммы элементов массива, расположенных после первого
     *       максимального элемента
     *     o Вычисление суммы элементов массива, расположенных перед последним
     *       минимальным по модулю элементом
     *
     * Задача 3.
     * Для коллекции товаров из задачи 1 выполнить следующие LINQ-запросы
     * (создавайте 2 варианта запросов – в синтаксисе LINQ и в синтаксисе
     * расширяющих методов):
     *     o товары с заданным диапазоном цен
     *     o сумма товаров с заданным годом выпуска
     *     o сумма товаров с заданным наименованием (суммируем произведение
     *       цены на количество, наименование товара может быть задано
     *       частично, но без маски типа %, _)
     *     o наименование и год выпуска товаров с максимальным количеством
     *     o все товары, для которых произведение цены на количество находится
     *       в заданном диапазоне
     *
     */
    class Program
    {
       static void Main(string[] args) {
            Console.Title = "Задание на 13.01.2022 - введение в обработку коллекций при помощи LINQ";

            // простейшее меню приложения
            List<MenuItem> menu = new List<MenuItem>(new[]{
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Вывести список товаров в коллекции для задач 1 и 3" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Демонстрация расширяющего метода класса Goods" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Separator" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.T, Text = "Заполнить массив новым набором чисел, показать массив" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Количество элементов массива, со значениями в диапазоне от A до B" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Количество элементов массива, равных 0" },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Сумма элементов массива, расположенных после первого максимального элемента" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Сумма элементов массива, расположенных перед последним минимальным по модулю элементом" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Separator" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Товары с заданным диапазоном цен" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Сумма товаров с заданным годом выпуска" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Сумма товаров с заданным наименованием" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Наименование и год выпуска товаров с максимальным количеством" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Все товары, для которых произведение цены на количество находится в заданном диапазоне" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Separator" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            });
            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    Utils.SetColor(ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 13.01.2022 - шифрование конфигурационного файла, модели в запросах");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        #region Решение задачи 1
                        // Вывести список товаров в коллекции для задач 1 и 3
                        case ConsoleKey.Q:
                            app.ShowGoods();
                            break;

                        // Демонстрация расширяющего метода класса Goods
                        case ConsoleKey.W:
                            app.ExtentionMethodDemo();
                            break;
                        #endregion

                        #region Выполнение запросов LINQ по задаче 2
                        // Заполнить массив новым набором чисел, показать массив
                        case ConsoleKey.T:
                            app.ArrayFillAndShow();
                            break;

                        // Количество элементов массива, со значениями в диапазоне от A до B 
                        case ConsoleKey.Y:
                            app.NumberOfItemInRangeAb();
                            break;

                        // Количество элементов массива, равных 0
                        case ConsoleKey.U:
                            app.NumberOfItemEqZero();
                            break;

                        // Сумма элементов массива, расположенных после первого максимального элемента
                        case ConsoleKey.I:
                            app.SumAfterFirstMax();
                            break;

                        // Сумма элементов массива, расположенных перед последним минимальным по модулю элементом
                        case ConsoleKey.O:
                            app.SumBeforeLastAbsMin();
                            break;
                        #endregion

                        #region Выполнение запросов по задаче 3
                        // Товары с заданным диапазоном цен
                        case ConsoleKey.A:
                            app.GoodsPriceInRange();
                            break;

                        // Сумма товаров с заданным годом выпуска
                        case ConsoleKey.S:
                            app.SumGoodsYearIssue();
                            break;

                        // Сумма товаров с заданным наименованием
                        case ConsoleKey.D:
                            app.SumGoodsWhereName();
                            break;

                        // Наименование и год выпуска товаров с максимальным количеством
                        case ConsoleKey.F:
                            app.NameAndYearWhereMaxAmount();
                            break;

                        // Все товары, для которых произведение цены на количество находится в заданном диапазоне
                        case ConsoleKey.G:
                            app.GoodsWhereCostInRange();
                            break;
                        #endregion

                        // выход из приложения назначен на клавишу F10 или кавишу Z или на клавишу Esc
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                } catch (Exception ex) {
                    // получить первые 79 символов сообщения об ошибке
                    string str = ex.Message.Length > 79?ex.Message.Substring(0, 79):ex.Message;

                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20,  9, $"                                                                                        ", ConsoleColor.White);
                    Utils.WriteXY(20, 10, $"  ┌──────────────────────────────────────────────────────────────────────────────────┐  ", ConsoleColor.White);
                    Utils.WriteXY(20, 11, $"  │                                   Исключение                                     │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  │ {str, -79}  │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 13, $"  │                                                                                  │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 14, $"  └──────────────────────────────────────────────────────────────────────────────────┘  ", ConsoleColor.White);
                    Utils.WriteXY(20, 15, $"                                                                                        ", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                } finally {
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                } // try-catch
            } // while
       } // Main
    }
}
