﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Realestate.Helpers;

namespace Realestate.Application
{
    /* 
    * Методы для решения задачи
    */
    internal partial class App {

        public delegate void Proc(int n);


        // 1. Запрос с параметрами	
        //    Выбирает информацию о 3-комнатных квартирах,
        //    расположенных на улице «Садовая». Значения задавать параметрами запроса
        public void Query01(int roomNum = 3, string street = "ул. Садовая") {
            Utils.ShowNavBarTask("Запрос 1. 3-комнатные квартиры, расположенные на улице \"Садовая\"");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      Apartments.Id
                      , Streets.Street
                      , Apartments.Building
                      , Apartments.Flat
                      , Apartments.Area
                      , Apartments.RoomNum
                  from
                      Apartments join Streets on Apartments.IdStreet = Streets.Id
                  where
                      Apartments.RoomNum = @roomNum and Streets.Street = @street;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);
                cmd.Parameters.AddWithValue("@street", street);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬────────────┬────────────┬─────────┬──────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2), -10} │ {reader.GetName(3), -10} │ {reader.GetName(4),-7} │ {reader.GetName(5),-8} │");
                    Console.WriteLine("\t├────┼─────────────────┼────────────┼────────────┼─────────┼──────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2), 10} │ " +
                            $"{reader.GetInt32(3), 10} │ {reader.GetInt32(4), 7:n2} │ {reader.GetInt32(5), 8} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴────────────┴────────────┴─────────┴──────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query01


        // 2. Запрос с параметрами	
        //    Выбирает информацию о риэлторах, фамилия которых начинается
        //    с буквы «И» и процент вознаграждения больше 10%.
        //    Значения задавать параметрами запроса
        public void Query02(double percent = 10, string surname = "И") {
            Utils.ShowNavBarTask("Запрос 2. Риэлторы, фамилия которых начинается с буквы \"И\" и процент вознаграждения больше 10%");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      Realtors.Id
                      , Persons.Surname
                      , Persons.[Name]
                      , Persons.Patronymic
                      , Realtors.[Percent]
                  from
                      Realtors join Persons on Realtors.IdPerson = Persons.Id
                  where
                      Persons.Surname like (@surname + N'%') and Realtors.[Percent] > @percent;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@percent", percent);
                cmd.Parameters.AddWithValue("@surname", surname);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬─────────────────┬─────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-15} │ {reader.GetName(3),-15} │ {reader.GetName(4),-7} │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼─────────────────┼─────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),-15} │ " +
                            $"{reader.GetString(3),-15} │ {reader.GetDouble(4),7:n2} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴─────────────────┴─────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query02


        // 3. Запрос с параметрами	
        //    Выбирает информацию об 1-комнатных квартирах, цена на которых
        //    находится в диапазоне от 900 000 руб. до 1000 000 руб.
        //    Значения задавать параметрами запроса
        public void Query03(int roomNum = 1, int lo = 900_000, int hi = 1_000_000) {
            Utils.ShowNavBarTask("Запрос 3. 1-комнатные квартиры, цена которых от 900 000 руб. до 1000 000 руб");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      Apartments.Id
                      , Streets.Street
                      , Apartments.Building
                      , Apartments.Flat
                      , Apartments.Area
                      , Apartments.RoomNum
                      , Offers.Price
                  from
                      Apartments join Streets on Apartments.IdStreet = Streets.Id
                                 join Offers on Apartments.Id = Offers.IdApartment
                  where
                      Apartments.RoomNum = @roomNum and Offers.Price between @lo and @hi;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬────────────┬────────────┬───────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-10} │ {reader.GetName(3),-10} │ {reader.GetName(4),-5} │ {reader.GetName(5),-10} │ {reader.GetName(6),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼────────────┼────────────┼───────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),10} │ " +
                            $"{reader.GetInt32(3),10} │ {reader.GetInt32(4),5:n2} │ {reader.GetInt32(5),10} │ {reader.GetInt32(6),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴────────────┴────────────┴───────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query03


        // 4. Запрос с параметрами
        //    Выбирает информацию о квартирах с заданным числом комнат.
        //    Значения задавать параметрами запроса
        public void Query04(int roomNum) {
            Utils.ShowNavBarTask("Запрос 4. Квартиры с заданным числом комнат");
            Console.WriteLine($"\nЗаданное число комнат:{roomNum}");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("Соединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      Apartments.Id
                      , Streets.Street
                      , Apartments.Building
                      , Apartments.Flat
                      , Apartments.Area
                      , Apartments.RoomNum
                      , Offers.Price
                  from
                      Apartments join Streets on Apartments.IdStreet = Streets.Id
                                 join Offers on Apartments.Id = Offers.IdApartment
                  where
                      Apartments.RoomNum = @roomNum;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬────────────┬────────────┬──────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-10} │ {reader.GetName(3),-10} │ {reader.GetName(4),-8} │ {reader.GetName(5),-10} │ {reader.GetName(6),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼────────────┼────────────┼──────────┼────────────┼────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),10} │ " +
                            $"{reader.GetInt32(3),10} │ {reader.GetInt32(4),8:n2} │ {reader.GetInt32(5),10} │ {reader.GetInt32(6),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴────────────┴────────────┴──────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query04


        // 5. Запрос с параметрами	
        //    Выбирает информацию обо всех 2-комнатных квартирах,
        //    площадь которых есть значение из некоторого диапазона.
        //    Значения задавать параметрами запроса
        public void Query05(int roomNum = 2, int lo = 80, int hi = 120) {
            Utils.ShowNavBarTask("Запрос 5. 2-комнатные квартиры, площадь которых есть значение из некоторого диапазона");
            Console.WriteLine($"\nЗаданный диапазон: от {lo:n2} до {hi:n2}");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("Соединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      Apartments.Id
                      , Streets.Street
                      , Apartments.Building
                      , Apartments.Flat
                      , Apartments.Area
                      , Apartments.RoomNum
                      , Offers.Price
                  from
                      Apartments join Streets on Apartments.IdStreet = Streets.Id
                                 join Offers on Apartments.Id = Offers.IdApartment
                  where
                      Apartments.RoomNum = @roomNum --and Apartments.Area between @lo and @hi;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬────────────┬────────────┬───────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-10} │ {reader.GetName(3),-10} │ {reader.GetName(4),-5} │ {reader.GetName(5),-10} │ {reader.GetName(6),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼────────────┼────────────┼───────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),10} │ " +
                            $"{reader.GetInt32(3),10} │ {reader.GetInt32(4),5:n2} │ {reader.GetInt32(5),10} │ {reader.GetInt32(6),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴────────────┴────────────┴───────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query05


        // 6. Запрос с вычисляемыми полями	
        //    Вычисляет для каждой оформленной сделки размер комиссионного
        //    вознаграждения риэлтора.
        //    Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора,
        //    Дата сделки, Цена квартиры, Комиссионные.
        //    Сортировка по полю Дата сделки
        public void Query06() {
            Utils.ShowNavBarTask("Запрос 6. Вычислить для каждой оформленной сделки размер комиссионного вознаграждения риэлтора");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      Persons.Surname
                      , Persons.[Name]
                      , Persons.Patronymic
                      , Deals.DealDate
                      , Deals.DealPrice
                      , Realtors.[Percent]
                      , Deals.DealPrice * Realtors.[Percent] / 100 as Fee
                  from
                      Deals join (Realtors join Persons on Realtors.IdPerson = Persons.Id) 
                          on Deals.IdRealtor = Realtors.Id
                  order by
                      Deals.DealDate;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌─────────────────┬─────────────────┬─────────────────┬────────────┬─────────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-15} │ " +
                        $"{reader.GetName(1),-15} │ {reader.GetName(2),-15} │ {reader.GetName(3),-10} │ {reader.GetName(4),-15} │ {reader.GetName(5),-10} │ {reader.GetName(6),-10} │");
                    Console.WriteLine("\t├─────────────────┼─────────────────┼─────────────────┼────────────┼─────────────────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-15} │ {reader.GetString(1),-15} │ " +
                            $"{reader.GetString(2),-15} │ {reader.GetDateTime(3),10:dd/MM/yyyy} │ " +
                            $"{reader.GetInt32(4),15:n2} │ {reader.GetDouble(5),10:n2} │ {reader.GetDouble(6),10:n2} │");
                    } // while
                    Console.WriteLine("\t└─────────────────┴─────────────────┴─────────────────┴────────────┴─────────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query06


        // 7. Запрос на левое соединение	
        //    Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки
        //    и сумму сделок риэлтора. Упорядочить выборку по убыванию суммы сделок.
        public void Query07() {
            Utils.ShowNavBarTask("Запрос 7. Все риэлторы, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      -- данные риелтора - группа
                      Realtors.Id
                      , Persons.Surname
                      , Persons.[Name]
                      , Persons.Patronymic
                      -- агрегатные функции
                      , ISNULL(Count(Deals.IdOffer), 0) as ClientTotal 
                      , ISNULL(Sum(Deals.DealPrice), 0) as RealtorSum
                  from
                      (Realtors join Persons on Realtors.IdPerson = Persons.Id)
                          left join 
                      Deals on Realtors.Id = Deals.IdRealtor
                  group by
                      Realtors.Id, Persons.Surname, Persons.[Name], Persons.Patronymic;"
                );

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬─────────────────┬──────────────┬──────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-15} │ {reader.GetName(3),-15} │ {reader.GetName(4),-12} │ {reader.GetName(5),-12} │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼─────────────────┼──────────────┼──────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),-15} │ " +
                            $"{reader.GetString(3),-15} │ {reader.GetInt32(4),12} │ {reader.GetInt32(5), 12:n2} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴─────────────────┴──────────────┴──────────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query07


        // 8. Запрос на левое соединение	
        //    Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
        public void Query08() {
            Utils.ShowNavBarTask("Запрос 8. Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      Streets.Street
                      , ISNULL(Sum(Deals.DealPrice), 0) as SumDeals
                  from
                      Streets left join (Apartments join (Offers join Deals on Offers.Id = Deals.IdOffer) on Apartments.Id = Offers.IdApartment) 
                          on Streets.Id = Apartments.IdStreet
                  group by
                      Streets.Street
                  order by 
                      SumDeals desc;"
                );

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌───────────────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-17} │ {reader.GetName(1),-15} │");
                    Console.WriteLine("\t├───────────────────┼─────────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-17} │ {reader.GetInt32(1), 15:n2} │");
                    } // while
                    Console.WriteLine("\t└───────────────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query08


        // 9. Запрос на левое соединение	
        //    Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку
        //    по убыванию суммы сделки. Диапазон задавать параметрами запроса
        // {reader.GetDateTime(3),10:dd/MM/yyyy}
        public void Query09(DateTime from, DateTime to) {
            Utils.ShowNavBarTask("Запрос 9. Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки");
            Console.WriteLine($"\nЗаданный диапазон: c {from,10:dd/MM/yyyy} до {to,10:dd/MM/yyyy}");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("Соединение открыто");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      Streets.Street
                      , ISNULL(COUNT(PeriodDeals.DealPrice), 0) as Amount
                      , ISNULL(SUM(PeriodDeals.DealPrice), 0) as Total
                  from
                      Streets left join 
                          -- данные по сделкам за период извлекаем при помощи подзапроса, требуется назначить 
                          -- псевдоним этому подзапросу
                          (select Deals.DealDate, Deals.DealPrice, Apartments.IdStreet from (Deals join (Offers join Apartments on Offers.IdApartment = Apartments.Id) on Deals.IdOffer = Offers.Id)  
                           where Deals.DealDate between @from and @to) PeriodDeals
                      on Streets.Id = PeriodDeals.IdStreet
                  group by
                      Streets.Street
                  order by
                      Total desc;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to", to);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌───────────────────┬────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-17} │ {reader.GetName(1),-6} │ {reader.GetName(2),-15} │");
                    Console.WriteLine("\t├───────────────────┼────────┼─────────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-17} │ {reader.GetInt32(1),6} │ {reader.GetInt32(2), 15:n2} │");
                    } // while
                    Console.WriteLine("\t└───────────────────┴────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine("Соединение закрыто");
            Console.WriteLine();
        } // Query09
    } // App
}
