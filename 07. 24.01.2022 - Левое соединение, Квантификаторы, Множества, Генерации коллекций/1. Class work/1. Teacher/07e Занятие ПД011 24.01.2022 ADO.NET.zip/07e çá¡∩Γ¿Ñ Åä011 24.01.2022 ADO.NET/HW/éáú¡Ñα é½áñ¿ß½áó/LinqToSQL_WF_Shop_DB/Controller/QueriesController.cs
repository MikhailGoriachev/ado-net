﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqToSQL_WF_Shop_DB.Models;
using LinqToSQL_WF_Shop_DB.Utilities;
using LinqToSQL_WF_Shop_DB.Views;

namespace LinqToSQL_WF_Shop_DB.Controller
{
    public class QueriesController
    {
        //Доступ к базе данных
        Shop_DBDataContext _dataContext;

        public QueriesController():this(new Shop_DBDataContext())
        {}

        public QueriesController(Shop_DBDataContext dc)
        {
            _dataContext = dc;
        } //ctor 

        #region Запросы LinqToSQL

        /*Запрос_1: Выбирает из таблицы ТОВАРЫ информацию о товарах, 
         *          единицей измерения которых является «шт» (штуки) 
         *          и цена закупки составляет меньше 20'000 руб.*/
        public List<PurchasesViewModel> Query_1()
            => _dataContext.Purchases
                                    .Where(P => P.Unit.Short.ToLower() == "шт" && P.Purchase_price < 20_000)
                                    .Select(P => new PurchasesViewModel()
                                    {
                                        GoodsName = P.Good.Good_name,
                                        UnitShort = P.Unit.Short,
                                        Price = P.Purchase_price,
                                        Amount = P.Amount,
                                        Date = P.DatePurchase
                                    })
                                    .ToList();

        /*Запрос_2: Выбирает из таблицы ТОВАРЫ информацию о товарах, 
         * цена закупки которых больше 500 руб. за единицу товара*/
        public List<PurchasesViewModel> Query_2()
            => _dataContext.Purchases
                                    .Where(P => P.Purchase_price > 5_000)
                                    .Select(P => new PurchasesViewModel()
                                    {
                                        GoodsName = P.Good.Good_name,
                                        UnitShort = P.Unit.Short,
                                        Price = P.Purchase_price,
                                        Amount = P.Amount,
                                        Date = P.DatePurchase
                                    })
                                    .ToList();

        /*Запрос_3: Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием (например, «чехол защитный»), 
         *          для которых цена закупки меньше 1800 руб.*/
        public List<PurchasesViewModel> Query_3(string goodsName, int price = 20_000)
            => _dataContext.Purchases
                                    .Where(P => P.Purchase_price < price && P.Good.Good_name.ToLower() == goodsName.ToLower())
                                    .Select(P => new PurchasesViewModel()
                                    {
                                        GoodsName = P.Good.Good_name,
                                        UnitShort = P.Unit.Short,
                                        Price = P.Purchase_price,
                                        Amount = P.Amount,
                                        Date = P.DatePurchase
                                    })
                                    .ToList();

        //Для Comboxo в запросе 3
        public SortedSet<string> GoodsNames
            => new SortedSet<string>(_dataContext.Purchases.Select(P => P.Good.Good_name).ToList());


        /*Запрос_4: Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах 
         *          с заданным значением процента комиссионных.*/
        public List<SellersViewModel> Query_4(double interest)
            => _dataContext.Sellers
            .Where(Seller => Seller.Interest.CompareTo(interest) == 0)
            .Select(S => new SellersViewModel()
                        {
                            SellerSNP = $"{S.Surname}.{S.Name_s.Substring(0, 1)}.{S.Patronymic.Substring(0, 1)}",
                            Interest = S.Interest*100
                        }
            )
            .ToList();

        public SortedSet<double> GetInterests
            => new SortedSet<double>(_dataContext.Sellers.Select(S => S.Interest).ToList());


        #endregion
    }
}
