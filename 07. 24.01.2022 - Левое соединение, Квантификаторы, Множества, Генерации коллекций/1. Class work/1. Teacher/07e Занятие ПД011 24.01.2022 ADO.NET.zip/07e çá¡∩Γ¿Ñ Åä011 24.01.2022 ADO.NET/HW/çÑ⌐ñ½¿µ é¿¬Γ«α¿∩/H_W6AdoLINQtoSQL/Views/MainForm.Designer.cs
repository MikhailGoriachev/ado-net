﻿
namespace H_W6AdoLINQtoSQL
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAboutProgram = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbMain = new System.Windows.Forms.ToolStrip();
            this.TcbQuery1 = new System.Windows.Forms.ToolStripButton();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.Tbc01 = new System.Windows.Forms.TabPage();
            this.DgvQuery01 = new System.Windows.Forms.DataGridView();
            this.LblDgv1 = new System.Windows.Forms.Label();
            this.Tbc02 = new System.Windows.Forms.TabPage();
            this.DgvQuery02 = new System.Windows.Forms.DataGridView();
            this.LblDgv2 = new System.Windows.Forms.Label();
            this.Tbc03 = new System.Windows.Forms.TabPage();
            this.DgvQeury03 = new System.Windows.Forms.DataGridView();
            this.LblDgv3 = new System.Windows.Forms.Label();
            this.Tbc04 = new System.Windows.Forms.TabPage();
            this.DgvQuery04 = new System.Windows.Forms.DataGridView();
            this.LblDgv4 = new System.Windows.Forms.Label();
            this.Tbc05 = new System.Windows.Forms.TabPage();
            this.DgvQuery05 = new System.Windows.Forms.DataGridView();
            this.LblDgv5 = new System.Windows.Forms.Label();
            this.Tbc06 = new System.Windows.Forms.TabPage();
            this.DgvQuery06 = new System.Windows.Forms.DataGridView();
            this.LblDgv6 = new System.Windows.Forms.Label();
            this.Tbc07 = new System.Windows.Forms.TabPage();
            this.DgvQuery07 = new System.Windows.Forms.DataGridView();
            this.LblDgv7 = new System.Windows.Forms.Label();
            this.Tbc08 = new System.Windows.Forms.TabPage();
            this.LblDgv8 = new System.Windows.Forms.Label();
            this.DgvQuery08 = new System.Windows.Forms.DataGridView();
            this.TcbQuery2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TcbQuery3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TcbQuery4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TcbQuery5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.TcbQuery6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.TcbQuery7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.TcbQuery8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.TcbAboutProgram = new System.Windows.Forms.ToolStripButton();
            this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.CmnNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiNotifyRestore = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifyAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiNotifyExit = new System.Windows.Forms.ToolStripMenuItem();
            this.TcbToTray = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsViewModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameSellerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceSaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateSaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.allSalesViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dateSaleDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceSaleDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountSaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.profitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountPurchaseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.avgPricepurchaseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calculationViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idSellerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.avgPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameSellerDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calculateSellesViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.MnuMain.SuspendLayout();
            this.TsbMain.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.Tbc01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).BeginInit();
            this.Tbc02.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).BeginInit();
            this.Tbc03.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQeury03)).BeginInit();
            this.Tbc04.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).BeginInit();
            this.Tbc05.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).BeginInit();
            this.Tbc06.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).BeginInit();
            this.Tbc07.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery07)).BeginInit();
            this.Tbc08.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery08)).BeginInit();
            this.CmnNotify.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.goodsViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodsViewModelBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.allSalesViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.calculationViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.calculateSellesViewModelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.MniHelp});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(984, 24);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // MniExit
            // 
            this.MniExit.Image = ((System.Drawing.Image)(resources.GetObject("MniExit.Image")));
            this.MniExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniExit.Name = "MniExit";
            this.MniExit.Size = new System.Drawing.Size(138, 34);
            this.MniExit.Text = "Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniAboutProgram});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(90, 20);
            this.MniHelp.Text = "Справка";
            // 
            // MniAboutProgram
            // 
            this.MniAboutProgram.Image = ((System.Drawing.Image)(resources.GetObject("MniAboutProgram.Image")));
            this.MniAboutProgram.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniAboutProgram.Name = "MniAboutProgram";
            this.MniAboutProgram.Size = new System.Drawing.Size(222, 38);
            this.MniAboutProgram.Text = "О программе..";
            this.MniAboutProgram.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbMain
            // 
            this.TsbMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TcbQuery1,
            this.toolStripSeparator1,
            this.TcbQuery2,
            this.toolStripSeparator2,
            this.TcbQuery3,
            this.toolStripSeparator3,
            this.TcbQuery4,
            this.toolStripSeparator4,
            this.TcbQuery5,
            this.toolStripSeparator5,
            this.TcbQuery6,
            this.toolStripSeparator6,
            this.TcbQuery7,
            this.toolStripSeparator7,
            this.TcbQuery8,
            this.toolStripSeparator8,
            this.TcbToTray,
            this.toolStripSeparator9,
            this.TcbAboutProgram});
            this.TsbMain.Location = new System.Drawing.Point(0, 24);
            this.TsbMain.Name = "TsbMain";
            this.TsbMain.Size = new System.Drawing.Size(984, 39);
            this.TsbMain.TabIndex = 1;
            this.TsbMain.Text = "toolStrip1";
            // 
            // TcbQuery1
            // 
            this.TcbQuery1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery1.Image = ((System.Drawing.Image)(resources.GetObject("TcbQuery1.Image")));
            this.TcbQuery1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery1.Name = "TcbQuery1";
            this.TcbQuery1.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery1.Text = "toolStripButton1";
            this.TcbQuery1.ToolTipText = "Запрос 1";
            this.TcbQuery1.Click += new System.EventHandler(this.Query01_Command);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.Tbc01);
            this.TbcMain.Controls.Add(this.Tbc02);
            this.TbcMain.Controls.Add(this.Tbc03);
            this.TbcMain.Controls.Add(this.Tbc04);
            this.TbcMain.Controls.Add(this.Tbc05);
            this.TbcMain.Controls.Add(this.Tbc06);
            this.TbcMain.Controls.Add(this.Tbc07);
            this.TbcMain.Controls.Add(this.Tbc08);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Location = new System.Drawing.Point(0, 63);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(984, 498);
            this.TbcMain.TabIndex = 2;
            // 
            // Tbc01
            // 
            this.Tbc01.Controls.Add(this.DgvQuery01);
            this.Tbc01.Controls.Add(this.LblDgv1);
            this.Tbc01.Location = new System.Drawing.Point(4, 26);
            this.Tbc01.Name = "Tbc01";
            this.Tbc01.Padding = new System.Windows.Forms.Padding(3);
            this.Tbc01.Size = new System.Drawing.Size(976, 468);
            this.Tbc01.TabIndex = 0;
            this.Tbc01.Text = "Запрос 1";
            this.Tbc01.UseVisualStyleBackColor = true;
            // 
            // DgvQuery01
            // 
            this.DgvQuery01.AllowDrop = true;
            this.DgvQuery01.AllowUserToAddRows = false;
            this.DgvQuery01.AllowUserToDeleteRows = false;
            this.DgvQuery01.AutoGenerateColumns = false;
            this.DgvQuery01.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery01.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.DgvQuery01.DataSource = this.goodsViewModelBindingSource;
            this.DgvQuery01.Location = new System.Drawing.Point(8, 57);
            this.DgvQuery01.MultiSelect = false;
            this.DgvQuery01.Name = "DgvQuery01";
            this.DgvQuery01.ReadOnly = true;
            this.DgvQuery01.RowHeadersVisible = false;
            this.DgvQuery01.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery01.Size = new System.Drawing.Size(968, 417);
            this.DgvQuery01.TabIndex = 2;
            // 
            // LblDgv1
            // 
            this.LblDgv1.Location = new System.Drawing.Point(3, 3);
            this.LblDgv1.Name = "LblDgv1";
            this.LblDgv1.Size = new System.Drawing.Size(965, 51);
            this.LblDgv1.TabIndex = 1;
            this.LblDgv1.Text = "Оптовый магазин. Учет продаж";
            this.LblDgv1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Tbc02
            // 
            this.Tbc02.Controls.Add(this.DgvQuery02);
            this.Tbc02.Controls.Add(this.LblDgv2);
            this.Tbc02.Location = new System.Drawing.Point(4, 26);
            this.Tbc02.Name = "Tbc02";
            this.Tbc02.Padding = new System.Windows.Forms.Padding(3);
            this.Tbc02.Size = new System.Drawing.Size(976, 468);
            this.Tbc02.TabIndex = 1;
            this.Tbc02.Text = "Запрос 2";
            this.Tbc02.UseVisualStyleBackColor = true;
            // 
            // DgvQuery02
            // 
            this.DgvQuery02.AllowDrop = true;
            this.DgvQuery02.AllowUserToAddRows = false;
            this.DgvQuery02.AllowUserToDeleteRows = false;
            this.DgvQuery02.AutoGenerateColumns = false;
            this.DgvQuery02.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQuery02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery02.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15});
            this.DgvQuery02.DataSource = this.goodsViewModelBindingSource1;
            this.DgvQuery02.Location = new System.Drawing.Point(6, 57);
            this.DgvQuery02.MultiSelect = false;
            this.DgvQuery02.Name = "DgvQuery02";
            this.DgvQuery02.ReadOnly = true;
            this.DgvQuery02.RowHeadersVisible = false;
            this.DgvQuery02.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery02.Size = new System.Drawing.Size(967, 417);
            this.DgvQuery02.TabIndex = 4;
            // 
            // LblDgv2
            // 
            this.LblDgv2.Location = new System.Drawing.Point(3, 3);
            this.LblDgv2.Name = "LblDgv2";
            this.LblDgv2.Size = new System.Drawing.Size(965, 51);
            this.LblDgv2.TabIndex = 3;
            this.LblDgv2.Text = "Оптовый магазин. Учет продаж";
            this.LblDgv2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Tbc03
            // 
            this.Tbc03.Controls.Add(this.DgvQeury03);
            this.Tbc03.Controls.Add(this.LblDgv3);
            this.Tbc03.Location = new System.Drawing.Point(4, 26);
            this.Tbc03.Name = "Tbc03";
            this.Tbc03.Padding = new System.Windows.Forms.Padding(3);
            this.Tbc03.Size = new System.Drawing.Size(976, 468);
            this.Tbc03.TabIndex = 2;
            this.Tbc03.Text = "Запрос 3";
            this.Tbc03.UseVisualStyleBackColor = true;
            // 
            // DgvQeury03
            // 
            this.DgvQeury03.AllowDrop = true;
            this.DgvQeury03.AllowUserToAddRows = false;
            this.DgvQeury03.AllowUserToDeleteRows = false;
            this.DgvQeury03.AutoGenerateColumns = false;
            this.DgvQeury03.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQeury03.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQeury03.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20});
            this.DgvQeury03.DataSource = this.goodsViewModelBindingSource;
            this.DgvQeury03.Location = new System.Drawing.Point(6, 57);
            this.DgvQeury03.MultiSelect = false;
            this.DgvQeury03.Name = "DgvQeury03";
            this.DgvQeury03.ReadOnly = true;
            this.DgvQeury03.RowHeadersVisible = false;
            this.DgvQeury03.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQeury03.Size = new System.Drawing.Size(967, 419);
            this.DgvQeury03.TabIndex = 5;
            // 
            // LblDgv3
            // 
            this.LblDgv3.Location = new System.Drawing.Point(3, 3);
            this.LblDgv3.Name = "LblDgv3";
            this.LblDgv3.Size = new System.Drawing.Size(965, 51);
            this.LblDgv3.TabIndex = 4;
            this.LblDgv3.Text = "Оптовый магазин. Учет продаж";
            this.LblDgv3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Tbc04
            // 
            this.Tbc04.Controls.Add(this.DgvQuery04);
            this.Tbc04.Controls.Add(this.LblDgv4);
            this.Tbc04.Location = new System.Drawing.Point(4, 26);
            this.Tbc04.Name = "Tbc04";
            this.Tbc04.Padding = new System.Windows.Forms.Padding(3);
            this.Tbc04.Size = new System.Drawing.Size(976, 468);
            this.Tbc04.TabIndex = 3;
            this.Tbc04.Text = "Запрос 4";
            this.Tbc04.UseVisualStyleBackColor = true;
            // 
            // DgvQuery04
            // 
            this.DgvQuery04.AllowDrop = true;
            this.DgvQuery04.AllowUserToAddRows = false;
            this.DgvQuery04.AllowUserToDeleteRows = false;
            this.DgvQuery04.AutoGenerateColumns = false;
            this.DgvQuery04.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery04.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQuery04.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery04.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.surnameDataGridViewTextBoxColumn,
            this.nameSellerDataGridViewTextBoxColumn,
            this.patronymicDataGridViewTextBoxColumn,
            this.interestDataGridViewTextBoxColumn});
            this.DgvQuery04.DataSource = this.sellerViewModelBindingSource;
            this.DgvQuery04.Location = new System.Drawing.Point(6, 57);
            this.DgvQuery04.MultiSelect = false;
            this.DgvQuery04.Name = "DgvQuery04";
            this.DgvQuery04.ReadOnly = true;
            this.DgvQuery04.RowHeadersVisible = false;
            this.DgvQuery04.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery04.Size = new System.Drawing.Size(964, 417);
            this.DgvQuery04.TabIndex = 3;
            // 
            // LblDgv4
            // 
            this.LblDgv4.Location = new System.Drawing.Point(3, 3);
            this.LblDgv4.Name = "LblDgv4";
            this.LblDgv4.Size = new System.Drawing.Size(965, 51);
            this.LblDgv4.TabIndex = 2;
            this.LblDgv4.Text = "Оптовый магазин. Учет продаж";
            this.LblDgv4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Tbc05
            // 
            this.Tbc05.Controls.Add(this.DgvQuery05);
            this.Tbc05.Controls.Add(this.LblDgv5);
            this.Tbc05.Location = new System.Drawing.Point(4, 26);
            this.Tbc05.Name = "Tbc05";
            this.Tbc05.Padding = new System.Windows.Forms.Padding(3);
            this.Tbc05.Size = new System.Drawing.Size(976, 468);
            this.Tbc05.TabIndex = 4;
            this.Tbc05.Text = "Запрос 5";
            this.Tbc05.UseVisualStyleBackColor = true;
            // 
            // DgvQuery05
            // 
            this.DgvQuery05.AllowDrop = true;
            this.DgvQuery05.AllowUserToAddRows = false;
            this.DgvQuery05.AllowUserToDeleteRows = false;
            this.DgvQuery05.AutoGenerateColumns = false;
            this.DgvQuery05.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQuery05.ColumnHeadersHeight = 40;
            this.DgvQuery05.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.priceSaleDataGridViewTextBoxColumn,
            this.dateSaleDataGridViewTextBoxColumn});
            this.DgvQuery05.DataSource = this.allSalesViewModelBindingSource;
            this.DgvQuery05.Location = new System.Drawing.Point(3, 57);
            this.DgvQuery05.MultiSelect = false;
            this.DgvQuery05.Name = "DgvQuery05";
            this.DgvQuery05.ReadOnly = true;
            this.DgvQuery05.RowHeadersVisible = false;
            this.DgvQuery05.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery05.Size = new System.Drawing.Size(970, 419);
            this.DgvQuery05.TabIndex = 4;
            // 
            // LblDgv5
            // 
            this.LblDgv5.Location = new System.Drawing.Point(3, 3);
            this.LblDgv5.Name = "LblDgv5";
            this.LblDgv5.Size = new System.Drawing.Size(965, 51);
            this.LblDgv5.TabIndex = 3;
            this.LblDgv5.Text = "Оптовый магазин. Учет продаж";
            this.LblDgv5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Tbc06
            // 
            this.Tbc06.Controls.Add(this.DgvQuery06);
            this.Tbc06.Controls.Add(this.LblDgv6);
            this.Tbc06.Location = new System.Drawing.Point(4, 26);
            this.Tbc06.Name = "Tbc06";
            this.Tbc06.Padding = new System.Windows.Forms.Padding(3);
            this.Tbc06.Size = new System.Drawing.Size(976, 468);
            this.Tbc06.TabIndex = 5;
            this.Tbc06.Text = "Запрос 6";
            this.Tbc06.UseVisualStyleBackColor = true;
            // 
            // DgvQuery06
            // 
            this.DgvQuery06.AllowDrop = true;
            this.DgvQuery06.AllowUserToAddRows = false;
            this.DgvQuery06.AllowUserToDeleteRows = false;
            this.DgvQuery06.AutoGenerateColumns = false;
            this.DgvQuery06.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQuery06.ColumnHeadersHeight = 40;
            this.DgvQuery06.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dateSaleDataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.priceSaleDataGridViewTextBoxColumn1,
            this.amountSaleDataGridViewTextBoxColumn,
            this.profitDataGridViewTextBoxColumn});
            this.DgvQuery06.DataSource = this.saleViewModelBindingSource;
            this.DgvQuery06.Location = new System.Drawing.Point(6, 57);
            this.DgvQuery06.MultiSelect = false;
            this.DgvQuery06.Name = "DgvQuery06";
            this.DgvQuery06.ReadOnly = true;
            this.DgvQuery06.RowHeadersVisible = false;
            this.DgvQuery06.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery06.Size = new System.Drawing.Size(967, 419);
            this.DgvQuery06.TabIndex = 5;
            // 
            // LblDgv6
            // 
            this.LblDgv6.Location = new System.Drawing.Point(3, 3);
            this.LblDgv6.Name = "LblDgv6";
            this.LblDgv6.Size = new System.Drawing.Size(965, 51);
            this.LblDgv6.TabIndex = 4;
            this.LblDgv6.Text = "Оптовый магазин. Учет продаж";
            this.LblDgv6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Tbc07
            // 
            this.Tbc07.Controls.Add(this.DgvQuery07);
            this.Tbc07.Controls.Add(this.LblDgv7);
            this.Tbc07.Location = new System.Drawing.Point(4, 26);
            this.Tbc07.Name = "Tbc07";
            this.Tbc07.Padding = new System.Windows.Forms.Padding(3);
            this.Tbc07.Size = new System.Drawing.Size(976, 468);
            this.Tbc07.TabIndex = 6;
            this.Tbc07.Text = "Запрос 7";
            this.Tbc07.UseVisualStyleBackColor = true;
            // 
            // DgvQuery07
            // 
            this.DgvQuery07.AllowDrop = true;
            this.DgvQuery07.AllowUserToAddRows = false;
            this.DgvQuery07.AllowUserToDeleteRows = false;
            this.DgvQuery07.AutoGenerateColumns = false;
            this.DgvQuery07.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQuery07.ColumnHeadersHeight = 40;
            this.DgvQuery07.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn25,
            this.amountPurchaseDataGridViewTextBoxColumn,
            this.avgPricepurchaseDataGridViewTextBoxColumn});
            this.DgvQuery07.DataSource = this.calculationViewModelBindingSource;
            this.DgvQuery07.Location = new System.Drawing.Point(6, 57);
            this.DgvQuery07.MultiSelect = false;
            this.DgvQuery07.Name = "DgvQuery07";
            this.DgvQuery07.ReadOnly = true;
            this.DgvQuery07.RowHeadersVisible = false;
            this.DgvQuery07.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery07.Size = new System.Drawing.Size(967, 419);
            this.DgvQuery07.TabIndex = 6;
            // 
            // LblDgv7
            // 
            this.LblDgv7.Location = new System.Drawing.Point(3, 3);
            this.LblDgv7.Name = "LblDgv7";
            this.LblDgv7.Size = new System.Drawing.Size(965, 51);
            this.LblDgv7.TabIndex = 5;
            this.LblDgv7.Text = "Оптовый магазин. Учет продаж";
            this.LblDgv7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Tbc08
            // 
            this.Tbc08.Controls.Add(this.DgvQuery08);
            this.Tbc08.Controls.Add(this.LblDgv8);
            this.Tbc08.Location = new System.Drawing.Point(4, 26);
            this.Tbc08.Name = "Tbc08";
            this.Tbc08.Padding = new System.Windows.Forms.Padding(3);
            this.Tbc08.Size = new System.Drawing.Size(976, 468);
            this.Tbc08.TabIndex = 7;
            this.Tbc08.Text = "Запрос 8";
            this.Tbc08.UseVisualStyleBackColor = true;
            // 
            // LblDgv8
            // 
            this.LblDgv8.Location = new System.Drawing.Point(3, 3);
            this.LblDgv8.Name = "LblDgv8";
            this.LblDgv8.Size = new System.Drawing.Size(965, 51);
            this.LblDgv8.TabIndex = 6;
            this.LblDgv8.Text = "Оптовый магазин. Учет продаж";
            this.LblDgv8.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // DgvQuery08
            // 
            this.DgvQuery08.AllowDrop = true;
            this.DgvQuery08.AllowUserToAddRows = false;
            this.DgvQuery08.AllowUserToDeleteRows = false;
            this.DgvQuery08.AutoGenerateColumns = false;
            this.DgvQuery08.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.DgvQuery08.ColumnHeadersHeight = 40;
            this.DgvQuery08.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idSellerDataGridViewTextBoxColumn,
            this.salesAmountDataGridViewTextBoxColumn,
            this.avgPriceDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn1,
            this.nameSellerDataGridViewTextBoxColumn1,
            this.patronymicDataGridViewTextBoxColumn1,
            this.interestDataGridViewTextBoxColumn1});
            this.DgvQuery08.DataSource = this.calculateSellesViewModelBindingSource;
            this.DgvQuery08.Location = new System.Drawing.Point(6, 57);
            this.DgvQuery08.MultiSelect = false;
            this.DgvQuery08.Name = "DgvQuery08";
            this.DgvQuery08.ReadOnly = true;
            this.DgvQuery08.RowHeadersVisible = false;
            this.DgvQuery08.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery08.Size = new System.Drawing.Size(967, 422);
            this.DgvQuery08.TabIndex = 7;
            // 
            // TcbQuery2
            // 
            this.TcbQuery2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery2.Image = ((System.Drawing.Image)(resources.GetObject("TcbQuery2.Image")));
            this.TcbQuery2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery2.Name = "TcbQuery2";
            this.TcbQuery2.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery2.Text = "toolStripButton1";
            this.TcbQuery2.ToolTipText = "Запрос 2";
            this.TcbQuery2.Click += new System.EventHandler(this.Query02_Comman);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TcbQuery3
            // 
            this.TcbQuery3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery3.Image = ((System.Drawing.Image)(resources.GetObject("TcbQuery3.Image")));
            this.TcbQuery3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery3.Name = "TcbQuery3";
            this.TcbQuery3.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery3.Text = "toolStripButton1";
            this.TcbQuery3.ToolTipText = "Запрос 3";
            this.TcbQuery3.Click += new System.EventHandler(this.Query03_Comman);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TcbQuery4
            // 
            this.TcbQuery4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery4.Image = ((System.Drawing.Image)(resources.GetObject("TcbQuery4.Image")));
            this.TcbQuery4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery4.Name = "TcbQuery4";
            this.TcbQuery4.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery4.Text = "toolStripButton2";
            this.TcbQuery4.ToolTipText = "Запрос 4";
            this.TcbQuery4.Click += new System.EventHandler(this.Query04_Comman);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // TcbQuery5
            // 
            this.TcbQuery5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery5.Image = ((System.Drawing.Image)(resources.GetObject("TcbQuery5.Image")));
            this.TcbQuery5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery5.Name = "TcbQuery5";
            this.TcbQuery5.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery5.Text = "toolStripButton3";
            this.TcbQuery5.ToolTipText = "Запрос 5";
            this.TcbQuery5.Click += new System.EventHandler(this.Query05_Comman);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
            // 
            // TcbQuery6
            // 
            this.TcbQuery6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery6.Image = ((System.Drawing.Image)(resources.GetObject("TcbQuery6.Image")));
            this.TcbQuery6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery6.Name = "TcbQuery6";
            this.TcbQuery6.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery6.Text = "toolStripButton4";
            this.TcbQuery6.ToolTipText = "Запрос 6";
            this.TcbQuery6.Click += new System.EventHandler(this.Query06_Comman);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 39);
            // 
            // TcbQuery7
            // 
            this.TcbQuery7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery7.Image = ((System.Drawing.Image)(resources.GetObject("TcbQuery7.Image")));
            this.TcbQuery7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery7.Name = "TcbQuery7";
            this.TcbQuery7.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery7.Text = "toolStripButton5";
            this.TcbQuery7.ToolTipText = "Запрос 7";
            this.TcbQuery7.Click += new System.EventHandler(this.Query07_Comman);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 39);
            // 
            // TcbQuery8
            // 
            this.TcbQuery8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbQuery8.Image = ((System.Drawing.Image)(resources.GetObject("TcbQuery8.Image")));
            this.TcbQuery8.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbQuery8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbQuery8.Name = "TcbQuery8";
            this.TcbQuery8.Size = new System.Drawing.Size(36, 36);
            this.TcbQuery8.Text = "toolStripButton6";
            this.TcbQuery8.ToolTipText = "Запрос 8";
            this.TcbQuery8.Click += new System.EventHandler(this.Query08_Comman);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 39);
            // 
            // TcbAboutProgram
            // 
            this.TcbAboutProgram.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbAboutProgram.Image = ((System.Drawing.Image)(resources.GetObject("TcbAboutProgram.Image")));
            this.TcbAboutProgram.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbAboutProgram.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbAboutProgram.Name = "TcbAboutProgram";
            this.TcbAboutProgram.Size = new System.Drawing.Size(36, 36);
            this.TcbAboutProgram.Text = "toolStripButton7";
            this.TcbAboutProgram.ToolTipText = "О программе..";
            this.TcbAboutProgram.Click += new System.EventHandler(this.About_Command);
            // 
            // NtiMain
            // 
            this.NtiMain.ContextMenuStrip = this.CmnNotify;
            this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
            this.NtiMain.Text = "Оптовый магазин.Учёт продаж.";
            this.NtiMain.Visible = true;
            // 
            // CmnNotify
            // 
            this.CmnNotify.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.CmnNotify.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CmnNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiNotifyRestore,
            this.CmiNotifyAbout,
            this.toolStripMenuItem1,
            this.CmiNotifyExit});
            this.CmnNotify.Name = "CmnNotify";
            this.CmnNotify.Size = new System.Drawing.Size(183, 88);
            // 
            // CmiNotifyRestore
            // 
            this.CmiNotifyRestore.Name = "CmiNotifyRestore";
            this.CmiNotifyRestore.Size = new System.Drawing.Size(182, 26);
            this.CmiNotifyRestore.Text = "Восстановить";
            this.CmiNotifyRestore.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // CmiNotifyAbout
            // 
            this.CmiNotifyAbout.Name = "CmiNotifyAbout";
            this.CmiNotifyAbout.Size = new System.Drawing.Size(182, 26);
            this.CmiNotifyAbout.Text = "О программе..";
            this.CmiNotifyAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(179, 6);
            // 
            // CmiNotifyExit
            // 
            this.CmiNotifyExit.Name = "CmiNotifyExit";
            this.CmiNotifyExit.Size = new System.Drawing.Size(182, 26);
            this.CmiNotifyExit.Text = "Выход";
            this.CmiNotifyExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TcbToTray
            // 
            this.TcbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TcbToTray.Image = ((System.Drawing.Image)(resources.GetObject("TcbToTray.Image")));
            this.TcbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TcbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TcbToTray.Name = "TcbToTray";
            this.TcbToTray.Size = new System.Drawing.Size(36, 36);
            this.TcbToTray.Text = "Свернуть в трей";
            this.TcbToTray.ToolTipText = "Свернуть в трей";
            this.TcbToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 39);
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn6.FillWeight = 449.2386F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 410;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Amount";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn7.FillWeight = 12.69035F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Количество товара";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 120;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Short";
            this.dataGridViewTextBoxColumn8.FillWeight = 12.69035F;
            this.dataGridViewTextBoxColumn8.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 120;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "PricePurchase";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn9.FillWeight = 12.69035F;
            this.dataGridViewTextBoxColumn9.HeaderText = "Цена закупки(рубл.)";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 160;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "DatePurchase";
            this.dataGridViewTextBoxColumn10.FillWeight = 12.69035F;
            this.dataGridViewTextBoxColumn10.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 160;
            // 
            // goodsViewModelBindingSource
            // 
            this.goodsViewModelBindingSource.DataSource = typeof(H_W6AdoLINQtoSQL.Models.GoodsViewModel);
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn11.HeaderText = "Наименование товара ";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 410;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Amount";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn12.HeaderText = "Количество товара";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 120;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Short";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn13.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 120;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "PricePurchase";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle5.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn14.HeaderText = "Цена закупки";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 150;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "DatePurchase";
            this.dataGridViewTextBoxColumn15.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 150;
            // 
            // goodsViewModelBindingSource1
            // 
            this.goodsViewModelBindingSource1.DataSource = typeof(H_W6AdoLINQtoSQL.Models.GoodsViewModel);
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn16.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 410;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Amount";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle6.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.dataGridViewTextBoxColumn17.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn17.HeaderText = "Количество товара";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 130;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Short";
            this.dataGridViewTextBoxColumn18.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 120;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "PricePurchase";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle7.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn19.HeaderText = "Цена закупки";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 150;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "DatePurchase";
            this.dataGridViewTextBoxColumn20.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 150;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Фамилия продавца";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameSellerDataGridViewTextBoxColumn
            // 
            this.nameSellerDataGridViewTextBoxColumn.DataPropertyName = "NameSeller";
            this.nameSellerDataGridViewTextBoxColumn.HeaderText = "Имя  продавца";
            this.nameSellerDataGridViewTextBoxColumn.Name = "nameSellerDataGridViewTextBoxColumn";
            this.nameSellerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // patronymicDataGridViewTextBoxColumn
            // 
            this.patronymicDataGridViewTextBoxColumn.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn.HeaderText = "Отчество  продавца";
            this.patronymicDataGridViewTextBoxColumn.Name = "patronymicDataGridViewTextBoxColumn";
            this.patronymicDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // interestDataGridViewTextBoxColumn
            // 
            this.interestDataGridViewTextBoxColumn.DataPropertyName = "Interest";
            this.interestDataGridViewTextBoxColumn.HeaderText = "Процент комиссионных";
            this.interestDataGridViewTextBoxColumn.Name = "interestDataGridViewTextBoxColumn";
            this.interestDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sellerViewModelBindingSource
            // 
            this.sellerViewModelBindingSource.DataSource = typeof(H_W6AdoLINQtoSQL.Models.SellerViewModel);
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn21.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 420;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "PricePurchase";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle8.Padding = new System.Windows.Forms.Padding(0, 0, 30, 0);
            this.dataGridViewTextBoxColumn22.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewTextBoxColumn22.HeaderText = "Цена закупки";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 180;
            // 
            // priceSaleDataGridViewTextBoxColumn
            // 
            this.priceSaleDataGridViewTextBoxColumn.DataPropertyName = "PriceSale";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle9.Padding = new System.Windows.Forms.Padding(0, 0, 30, 0);
            this.priceSaleDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle9;
            this.priceSaleDataGridViewTextBoxColumn.HeaderText = "Цена продажи";
            this.priceSaleDataGridViewTextBoxColumn.Name = "priceSaleDataGridViewTextBoxColumn";
            this.priceSaleDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceSaleDataGridViewTextBoxColumn.Width = 180;
            // 
            // dateSaleDataGridViewTextBoxColumn
            // 
            this.dateSaleDataGridViewTextBoxColumn.DataPropertyName = "DateSale";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle10.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.dateSaleDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle10;
            this.dateSaleDataGridViewTextBoxColumn.HeaderText = "Дата продажи";
            this.dateSaleDataGridViewTextBoxColumn.Name = "dateSaleDataGridViewTextBoxColumn";
            this.dateSaleDataGridViewTextBoxColumn.ReadOnly = true;
            this.dateSaleDataGridViewTextBoxColumn.Width = 190;
            // 
            // allSalesViewModelBindingSource
            // 
            this.allSalesViewModelBindingSource.DataSource = typeof(H_W6AdoLINQtoSQL.Models.AllSalesViewModel);
            // 
            // dateSaleDataGridViewTextBoxColumn1
            // 
            this.dateSaleDataGridViewTextBoxColumn1.DataPropertyName = "DateSale";
            this.dateSaleDataGridViewTextBoxColumn1.HeaderText = "Дата продажи";
            this.dateSaleDataGridViewTextBoxColumn1.Name = "dateSaleDataGridViewTextBoxColumn1";
            this.dateSaleDataGridViewTextBoxColumn1.ReadOnly = true;
            this.dateSaleDataGridViewTextBoxColumn1.Width = 140;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn23.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 380;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "PricePurchase";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle11.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.dataGridViewTextBoxColumn24.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn24.HeaderText = "Цена закупки";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // priceSaleDataGridViewTextBoxColumn1
            // 
            this.priceSaleDataGridViewTextBoxColumn1.DataPropertyName = "PriceSale";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle12.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.priceSaleDataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle12;
            this.priceSaleDataGridViewTextBoxColumn1.HeaderText = "Цена продажи";
            this.priceSaleDataGridViewTextBoxColumn1.Name = "priceSaleDataGridViewTextBoxColumn1";
            this.priceSaleDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // amountSaleDataGridViewTextBoxColumn
            // 
            this.amountSaleDataGridViewTextBoxColumn.DataPropertyName = "AmountSale";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle13.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.amountSaleDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle13;
            this.amountSaleDataGridViewTextBoxColumn.HeaderText = "Кол-во проданных ед.";
            this.amountSaleDataGridViewTextBoxColumn.Name = "amountSaleDataGridViewTextBoxColumn";
            this.amountSaleDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountSaleDataGridViewTextBoxColumn.Width = 150;
            // 
            // profitDataGridViewTextBoxColumn
            // 
            this.profitDataGridViewTextBoxColumn.DataPropertyName = "Profit";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle14.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.profitDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle14;
            this.profitDataGridViewTextBoxColumn.HeaderText = "Прибыль";
            this.profitDataGridViewTextBoxColumn.Name = "profitDataGridViewTextBoxColumn";
            this.profitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // saleViewModelBindingSource
            // 
            this.saleViewModelBindingSource.DataSource = typeof(H_W6AdoLINQtoSQL.Models.SaleViewModel);
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn25.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 500;
            // 
            // amountPurchaseDataGridViewTextBoxColumn
            // 
            this.amountPurchaseDataGridViewTextBoxColumn.DataPropertyName = "AmountPurchase";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle15.Padding = new System.Windows.Forms.Padding(0, 0, 30, 0);
            this.amountPurchaseDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle15;
            this.amountPurchaseDataGridViewTextBoxColumn.HeaderText = "Количество закупок";
            this.amountPurchaseDataGridViewTextBoxColumn.Name = "amountPurchaseDataGridViewTextBoxColumn";
            this.amountPurchaseDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountPurchaseDataGridViewTextBoxColumn.Width = 200;
            // 
            // avgPricepurchaseDataGridViewTextBoxColumn
            // 
            this.avgPricepurchaseDataGridViewTextBoxColumn.DataPropertyName = "AvgPricepurchase";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle16.Padding = new System.Windows.Forms.Padding(0, 0, 30, 0);
            this.avgPricepurchaseDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle16;
            this.avgPricepurchaseDataGridViewTextBoxColumn.HeaderText = "Средняя цена закупки товара";
            this.avgPricepurchaseDataGridViewTextBoxColumn.Name = "avgPricepurchaseDataGridViewTextBoxColumn";
            this.avgPricepurchaseDataGridViewTextBoxColumn.ReadOnly = true;
            this.avgPricepurchaseDataGridViewTextBoxColumn.Width = 300;
            // 
            // calculationViewModelBindingSource
            // 
            this.calculationViewModelBindingSource.DataSource = typeof(H_W6AdoLINQtoSQL.Models.CalculationViewModel);
            // 
            // idSellerDataGridViewTextBoxColumn
            // 
            this.idSellerDataGridViewTextBoxColumn.DataPropertyName = "IdSeller";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.idSellerDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle17;
            this.idSellerDataGridViewTextBoxColumn.HeaderText = "Ид";
            this.idSellerDataGridViewTextBoxColumn.Name = "idSellerDataGridViewTextBoxColumn";
            this.idSellerDataGridViewTextBoxColumn.ReadOnly = true;
            this.idSellerDataGridViewTextBoxColumn.Width = 70;
            // 
            // salesAmountDataGridViewTextBoxColumn
            // 
            this.salesAmountDataGridViewTextBoxColumn.DataPropertyName = "SalesAmount";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle18.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.salesAmountDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle18;
            this.salesAmountDataGridViewTextBoxColumn.HeaderText = "Кол-во продаж";
            this.salesAmountDataGridViewTextBoxColumn.Name = "salesAmountDataGridViewTextBoxColumn";
            this.salesAmountDataGridViewTextBoxColumn.ReadOnly = true;
            this.salesAmountDataGridViewTextBoxColumn.Width = 120;
            // 
            // avgPriceDataGridViewTextBoxColumn
            // 
            this.avgPriceDataGridViewTextBoxColumn.DataPropertyName = "AvgPrice";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle19.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.avgPriceDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle19;
            this.avgPriceDataGridViewTextBoxColumn.HeaderText = "Среднее значение цены продажи ед.тов.";
            this.avgPriceDataGridViewTextBoxColumn.Name = "avgPriceDataGridViewTextBoxColumn";
            this.avgPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.avgPriceDataGridViewTextBoxColumn.Width = 170;
            // 
            // surnameDataGridViewTextBoxColumn1
            // 
            this.surnameDataGridViewTextBoxColumn1.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn1.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn1.Name = "surnameDataGridViewTextBoxColumn1";
            this.surnameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.surnameDataGridViewTextBoxColumn1.Width = 170;
            // 
            // nameSellerDataGridViewTextBoxColumn1
            // 
            this.nameSellerDataGridViewTextBoxColumn1.DataPropertyName = "NameSeller";
            this.nameSellerDataGridViewTextBoxColumn1.HeaderText = "Имя";
            this.nameSellerDataGridViewTextBoxColumn1.Name = "nameSellerDataGridViewTextBoxColumn1";
            this.nameSellerDataGridViewTextBoxColumn1.ReadOnly = true;
            this.nameSellerDataGridViewTextBoxColumn1.Width = 120;
            // 
            // patronymicDataGridViewTextBoxColumn1
            // 
            this.patronymicDataGridViewTextBoxColumn1.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn1.HeaderText = "Отчество";
            this.patronymicDataGridViewTextBoxColumn1.Name = "patronymicDataGridViewTextBoxColumn1";
            this.patronymicDataGridViewTextBoxColumn1.ReadOnly = true;
            this.patronymicDataGridViewTextBoxColumn1.Width = 170;
            // 
            // interestDataGridViewTextBoxColumn1
            // 
            this.interestDataGridViewTextBoxColumn1.DataPropertyName = "Interest";
            this.interestDataGridViewTextBoxColumn1.HeaderText = "Процент комиссионных";
            this.interestDataGridViewTextBoxColumn1.Name = "interestDataGridViewTextBoxColumn1";
            this.interestDataGridViewTextBoxColumn1.ReadOnly = true;
            this.interestDataGridViewTextBoxColumn1.Width = 140;
            // 
            // calculateSellesViewModelBindingSource
            // 
            this.calculateSellesViewModelBindingSource.DataSource = typeof(H_W6AdoLINQtoSQL.Models.CalculateSellesViewModel);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.TsbMain);
            this.Controls.Add(this.MnuMain);
            this.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnuMain;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximumSize = new System.Drawing.Size(1100, 600);
            this.MinimumSize = new System.Drawing.Size(1000, 566);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №6";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.TsbMain.ResumeLayout(false);
            this.TsbMain.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.Tbc01.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).EndInit();
            this.Tbc02.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).EndInit();
            this.Tbc03.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQeury03)).EndInit();
            this.Tbc04.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).EndInit();
            this.Tbc05.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).EndInit();
            this.Tbc06.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).EndInit();
            this.Tbc07.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery07)).EndInit();
            this.Tbc08.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery08)).EndInit();
            this.CmnNotify.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.goodsViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodsViewModelBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.allSalesViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.calculationViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.calculateSellesViewModelBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStrip TsbMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage Tbc01;
        private System.Windows.Forms.TabPage Tbc02;
        private System.Windows.Forms.ToolStripButton TcbQuery1;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniAboutProgram;
        private System.Windows.Forms.Label LblDgv1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pricePurchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datePurchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label LblDgv2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridView DgvQuery01;
        private System.Windows.Forms.BindingSource goodsViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridView DgvQuery02;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.BindingSource goodsViewModelBindingSource1;
        private System.Windows.Forms.TabPage Tbc03;
        private System.Windows.Forms.Label LblDgv3;
        private System.Windows.Forms.TabPage Tbc04;
        private System.Windows.Forms.TabPage Tbc05;
        private System.Windows.Forms.TabPage Tbc06;
        private System.Windows.Forms.TabPage Tbc07;
        private System.Windows.Forms.TabPage Tbc08;
        private System.Windows.Forms.DataGridView DgvQeury03;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridView DgvQuery04;
        private System.Windows.Forms.Label LblDgv4;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameSellerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sellerViewModelBindingSource;
        private System.Windows.Forms.Label LblDgv5;
        private System.Windows.Forms.DataGridView DgvQuery05;
        private System.Windows.Forms.BindingSource saleViewModelBindingSource;
        private System.Windows.Forms.BindingSource allSalesViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceSaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateSaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label LblDgv6;
        private System.Windows.Forms.DataGridView DgvQuery06;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateSaleDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceSaleDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountSaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn profitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView DgvQuery07;
        private System.Windows.Forms.Label LblDgv7;
        private System.Windows.Forms.BindingSource calculationViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountPurchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn avgPricepurchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label LblDgv8;
        private System.Windows.Forms.DataGridView DgvQuery08;
        private System.Windows.Forms.BindingSource calculateSellesViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSellerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salesAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn avgPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameSellerDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn1;
        private System.Windows.Forms.ToolStripButton TcbQuery2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TcbQuery3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton TcbQuery4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton TcbQuery5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton TcbQuery6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton TcbQuery7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton TcbQuery8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton TcbAboutProgram;
        private System.Windows.Forms.NotifyIcon NtiMain;
        private System.Windows.Forms.ContextMenuStrip CmnNotify;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyRestore;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyExit;
        private System.Windows.Forms.ToolStripButton TcbToTray;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
    }
}

