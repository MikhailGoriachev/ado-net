﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Railway.Helpers;

namespace Railway.Models
{
	// класс, описывающий поезд
	public class Train
	{
		// максимальное количество вагонов в поезде 
		public const int MaxCarriages = 20;

		// номер поезда
		private string _number;

		public string Number
		{
			get => _number; 
			set 
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new InvalidDataException("Train: номер поезда не указан");
				_number = value; 
			}
		}

		// пункт отправления
		private string _departure;

		public string Departure
		{
			get => _departure;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new InvalidDataException("Train: пункт отправления не указан");
				_departure = value;
			}
		}

		// пункт назначения
		private string _destination;

		public string Destination
		{
			get => _destination;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new InvalidDataException("Train: пункт назначения не указан");
				_destination = value;
			}
		}

		// коллекция вагонов поезда
		private List<Car> _cars;

		public List<Car> Cars
		{
			get => _cars; 
			set {
				_cars = value; 
			}
		}

		// конструкторы
		public Train()
		{}
		
		public Train(string number, string departure, string destination, List<Car> cars)
		{
			Number = number;
			Departure = departure;
			Destination = destination;
			_cars = cars;
		}


		// индексатор
		public Car this[int index]
		{
			get => _cars[index];
			set => _cars[index] = value;
		}

		public void OrderBy(Comparison<Car> pred) => _cars.Sort(pred);


		// текущее количество вагонов
		public int Count => Cars.Count;


		public int CountCarsWhere(Predicate<Car> predicate)
		{
			int total = 0;
			_cars.ForEach(car =>
			{
				if (predicate(car)) ++total;
			});
			return total;
		}


		public int CountPlacesWhere(Predicate<Car> predicateCar, Predicate<Place> predicatePlace)
		{

			int total = 0;
			_cars.ForEach(car =>
			{
				if (predicateCar(car))
				{
					car.Compartments.ForEach(cmp =>
					{
						cmp.Places.ForEach(place =>
						{
							if (predicatePlace(place))
								++total;
						});
					});
				}
			});
			return total;
		}


		// добавление вагона
		public void AddCar(string type) => _cars.Add(Car.Generate(type, _cars.Count + 1));
		// удаление вагона
		public void RemoveCar(Car car) => _cars.RemoveAt(_cars.FindIndex(c => c == car));

		// генерация поезда
		public static Train Generate()
		{
			// данные поезда
			(string Departure, string Destination, string Number)[] points = {
				("Ясиноватая", "Луганск", "001М"),
				("Ясиноватая", "Горловка", "506П"),
				("Донецк-2", "Макеевка", "504П"),
				("Донецк-2", "Иловайск", "505П"),
				("Ясиноватая", "Ростов-на-Дону", "002М")
			};
			
			// генерация данных пользователя
			int index = Utils.GetRandom(0, points.Length - 1);
			

			Train train = new Train(points[index].Number, points[index].Departure, points[index].Destination, new List<Car>());

			int nCars = Utils.GetRandom(5, 20);

			for (int i = 0; i < nCars; i++)
			{
				string type = Utils.GetRandom(1, 3) switch
				{
					1 => "св",
					2 => "купе",
					3 => "плацкарт",
					_ => throw new ArgumentOutOfRangeException()
				};

				train.Cars.Add(Car.Generate(type, i + 1));
			}

			return train;
		}
	}
}
