﻿using Main.Controllers;
using Main.Utilities.Menu;


namespace Main
{
	public sealed class App : MenuWrapper
	{
		private readonly Task1Controller _firstTask = new();
		private readonly Task2Controller _secondTask = new();


		public App() =>
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Первая задача", _firstTask.Run) { IsSimpleInvoke  = true },
				new MenuItem("Вторая задача", _secondTask.Run) { IsSimpleInvoke = true }
			});
	}
}