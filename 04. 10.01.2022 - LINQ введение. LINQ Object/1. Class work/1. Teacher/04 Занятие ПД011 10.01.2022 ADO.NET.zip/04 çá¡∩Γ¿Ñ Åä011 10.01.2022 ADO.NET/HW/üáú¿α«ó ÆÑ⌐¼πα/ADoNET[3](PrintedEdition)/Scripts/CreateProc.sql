﻿-- Создание процедур 

-- Процедура №1	
-- Выбирает из таблицы ИЗДАНИЯ информацию 
-- о доступных для подписки изданиях заданного типа, 
-- стоимость 1 экземпляра для которых меньше заданной.
drop proc if exists Proc1;
go

create proc Proc1
	@type nvarchar(20),
	@hiPrice float
as
begin
	select 
		Editions.id
		,Editions.IndexEditions
		,GoodsEditions.[Name]
		,TypeEditions.TypeEdition
		,GoodsEditions.Price
	from
		Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
						on Editions.IdGoodsEditions = GoodsEditions.id
	where
		TypeEditions.TypeEdition = @type and GoodsEditions.Price < @hiPrice;
end;
go

-- Демонстрация работы процедуры
exec Proc1 N'Газета', 200; 
go


-- Процедура №2 
-- Выбирает из таблиц информацию о подписчиках,
-- проживающих на заданной параметром улице и номере дома, 
-- которые оформили подписку на издание с заданным параметром наименованием
drop proc if exists Proc2;
go

create proc Proc2
	@street    nvarchar(20),
	@houseNum  nvarchar(20),
	@name      nvarchar(35)
as 
begin
	select
		Delivery.Id
		,Subscribers.Surname
		,Subscribers.[Name]
		,Subscribers.Patronymic
		,Subscribers.Passport
		,Streets.Street
		,HouseNumbers.HouseNumber
		,Subscribers.ApartmentNumber
		,Delivery.SubscriptionDate
		,Delivery.SubDuration
		,TypeEditions.TypeEdition
		,GoodsEditions.[Name]
	from
		Delivery join (Subscribers join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id
								   join Streets	     on Subscribers.IdStreet      = Streets.Id) 
					  on Delivery.IdSubscriber = Subscribers.Id
				 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
					  on Editions.IdGoodsEditions = GoodsEditions.id)
					  on Delivery.IdEdition = Editions.Id
	where
		Streets.Street = @street and HouseNumbers.HouseNumber = @houseNum 
		and GoodsEditions.[Name] = @name;
end;
go

-- Демонстрация работы процедуры
exec Proc2 N'ул. Судовая', N'д. 2', N'1000 и 1 ночь с Абрамяном';
go


-- Процедура №3
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, 
-- для которых значение в поле Цена 1 экземпляра 
-- находится в заданном диапазоне значений
drop proc if exists Proc3;
go

create proc Proc3
	@loPrice float = 200,
	@hiPrice float = 300
as 
begin
	select 
		Editions.id
		,Editions.IndexEditions
		,GoodsEditions.[Name]
		,TypeEditions.TypeEdition
		,GoodsEditions.Price
	from	
		Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.Id)
					  on Editions.IdGoodsEditions = GoodsEditions.id
	where
		GoodsEditions.Price between @loPrice and @hiPrice
	order by
		Price
end;
go

-- Демонстрация работы процедуры
exec Proc3 200, 300;
go


-- Процедура №4
-- Выбирает из таблиц информацию о подписчиках, 
-- подписавшихся на заданный параметром тип издания
drop proc if exists Proc4;
go

create proc Proc4
	@type nvarchar(20) 
as 
begin
	select
		Delivery.id
		,Subscribers.Surname
		,Subscribers.[Name]
		,Subscribers.Patronymic
		,Subscribers.Passport
		,Streets.Street
		,HouseNumbers.HouseNumber
		,Subscribers.ApartmentNumber
		,Delivery.SubscriptionDate
		,Delivery.SubDuration
		,TypeEditions.TypeEdition
		,GoodsEditions.[Name]
	from
		Delivery join (Subscribers join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id
								   join Streets	     on Subscribers.IdStreet      = Streets.Id) 
					  on Delivery.IdSubscriber = Subscribers.Id
				 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
								on Editions.IdGoodsEditions = GoodsEditions.id)
					  on Delivery.IdEdition = Editions.Id
	where
		TypeEditions.TypeEdition = @type;
end;
go

-- Демонстрация работы процедуры
exec Proc4 N'Энциклопедия';
go


-- Процедура №5
-- Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА 
-- информацию обо всех оформленных подписках,
-- для которых срок подписки есть значение из некоторого диапазона. 
-- Нижняя и верхняя границы диапазона задаются при выполнении запроса
drop proc if exists Proc5;
go

create proc Proc5
	@loSubDuration int,
	@hiSubDuration int 
as 	
begin
	select
		 Delivery.id
		,Subscribers.Surname		--  |
		,Subscribers.[Name]			--  | => Не по запросу, но так лучше
		,Subscribers.Patronymic		--  |
		,Editions.IndexEditions
		,TypeEditions.TypeEdition
		,GoodsEditions.[Name]
		,GoodsEditions.Price
		,Delivery.SubscriptionDate
		,Delivery.SubDuration 
	from
		Delivery join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
								on Editions.IdGoodsEditions = GoodsEditions.id)
					   on Delivery.IdEdition = Editions.Id
				 join  Subscribers on Delivery.IdSubscriber = Subscribers.Id
	where
		Delivery.SubDuration between @loSubDuration and @hiSubDuration
	order by 
		Delivery.SubDuration;
end;
go

-- Демонстрация работы процедуры
exec Proc5  4, 7;
go		    


-- Процедура №6
-- Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
-- Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, 
-- Дата начала подписки, Срок подписки, Стоимость подписки без НДС. 
-- Сортировка по полю Индекс издания
drop proc if exists Proc6;
go

create proc Proc6
as 	
begin
select
	Delivery.id
	,Editions.IndexEditions
	,GoodsEditions.[Name]
	,GoodsEditions.Price
	,Delivery.SubscriptionDate
	,Delivery.SubDuration
	,(GoodsEditions.Price * Delivery.SubDuration) * 1.01 as PriceSubscription
from
	Delivery join (Editions join GoodsEditions on Editions.IdGoodsEditions = GoodsEditions.id)
				   on Delivery.IdEdition = Editions.Id
order by
	Editions.IndexEditions;
end;
go

-- Демонстрация работы процедуры
exec Proc6;
go		    


-- Процедура №7
-- Выполняет группировку по полю Вид издания. 
-- Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
drop proc if exists Proc7;
go

create proc Proc7
as 	
begin
	select
		TypeEditions.TypeEdition
		,MIN(GoodsEditions.Price) as MinPrice
		,AVG(GoodsEditions.Price) as AvgPrice   
		,MAX(GoodsEditions.Price) as MaxPrice
	from
		GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.Id
	group by
		TypeEditions.TypeEdition;
end;
go

-- Демонстрация работы процедуры
exec Proc7;
go		


-- Процедура №8
-- Выполняет группировку по полю Улица. 
-- Для всех улиц вычисляет количество подписчиков, 
-- проживающих на данной улице (итоги по полю Код получателя)
drop proc if exists Proc8;
go

create proc Proc8
as 	
begin 
	select
		Streets.Street
		,COUNT(Subscribers.IdStreet) as AmountSubscribers
	from 
		Streets left join  Subscribers  on Subscribers.IdStreet = Streets.id
	group by
		Streets.Street;
end;
go

-- Демонстрация работы процедуры
exec Proc8;
go		


-- Процедура №9
-- Для всех изданий выводит количество оформленных подписок
drop proc if exists Proc9;
go

create proc Proc9
as 	
begin 
	select
		Editions.Id
		,Editions.IndexEditions
		,TypeEditions.TypeEdition
		,GoodsEditions.[Name]
		,GoodsEditions.Price
		,COUNT(Delivery.IdEdition) as AmountSubscription
	from 
		(Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
								on Editions.IdGoodsEditions = GoodsEditions.id) left join Delivery
				   on Delivery.IdEdition = Editions.Id
	group by
		Editions.Id, Editions.IndexEditions, TypeEditions.TypeEdition,
		GoodsEditions.[Name], GoodsEditions.Price;
end;
go

-- Демонстрация работы процедуры
exec Proc9;
go	