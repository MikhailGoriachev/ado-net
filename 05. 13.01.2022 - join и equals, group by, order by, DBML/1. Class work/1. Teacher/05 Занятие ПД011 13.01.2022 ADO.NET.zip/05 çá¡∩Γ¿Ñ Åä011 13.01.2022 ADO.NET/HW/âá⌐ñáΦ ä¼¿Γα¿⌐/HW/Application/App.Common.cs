﻿using System;
using System.Collections.Generic;
using HW.Helpers;
using HW.Models;

using HW.Controllers;

namespace HW.Application{
    public partial class App
    {
        // контроллер для выполнения задач в первом задании
        private Task1Controller _task1Controller;
        private Task2Controller _task2Controller;


        // конструктор с параметрами
        public App(Task1Controller task1Controller, Task2Controller task2Controller)
        {
            _task1Controller = task1Controller;
            _task2Controller = task2Controller;
        }

        // конструктор по умолчанию
        public App() :
            this(new Task1Controller(), new Task2Controller())
        { }

    } // App
}
