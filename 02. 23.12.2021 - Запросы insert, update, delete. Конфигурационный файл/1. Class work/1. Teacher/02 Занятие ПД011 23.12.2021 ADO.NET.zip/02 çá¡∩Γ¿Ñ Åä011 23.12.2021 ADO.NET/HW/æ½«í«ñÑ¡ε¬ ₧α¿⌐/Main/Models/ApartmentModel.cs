﻿using System.Data;
using Main.Utilities.TableFormatter;


namespace Main.Models
{
	public sealed class ApartmentModel : IMappable<ApartmentModel>
	{
		[TableData("Улица", "{0, -30}")]
		public string? Street { get; set; }

		[TableData("Дом", "{0, 7}")]
		public string? House { get; set; }

		[TableData("Квартира", "{0, 10}")]
		public string? Number { get; set; }

		[TableData("Площадь", "{0, 10}")]
		public double Area { get; set; }

		[TableData("Комнат", "{0, 8}")]
		public int Rooms { get; set; }

		[TableData("Цена", "{0, 8:F0}")]
		public decimal Price { get; set; }


		public ApartmentModel Map(DataRow row) =>
			new()
			{
				Street = (string)row["Street"],
				Area   = (double)row["Area"],
				House  = (string)row["House"],
				Number = (string)row["Number"],
				Price  = (decimal)row["Price"],
				Rooms  = (int)row["Rooms"]
			};
	}
}