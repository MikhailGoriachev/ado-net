﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Controllers;

namespace Homework
{
	internal partial class App
	{
		// строка подключения к базе данных
		private string _connectingString;

		private Menu _mainMenu;

		private Task1Controller _task1Controller;

		public App(string connectingString) 
		{
			_connectingString = connectingString;
			_task1Controller = new Task1Controller(_connectingString);
			InitMenu();
		}
		

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem {Text = "Запрос 1", Callback = Task1MenuItem1},
					new Menu.MenuItem {Text = "Запрос 2", Callback = Task1MenuItem2},
					new Menu.MenuItem {Text = "Запрос 3", Callback = Task1MenuItem3},
					new Menu.MenuItem {Text = "Запрос 4", Callback = Task1MenuItem4},
					new Menu.MenuItem {Text = "Запрос 5", Callback = Task1MenuItem5},
					new Menu.MenuItem {Text = "Запрос 6", Callback = Task1MenuItem6},
					new Menu.MenuItem {Text = "Запрос 7", Callback = Task1MenuItem7},
					new Menu.MenuItem {Text = "Запрос 8", Callback = Task1MenuItem8},
					new Menu.MenuItem {Text = "Запрос 9", Callback = Task1MenuItem9},
					new Menu.MenuItem {Text = "Шифровать конфигурационный файл", Callback = EncryptConfig},
					new Menu.MenuItem {Text = "Расшифровать конфигурационный файл", Callback = DecryptConfig},
					new Menu.MenuItem {Text = "Выход"}
				}, new Point(5, 5),
				"Меню приложения");
		}
		public void Run() =>_mainMenu.Run();

		public void EncryptConfig()
		{
			Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
			ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

			if (!section.SectionInformation.IsProtected)
			{
				// Зашифровать секцию.
				section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
				// Сохранить файл конфигурации.
				config.Save();

				Console.WriteLine("\n\n  Конфигурационный файл зашифрован. Нажмите любую клавишу для продолжения..");

			} else Console.WriteLine("\n\n  Конфигурационный файл уже зашифрован.");
		}

		public void DecryptConfig()
		{
			Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
			ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

			if (section.SectionInformation.IsProtected)
			{
				// Расшифровать секцию.
				section.SectionInformation.UnprotectSection();
				// Сохранить файл конфигурации.
				config.Save();

				Console.WriteLine("\n\n  Конфигурационный файл расшифрован. Нажмите любую клавишу для продолжения..");
			}
			else Console.WriteLine("\n\n  Конфигурационный файл уже расшифрован.");
		}
	}
}
