﻿using System.Collections.Generic;
using Dapper;
using Microsoft.Data.SqlClient;


namespace Main.DataAccess
{
	public sealed class DapperDataAccess
	{
		private readonly string _connectionString;


		public DapperDataAccess(string connectionString) =>
			_connectionString = connectionString;


		public IEnumerable<object> QueryObject(CommandDefinition command) =>
			Query<object>(command);


		public IEnumerable<T> Query<T>(CommandDefinition command)
		{
			using var connection = new SqlConnection(_connectionString);
			connection.Open();

			return connection.Query<T>(command);
		}
	}
}