﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Models
{

    /*
            Id
            , Surname
            , [Name]
            , Patronymic    
            , PassportID
            , StreetType + N' ' + StreetName + N' ' + HouseNumber + N'/' + ApartmentNumber as [Address] 
            , [Index]
            , TypeOfPrintEdition
            , NameOfPublications
            , Price
            , DateStartSubsribe
            , SubscriptionTerm
     */
    public class SubscribersModel
    {
        // Id
        public int Id { get; set; }

        // Фамилия 
        public string SurName { get; set; }

        // Имя
        public string Name { get; set; }

        // Отчество
        public string Patronymic { get; set; }

        // пасспорт
        public string Passport { get; set; }

        // адресс
        public string Address { get; set; }




        // Индекс публикации
        public string Index { get; set; }

        // Тип печатного издания
        public string TypeOfPrintEdition { get; set; }

        // название публикации
        public string NameOfPublication { get; set; }

        // цена 
        public int Price { get; set; }

        // дата начала подписки
        public DateTime DateStartSubsribe { get; set; }

        // длительность подписки
        public int SubscriptionTerm { get; set; }

        public SubscribersModel(int id, string surName, string name, string patronymic, string passport, string address, string index, string typeOfPrintEdition, string nameOfPublication, int price, DateTime dateStartSubsribe, int subscriptionTerm) {

            Id = id;
            SurName = surName;
            Name = name;
            Patronymic = patronymic;
            Passport = passport;
            Address = address;
            Index = index;
            TypeOfPrintEdition = typeOfPrintEdition;
            NameOfPublication = nameOfPublication;
            Price = price;
            DateStartSubsribe = dateStartSubsribe;
            SubscriptionTerm = subscriptionTerm;
        }

        private string FIO => $"{SurName} {Name.Substring(1, 1).ToUpper()}. {Patronymic.Substring(1, 1).ToUpper()}.";

        public static string Header()
        {

            return
            $"┌──────┬────────────────────────────────────────────────────────────────────────────┬──────────────────────────────────────────────────────────────────────────────────────────────────────────┐\n" +
            $"│      │                          Информация о подписчике                           │                                                Информация о подписке                                     │\n" +
            $"├──────┼────────────────────────┬────────────┬──────────────────────────────────────┼──────────────┬───────────────────┬────────────────────────────────────┬──────────┬────────────┬──────────┤\n" +
            $"│  Id  │      Фамилия И.О.      │  Пасспорт  │                 Адрес                │    Индекс    │    Тип издания    │         Название публикации        │   Цена   │    Дата    │   Срок   │\n" +
            $"├──────┼────────────────────────┼────────────┼──────────────────────────────────────┼──────────────┼───────────────────┼────────────────────────────────────┼──────────┼────────────┼──────────┤";

        }

        public string ToTableRow() =>
            $"│ {Id,4} │ {FIO,-22} │ {Passport,-10} │ {Address,-36} │ {Index,-12} │ {TypeOfPrintEdition,-17} │ {NameOfPublication,-34} │ {Price,8} │ {DateStartSubsribe.ToShortDateString(),8} │ {SubscriptionTerm,8} │";


        public static string Footer() =>
            $"└──────┴────────────────────────┴────────────┴──────────────────────────────────────┴──────────────┴───────────────────┴────────────────────────────────────┴──────────┴────────────┴──────────┘\n";

    }
}
