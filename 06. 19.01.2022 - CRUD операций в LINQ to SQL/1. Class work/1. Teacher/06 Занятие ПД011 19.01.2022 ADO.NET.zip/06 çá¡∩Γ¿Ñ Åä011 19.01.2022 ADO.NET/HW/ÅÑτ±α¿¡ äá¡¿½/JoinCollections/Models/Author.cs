﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoinCollections.Models
{
    public class Author
    {
        public int Id { get; set; }            //идентификатор
        public string SurnameNP { get; set; }  // фамилия, инициалы

        public int BirthYear { get; set; }     // год рождения

        public override string ToString() => $" | Автор: {SurnameNP,18} | Год рожения : {BirthYear} ";

    }
}
