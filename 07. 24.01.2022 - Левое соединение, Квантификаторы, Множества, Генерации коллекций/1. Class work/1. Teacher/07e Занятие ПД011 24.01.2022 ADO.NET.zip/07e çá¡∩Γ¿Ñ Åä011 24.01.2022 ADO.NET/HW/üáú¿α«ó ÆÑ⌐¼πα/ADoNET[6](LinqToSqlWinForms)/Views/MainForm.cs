﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ADoNET_6__LinqToSqlWinForms_.Controllers;

namespace ADoNET_6__LinqToSqlWinForms_.Views
{
    public partial class MainForm : Form
    {
        private QueriesController _queriesController;
            
        public MainForm() { 
            InitializeComponent();
            _queriesController = new QueriesController();
        } // MainForm

        // Открытие формы "О программе" 
        private void About_Command(object sender, EventArgs e)
        {
            AboutForm formAbout = new AboutForm();
            formAbout.ShowDialog();
        } // About_Command

        // Закрытие приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        // Информация о товарах, единица измерения которых «шт» (штуки) и цена закупки меньше 200 руб
        // синтаксис расширяющих методов
        private void Query01View_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpQuery01;
            dgvQuery01.DataSource = _queriesController.Query01();
        }

        // Информация о товарах, цена закупки которых больше 500 руб
        // синтаксис расширяющих методов
        private void Query02View_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpQuery02;
            dgvQuery02.DataSource = _queriesController.Query02();
        }

        // Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1800 руб
        // синтаксис расширяющих методов
        private void Query03View_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpQuery03;
            dgvQuery03.DataSource = _queriesController.Query03();
        }

        // Информация о продавцах с заданным значением процента комиссионных
        // синтаксис расширяющих методов
        private void Query04View_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpQuery04;
            dgvQuery04.DataSource = _queriesController.Query04();
        }

        // Информация о фактах продажи, для которых цена продажи в заданном диапазоне
        // синтаксис расширяющих методов
        private void Query05View_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpQuery05;
            dgvQuery05.DataSource = _queriesController.Query05();
        }

        // Вычислить прибыль от продажи за каждый проданный товар
        // синтаксис расширяющих методов
        private void Query06View_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpQuery06;
            dgvQuery06.DataSource = _queriesController.Query06();
        }
    }
}
