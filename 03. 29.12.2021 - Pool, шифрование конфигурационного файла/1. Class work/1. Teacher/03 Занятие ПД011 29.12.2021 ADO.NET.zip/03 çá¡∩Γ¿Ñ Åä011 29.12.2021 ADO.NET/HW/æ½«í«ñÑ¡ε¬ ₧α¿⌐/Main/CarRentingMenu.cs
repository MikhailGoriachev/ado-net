﻿using System;
using Main.Controllers;
using Main.Utilities;
using Main.Utilities.Menu;


namespace Main
{
	public sealed class CarRentingMenu : MenuWrapper
	{
		private static readonly string ConnectionString =
			@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Catalan\Desktop\Homework_2\Main\DB\CarRenting\CarRenting.mdf;Integrated Security=True";

		private readonly CarRentingController _carRentingController = new(ConnectionString);


		public CarRentingMenu() =>
			Menu = new("Прокат автомобилей", new[]
			{
				new MenuItem("Первый запрос", Query1),
				new MenuItem("Второй запрос", Query2),
				new MenuItem("Третий запрос", Query3),
				new MenuItem("Четвертый запрос", Query4),
				new MenuItem("Пятый запрос", Query5),
				new MenuItem("Шестой запрос", Query6),
				new MenuItem("Седьмой запрос", Query7),
				new MenuItem("Восьмой запрос", Query8),
			});


		private void Query1()
		{
			string licensenNumber = "Y421ET";

			Console.WriteLine(@$"
Выбирает информацию обо всех фактах проката автомобиля с заданным госномером({licensenNumber})");

			_carRentingController.Query1(licensenNumber);
		}


		private void Query2()
		{
			int brandId = 3;

			Console.WriteLine(@$"
Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом({brandId})");

			_carRentingController.Query2(brandId);
		}


		private void Query3()
		{
			string licensenNumber = "Y421ET";

			Console.WriteLine(@$"
Выбирает информацию об автомобиле с заданным госномером({licensenNumber})");

			_carRentingController.Query3(licensenNumber);
		}


		private void Query4()
		{
			string passport = "BH25736525766254352348";

			Console.WriteLine(@$"
Выбирает информацию о клиентах по серии и номеру паспорта({passport})");

			_carRentingController.Query4(passport);
		}


		private void Query5()
		{
			// @from = '10.31.21', @to = '10.31.22'
			Range<DateTime> dates = new Range<DateTime>(
				new(2021, 10, 31),
				new(2022, 10, 31)
			);

			Console.WriteLine(@$"
Выбирает информацию обо всех зафиксированных фактах проката 
автомобилей в некоторый заданный интервал времени. 
(min - {dates.Min:d}, max - {dates.Max:d})");

			_carRentingController.Query5(dates);
		}


		private void Query6()
		{
			Console.WriteLine(@"
Вычисляет для каждого факта проката стоимость проката. Включает поля Дата проката, 
Госномер автомобиля, Модель автомобиля, Стоимость проката. Сортировка по полю Дата проката");

			_carRentingController.Query6();
		}


		private void Query7()
		{
			Console.WriteLine(@"
Для всех клиентов прокатной фирмы вычисляет количество фактов проката, суммарное 
количество дней проката, упорядочивание по убыванию суммарного количества дней проката");

			_carRentingController.Query7();
		}


		private void Query8()
		{
			string licenseNumber = "Y421ET";

			Console.WriteLine(@$"
Выбирает информацию о фактах проката автомобилей по госномеру({licenseNumber}): количество фактов 
проката, сумма за прокаты, суммарная длительность прокатов");

			_carRentingController.Query8(licenseNumber);
		}
	}
}