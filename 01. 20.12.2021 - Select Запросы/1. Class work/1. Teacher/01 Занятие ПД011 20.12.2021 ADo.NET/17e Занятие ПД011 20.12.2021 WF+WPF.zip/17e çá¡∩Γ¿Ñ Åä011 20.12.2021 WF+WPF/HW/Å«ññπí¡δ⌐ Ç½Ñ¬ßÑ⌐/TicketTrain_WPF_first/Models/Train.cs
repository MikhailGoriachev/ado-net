﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using TicketTrain_WPF_first.Utils;
using TicketTrain_WPF_first.ViewModels;

namespace TicketTrain_WPF_first.Models
{
    public enum TypeTrains
    {
        sv = 2,
        coupe = 4,
        reserved = 6
    }



    [Serializable]
    [DataContract]
    // класс, описующий поезд
    public class Train
    {
        [DataMember]
        // номер поезда
        private string _number;
        public string Number
        {
            get { return _number; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    throw new Exception("Train: ошибка номера поезда");
                _number = value;
            }
        }

        [DataMember]
        // коллекция вагонов
        private List<TrainCar> _wagons;
        public List<TrainCar> Wagons
        {
            get { return _wagons; }
            set { _wagons = value; }
        }


        // конструктор
        public Train(string number, int countWagons)
        {
            _number = number;
            _wagons = new List<TrainCar>();
            for (int i = 0; i < countWagons; i++)
            {
                _wagons.Add(new TrainCar(Utils.Utils.types.Values.ElementAt(Utils.Utils.GetRandom(0, 3)), i + 1));
            }
        }

        // получить вагон по номеру
        public TrainCar TrainCarAt(int number) => _wagons[number - 1];

        // получить все вагоны
        public List<TrainCar> GetAllCarriages() => _wagons;


        // отбор данных из коллекции вагонов по номеру вагона в формате для отображения
        // в DataGridView
        public List<TrainTicket> MapToCarriageView(int carriageNumber)
        {
            // итоговая коллекция
            List<TrainTicket> wagonViews = new List<TrainTicket>();

            // получили ссылку на вагон с номером carriageNumber
            TrainCar wagon = TrainCarAt(carriageNumber);

            // перебираем все купе вагона
            for (int i = 0; i < TrainCar._countTrainCarCompartment; i++)
            {
                for (int j = 0; j < wagon.GetCountSeatinCoupe(); j++)
                {
                    wagonViews.Add(new TrainTicket
                    {
                        WagonType = wagon.TypeTrainCar,
                        Number = carriageNumber,
                        CompartmentNumber = i + 1,
                        SeatNumber = wagon[i].Seats[j].Number.ToString(),
                        State = wagon[i].Seats[j].State ? "продано" : "свободно"
                    });
                } // for j
            } // for i

            return wagonViews;
        } // MapToCarriageView

        public void Clear()
        {
            _number = "UNK";
            _wagons.Clear();
        }
    }
}
