﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
    public class Good {

        string _name;     // название товара
        public string Name {
            get => _name;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Good: Некорректное название товара!"); _name = value; }
        } // Name

        int _number;      // количество товара(в условных единицах)
        public int Number {
            get => _number;
            set { if (value < 0) throw new Exception("Good: Некорректное значение количества товара!"); _number = value; }
        } // Number

        int _price;       // стоимость товара в рублях
        public int Price {
            get => _price;
            set { if (value <= 0) throw new Exception("Good: Некорректное значение стоимости товара!"); _price = value; }
        } // Price

        private int _year; // год выпуска
        public int Year {
            get => _year;
            set { if (value > DateTime.Now.Year) throw new Exception("Good: Некорректное значение года выпуска товара!"); _year = value; }
        } // Year


        // представление объекта в виде строки таблицы
        public string ToTableRow(int rowNumber) =>
            $"  │ {rowNumber,3} │ {_name,-21} │ {_number, 11}   │ {_year, 11} │ {_price, 15}  │ {_price * _number,15} │";

        // статическое свойство для вывода шапки таблицы
        public static string Header() {
            return 
                $"  ┌─────┬───────────────────────┬───────────────┬─────────────┬──────────────────┬─────────────────┐\n" +
                $"  │  №  │    Название товара    │ Кол-во товара │ Год выпуска │ Cтоимость 1 ед.  │ Общая стоимость │\n" +
                $"  ├─────┼───────────────────────┼───────────────┼─────────────┼──────────────────┼─────────────────┤";
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────┴───────────────────────┴───────────────┴─────────────┴──────────────────┴─────────────────┘";
       

    } // Good
}
