﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_first
{
    public static class MathTask
    {
        public static double GetAVG(int a, int b, int c) {
            return (a + b + c) / 3;        
        }

        public static double GetGVG(int a, int b, int c)
        {
            return (a * b * c) / 3;
        }

        public static List<double> GetRoots(int a, int b, int c)
        {
            List<double> result = new List<double>();
            double d = b * b - 4 * a * c;

            if(d > 0)
            {
                double x = (-b + Math.Sqrt(d)) / 2 * a;
                result.Add(x);
                x = (-b - Math.Sqrt(d)) / 2 * a;
                result.Add(x);


            }
            else if(d == 0)
            {
                double x = (-b + Math.Sqrt(d)) / 2 * a;
                result.Add(x);               

            }
            return result;
        }

    }
}
