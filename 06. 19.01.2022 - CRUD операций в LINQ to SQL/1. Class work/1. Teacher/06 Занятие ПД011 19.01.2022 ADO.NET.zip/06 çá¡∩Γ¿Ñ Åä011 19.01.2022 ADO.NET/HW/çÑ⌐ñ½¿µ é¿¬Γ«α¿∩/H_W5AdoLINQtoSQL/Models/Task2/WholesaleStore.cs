﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W5AdoLINQtoSQL.Models.Task2
{
    // Класс для решения задачи 2
    public class WholesaleStore
    {
        // Подключение к базе данных
        WholesaleStoreDataContext db = new WholesaleStoreDataContext();

        // Выбирает из таблицы ТОВАРЫ информацию о товарах,
        // единицей измерения которых является «шт» (штуки) и
        // цена закупки составляет меньше 100 руб. 
        public void Query01Ext()
        {
            var query =
                from purchase in db.Purchases
                join good in db.Goods on purchase.IdGood equals good.Id
                join unit in db.Units on purchase.IdUnit equals unit.Id
                where purchase.PricePurchase < 100 && purchase.Units.Short == "шт."
                select purchase;

            Console.WriteLine("\n\n\n Товары цена закупки составляет меньше 100 руб., синтаксис запроса :\n" +
                  "--------------------------------------------------------------------------------------------------------\n" +
                  "           Наименование товара                 Кол-во товара  Ед. измерения  Цена закупки   Дата закупки\n" +
                  "--------------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Goods.Name,-41}   {p.Amount,14} {p.Units.Short,13}  {p.PricePurchase,12}  " +
                                  $"{p.DatePurchase,15:d}");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------------------------\n");
        }// Query01Ext

        public void Query01Linq()
        {
            var query = db.Purchases
                .Join(db.Purchases, purchase => purchase.IdGood, good => good.Id,
                (p, g) => new { p.Goods.Name, p.Amount, p.Units.Short, p.PricePurchase, p.DatePurchase })
                .Where(purchase => purchase.PricePurchase < 100 && purchase.Short == "шт.")
                .ToList();
            Console.WriteLine("\n Товары цена закупки составляет меньше 100 руб., синтаксис методов расширения:\n" +
                              "--------------------------------------------------------------------------------------------------------\n" +
                              "           Наименование товара                 Кол-во товара  Ед. измерения  Цена закупки   Дата закупки\n" +
                              "--------------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Name,-41}   {p.Amount,14} {p.Short,13}  {p.PricePurchase,12}  " +
                                  $"{p.DatePurchase,15:d}");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------------------------\n");
        }// Query01Linq


        // Выбирает из таблицы ТОВАРЫ информацию о товарах,
        // цена закупки которых больше 140 руб. за единицу товара
        public void Query02Ext()
        {
            var query =
                from purchase in db.Purchases
                join good in db.Goods on purchase.IdGood equals good.Id
                join unit in db.Units on purchase.IdUnit equals unit.Id
                where purchase.PricePurchase > 140
                select purchase;

            Console.WriteLine("\n\n\n Товары цена закупки составляет больше 140 руб., синтаксис запроса :\n" +
                  "--------------------------------------------------------------------------------------------------------\n" +
                  "           Наименование товара                 Кол-во товара  Ед. измерения  Цена закупки   Дата закупки\n" +
                  "--------------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Goods.Name,-41}   {p.Amount,14} {p.Units.Short,13}  {p.PricePurchase,12}  " +
                                  $"{p.DatePurchase,15:d}");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------------------------\n");
        }// Query02Ext


        public void Query02Linq()
        {
            var query = db.Purchases
                .Join(db.Purchases, purchase => purchase.IdGood, good => good.Id,
                (p, g) => new { p.Goods.Name, p.Amount, p.Units.Short, p.PricePurchase, p.DatePurchase })
                .Where(purchase => purchase.PricePurchase > 140)
                .ToList();
            Console.WriteLine("\n Товары цена закупки составляет больше 140 руб., синтаксис методов расширения:\n" +
                              "--------------------------------------------------------------------------------------------------------\n" +
                              "           Наименование товара                 Кол-во товара  Ед. измерения  Цена закупки   Дата закупки\n" +
                              "--------------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Name,-41}   {p.Amount,14} {p.Short,13}  {p.PricePurchase,12}  " +
                                  $"{p.DatePurchase,15:d}");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------------------------\n");
        }// Query02Linq


        // Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием
        // (например, «чехол защитный»), для которых цена закупки меньше 200 руб.
        public void Query03Ext()
        {
            var query =
                from purchase in db.Purchases
                join good in db.Goods on purchase.IdGood equals good.Id
                join unit in db.Units on purchase.IdUnit equals unit.Id
                where purchase.Goods.Name == "Кофе NESCAFE Классик растворимый" && purchase.PricePurchase < 200
                select purchase;

            Console.WriteLine("\n\n\n Товары с заданным наименованием, для которых цена закупки меньше 200 руб., синтаксис запроса :\n" +
                  "--------------------------------------------------------------------------------------------------------\n" +
                  "           Наименование товара                 Кол-во товара  Ед. измерения  Цена закупки   Дата закупки\n" +
                  "--------------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Goods.Name,-41}   {p.Amount,14} {p.Units.Short,13}  {p.PricePurchase,12}  " +
                                  $"{p.DatePurchase,15:d}");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------------------------\n");
        }// Query03Ext


        public void Query03Linq()
        {
            var query = db.Purchases
                .Join(db.Purchases, purchase => purchase.IdGood, good => good.Id,
                (p, g) => new { p.Goods.Name, p.Amount, p.Units.Short, p.PricePurchase, p.DatePurchase })
                .Where(purchase => purchase.Name == "Кофе NESCAFE Классик растворимый" && purchase.PricePurchase < 200)
                .ToList();
            Console.WriteLine("\n Товары с заданным наименованием, для которых цена закупки меньше 200 руб., синтаксис методов расширения:\n" +
                              "--------------------------------------------------------------------------------------------------------\n" +
                              "           Наименование товара                 Кол-во товара  Ед. измерения  Цена закупки   Дата закупки\n" +
                              "--------------------------------------------------------------------------------------------------------");
            foreach (var p in query)
            {
                Console.WriteLine($" {p.Name,-41}   {p.Amount,14} {p.Short,13}  {p.PricePurchase,12}  " +
                                  $"{p.DatePurchase,15:d}");
            } // for p
            Console.WriteLine("--------------------------------------------------------------------------------------------------------\n");
        }// Query03Linq


        // Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с
        // заданным значением процента комиссионных. 
        public void Query04Ext()
        {
            var query =
                from seller in db.Sellers
                where seller.Interest == 4
                select seller;

            Console.WriteLine("\n\n\n Продавцы с заданным значением процента комиссионных, синтаксис запроса :\n" +
                  "-------------------------------------------------------------------------\n" +
                  "    Фамилия            Имя            Отчество     Процент комиссионных\n" +
                  "-------------------------------------------------------------------------");
            foreach (var s in query)
            {
                Console.WriteLine($"   {s.Surname,-15}   {s.NameSeller,-14} {s.Patronymic,-14}  {s.Interest,12}");
            } // for p
            Console.WriteLine("-------------------------------------------------------------------------\n");
        }// Query04Ext


        public void Query04Linq()
        {
            var query = db.Sellers
                .Where(seller => seller.Interest == 4)
                .ToList();
            Console.WriteLine("\n Продавцы с заданным значением процента комиссионных, синтаксис методов расширения:\n" +
                  "-------------------------------------------------------------------------\n" +
                  "    Фамилия            Имя            Отчество     Процент комиссионных\n" +
                  "-------------------------------------------------------------------------");
            foreach (var s in query)
            {
                Console.WriteLine($"   {s.Surname,-15}   {s.NameSeller,-14} {s.Patronymic,-14}  {s.Interest,12}");
            } // for p
            Console.WriteLine("-------------------------------------------------------------------------\n");
        }// Query04Linq


        // Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех
        // зафиксированных фактах продажи товаров (Наименование товара, Цена закупки,
        // Цена продажи, дата продажи),
        // для которых Цена продажи оказалась в некоторых заданных границах. 
        public void Query05Ext()
        {
            var query =
                from sale in db.Sales
                join purchase in db.Sales on sale.IdPurchase equals purchase.Id
                where sale.PriceSale >= 150 && sale.PriceSale <= 300
                select sale;

            Console.WriteLine("\n\n\n Товары цена продажи которых оказалась в некоторых заданных границах, синтаксис запроса :\n" +
                  "-------------------------------------------------------------------------------------------\n" +
                  "           Наименование товара                    Цена закупки  Цена продажи  Дата продажи\n" +
                  "-------------------------------------------------------------------------------------------");
            foreach (var s in query)
            {
                Console.WriteLine($" {s.Purchases.Goods.Name,-41}   {s.Purchases.PricePurchase,14} {s.PriceSale,14} {s.DateSale,15:d}");
            } // for p
            Console.WriteLine("-------------------------------------------------------------------------------------------\n");
        }// Query05Ext


        public void Query05Linq()
        {
            var query = db.Sales
                .Join(db.Sales, sale => sale.IdPurchase, purchase => purchase.Id,
                (s, p) => new { s.Purchases.Goods.Name, s.Purchases.PricePurchase, s.PriceSale, s.DateSale })
                .Where(sale => sale.PriceSale >= 150 && sale.PriceSale <= 300)
                .ToList();
            Console.WriteLine("\n Товары цена продажи которых оказалась в некоторых заданных границах, синтаксис методов расширения:\n" +
                  "-------------------------------------------------------------------------------------------\n" +
                  "           Наименование товара                    Цена закупки  Цена продажи  Дата продажи\n" +
                  "-------------------------------------------------------------------------------------------");
            foreach (var s in query)
            {
                Console.WriteLine($" {s.Name,-41}   {s.PricePurchase,14} {s.PriceSale,14} {s.DateSale,15:d}");
            } // for p
            Console.WriteLine("-------------------------------------------------------------------------------------------\n");
        }// Query05Linq


        // Вычисляет прибыль от продажи за каждый проданный товар.
        // Включает поля Дата продажи, Наименование товара,
        // Цена закупки, Цена продажи, Количество проданных единиц,
        // Прибыль. Сортировка по полю Наименование товара
        public void Query06Ext()
        {
            var query =
                from sale in db.Sales
                join purchase in db.Sales on sale.IdPurchase equals purchase.Id
                orderby sale.Purchases.Goods.Name
                select sale;

            Console.WriteLine("\n\n\n Вычисляет прибыль от продажи за каждый проданный товар, синтаксис запроса :\n" +
                  "---------------------------------------------------------------------------------------------------------------------\n" +
                  " Дата продажи          Наименование товара                    Цена закупки  Цена продажи  Кол-во проданых ед. Прибыль\n" +
                  "---------------------------------------------------------------------------------------------------------------------");
            foreach (var s in query)
            {
                Console.WriteLine($"{s.DateSale,12:d}   {s.Purchases.Goods.Name,-41} {s.Purchases.PricePurchase,14}" +
                    $" {s.PriceSale,14} {s.AmountSale, 16} {(s.AmountSale - s.PriceSale) * -s.AmountSale, 10}");
            } // for p
            Console.WriteLine("---------------------------------------------------------------------------------------------------------------------\n");
        }// Query06Ext


        public void Query06Linq()
        {
            var query = db.Sales
                .Join(db.Sales, sale => sale.IdPurchase, purchase => purchase.Id,
                (s, p) => new { s.Purchases.Goods.Name, s.Purchases.PricePurchase, s.PriceSale, s.DateSale, s.AmountSale })
                .OrderBy(good => good.Name)
                .ToList();
            Console.WriteLine("\n Вычисляет прибыль от продажи за каждый проданный товар, синтаксис методов расширения:\n" +
                  "---------------------------------------------------------------------------------------------------------------------\n" +
                  " Дата продажи          Наименование товара                    Цена закупки  Цена продажи  Кол-во проданых ед. Прибыль\n" +
                  "---------------------------------------------------------------------------------------------------------------------");
            foreach (var s in query)
            {
                Console.WriteLine($"{s.DateSale,12:d}   {s.Name,-41} {s.PricePurchase,14}" +
                    $" {s.PriceSale,14} {s.AmountSale,16} {(s.AmountSale - s.PriceSale) * -s.AmountSale,10}");
            } // for p
            Console.WriteLine("---------------------------------------------------------------------------------------------------------------------\n");
        }// Query06Linq


    }// class WholesaleStore
}
