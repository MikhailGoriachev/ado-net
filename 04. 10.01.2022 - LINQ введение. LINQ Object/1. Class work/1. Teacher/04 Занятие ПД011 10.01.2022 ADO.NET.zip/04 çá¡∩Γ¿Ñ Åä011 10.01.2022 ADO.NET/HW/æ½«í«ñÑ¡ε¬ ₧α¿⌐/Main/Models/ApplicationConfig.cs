﻿namespace Main.Models
{
	public static class ApplicationConfig
	{
		public static readonly string JsonConfig = "Config.json";

		public static readonly string PublishingConnectionString = "PublishingLocalDb";
	}
}