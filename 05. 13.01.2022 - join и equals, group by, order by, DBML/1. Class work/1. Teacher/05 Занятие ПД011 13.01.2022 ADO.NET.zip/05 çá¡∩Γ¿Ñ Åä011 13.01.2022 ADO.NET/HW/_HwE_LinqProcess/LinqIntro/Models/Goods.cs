﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqIntro.Models
{
    // Класс, представляющего товар (наименование, цена, количество,
    // год выпуска) 
    public class Goods
    {
        // наименование товара
        private string _goodsName;
        public string GoodsName {
            get => _goodsName;
            set => _goodsName = value;
        } // GoodsName

        // год выпуска
        private int _year;
        public int Year {
            get => _year;
            set => _year = value;
        } // Year

        // цена
        private double _price;
        public double Price {
            get => _price;
            set {
                if (_price < 0)
                    throw new Exception($"Goods: отрицательная цена, _price = {_price}");
                _price = value;
            } // set
        } // Price

        // количество
        private int _amount;
        public int Amount {
            get => _amount;
            set {
                if (_amount < 0)
                    throw new Exception($"Goods: отрицательное количество, _amount = {_amount}");
                _amount = value;
            } // set
        } // Amount

        // Конструкторы
        public Goods() : this("мяч", 2020, 45, 1) { } // Goods

        public Goods(string goodsName, int year, double price, int amount) {
            GoodsName = goodsName;
            Year = year;
            Price = price;
            Amount = amount;
        } // Goods

        // строковое представление
        public override string ToString() =>
            $"наименование \"{_goodsName}\", год выпуска {_year}, цена единицы {_price:N2}, количество {_amount}";

        // строка таблицы
        public string ToTableRow(int i, string prefix="\t") =>
            $"{prefix}│ {i, 5} │ {_goodsName, -24} │ {_year, 11} │ {_price, 12:N2} │" +
            $" {_amount, 10} │ {_amount*_price, 12:n2} │\n";

        // заголовок таблицы товаров
        public static string Header =
            "\t┌───────┬──────────────────────────┬─────────────┬──────────────┬────────────┬──────────────┐\n" +
            "\t│ Номер │ Наименование товара      │ Год выпуска │ Цена единицы │ Количество │ Сумма товара |\n" +
            "\t├───────┼──────────────────────────┼─────────────┼──────────────┼────────────┼──────────────┤\n";

        // подвал таблицы вывода товаров
        public static string Footer =
            "\t└───────┴──────────────────────────┴─────────────┴──────────────┴────────────┴──────────────┘\n";
    } // class Goods
}
