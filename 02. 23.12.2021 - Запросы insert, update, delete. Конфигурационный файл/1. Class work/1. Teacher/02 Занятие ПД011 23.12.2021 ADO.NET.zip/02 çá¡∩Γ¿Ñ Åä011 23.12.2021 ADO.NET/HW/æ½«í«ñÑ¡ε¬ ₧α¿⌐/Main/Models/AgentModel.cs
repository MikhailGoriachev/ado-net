﻿using System.Data;
using Main.Utilities.TableFormatter;


namespace Main.Models
{
	public sealed class AgentModel : IMappable<AgentModel>
	{
		[TableData("Имя", "{0, -20}")]
		public string? Firstname { get; set; }

		[TableData("Фамилия", "{0, -20}")]
		public string? Surname { get; set; }

		[TableData("Отчество", "{0, -10}")]
		public string? Patronymic { get; set; }

		[TableData("Процент", "{0, -10:F1}")]
		public double DealPercent { get; set; }


		public AgentModel Map(DataRow row) =>
			new()
			{
				Firstname   = (string)row["Firstname"],
				Surname     = (string)row["AgentSurname"],
				Patronymic  = (string)row["Patronymic"],
				DealPercent = (double)row["DealPercent"]
			};
	}
}