﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Railway.Models
{
	// Класс, описывающий место в купе
	public class Place
	{
		// номер места
		private int _number;

		public int Number
		{
			get => _number; 
			set {
				if (value <= 0)
					throw new InvalidDataException("Place: Номер места не может быть меньше или равен нулю");

				_number = value; 
			}
		}


		// состояние места
		private bool _state;

		public bool State
		{
			get => _state;
			set { 
				_state = value;
			}
		}

		// состояние места строкой
		public string StateToString => _state ? "свободно" : "продано";


		public Place():this(1, false)
		{}


		public Place(int number, bool state)
		{
			Number = number;
			State = state;
		}
	}
}
