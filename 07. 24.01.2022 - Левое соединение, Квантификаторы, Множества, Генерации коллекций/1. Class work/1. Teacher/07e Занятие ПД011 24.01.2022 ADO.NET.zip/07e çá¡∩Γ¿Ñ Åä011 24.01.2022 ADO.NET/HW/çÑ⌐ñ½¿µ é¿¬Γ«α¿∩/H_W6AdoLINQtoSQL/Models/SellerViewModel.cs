﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6AdoLINQtoSQL.Models
{
    // Класс для Представления продавцов
    public class SellerViewModel
    {
        public string Surname { get; set; }
        public string NameSeller { get; set; }
        public string Patronymic { get; set; }
        public int Interest { get; set; }

    }// class SellerViewModel
}
