﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeriodicalsModels.Models
{
    public class SubscribersCost
    {
        public int Id { get; set; }

        public string PubType { get; set; }

        public string Title { get; set; }

        public int Price { get; set; }
        public DateTime DateStart { get; set; }

        public int Duration { get; set; }

        public decimal SubscriberCost { get; set; }

        public string ToTableRow() =>
            $"\t| {Id,3} | {PubType, 8} | {Title, 31} | {DateStart, 17} | {Duration, 10} | {SubscriberCost, 10}";


    }
}
