﻿using HomeWork.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Controllers
{
    public class Task3Controller
    {
        // список товаров
        private List<Goods> _listGoods;
        public List<Goods> ListGoods
        {
            get { return _listGoods; }
            set { _listGoods = value; }
        }


        // конструктор по умолчанию
        public Task3Controller()
        {

            _listGoods = new List<Goods>();
            InitListGoods(12);
        }


        // заполнение массива товаров
        public void InitListGoods(int count)
        {
            _listGoods.Clear();

            for (int i = 0; i < count; i++)
            {
                _listGoods.Add(Goods.CreateGoods());
            }
        }


        // товары с заданным диапазоном цен
        public void Task1(double lo, double hi)
        {

            Console.WriteLine($"Вычисление товаров с заданным диапазоном цен от {lo:f3} до {hi:f3}");
            Console.WriteLine("\nМассив товаров:");
            Console.WriteLine(Goods.Header());
            foreach (var item in _listGoods)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Goods.Footer());
            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 
            var query1 = from item in _listGoods
                          where item.Price >= lo && item.Price <= hi
                          select item;    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"товары с заданным диапазоном:\n");
            Console.WriteLine(Goods.Header());
            foreach (var item in query1)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Goods.Footer());


            Console.WriteLine("Cинтаксис методов расширения");

            // синтаксис методов расширения 
            var query2 = _listGoods
               .Where(item => item.Price >= lo && item.Price <= hi);

            Console.WriteLine($"товары с заданным диапазоном:\n");
            Console.WriteLine(Goods.Header());
            foreach (var item in query2)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Goods.Footer());
        }//  Task1()

        // сумма товаров с заданным годом выпуска
        public void Task2(int year)
        {

            Console.WriteLine($"Cумма товаров с заданным годом выпуска {year}");
            Console.WriteLine("\nМассив товаров:");
            Console.WriteLine(Goods.Header());
            foreach (var item in _listGoods)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Goods.Footer());
            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 
            double query1 = (from item in _listGoods
                             where item.Year == year
                             select item.Price * item.Amount).Sum();    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"Cумма товаров с заданным годом выпуска: {query1:f3}\n");
           


            Console.WriteLine("Cинтаксис методов расширения");

            // синтаксис методов расширения 
            double query2 = _listGoods
               .Where(item => item.Year == year)
               .Select(item => item.Price * item.Amount)
               .Sum();

            Console.WriteLine($"Cумма товаров с заданным годом выпуска: {query2:f3}\n");

        }//  Task2()

        // сумма товаров с заданным годом выпуска
        public void Task3(string name)
        {

            Console.WriteLine($"Cумма товаров с заданным наименованием  {name}");
            Console.WriteLine("\nМассив товаров:");
            Console.WriteLine(Goods.Header());
            foreach (var item in _listGoods)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Goods.Footer());
            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 
            double query1 = (from item in _listGoods
                             where item.Name == name
                             select item.Price * item.Amount).Sum();    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"Cумма товаров с заданным наименованием: {query1:f3}\n");



            Console.WriteLine("Cинтаксис методов расширения");

            // синтаксис методов расширения 
            double query2 = _listGoods
               .Where(item => item.Name == name)
               .Select(item => item.Price * item.Amount)
               .Sum();

            Console.WriteLine($"Cумма товаров с заданным наименованием: {query2:f3}\n");

        }//  Task3()

        // o	наименование и год выпуска товаров с максимальным количеством
        public void Task4()
        {

            Console.WriteLine($"Наименование и год выпуска товаров с максимальным количеством");
            Console.WriteLine("\nМассив товаров:");
            Console.WriteLine(Goods.Header());
            foreach (var item in _listGoods)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Goods.Footer());

            int maxAmount = _listGoods.Max(item => item.Amount);

            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 
            var query1 = from item in _listGoods
                             where item.Amount == maxAmount
                             select item.Name +" "+ item.Year;    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"Товары с максимальным количеством:");           
            foreach (var item in query1)
            {
                Console.WriteLine(item);
            }
            


            Console.WriteLine("\n\nCинтаксис методов расширения");

            // синтаксис методов расширения 
            var query2 = _listGoods
               .Where(item => item.Amount == maxAmount)
               .Select(item => item.Name + " " + item.Year);

            Console.WriteLine($"Товары с максимальным количеством:");
            foreach (var item in query2)
            {
                Console.WriteLine(item);
            }

        }//  Task3()

        // все товары, для которых произведение цены на количество находится в заданном диапазоне
        public void Task5(double lo, double hi)
        {

            Console.WriteLine($"Все товары, для которых произведение цены на количество находится в заданном диапазоне от {lo:f3} до {hi:f3}");
            Console.WriteLine("\nМассив товаров:");
            Console.WriteLine(Goods.Header());
            foreach (var item in _listGoods)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Goods.Footer());


           

            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 
            var query1 = from item in _listGoods
                         where item.Price * item.Amount >= lo && item.Price* item.Amount <= hi
                        select item;    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"Товары, для которых произведение цены на количество находится в заданном диапазоне:");
            Console.WriteLine(Goods.HeaderCoast());
            foreach (var item in query1)
            {
                Console.WriteLine(item.ToTableRow() + $" {item.Price * item.Amount,-20} |");
            }
            Console.WriteLine(Goods.FooterCoast());



            Console.WriteLine("\n\nCинтаксис методов расширения");

            // синтаксис методов расширения 
            var query2 = _listGoods
               .Where(item => item.Price * item.Amount >= lo && item.Price * item.Amount <= hi);


            Console.WriteLine($"Товары, для которых произведение цены на количество находится в заданном диапазоне:");
            Console.WriteLine(Goods.HeaderCoast() );
            foreach (var item in query2)
            {
                Console.WriteLine(item.ToTableRow() + $" {item.Price * item.Amount,-20} |") ;
            }
            Console.WriteLine(Goods.FooterCoast());

        }//  Task3()
    }
}
