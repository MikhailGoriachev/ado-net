﻿namespace Main.Models
{
	public sealed class MathModel
	{
		public double A { get; set; }
		public double B { get; set; }
		public double C { get; set; }


		public void Deconstruct(out double a, out double b, out double c)
		{
			a  = A;
			b = B;
			c  = C;
		}
	}
}