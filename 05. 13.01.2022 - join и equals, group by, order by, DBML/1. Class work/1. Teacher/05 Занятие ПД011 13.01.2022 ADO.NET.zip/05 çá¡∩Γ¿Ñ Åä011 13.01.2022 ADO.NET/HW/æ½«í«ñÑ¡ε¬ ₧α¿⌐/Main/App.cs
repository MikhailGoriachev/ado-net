﻿using Main.Controllers;
using Main.Utilities.Menu;


namespace Main
{
	public sealed class App : MenuWrapper
	{
		private readonly Task2Controller _secondTask = new();
		private readonly Task3Controller _thirdTask = new();


		public App() =>
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Вторая задача", _secondTask.Run) { IsSimpleInvoke = true },
				new MenuItem("Третья задача", _thirdTask.Run) { IsSimpleInvoke  = true }
			});
	}
}