﻿using System;
using Main.Models;


namespace Main.Controllers
{
	internal sealed class MainController
	{
		private readonly MathModel _model;


		public MainController(MathModel model) =>
			_model = model;


		public double CalculateAverageArithmetic()
		{
			var (a, b, c) = _model;

			return (a + b + c) / 3;
		}


		public double CalculateAverageGeometric()
		{
			var (a, b, c) = _model;

			return Math.Cbrt(a * b * c);
		}


		public (double x1, double x2) CalculateEquation()
		{
			var (a, b, c) = _model;

			double d = b * b - 4 * a * c;

			return d switch
			{
				> 0 => (CalculateRoot(false), CalculateRoot(true)),
				< 0 => (double.NaN, double.NaN),
				_   => (-(b / (2 * a)), double.NaN)
			};
		}


		private double Discriminant()
		{
			var (a, b, c) = _model;

			return b * b - 4 * a * c;
		}


		private double CalculateRoot(bool isPlusInvertedToMinus)
		{
			var (a, b, c) = _model;

			return isPlusInvertedToMinus
					   ? (-b - Math.Sqrt(Discriminant())) / (2 * a)
					   : (-b + Math.Sqrt(Discriminant())) / (2 * a);
		}
	}
}