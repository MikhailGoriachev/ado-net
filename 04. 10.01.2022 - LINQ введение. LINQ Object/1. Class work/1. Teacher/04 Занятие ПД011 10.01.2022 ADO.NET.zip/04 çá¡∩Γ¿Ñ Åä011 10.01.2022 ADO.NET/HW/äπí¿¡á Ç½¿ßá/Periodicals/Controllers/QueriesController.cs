﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Periodicals.Models;

namespace Periodicals.Controllers
{
    class QueriesController {
        // строка подключения к базе данных
        private string _connectingString;
        public string ConnectingString {
            get => _connectingString;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Не указана строка подключения к базе данных");

                _connectingString = value;
            } // set
        } // ConnectionString

        public QueriesController(string connectingString) {
            ConnectingString = connectingString;
        } // QueriesController

        // 1. Хранимая процедура
        //    Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа,
        //    стоимость 1 экземпляра для которых меньше заданной.
        //    Требуется модельдля вывода данных – данные выборки помещать в коллекцию
        public void Query01(int price = 250, string pubType = "журнал") {
            Console.WriteLine($"\n  Заданный тип : {pubType}");
            Console.WriteLine($"  Заданная цена: {price}");
            List<PublicationViewModel> publications = new List<PublicationViewModel>();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery01");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // задать параметры запроса
                cmd.Parameters.AddWithValue("@price", price);
                cmd.Parameters.AddWithValue("@pubType", pubType);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    while (reader.Read()) {
                        publications.Add(new PublicationViewModel
                        {
                            Id = reader.GetInt32(0),
                            PubIndex = reader.GetString(1),
                            PubType = reader.GetString(2),
                            Title = reader.GetString(3),
                            Price = reader.GetInt32(4),

                        });
                    } // while
                    Console.WriteLine(PublicationViewModel.Header);
                    publications.ForEach(x => Console.WriteLine(x.ToTableRow));
                    Console.WriteLine(PublicationViewModel.Footer);
                } // if
            } // using
            Console.WriteLine();
        } // Query01


        // 2. Хранимая процедура	
        //    Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром
        //    улице и номере дома, которые оформили подписку на издание с заданным параметром наименованием
        //    Требуется модельдля вывода данных – данные выборки помещать в коллекцию
        public void Query02(string title = "Юный техник", string street = "ул. Садовая", string building = "118") {
            Console.WriteLine($"\n  Заданная улица             : {street}");
            Console.WriteLine($"  Заданный номер дома        : {building}");
            Console.WriteLine($"  Заданное номер наименование: {title}");

            List<SubscriberViewModel> subscribers = new List<SubscriberViewModel>();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery02");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@street", street);
                cmd.Parameters.AddWithValue("@building", building);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    while (reader.Read()) {
                        subscribers.Add(new SubscriberViewModel { 
                            Id = reader.GetInt32(0),
                            FullName = reader.GetString(1),
                            Passport = reader.GetString(2),
                            Address = reader.GetString(3),
                            PubType = reader.GetString(4),
                            Title = reader.GetString(5),
                        });
                    } // while
                    Console.WriteLine(SubscriberViewModel.Header);
                    subscribers.ForEach(subscriber => Console.WriteLine(subscriber.ToTableRow));
                    Console.WriteLine(SubscriberViewModel.Footer);
                } // if
            } // using
            Console.WriteLine();
        } // Query02


        // 3. Хранимая процедура	
        //    Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение
        //    в поле Цена 1 экземпляра находится в заданном диапазоне значений
        //    Требуется модель для вывода данных – данные выборки помещать в коллекцию
        public void Query03(int lo = 100, int hi = 150) {
            Console.WriteLine($"  Заданный диапазон: от {lo:n2} до {hi:n2}");

            List<PublicationViewModel> publications = new List<PublicationViewModel>();
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery03");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    while (reader.Read()) {
                        publications.Add(new PublicationViewModel
                        {
                            Id = reader.GetInt32(0),
                            PubIndex = reader.GetString(1),
                            PubType = reader.GetString(2),
                            Title = reader.GetString(3),
                            Price = reader.GetInt32(4),

                        });
                    } // while
                    Console.WriteLine(PublicationViewModel.Header);
                    publications.ForEach(x => Console.WriteLine(x.ToTableRow));
                    Console.WriteLine(PublicationViewModel.Footer);
                } // if
            } // using
            Console.WriteLine();
        } // Query03


        // 4. Хранимая процедура	
        //    Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания
        //    Требуется модель для вывода данных – данные выборки помещать в коллекцию
        public void Query04(string pubType = "газета") {
            Console.WriteLine($"\nЗаданный тип издания:{pubType}");

            List<SubscriberViewModel> subscribers = new List<SubscriberViewModel>();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery04");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@pubType", pubType);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    while (reader.Read()) {
                        subscribers.Add(new SubscriberViewModel { 
                            Id = reader.GetInt32(0),
                            FullName = reader.GetString(1),
                            Passport = reader.GetString(2),
                            Address = reader.GetString(3),
                            PubType = reader.GetString(4),
                            Title = reader.GetString(5),
                        });
                    } // while
                    Console.WriteLine(SubscriberViewModel.Header);
                    subscribers.ForEach(subscriber => Console.WriteLine(subscriber.ToTableRow));
                    Console.WriteLine(SubscriberViewModel.Footer);
                } // if
            } // using
            Console.WriteLine();
        } // Query04


        // 5. Хранимая процедура	
        //    Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках,
        //    для которых срок подписки есть значение из некоторого диапазона
        public void Query05(int lo = 3, int hi = 4) {
            Console.WriteLine($"\nЗаданный диапазон: от {lo} до {hi}");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery05");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────────────────────┬────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-31} │ " +
                        $"{reader.GetName(2),-10} │ {reader.GetName(3),-10} │ {reader.GetName(4),-10} │");
                    Console.WriteLine("\t├────┼─────────────────────────────────┼────────────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-31} │ {reader.GetString(2),10} │ " +
                            $"{reader.GetInt32(3),10} │ {reader.GetDateTime(4),10:dd/MM/yyyy} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────────────────────┴────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query05


        // 6. Хранимая процедура	
        //    Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС.
        //    Включает поля: Индекс издания, Наименование издания, Цена 1 экземпляра,
        //    Дата начала подписки, Срок подписки, Стоимость подписки без НДС.
        //    Сортировка по полю Индекс издания
        public void Query06() {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery06");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬──────────┬──────────────────────────────────┬─────────┬────────────┬────────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),2} │ " +
                        $"{reader.GetName(1),-8} │ {reader.GetName(2),-32} │ {reader.GetName(3),-7} │ {reader.GetName(4),-10} │ {reader.GetName(5),-10} │ {reader.GetName(6),-15} │");
                    Console.WriteLine("\t├────┼──────────┼──────────────────────────────────┼─────────┼────────────┼────────────┼─────────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0), 2} │ {reader.GetString(1),8} │ " +
                            $"{reader.GetString(2),-32} │ {reader.GetInt32(3),7:n1} │ " +
                            $"{reader.GetDateTime(4),10:dd/MM/yyyy} │ {reader.GetInt32(5),10} │ {reader.GetDecimal(6),15:n2} │");
                    } // while
                    Console.WriteLine("\t└────┴──────────┴──────────────────────────────────┴─────────┴────────────┴────────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query06


        // 7. Хранимая процедура
        //    Выполняет группировку по полю Вид издания.
        //    Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра

        public void Query07() {

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery07");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌─────────────────┬────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0), -15} │ {reader.GetName(1),-10} │ " +
                        $"{reader.GetName(2),-10} │ {reader.GetName(3),-10} │");
                    Console.WriteLine("\t├─────────────────┼────────────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-15} │ " +
                            $"{reader.GetInt32(1),10} │ {reader.GetInt32(2),10:n2} │ " +
                            $"{reader.GetInt32(2),10:n2} │");
                    } // while
                    Console.WriteLine("\t└─────────────────┴────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query07


        // 8. Хранимая процедура	
        //    Выполняет группировку по полю Улица.
        //    Для всех улиц вычисляет количество подписчиков, проживающих на данной улице

        public void Query08() {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery08");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌───────────────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-17} │ {reader.GetName(1),-15} │");
                    Console.WriteLine("\t├───────────────────┼─────────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-17} │ {reader.GetInt32(1), 15} │");
                    } // while
                    Console.WriteLine("\t└───────────────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query08


        // 9. Хранимая процедура	
        //    Для всех изданий выводит количество оформленных подписок

        public void Query09() {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery09");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────────────────────────────────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-34} │ {reader.GetName(1),-15} │");
                    Console.WriteLine("\t├────────────────────────────────────┼─────────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-34} │ {reader.GetInt32(1), 15} │");
                    } // while
                    Console.WriteLine("\t└────────────────────────────────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query09
    }
}
