﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	// модель представления закупки товара
	public class GoodsPurchaseViewModel
	{
		// идентификатор товара
		public int Id { get; set; }
		
		// номенклатура товара
		public string Title { get; set; }
		
		// стоимость закупки товара
		public int Price { get; set; }

	}
}
