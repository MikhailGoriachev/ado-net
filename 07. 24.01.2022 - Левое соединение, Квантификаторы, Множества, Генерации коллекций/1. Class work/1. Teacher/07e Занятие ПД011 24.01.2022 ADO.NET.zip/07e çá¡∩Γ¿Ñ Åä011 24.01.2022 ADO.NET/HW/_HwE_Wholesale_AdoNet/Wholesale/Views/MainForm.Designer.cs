﻿
namespace Wholesale
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.товарыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.продавцыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.закупеиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.продажиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.запрос5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.запрос7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.TsbGoods = new System.Windows.Forms.ToolStripButton();
            this.TsbSellers = new System.Windows.Forms.ToolStripButton();
            this.TsbPurchases = new System.Windows.Forms.ToolStripButton();
            this.TsbSales = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbQuery01 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery02 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery03 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery04 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbQuery05 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery06 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbQuery07 = new System.Windows.Forms.ToolStripButton();
            this.TsbQuery08 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.TslInfo = new System.Windows.Forms.ToolStripStatusLabel();
            this.TbcResults = new System.Windows.Forms.TabControl();
            this.TbpGoods = new System.Windows.Forms.TabPage();
            this.DgvGoods = new System.Windows.Forms.DataGridView();
            this.TbpSellers = new System.Windows.Forms.TabPage();
            this.DgvSellers = new System.Windows.Forms.DataGridView();
            this.TbpPurchases = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.TbpSales = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.TbpQuery01 = new System.Windows.Forms.TabPage();
            this.DgvQuery01 = new System.Windows.Forms.DataGridView();
            this.TbpQuery02 = new System.Windows.Forms.TabPage();
            this.DgvQuery02 = new System.Windows.Forms.DataGridView();
            this.TbpQuery03 = new System.Windows.Forms.TabPage();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.TbpQuery04 = new System.Windows.Forms.TabPage();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.TbpQuery05 = new System.Windows.Forms.TabPage();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.TbpQuery06 = new System.Windows.Forms.TabPage();
            this.DgvQuery06 = new System.Windows.Forms.DataGridView();
            this.TbpQuery07 = new System.Windows.Forms.TabPage();
            this.DgvQuery07 = new System.Windows.Forms.DataGridView();
            this.TbpQuery08 = new System.Windows.Forms.TabPage();
            this.DgvQuery08 = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.TbcResults.SuspendLayout();
            this.TbpGoods.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvGoods)).BeginInit();
            this.TbpSellers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSellers)).BeginInit();
            this.TbpPurchases.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.TbpSales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.TbpQuery01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).BeginInit();
            this.TbpQuery02.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).BeginInit();
            this.TbpQuery03.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.TbpQuery04.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.TbpQuery05.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.TbpQuery06.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).BeginInit();
            this.TbpQuery07.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery07)).BeginInit();
            this.TbpQuery08.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery08)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.таблицыToolStripMenuItem,
            this.запросыToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(979, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(53, 23);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = global::Wholesale.Properties.Resources.door_out;
            this.выходToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(134, 38);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // таблицыToolStripMenuItem
            // 
            this.таблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.товарыToolStripMenuItem,
            this.продавцыToolStripMenuItem,
            this.закупеиToolStripMenuItem,
            this.продажиToolStripMenuItem});
            this.таблицыToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.таблицыToolStripMenuItem.Name = "таблицыToolStripMenuItem";
            this.таблицыToolStripMenuItem.Size = new System.Drawing.Size(76, 23);
            this.таблицыToolStripMenuItem.Text = "Таблицы";
            // 
            // товарыToolStripMenuItem
            // 
            this.товарыToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.товарыToolStripMenuItem.Name = "товарыToolStripMenuItem";
            this.товарыToolStripMenuItem.Size = new System.Drawing.Size(144, 24);
            this.товарыToolStripMenuItem.Text = "Товары";
            this.товарыToolStripMenuItem.Click += new System.EventHandler(this.ViewGoods_Command);
            // 
            // продавцыToolStripMenuItem
            // 
            this.продавцыToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.продавцыToolStripMenuItem.Name = "продавцыToolStripMenuItem";
            this.продавцыToolStripMenuItem.Size = new System.Drawing.Size(144, 24);
            this.продавцыToolStripMenuItem.Text = "Продавцы";
            this.продавцыToolStripMenuItem.Click += new System.EventHandler(this.ViewSellers_Command);
            // 
            // закупеиToolStripMenuItem
            // 
            this.закупеиToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.закупеиToolStripMenuItem.Name = "закупеиToolStripMenuItem";
            this.закупеиToolStripMenuItem.Size = new System.Drawing.Size(144, 24);
            this.закупеиToolStripMenuItem.Text = "Закупки";
            // 
            // продажиToolStripMenuItem
            // 
            this.продажиToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.продажиToolStripMenuItem.Name = "продажиToolStripMenuItem";
            this.продажиToolStripMenuItem.Size = new System.Drawing.Size(144, 24);
            this.продажиToolStripMenuItem.Text = "Продажи";
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запрос1ToolStripMenuItem,
            this.запрос2ToolStripMenuItem,
            this.запрос3ToolStripMenuItem,
            this.запрос4ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.запрос5ToolStripMenuItem,
            this.запрос6ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.запрос7ToolStripMenuItem,
            this.запрос8ToolStripMenuItem});
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(76, 23);
            this.запросыToolStripMenuItem.Text = "Запросы";
            // 
            // запрос1ToolStripMenuItem
            // 
            this.запрос1ToolStripMenuItem.Image = global::Wholesale.Properties.Resources.report_images;
            this.запрос1ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос1ToolStripMenuItem.Name = "запрос1ToolStripMenuItem";
            this.запрос1ToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.запрос1ToolStripMenuItem.Text = "Запрос 1";
            this.запрос1ToolStripMenuItem.Click += new System.EventHandler(this.Query01_Command);
            // 
            // запрос2ToolStripMenuItem
            // 
            this.запрос2ToolStripMenuItem.Image = global::Wholesale.Properties.Resources.report_key;
            this.запрос2ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос2ToolStripMenuItem.Name = "запрос2ToolStripMenuItem";
            this.запрос2ToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.запрос2ToolStripMenuItem.Text = "Запрос 2";
            this.запрос2ToolStripMenuItem.Click += new System.EventHandler(this.Query02_Command);
            // 
            // запрос3ToolStripMenuItem
            // 
            this.запрос3ToolStripMenuItem.Image = global::Wholesale.Properties.Resources.report_link;
            this.запрос3ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос3ToolStripMenuItem.Name = "запрос3ToolStripMenuItem";
            this.запрос3ToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.запрос3ToolStripMenuItem.Text = "Запрос 3";
            // 
            // запрос4ToolStripMenuItem
            // 
            this.запрос4ToolStripMenuItem.Image = global::Wholesale.Properties.Resources.report_picture;
            this.запрос4ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос4ToolStripMenuItem.Name = "запрос4ToolStripMenuItem";
            this.запрос4ToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.запрос4ToolStripMenuItem.Text = "Запрос 4";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(148, 6);
            // 
            // запрос5ToolStripMenuItem
            // 
            this.запрос5ToolStripMenuItem.Image = global::Wholesale.Properties.Resources.report_stack;
            this.запрос5ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос5ToolStripMenuItem.Name = "запрос5ToolStripMenuItem";
            this.запрос5ToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.запрос5ToolStripMenuItem.Text = "Запрос 5";
            // 
            // запрос6ToolStripMenuItem
            // 
            this.запрос6ToolStripMenuItem.Image = global::Wholesale.Properties.Resources.report_user;
            this.запрос6ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос6ToolStripMenuItem.Name = "запрос6ToolStripMenuItem";
            this.запрос6ToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.запрос6ToolStripMenuItem.Text = "Запрос 6";
            this.запрос6ToolStripMenuItem.Click += new System.EventHandler(this.Query06_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(148, 6);
            // 
            // запрос7ToolStripMenuItem
            // 
            this.запрос7ToolStripMenuItem.Image = global::Wholesale.Properties.Resources.report;
            this.запрос7ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос7ToolStripMenuItem.Name = "запрос7ToolStripMenuItem";
            this.запрос7ToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.запрос7ToolStripMenuItem.Text = "Запрос 7";
            this.запрос7ToolStripMenuItem.Click += new System.EventHandler(this.Query07_Command);
            // 
            // запрос8ToolStripMenuItem
            // 
            this.запрос8ToolStripMenuItem.Image = global::Wholesale.Properties.Resources.report_green;
            this.запрос8ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос8ToolStripMenuItem.Name = "запрос8ToolStripMenuItem";
            this.запрос8ToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.запрос8ToolStripMenuItem.Text = "Запрос 8";
            this.запрос8ToolStripMenuItem.Click += new System.EventHandler(this.Query08_Command);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(74, 23);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::Wholesale.Properties.Resources.help;
            this.оПрограммеToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(180, 38);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbGoods,
            this.TsbSellers,
            this.TsbPurchases,
            this.TsbSales,
            this.toolStripSeparator1,
            this.TsbQuery01,
            this.TsbQuery02,
            this.TsbQuery03,
            this.TsbQuery04,
            this.toolStripSeparator2,
            this.TsbQuery05,
            this.TsbQuery06,
            this.toolStripSeparator3,
            this.TsbQuery07,
            this.TsbQuery08,
            this.toolStripSeparator4,
            this.TsbAbout,
            this.TsbExit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 27);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.toolStrip1.Size = new System.Drawing.Size(979, 39);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // TsbGoods
            // 
            this.TsbGoods.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbGoods.Image = ((System.Drawing.Image)(resources.GetObject("TsbGoods.Image")));
            this.TsbGoods.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbGoods.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbGoods.Name = "TsbGoods";
            this.TsbGoods.Size = new System.Drawing.Size(23, 36);
            this.TsbGoods.Text = "toolStripButton1";
            this.TsbGoods.ToolTipText = "Товары";
            this.TsbGoods.Click += new System.EventHandler(this.ViewGoods_Command);
            // 
            // TsbSellers
            // 
            this.TsbSellers.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSellers.Image = ((System.Drawing.Image)(resources.GetObject("TsbSellers.Image")));
            this.TsbSellers.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSellers.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSellers.Name = "TsbSellers";
            this.TsbSellers.Size = new System.Drawing.Size(23, 36);
            this.TsbSellers.Text = "toolStripButton2";
            this.TsbSellers.ToolTipText = "Продавцы";
            this.TsbSellers.Click += new System.EventHandler(this.ViewSellers_Command);
            // 
            // TsbPurchases
            // 
            this.TsbPurchases.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbPurchases.Image = ((System.Drawing.Image)(resources.GetObject("TsbPurchases.Image")));
            this.TsbPurchases.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbPurchases.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbPurchases.Name = "TsbPurchases";
            this.TsbPurchases.Size = new System.Drawing.Size(23, 36);
            this.TsbPurchases.Text = "toolStripButton3";
            this.TsbPurchases.ToolTipText = "Закупки";
            // 
            // TsbSales
            // 
            this.TsbSales.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSales.Image = ((System.Drawing.Image)(resources.GetObject("TsbSales.Image")));
            this.TsbSales.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSales.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSales.Name = "TsbSales";
            this.TsbSales.Size = new System.Drawing.Size(23, 36);
            this.TsbSales.Text = "toolStripButton4";
            this.TsbSales.ToolTipText = "Продажи";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbQuery01
            // 
            this.TsbQuery01.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery01.Image = global::Wholesale.Properties.Resources.report_images;
            this.TsbQuery01.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery01.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery01.Name = "TsbQuery01";
            this.TsbQuery01.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery01.Text = "toolStripButton5";
            this.TsbQuery01.Click += new System.EventHandler(this.Query01_Command);
            // 
            // TsbQuery02
            // 
            this.TsbQuery02.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery02.Image = global::Wholesale.Properties.Resources.report_key;
            this.TsbQuery02.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery02.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery02.Name = "TsbQuery02";
            this.TsbQuery02.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery02.Text = "toolStripButton6";
            this.TsbQuery02.Click += new System.EventHandler(this.Query02_Command);
            // 
            // TsbQuery03
            // 
            this.TsbQuery03.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery03.Image = global::Wholesale.Properties.Resources.report_link;
            this.TsbQuery03.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery03.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery03.Name = "TsbQuery03";
            this.TsbQuery03.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery03.Text = "toolStripButton7";
            // 
            // TsbQuery04
            // 
            this.TsbQuery04.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery04.Image = global::Wholesale.Properties.Resources.report_picture;
            this.TsbQuery04.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery04.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery04.Name = "TsbQuery04";
            this.TsbQuery04.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery04.Text = "toolStripButton8";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbQuery05
            // 
            this.TsbQuery05.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery05.Image = global::Wholesale.Properties.Resources.report_stack;
            this.TsbQuery05.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery05.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery05.Name = "TsbQuery05";
            this.TsbQuery05.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery05.Text = "toolStripButton9";
            // 
            // TsbQuery06
            // 
            this.TsbQuery06.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery06.Image = global::Wholesale.Properties.Resources.report_user;
            this.TsbQuery06.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery06.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery06.Name = "TsbQuery06";
            this.TsbQuery06.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery06.Text = "toolStripButton10";
            this.TsbQuery06.Click += new System.EventHandler(this.Query06_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbQuery07
            // 
            this.TsbQuery07.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery07.Image = global::Wholesale.Properties.Resources.report;
            this.TsbQuery07.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery07.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery07.Name = "TsbQuery07";
            this.TsbQuery07.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery07.Text = "toolStripButton11";
            this.TsbQuery07.Click += new System.EventHandler(this.Query07_Command);
            // 
            // TsbQuery08
            // 
            this.TsbQuery08.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuery08.Image = global::Wholesale.Properties.Resources.report_green;
            this.TsbQuery08.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuery08.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuery08.Name = "TsbQuery08";
            this.TsbQuery08.Size = new System.Drawing.Size(36, 36);
            this.TsbQuery08.Text = "toolStripButton12";
            this.TsbQuery08.Click += new System.EventHandler(this.Query08_Command);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAbout
            // 
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::Wholesale.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.Text = "toolStripButton13";
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::Wholesale.Properties.Resources.door_out;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(36, 36);
            this.TsbExit.Text = "toolStripButton14";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TslInfo});
            this.statusStrip1.Location = new System.Drawing.Point(0, 534);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(979, 24);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // TslInfo
            // 
            this.TslInfo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.TslInfo.Name = "TslInfo";
            this.TslInfo.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.TslInfo.Size = new System.Drawing.Size(964, 19);
            this.TslInfo.Spring = true;
            this.TslInfo.Text = "Готово";
            this.TslInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbcResults
            // 
            this.TbcResults.Controls.Add(this.TbpGoods);
            this.TbcResults.Controls.Add(this.TbpSellers);
            this.TbcResults.Controls.Add(this.TbpPurchases);
            this.TbcResults.Controls.Add(this.TbpSales);
            this.TbcResults.Controls.Add(this.TbpQuery01);
            this.TbcResults.Controls.Add(this.TbpQuery02);
            this.TbcResults.Controls.Add(this.TbpQuery03);
            this.TbcResults.Controls.Add(this.TbpQuery04);
            this.TbcResults.Controls.Add(this.TbpQuery05);
            this.TbcResults.Controls.Add(this.TbpQuery06);
            this.TbcResults.Controls.Add(this.TbpQuery07);
            this.TbcResults.Controls.Add(this.TbpQuery08);
            this.TbcResults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcResults.Location = new System.Drawing.Point(0, 66);
            this.TbcResults.Name = "TbcResults";
            this.TbcResults.SelectedIndex = 0;
            this.TbcResults.Size = new System.Drawing.Size(979, 468);
            this.TbcResults.TabIndex = 3;
            // 
            // TbpGoods
            // 
            this.TbpGoods.Controls.Add(this.DgvGoods);
            this.TbpGoods.Location = new System.Drawing.Point(4, 25);
            this.TbpGoods.Name = "TbpGoods";
            this.TbpGoods.Padding = new System.Windows.Forms.Padding(3);
            this.TbpGoods.Size = new System.Drawing.Size(971, 439);
            this.TbpGoods.TabIndex = 0;
            this.TbpGoods.Text = "Товары";
            this.TbpGoods.UseVisualStyleBackColor = true;
            // 
            // DgvGoods
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.DgvGoods.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvGoods.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvGoods.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvGoods.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvGoods.Location = new System.Drawing.Point(3, 3);
            this.DgvGoods.MultiSelect = false;
            this.DgvGoods.Name = "DgvGoods";
            this.DgvGoods.ReadOnly = true;
            this.DgvGoods.RowHeadersVisible = false;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DgvGoods.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DgvGoods.Size = new System.Drawing.Size(965, 433);
            this.DgvGoods.TabIndex = 0;
            // 
            // TbpSellers
            // 
            this.TbpSellers.Controls.Add(this.DgvSellers);
            this.TbpSellers.Location = new System.Drawing.Point(4, 25);
            this.TbpSellers.Name = "TbpSellers";
            this.TbpSellers.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSellers.Size = new System.Drawing.Size(971, 439);
            this.TbpSellers.TabIndex = 1;
            this.TbpSellers.Text = "Продавцы";
            this.TbpSellers.UseVisualStyleBackColor = true;
            // 
            // DgvSellers
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.DgvSellers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.DgvSellers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvSellers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSellers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvSellers.Location = new System.Drawing.Point(3, 3);
            this.DgvSellers.MultiSelect = false;
            this.DgvSellers.Name = "DgvSellers";
            this.DgvSellers.ReadOnly = true;
            this.DgvSellers.RowHeadersVisible = false;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DgvSellers.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DgvSellers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvSellers.Size = new System.Drawing.Size(965, 433);
            this.DgvSellers.TabIndex = 1;
            // 
            // TbpPurchases
            // 
            this.TbpPurchases.Controls.Add(this.dataGridView1);
            this.TbpPurchases.Location = new System.Drawing.Point(4, 25);
            this.TbpPurchases.Name = "TbpPurchases";
            this.TbpPurchases.Padding = new System.Windows.Forms.Padding(3);
            this.TbpPurchases.Size = new System.Drawing.Size(971, 439);
            this.TbpPurchases.TabIndex = 2;
            this.TbpPurchases.Text = "Закупки";
            this.TbpPurchases.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(965, 433);
            this.dataGridView1.TabIndex = 2;
            // 
            // TbpSales
            // 
            this.TbpSales.Controls.Add(this.dataGridView2);
            this.TbpSales.Location = new System.Drawing.Point(4, 25);
            this.TbpSales.Name = "TbpSales";
            this.TbpSales.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSales.Size = new System.Drawing.Size(971, 439);
            this.TbpSales.TabIndex = 3;
            this.TbpSales.Text = "Продажи";
            this.TbpSales.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(965, 433);
            this.dataGridView2.TabIndex = 2;
            // 
            // TbpQuery01
            // 
            this.TbpQuery01.Controls.Add(this.DgvQuery01);
            this.TbpQuery01.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery01.Name = "TbpQuery01";
            this.TbpQuery01.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery01.Size = new System.Drawing.Size(971, 439);
            this.TbpQuery01.TabIndex = 4;
            this.TbpQuery01.Text = "Запрос 1";
            this.TbpQuery01.UseVisualStyleBackColor = true;
            // 
            // DgvQuery01
            // 
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.DgvQuery01.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.DgvQuery01.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvQuery01.Location = new System.Drawing.Point(3, 3);
            this.DgvQuery01.MultiSelect = false;
            this.DgvQuery01.Name = "DgvQuery01";
            this.DgvQuery01.ReadOnly = true;
            this.DgvQuery01.RowHeadersVisible = false;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DgvQuery01.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DgvQuery01.Size = new System.Drawing.Size(965, 433);
            this.DgvQuery01.TabIndex = 1;
            // 
            // TbpQuery02
            // 
            this.TbpQuery02.Controls.Add(this.DgvQuery02);
            this.TbpQuery02.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery02.Name = "TbpQuery02";
            this.TbpQuery02.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery02.Size = new System.Drawing.Size(971, 439);
            this.TbpQuery02.TabIndex = 5;
            this.TbpQuery02.Text = "Запрос 2";
            this.TbpQuery02.UseVisualStyleBackColor = true;
            // 
            // DgvQuery02
            // 
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.DgvQuery02.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.DgvQuery02.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvQuery02.Location = new System.Drawing.Point(3, 3);
            this.DgvQuery02.MultiSelect = false;
            this.DgvQuery02.Name = "DgvQuery02";
            this.DgvQuery02.ReadOnly = true;
            this.DgvQuery02.RowHeadersVisible = false;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DgvQuery02.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.DgvQuery02.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery02.Size = new System.Drawing.Size(965, 433);
            this.DgvQuery02.TabIndex = 2;
            // 
            // TbpQuery03
            // 
            this.TbpQuery03.Controls.Add(this.dataGridView4);
            this.TbpQuery03.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery03.Name = "TbpQuery03";
            this.TbpQuery03.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery03.Size = new System.Drawing.Size(971, 439);
            this.TbpQuery03.TabIndex = 6;
            this.TbpQuery03.Text = "Запрос 3";
            this.TbpQuery03.UseVisualStyleBackColor = true;
            // 
            // dataGridView4
            // 
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridView4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView4.Location = new System.Drawing.Point(3, 3);
            this.dataGridView4.MultiSelect = false;
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowHeadersVisible = false;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView4.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4.Size = new System.Drawing.Size(965, 433);
            this.dataGridView4.TabIndex = 2;
            // 
            // TbpQuery04
            // 
            this.TbpQuery04.Controls.Add(this.dataGridView5);
            this.TbpQuery04.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery04.Name = "TbpQuery04";
            this.TbpQuery04.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery04.Size = new System.Drawing.Size(971, 439);
            this.TbpQuery04.TabIndex = 7;
            this.TbpQuery04.Text = "Запрос 4";
            this.TbpQuery04.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridView5.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView5.Location = new System.Drawing.Point(3, 3);
            this.dataGridView5.MultiSelect = false;
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.RowHeadersVisible = false;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView5.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView5.Size = new System.Drawing.Size(965, 433);
            this.dataGridView5.TabIndex = 2;
            // 
            // TbpQuery05
            // 
            this.TbpQuery05.Controls.Add(this.dataGridView6);
            this.TbpQuery05.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery05.Name = "TbpQuery05";
            this.TbpQuery05.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery05.Size = new System.Drawing.Size(971, 439);
            this.TbpQuery05.TabIndex = 8;
            this.TbpQuery05.Text = "Запрос 5";
            this.TbpQuery05.UseVisualStyleBackColor = true;
            // 
            // dataGridView6
            // 
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridView6.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView6.Location = new System.Drawing.Point(3, 3);
            this.dataGridView6.MultiSelect = false;
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            this.dataGridView6.RowHeadersVisible = false;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView6.RowsDefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView6.Size = new System.Drawing.Size(965, 433);
            this.dataGridView6.TabIndex = 2;
            // 
            // TbpQuery06
            // 
            this.TbpQuery06.Controls.Add(this.DgvQuery06);
            this.TbpQuery06.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery06.Name = "TbpQuery06";
            this.TbpQuery06.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery06.Size = new System.Drawing.Size(971, 439);
            this.TbpQuery06.TabIndex = 9;
            this.TbpQuery06.Text = "Запрос 6";
            this.TbpQuery06.UseVisualStyleBackColor = true;
            // 
            // DgvQuery06
            // 
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.DgvQuery06.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.DgvQuery06.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery06.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvQuery06.Location = new System.Drawing.Point(3, 3);
            this.DgvQuery06.MultiSelect = false;
            this.DgvQuery06.Name = "DgvQuery06";
            this.DgvQuery06.ReadOnly = true;
            this.DgvQuery06.RowHeadersVisible = false;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DgvQuery06.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.DgvQuery06.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery06.Size = new System.Drawing.Size(965, 433);
            this.DgvQuery06.TabIndex = 2;
            // 
            // TbpQuery07
            // 
            this.TbpQuery07.Controls.Add(this.DgvQuery07);
            this.TbpQuery07.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery07.Name = "TbpQuery07";
            this.TbpQuery07.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery07.Size = new System.Drawing.Size(971, 439);
            this.TbpQuery07.TabIndex = 10;
            this.TbpQuery07.Text = "Запрос 7";
            this.TbpQuery07.UseVisualStyleBackColor = true;
            // 
            // DgvQuery07
            // 
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.DgvQuery07.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.DgvQuery07.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery07.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvQuery07.Location = new System.Drawing.Point(3, 3);
            this.DgvQuery07.MultiSelect = false;
            this.DgvQuery07.Name = "DgvQuery07";
            this.DgvQuery07.ReadOnly = true;
            this.DgvQuery07.RowHeadersVisible = false;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DgvQuery07.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.DgvQuery07.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery07.Size = new System.Drawing.Size(965, 433);
            this.DgvQuery07.TabIndex = 2;
            // 
            // TbpQuery08
            // 
            this.TbpQuery08.Controls.Add(this.DgvQuery08);
            this.TbpQuery08.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery08.Name = "TbpQuery08";
            this.TbpQuery08.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery08.Size = new System.Drawing.Size(971, 439);
            this.TbpQuery08.TabIndex = 11;
            this.TbpQuery08.Text = "Запрос 8";
            this.TbpQuery08.UseVisualStyleBackColor = true;
            // 
            // DgvQuery08
            // 
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.DgvQuery08.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle23;
            this.DgvQuery08.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery08.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvQuery08.Location = new System.Drawing.Point(3, 3);
            this.DgvQuery08.MultiSelect = false;
            this.DgvQuery08.Name = "DgvQuery08";
            this.DgvQuery08.ReadOnly = true;
            this.DgvQuery08.RowHeadersVisible = false;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DgvQuery08.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.DgvQuery08.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery08.Size = new System.Drawing.Size(965, 433);
            this.DgvQuery08.TabIndex = 2;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 558);
            this.Controls.Add(this.TbcResults);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 24.01.2022 - запросы LINQ to SQL для БД \"Оптовый магазин. Учет продаж\"" +
    "";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.TbcResults.ResumeLayout(false);
            this.TbpGoods.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvGoods)).EndInit();
            this.TbpSellers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvSellers)).EndInit();
            this.TbpPurchases.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.TbpSales.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.TbpQuery01.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).EndInit();
            this.TbpQuery02.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).EndInit();
            this.TbpQuery03.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.TbpQuery04.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.TbpQuery05.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.TbpQuery06.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).EndInit();
            this.TbpQuery07.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery07)).EndInit();
            this.TbpQuery08.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery08)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel TslInfo;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem товарыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem продавцыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem закупеиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem продажиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem запрос5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem запрос7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton TsbGoods;
        private System.Windows.Forms.ToolStripButton TsbSellers;
        private System.Windows.Forms.ToolStripButton TsbPurchases;
        private System.Windows.Forms.ToolStripButton TsbSales;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton TsbQuery01;
        private System.Windows.Forms.ToolStripButton TsbQuery02;
        private System.Windows.Forms.ToolStripButton TsbQuery03;
        private System.Windows.Forms.ToolStripButton TsbQuery04;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TsbQuery05;
        private System.Windows.Forms.ToolStripButton TsbQuery06;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton TsbQuery07;
        private System.Windows.Forms.ToolStripButton TsbQuery08;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.TabControl TbcResults;
        private System.Windows.Forms.TabPage TbpGoods;
        private System.Windows.Forms.TabPage TbpSellers;
        private System.Windows.Forms.TabPage TbpPurchases;
        private System.Windows.Forms.TabPage TbpSales;
        private System.Windows.Forms.TabPage TbpQuery01;
        private System.Windows.Forms.TabPage TbpQuery02;
        private System.Windows.Forms.TabPage TbpQuery03;
        private System.Windows.Forms.TabPage TbpQuery04;
        private System.Windows.Forms.TabPage TbpQuery05;
        private System.Windows.Forms.TabPage TbpQuery06;
        private System.Windows.Forms.TabPage TbpQuery07;
        private System.Windows.Forms.TabPage TbpQuery08;
        private System.Windows.Forms.DataGridView DgvGoods;
        private System.Windows.Forms.DataGridView DgvQuery01;
        private System.Windows.Forms.DataGridView DgvSellers;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView DgvQuery02;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridView DgvQuery06;
        private System.Windows.Forms.DataGridView DgvQuery07;
        private System.Windows.Forms.DataGridView DgvQuery08;
    }
}

