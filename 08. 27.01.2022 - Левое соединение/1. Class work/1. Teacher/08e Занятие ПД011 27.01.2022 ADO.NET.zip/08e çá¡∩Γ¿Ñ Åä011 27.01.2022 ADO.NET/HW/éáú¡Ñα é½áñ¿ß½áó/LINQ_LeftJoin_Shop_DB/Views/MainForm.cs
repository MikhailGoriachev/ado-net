﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LINQ_LeftJoin_Shop_DB.Controller;
using LINQ_LeftJoin_Shop_DB.Utilities;

namespace LINQ_LeftJoin_Shop_DB.Views
{
    public partial class MainForm : Form
    {
        //Конроллер 
        QueriesController _controller;

        public MainForm()
        {
            _controller = new QueriesController();
            InitializeComponent();

        }

        //Изменение строки статуса
        private void ChangeStatusStr(int QueryNum, int ObjAmount)
        {
            Lbl_Status_Qantity.Text = $"Выбрано обектов: {ObjAmount}";
            Lbl_Query_Num.Text = $"Запрос N_{QueryNum}";
        }

        //Связывание 
        void BindDgv(DataGridView dgv, IEnumerable<object> collection)
        {
            dgv.DataSource = null;
            dgv.DataSource = collection;
        }


        private void Tab_Query_1_Enter(object sender, EventArgs e)
        {
            if (Tbc_Main.SelectedTab != Tab_Query_1 || Utils.Query_1_Executed)
                return;
            //2021-09-02
            //BindDgv(Dgv_Query_1, _controller.Query_1(new DateTime(2021,09,02), new DateTime(2021, 10, 29)));

            Dgv_Query_1.DataSource = null;
            Dgv_Query_1.DataSource = _controller.Query_1(new DateTime(2021, 09, 02), new DateTime(2021, 10, 29));
            Utils.Query_1_Executed = true;

            //Строка состояния
            ChangeStatusStr(1, Dgv_Query_1.Rows.Count);
        }

        private void Tab_Query_2_Enter(object sender, EventArgs e)
        {
            //Если текущая вкладка - не вкладка запроса или запрос по умолчанию исполнялся
            if (Tbc_Main.SelectedTab != Tab_Query_2 || Utils.Query_2_Executed)
                return;

            Dgv_Query_2.DataSource = null;
            Dgv_Query_2.DataSource = _controller.Query_2();

            Utils.Query_2_Executed = true;

            ChangeStatusStr(2, Dgv_Query_2.Rows.Count);
        }

        private void Exit_Command(object sender, EventArgs e)
         => Application.Exit();

        private void Tab_Sales_Enter(object sender, EventArgs e)
        {
            //Если текущая вкладка - не вкладка запроса или запрос по умолчанию исполнялся
            if (Tbc_Main.SelectedTab != Tab_Sales_Table || Utils.Query_3_Executed)
                return;

            Dgv_Sales_Table.DataSource = null;
            Dgv_Sales_Table.DataSource = _controller.showSalesTable();

            Utils.Query_3_Executed = true;

            ChangeStatusStr(3, Dgv_Sales_Table.Rows.Count);
        }


        private void Tab_Query_4_Enter(object sender, EventArgs e)
        {

            //Если текущая вкладка - не вкладка запроса или запрос по умолчанию исполнялся
            if (Tbc_Main.SelectedTab != Tab_Purchases_Table || Utils.Query_4_Executed)
                return;

            Utils.Query_4_Executed = true;

            ChangeStatusStr(4, Dgv_Purchases.Rows.Count);
        }

        private void Cbx_Query4_Changed(object sender, EventArgs e)
        {
            //Если текущая вкладка - не вкладка запроса или запрос по умолчанию исполнялся
            if (Tbc_Main.SelectedTab != Tab_Purchases_Table )
                return;

            Utils.Query_4_Executed = true;

            ChangeStatusStr(4, Dgv_Purchases.Rows.Count);
        }
    }
}
