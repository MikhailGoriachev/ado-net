﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework.Models
{
	// класс, описывающий книгу
	public class Book
	{
		// идентификатор
		public int Id { get; set; }

		// идентификатор автора
		public int IdAuthor { get; set; }

		// название книги
		public string Title { get; set; }

		// год издания
		public int Year { get; set; }

		// цена
		public int Price { get; set; }

		public override string ToString() =>
			$"  Id:{Id}. {Title}, {Year}г., {Price}р.";
	}
}
