﻿
namespace LinqWinForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TlstMenuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TlsAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.TbcQueries = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.DgvQuery1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.DgvQuery2 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.DgvQuery3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.DgvQuery4 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.DgvQuery5 = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.DgvQuery6 = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.DgvQuery7 = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.DgvQuery8 = new System.Windows.Forms.DataGridView();
            this.ButtonExit = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.TbcQueries.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery4)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery5)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery6)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery7)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery8)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(945, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TlstMenuExit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(69, 29);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // TlstMenuExit
            // 
            this.TlstMenuExit.Name = "TlstMenuExit";
            this.TlstMenuExit.Size = new System.Drawing.Size(166, 34);
            this.TlstMenuExit.Text = "Выход";
            this.TlstMenuExit.Click += new System.EventHandler(this.Close_Click);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TlsAbout});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(97, 29);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // TlsAbout
            // 
            this.TlsAbout.Name = "TlsAbout";
            this.TlsAbout.Size = new System.Drawing.Size(270, 34);
            this.TlsAbout.Text = "О программе";
            this.TlsAbout.Click += new System.EventHandler(this.About_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ButtonExit,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 33);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(945, 33);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // TbcQueries
            // 
            this.TbcQueries.Controls.Add(this.tabPage1);
            this.TbcQueries.Controls.Add(this.tabPage2);
            this.TbcQueries.Controls.Add(this.tabPage3);
            this.TbcQueries.Controls.Add(this.tabPage4);
            this.TbcQueries.Controls.Add(this.tabPage5);
            this.TbcQueries.Controls.Add(this.tabPage6);
            this.TbcQueries.Controls.Add(this.tabPage7);
            this.TbcQueries.Controls.Add(this.tabPage8);
            this.TbcQueries.Location = new System.Drawing.Point(13, 87);
            this.TbcQueries.Name = "TbcQueries";
            this.TbcQueries.SelectedIndex = 0;
            this.TbcQueries.Size = new System.Drawing.Size(920, 390);
            this.TbcQueries.TabIndex = 3;
            this.TbcQueries.Click += new System.EventHandler(this.Query1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.DgvQuery1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(912, 357);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Запрос 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // DgvQuery1
            // 
            this.DgvQuery1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery1.Location = new System.Drawing.Point(6, 6);
            this.DgvQuery1.Name = "DgvQuery1";
            this.DgvQuery1.RowHeadersWidth = 62;
            this.DgvQuery1.RowTemplate.Height = 28;
            this.DgvQuery1.Size = new System.Drawing.Size(900, 345);
            this.DgvQuery1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.DgvQuery2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(912, 357);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Запрос 2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // DgvQuery2
            // 
            this.DgvQuery2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery2.Location = new System.Drawing.Point(6, 6);
            this.DgvQuery2.Name = "DgvQuery2";
            this.DgvQuery2.RowHeadersWidth = 62;
            this.DgvQuery2.RowTemplate.Height = 28;
            this.DgvQuery2.Size = new System.Drawing.Size(906, 355);
            this.DgvQuery2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.DgvQuery3);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(912, 357);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Запрос 3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // DgvQuery3
            // 
            this.DgvQuery3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery3.Location = new System.Drawing.Point(6, 6);
            this.DgvQuery3.Name = "DgvQuery3";
            this.DgvQuery3.RowHeadersWidth = 62;
            this.DgvQuery3.RowTemplate.Height = 28;
            this.DgvQuery3.Size = new System.Drawing.Size(900, 345);
            this.DgvQuery3.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.DgvQuery4);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(912, 357);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Запрос 4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // DgvQuery4
            // 
            this.DgvQuery4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery4.Location = new System.Drawing.Point(0, 6);
            this.DgvQuery4.Name = "DgvQuery4";
            this.DgvQuery4.RowHeadersWidth = 62;
            this.DgvQuery4.RowTemplate.Height = 28;
            this.DgvQuery4.Size = new System.Drawing.Size(906, 345);
            this.DgvQuery4.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.DgvQuery5);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(912, 357);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Запрос 5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // DgvQuery5
            // 
            this.DgvQuery5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery5.Location = new System.Drawing.Point(6, 6);
            this.DgvQuery5.Name = "DgvQuery5";
            this.DgvQuery5.RowHeadersWidth = 62;
            this.DgvQuery5.RowTemplate.Height = 28;
            this.DgvQuery5.Size = new System.Drawing.Size(900, 348);
            this.DgvQuery5.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.DgvQuery6);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(912, 357);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Запрос 6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // DgvQuery6
            // 
            this.DgvQuery6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery6.Location = new System.Drawing.Point(6, 6);
            this.DgvQuery6.Name = "DgvQuery6";
            this.DgvQuery6.RowHeadersWidth = 62;
            this.DgvQuery6.RowTemplate.Height = 28;
            this.DgvQuery6.Size = new System.Drawing.Size(900, 345);
            this.DgvQuery6.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.DgvQuery7);
            this.tabPage7.Location = new System.Drawing.Point(4, 29);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(912, 357);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Запрос 7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // DgvQuery7
            // 
            this.DgvQuery7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery7.Location = new System.Drawing.Point(6, 6);
            this.DgvQuery7.Name = "DgvQuery7";
            this.DgvQuery7.RowHeadersWidth = 62;
            this.DgvQuery7.RowTemplate.Height = 28;
            this.DgvQuery7.Size = new System.Drawing.Size(900, 351);
            this.DgvQuery7.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.DgvQuery8);
            this.tabPage8.Location = new System.Drawing.Point(4, 29);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(912, 357);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Запрос 8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // DgvQuery8
            // 
            this.DgvQuery8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery8.Location = new System.Drawing.Point(6, 6);
            this.DgvQuery8.Name = "DgvQuery8";
            this.DgvQuery8.RowHeadersWidth = 62;
            this.DgvQuery8.RowTemplate.Height = 28;
            this.DgvQuery8.Size = new System.Drawing.Size(900, 345);
            this.DgvQuery8.TabIndex = 0;
            // 
            // ButtonExit
            // 
            this.ButtonExit.AutoSize = false;
            this.ButtonExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonExit.Image = global::LinqWinForms.Properties.Resources.exit;
            this.ButtonExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonExit.Name = "ButtonExit";
            this.ButtonExit.Size = new System.Drawing.Size(34, 28);
            this.ButtonExit.Text = "toolStripButton1";
            this.ButtonExit.Click += new System.EventHandler(this.Close_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::LinqWinForms.Properties.Resources.help;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.About_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 489);
            this.Controls.Add(this.TbcQueries);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Домашнее задание на 24.01.2021";
            this.Load += new System.EventHandler(this.Load_Queries);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.TbcQueries.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery4)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery5)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery6)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery7)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TlstMenuExit;
        private System.Windows.Forms.ToolStripMenuItem TlsAbout;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton ButtonExit;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.TabControl TbcQueries;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView DgvQuery1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView DgvQuery2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.DataGridView DgvQuery3;
        private System.Windows.Forms.DataGridView DgvQuery4;
        private System.Windows.Forms.DataGridView DgvQuery5;
        private System.Windows.Forms.DataGridView DgvQuery6;
        private System.Windows.Forms.DataGridView DgvQuery7;
        private System.Windows.Forms.DataGridView DgvQuery8;
    }
}

