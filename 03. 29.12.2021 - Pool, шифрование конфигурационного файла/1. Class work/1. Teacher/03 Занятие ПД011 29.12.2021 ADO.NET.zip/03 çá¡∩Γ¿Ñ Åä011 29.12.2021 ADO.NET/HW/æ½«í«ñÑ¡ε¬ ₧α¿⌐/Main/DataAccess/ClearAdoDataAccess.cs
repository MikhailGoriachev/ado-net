﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Main.Infrastructure;
using Microsoft.Data.SqlClient;


namespace Main.DataAccess
{
	public sealed class ClearAdoDataAccess
	{
		private readonly string _connectionString;


		public ClearAdoDataAccess(string connectionString) =>
			_connectionString = connectionString;


		public DataTable ExecuteQuery(Action<SqlCommand> commandPrepare)
		{
			using var connection = new SqlConnection(_connectionString);
			connection.Open();

			var command = connection.CreateCommand();
			commandPrepare.Invoke(command);

			var adapter = new SqlDataAdapter(command);
			var table = new DataTable();

			adapter.Fill(table);
			return table;
		}


		public IEnumerable<T> MapTo<T>(DataTable source) where T : IMappable<T>, new() =>
			source.Rows
				  .Cast<DataRow>()
				  .Select(row => new T().Map(row));
	}
}