﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ADO_NET_Procedures.Utilities;

namespace ADO_NET_Procedures.Application
{
    public class App
    {
        string ConnectString;

        public App()
        {
            // CreateConfigString();
            ConnectString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
        }

        //Вывод меню 
        public void ShowMenu(string title)
        {
            Palette.MainColor.EstablishColor();
            string MainTitle = title;

            //Add-up 19 symbols
            string Spaces = AddSymbols(19);

            //Массивы пунктов меню 
            MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Запрос_1: Выбирает информацию о 3-комнатных квартирах, расположенных на улице «Садовая»"},
                new MenuItem {key = " W ",Text = $" - Запрос_2: Выбирает информацию о риэлторах, фамилия которых начинается с буквы \"И\" \n{Spaces}и процент вознаграждения больше 10%.\n"},
                new MenuItem {key = " E ",Text = $" - Запрос_3: Выбирает информацию об 1-комнатных квартирах, \n{Spaces}цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб\n"},
                new MenuItem {key = " R ",Text = " - Запрос_4: Выбирает информацию о квартирах с заданным числом комнат"},
                new MenuItem {key = " T ",Text = $" - Запрос_5: Выбирает информацию обо всех 2-комнатных квартирах, \n{Spaces}площадь которых есть значение из некоторого диапазона"},
                new MenuItem {key = " Y ",Text = $" - Запрос_6: Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. \n{Spaces}Сортировка по дате сделки\n"},
                new MenuItem {key = " A ",Text = $" - Запрос_7: Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки \n{Spaces}и сумму сделок риэлтора. Упорядочить выборку по убыванию суммы сделок.\n"},
                new MenuItem {key = " S ",Text = " - Запрос_8: Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки"},
                new MenuItem {key = " D ",Text = $" - Запрос_9: Для всех улиц вывести сумму сделок за заданный период, \n{Spaces}упорядочить выборку по убыванию суммы сделки.\n"},
                new MenuItem {key = "ESC",Text = " - Выход"}
            };

            try
            {


                while (true)
                {
                    Console.Clear();
                    Utils.ShowBarMessage(MainTitle);
                    Console.CursorVisible = false;
                    Utils.ShowMenu(3, 3, "Выберете действие", FirstTaskMenu);

                    //Если задание сделано не до конца
                    /*
                    Console.ForegroundColor = Utils.colors.W;
                    Console.BackgroundColor = Utils.colors.R;
                    Console.SetCursorPosition(3, 12);
                    Console.Write("Ps.Задание в разработке. Методы не реализованы!");
                    Palette.MainColor.EstablishColor();*/
                    ConsoleKey key = Console.ReadKey().Key;

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            {
                                Console.Clear();
                                Query_1();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.W:
                            {
                                Console.Clear();
                                Query_2();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.E:
                            {
                                Console.Clear();
                                Query_3();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.R:
                            {
                                Console.Clear();
                                Query_4();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.T:
                            {
                                Console.Clear();
                                Query_5();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.Y:
                            {
                                Console.Clear();
                                Query_6();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.A:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("В разработке", "INFO", 2, 3);
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.S:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("В разработке", "INFO", 2, 3);
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.D:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("В разработке", "INFO", 2, 3);
                                Console.ReadKey();
                                break;
                            }

                        case ConsoleKey.Escape:
                            {
                                Console.Clear();
                                Console.ReadKey();
                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key} не поддерживается");
                    }//Switch

                }//While

            }//Try
             //Catсh блок
             //Обрабатываем общее исключение
            catch (Exception ex)
            {
                if (MessageBox.Show(ex.Message + $"\n\n{ex.StackTrace}", "Ошибка!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error) == DialogResult.OK)
                    ShowMenu(title);

            }//catch

        } //ShowMenu

        //Добавление пустых символов для вывода 
        private string AddSymbols(int count, string symbol = " ")
        {
            StringBuilder sb = new StringBuilder();

            //Добавление заданных символов
            for (int i = 0; i < count; i++)
                sb.Append(symbol);

            return sb.ToString();
        }

        //Сформировать строку подключения 
        private string CreateConfigString()
        {
            ConnectionStringSettings stringSettings = new ConnectionStringSettings()
            {
                Name = "DBConnectionString",
                ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\STEP – studying\Home works\2021\December 2021\-23.12.21 - result(ADO.net - CUDA)\Вагнер Владислав\ADO_NET_Procedures\App_Data\Immovables.mdf"";Integrated Security=True"
            };

            Configuration config;
            config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            //Если строка существует - возвращаем её
            int index = config.ConnectionStrings.ConnectionStrings.IndexOf(stringSettings);
            if (index >= 0)
            {
                config.ConnectionStrings.ConnectionStrings.RemoveAt(index);
            }

            config.ConnectionStrings.ConnectionStrings.Add(stringSettings);
            config.Save();

            //Возвращаеи строку подкючения 
            return ConfigurationManager.ConnectionStrings[stringSettings.Name].ConnectionString;
        }

        #region Запросы

        /*Запрос_1: Выбирает информацию о 3-комнатных квартирах, 
        *          расположенных на улице «Садовая». 
        *          Значения задавать параметрами запроса
        */
        void Query_1()
        {
            //Выводим верхнюю строку 
            Utils.ShowBarMessage("Запрос_1: 3-х комнатные квартиры на садовой");

            //Подключаемся к Db
            using (SqlConnection connection = new SqlConnection(ConnectString))
            {
                //Подкключаемся к серверу 
                connection.Open();

                //Создание запроса 
                SqlCommand command = new SqlCommand(@"Query_1_Proc");
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Соеденяемся с DB 
                command.Connection = connection;

                //Задаём параметры 
                command.Parameters.AddWithValue("@Street", "ул. Садовая");
                command.Parameters.AddWithValue("@Rooms", 3);

                //Выполняем запрос 
                SqlDataReader reader = command.ExecuteReader();

                //Проверка на наличие данных 
                if (reader.HasRows)
                {
                    //Выводим шапку таблицы 
                    Console.WriteLine($"| {reader.GetName(0),10} | {reader.GetName(1),10} | {reader.GetName(2),10} | {reader.GetName(3),10} | {reader.GetName(4),10} |");

                    while (reader.Read())
                    {
                        Console.WriteLine($"|{reader.GetString(0),10}|" +
                                          $"{reader.GetDouble(1),10}|" +
                                          $"{reader.GetInt32(2),10}|" +
                                          $"{reader.GetDouble(3),10}|" +
                                          $"{reader.GetString(4),10}|"
                                          );
                    }
                }

            } //using

        } //Query_1

        /*Запрос_2:  Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%. 
         *           Значения задавать параметрами запроса          
        */
        void Query_2()
        {
            //Выводим верхнюю строку 
            Utils.ShowBarMessage("Запрос_2: Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%");

            //Подключаемся к Db
            using (SqlConnection connection = new SqlConnection(ConnectString))
            {

                //Подкключаемся к серверу 
                connection.Open();

                //Создание запроса 
                SqlCommand command = new SqlCommand(@"Query_2_Proc");
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Соеденяемся с DB 
                command.Connection = connection;

                //Задаём параметры 
                command.Parameters.AddWithValue("Surname", "И%");
                command.Parameters.AddWithValue("@Interest", 0.01);

                //Выполняем запрос 
                SqlDataReader reader = command.ExecuteReader();

                //Проверка на наличие данных 
                if (reader.HasRows)
                {
                    //Выводим шапку таблицы 
                    Console.WriteLine($"| {reader.GetName(0),10} | {reader.GetName(1),10} |");

                    while (reader.Read())
                    {
                        Console.WriteLine($"|{reader.GetString(0),10}|" +
                                          $"{reader.GetFloat(1),10}|");
                    }
                }//while
            } //using
        } //Query_2

        /*Запрос_3:         
        */
        void Query_3()
        {
            //Выводим верхнюю строку 
            Utils.ShowBarMessage("Запрос_3: ");

            //Подключаемся к Db
            using (SqlConnection connection = new SqlConnection(ConnectString))
            {

                //Подкключаемся к серверу 
                connection.Open();

                //Создание запроса 
                SqlCommand command = new SqlCommand(@"Query_3_Proc");
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Соеденяемся с DB 
                command.Connection = connection;

                //Задаём параметры 
                command.Parameters.AddWithValue("@rooms", 1);
                command.Parameters.AddWithValue("@PriceLo", 12500);
                command.Parameters.AddWithValue("@PriceHigh", 14500);

                //Выполняем запрос 
                SqlDataReader reader = command.ExecuteReader();

                //Проверка на наличие данных 
                if (reader.HasRows)
                {
                    Color color = new Color();
                    color.EstablishColor();
                    //Выводим шапку таблицы 
                    Console.WriteLine($"| {reader.GetName(0),10} | {reader.GetName(1),10} |{reader.GetName(2),10} |{reader.GetName(3),10} |{reader.GetName(4),10} |");

                    while (reader.Read())
                    {
                        Console.WriteLine($"|{reader.GetString(0),10}|" +
                                          $"{reader.GetFloat(1),10}|" +
                                          $"{reader.GetInt32(2),10}|" +
                                          $"{reader.GetFloat(3),10}|" +
                                          $"{reader.GetString(4),10}|");
                    }
                }//while
            } //using
        } //Query_3

        /*Запрос_4: Выбирает информацию о квартирах с заданным числом комнат         
        */
        void Query_4()
        {
            //Выводим верхнюю строку 
            Utils.ShowBarMessage("Запрос_3: ");

            //Подключаемся к Db
            using (SqlConnection connection = new SqlConnection(ConnectString))
            {

                //Подкключаемся к серверу 
                connection.Open();

                //Создание запроса 
                SqlCommand command = new SqlCommand(@"Query_4_Proc");
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Соеденяемся с DB 
                command.Connection = connection;

                //Задаём параметры 
                command.Parameters.AddWithValue("@rooms", 2);

                //Выполняем запрос 
                SqlDataReader reader = command.ExecuteReader();

                //Проверка на наличие данных 
                if (reader.HasRows)
                {
                    Color color = new Color();
                    color.EstablishColor();
                    //Выводим шапку таблицы 
                    Console.WriteLine($"| {reader.GetName(0),10} | {reader.GetName(1),10} |{reader.GetName(2),10} |{reader.GetName(3),10} |{reader.GetName(4),10} |");

                    while (reader.Read())
                    {
                        Console.WriteLine($"|{reader.GetString(0),10}|" +
                                          $"{reader.GetFloat(1),10}|" +
                                          $"{reader.GetInt32(2),10}|" +
                                          $"{reader.GetFloat(3),10}|" +
                                          $"{reader.GetString(4),10}|");
                    }
                }//while
            } //using
        } //Query_4

        /*Запрос_5: Выбирает информацию обо всех 2-комнатных квартирах, 
--                  площадь которых есть значение из некоторого диапазона.         
        */
        void Query_5()
        {
            //Выводим верхнюю строку 
            Utils.ShowBarMessage($"Запрос_5: Выбирает информацию обо всех 2-комнатных квартирах, \n{AddSymbols(10)}площадь которых есть значение из некоторого диапазона.");

            //Подключаемся к Db
            using (SqlConnection connection = new SqlConnection(ConnectString))
            {

                //Подкключаемся к серверу 
                connection.Open();

                //Создание запроса 
                SqlCommand command = new SqlCommand(@"Query_5_Proc");
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Соеденяемся с DB 
                command.Connection = connection;
                //Задаём параметры 
                command.Parameters.AddWithValue("@rooms", 2);
                command.Parameters.AddWithValue("@MinS", 40);
                command.Parameters.AddWithValue("@MaxS", 70);

                //Выполняем запрос 
                SqlDataReader reader = command.ExecuteReader();

                //Проверка на наличие данных 
                if (reader.HasRows)
                {
                    Color color = new Color();
                    color.EstablishColor();
                    //Выводим шапку таблицы 
                    Console.WriteLine($"| {reader.GetName(0),10} | {reader.GetName(1),10} |{reader.GetName(2),10} |{reader.GetName(3),10} |{reader.GetName(4),10} |");

                    while (reader.Read())
                    {
                        Console.WriteLine($"|{reader.GetString(0),10}|" +
                                          $"{reader.GetFloat(1),10}|" +
                                          $"{reader.GetInt32(2),10}|" +
                                          $"{reader.GetFloat(3),10}|" +
                                          $"{reader.GetString(4),10}|");
                    }
                }//while
            } //using
        } //Query_5

        /*Запрос_6: Выбирает информацию обо всех 2-комнатных квартирах, 
--                  площадь которых есть значение из некоторого диапазона.         
        */
        void Query_6()
        {
            //Выводим верхнюю строку 
            Utils.ShowBarMessage($"Запрос_6.");

            //Подключаемся к Db
            using (SqlConnection connection = new SqlConnection(ConnectString))
            {

                //Подкключаемся к серверу 
                connection.Open();

                //Создание запроса 
                SqlCommand command = new SqlCommand(@"Query_5_Proc");
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Соеденяемся с DB 
                command.Connection = connection;

                //Выполняем запрос 
                SqlDataReader reader = command.ExecuteReader();

                //Проверка на наличие данных 
                if (reader.HasRows)
                {
                    Color color = new Color();
                    color.EstablishColor();
                    //Выводим шапку таблицы 
                    Console.WriteLine($"| {reader.GetName(0),10} | {reader.GetName(1),10} |{reader.GetName(2),10} |{reader.GetName(3),10} |{reader.GetName(4),10} |");

                    while (reader.Read())
                    {
                        Console.WriteLine($"|{reader.GetString(0),10}|" +
                                          $"{reader.GetDateTime(1),10}|" +
                                          $"{reader.GetFloat(2),10}|" +
                                          $"{reader.GetFloat(3),10}|");
                    }
                }//while
            } //using
        } //Query_6


        #endregion

    }
}
