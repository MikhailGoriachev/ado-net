﻿using System;
using System.Globalization;


namespace Main.Utilities
{
	public readonly struct Range<T> : IFormattable
		where T : unmanaged, IComparable<T>, IFormattable
	{
		public T Min { get; }
		public T Max { get; }
		public Func<T, T, T>? RandomFunc { private get; init; }


		public T RandomBetween => RandomFunc?.Invoke(Min, Max) ?? default;


		public Range(T min, T max)
		{
			if (min.CompareTo(max) is 1 or 0)
				throw new ArgumentOutOfRangeException(nameof(min));

			Min        = min;
			Max        = max;
			RandomFunc = null;
		}


		public static Range<T> CreateWithRandom(Func<T> randomFactory)
		{
			T max = randomFactory.Invoke();
			T min;

			do
			{
				min = randomFactory.Invoke();
			} while (min.CompareTo(max) >= 0);

			return new(min, max);
		}


		public bool IsInRangeExclusive(T value) => value.CompareTo(Min) is 1 && value.CompareTo(Max) is -1;


		public bool IsInRangeInclusive(T value) =>
			value.CompareTo(Min) is 1 or 0 && value.CompareTo(Max) is -1 or 0;


		public void Deconstruct(out T min, out T max)
		{
			min = Min;
			max = Max;
		}


		public override string ToString() => $"min: {Min} max: {Max}";


		public string ToString(string? format, IFormatProvider? formatProvider)
		{
			var min = Min.ToString(format, formatProvider);
			var max = Max.ToString(format, formatProvider);

			return $"min: {min}, max: {max}";
		}
	}
}