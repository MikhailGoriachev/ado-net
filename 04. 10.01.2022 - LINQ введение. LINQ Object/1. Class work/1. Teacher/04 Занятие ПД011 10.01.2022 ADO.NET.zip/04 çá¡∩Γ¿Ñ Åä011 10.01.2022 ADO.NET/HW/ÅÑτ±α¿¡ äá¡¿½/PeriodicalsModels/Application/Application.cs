﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PeriodicalsModels.Controllers;


namespace PeriodicalsModels.Application
{
        //данные для обработки и конструкторы 
    public partial class App
    {
        private static QueryControllers _queryControllers;


        public App(string connectingString)
        {
            _queryControllers = new QueryControllers(connectingString);
        }

        
    }
}
