﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Periodicals.Models {
    // модель издания для вывода данных 
    public class PublicationViewModel {
        // ИД
        public int Id { get; set; }

        // индекс издания по каталогу
        public string PubIndex { get; set; }

        // вид издания
        public string PubType { get; set; }

        // наименование (название) издания
        public string Title { get; set; }

        // цена 1 экземпляра
        public int Price { get; set; }


        public string ToTableRow => $"\t│ {Id,    2} │ " +
                                    $"{PubIndex, 18} │ " +
                                    $"{PubType, -11} │ " +
                                    $"{Title,   -32} │ " +
                                    $"{Price,  7:n2} │";

        public static string Header => "\t┌────┬────────────────────┬─────────────┬──────────────────────────────────┬─────────┐\n" +
                                       "\t│ ИД │ Индекс по каталогу │ Вид издания │ Наименование издания             │ Цена    │\n" +
                                       "\t├────┼────────────────────┼─────────────┼──────────────────────────────────┼─────────┤";
                                        
        public static string Footer => "\t└────┴────────────────────┴─────────────┴──────────────────────────────────┴─────────┘";
    }// PublicationViewModel
}
