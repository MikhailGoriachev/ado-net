﻿using Main.Utilities.TableFormatter;


namespace Main.Models.CarRenting
{
	public sealed class CarInfo
	{
		[TableData("Номер", "{0, -15}")]
		public string? LicenseNumber { get; set; }

		[TableData("Кол-во заказов", "{0, -16}")]
		public int Count { get; set; }

		[TableData("Суммарная выручка", "{0, -20}")]
		public decimal TotalRent { get; set; }

		[TableData("Суммарная длительность", "{0, -25}")]
		public int TotalDuration { get; set; }
	}
}