﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LINQIntro.Helpers;
using LINQIntro.App_Data;

namespace LINQIntro
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 13.02.2022 - Введение в LINQ";

            MenuItem[] menu = new[]
            {
                new MenuItem { HotKey = ConsoleKey.Q, Text ="Задача 1. Расширяющий метод, возвращающий процент скидки в зависимости от возраста товара"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Задача 2. Вычисление количества элементов массива, со значениями в диапазоне от A до B"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Задача 2. Вычисление количества элементов массива, равных 0"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Задача 2. Вычисление суммы элементов массива, расположенных после первого максимального элемента"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Задача 2. Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Задача 3. Товары с заданным диапазоном цен"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Задача 3. Сумма товаров с заданным годом выпуска"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Задача 3. Сумма товаров с заданным наименованием "},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Задача 3. Наименование и год выпуска товаров с максимальным количеством"},
                new MenuItem {HotKey = ConsoleKey.G, Text = "Задача 3. Все товары, для которых произведение цены на количество находится в заданном диапазоне"},

                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" }
            }; // MenuItem

            App app = new App();

            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  LINQ");
                    Utils.ShowMenu(12, 5, "Меню приложения для решения задач с помощью LINQ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            app.Task1_1();
                            break;
                        case ConsoleKey.W:
                            app.Task2_1();
                            break;
                        case ConsoleKey.E:
                            app.Task2_2();
                            break;
                        case ConsoleKey.A:
                            app.Task3_1();
                            break;
                        case ConsoleKey.S:
                            app.Task3_2();
                            break;
                        case ConsoleKey.D:
                            app.Task3_3();
                            break;
                        case ConsoleKey.F:
                            app.Task3_4();
                            break;
                        case ConsoleKey.G:
                            app.Task3_5();
                            break;
                    }

                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }
            }// while

        }
    }
}
