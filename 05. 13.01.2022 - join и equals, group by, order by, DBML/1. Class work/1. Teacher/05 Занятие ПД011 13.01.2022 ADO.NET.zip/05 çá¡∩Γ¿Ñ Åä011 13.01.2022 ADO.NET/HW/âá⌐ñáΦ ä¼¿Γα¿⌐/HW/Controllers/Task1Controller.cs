﻿using System;
using System.Collections.Generic;

using HW.Models;
using HW.Helpers;

namespace HW.Controllers
{
    public class Task1Controller
    {
        // Лист товаров
        private List<Item> _itemList;

        #region Ансамбль конструкторов

        public Task1Controller() : this(new List<Item>()) { Init(); }

        public Task1Controller(List<Item> itemList)
        {
            _itemList = itemList;
        } // Task1Controller
        #endregion

        // функция для заполнения листа
        private void Init() {
            _itemList.Clear();
            for(int i = 0;i<12;i++) _itemList.Add(Utils.NewItem());
        } // Init

        // демонстрация работы расширяющего метода
        /* не понял почему, но private void не видит в App.Task1 */ public void Task()
        {
            Console.Write($"{Item.Header}");
            
            for (int i = 0; i < _itemList.Count; i++)
                Console.Write($"{_itemList[i].ToRow()} - {_itemList[i].Discount()}%\n");
                
            Console.Write($"{Item.Footer}");
        }
    } // Task1Controller
}
