﻿using HomeWork.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// для работы с технологией ADO.NET
using System.Configuration;   // добавить сборку System.Configuration.dll
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace HomeWork.Application
{
    public partial class App
    {

        //  1	Хранимая процедура	
        //  Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа, стоимость 1 экземпляра для которых меньше заданной.
        //  Значения задавать параметрами запроса
        public void Query01()
        {
            List<PublicationModel> list = _taskController.Query01("газета", 80);

            Console.WriteLine(PublicationModel.Header());
            foreach (var item in list)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(PublicationModel.Footer());

        } // ExecQuery01

        //  2	Хранимая процедура	
        //  Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома, которые оформили подписку на издание с заданным параметром наименованием
        //  Значения задавать параметрами запроса
        public void Query02()
        {
            List<SubscribersModel> list = _taskController.Query02("Ведомости", "Артёма", "5а");

            Console.WriteLine(SubscribersModel.Header());
            foreach (var item in list)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(SubscribersModel.Footer());

        } // ExecQuery02

        //  3	Хранимая процедура	
        //  Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле Цена 1 экземпляра находится в заданном диапазоне значений
        //  Значения задавать параметрами запроса
        public void Query03()
        {
            List<PublicationModel> list = _taskController.Query03(50 , 80);

            Console.WriteLine(PublicationModel.Header());
            foreach (var item in list)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(PublicationModel.Footer());

        } // ExecQuery03


        //  4	Хранимая процедура	
        //  Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания
        //  Значения задавать параметрами запроса
        public void Query04()
        {
            List<SubscribersModel> list = _taskController.Query04("газета");

            Console.WriteLine(SubscribersModel.Header());
            foreach (var item in list)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(SubscribersModel.Footer());

        } // ExecQuery04

        //  5	Хранимая процедура	
        //  Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках, для которых срок подписки есть значение из некоторого диапазона
        //  Значения задавать параметрами запроса
        public void Query05()
        {
            List<SubscribersModel> list = _taskController.Query05( 6, 9);

            Console.WriteLine(SubscribersModel.Header());
            foreach (var item in list)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(SubscribersModel.Footer());

        } // ExecQuery05

        //  6	Хранимая процедура	
        //  Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
        //  Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки, Срок подписки, Стоимость подписки без НДС. 
        //  Сортировка по полю Индекс издания
        //  Значения задавать параметрами запроса
        public void Query06()
        {
            _taskController.Query06();

        } // ExecQuery06


        // 7	Итоговый запрос Хранимая процедура
        //      Выполняет группировку по полю Вид издания.Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
        public void Query07()
        {
            _taskController.Query07();

        } // ExecQuery07


        // 8	Итоговый запрос с левым соединением
        //      Хранимая процедура  Выполняет группировку по полю Улица.Для всех улиц вычисляет количество подписчиков, проживающих на данной улице(итоги по полю Код получателя)
        public void Query08()
        {
            _taskController.Query08();

        } // ExecQuery08

        // 9	Итоговый запрос с левым соединением
        //      Хранимая процедура  Для всех изданий выводит количество оформленных подписок
        public void Query09()
        {
            _taskController.Query09();

        } // ExecQuery09


        // Шифрования конфигурационного файла
        public void SecurityConfigON() {

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (!section.SectionInformation.IsProtected)
            {
                // Зашифровать секцию.
                section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                section.SectionInformation.ForceSave = true;

                // Сохранить файл конфигурации.
                config.Save(ConfigurationSaveMode.Full);
            } // if

            // Проверка шифрования
            Console.WriteLine($"Protected={section.SectionInformation.IsProtected}\n" +
                              $"{ConfigurationManager.ConnectionStrings["AccountingConnection"].ConnectionString}");

        }

        // Расшифровывания конфигурационного файла
        public void SecurityConfigOFF()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (section.SectionInformation.IsProtected)
            {
                // пример расшифровки секцию
                section.SectionInformation.UnprotectSection();
                config.Save();
            } // if

            

            // Проверка шифрования
            Console.WriteLine($"Protected={section.SectionInformation.IsProtected}\n" +
                              $"{ConfigurationManager.ConnectionStrings["AccountingConnection"].ConnectionString}");
        }
    }
}
