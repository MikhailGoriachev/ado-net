﻿
namespace TicketTrain_WPF_first
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Поезд");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьКакToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поездToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новыйПоездToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tss_lbl_allWagonTrain = new System.Windows.Forms.ToolStripStatusLabel();
            this.tss_lbl_infoAllWagonTrain = new System.Windows.Forms.ToolStripStatusLabel();
            this.tss_lbl_AllSeatsTrain = new System.Windows.Forms.ToolStripStatusLabel();
            this.tss_lbl_infoAllSeatsTrain = new System.Windows.Forms.ToolStripStatusLabel();
            this.tss_pgb_seats = new System.Windows.Forms.ToolStripProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tvr_train = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.Dgw_trainTicket = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Ofd_main = new System.Windows.Forms.OpenFileDialog();
            this.Sfd_main = new System.Windows.Forms.SaveFileDialog();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bns_view_trainticket = new System.Windows.Forms.BindingSource(this.components);
            this.tsb_add_wagon = new System.Windows.Forms.ToolStripButton();
            this.tsb_delete_wagon = new System.Windows.Forms.ToolStripButton();
            this.sortBySaleSeatsDesc = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.купитьБилетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вернутьБилетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgw_trainTicket)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bns_view_trainticket)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.поездToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1198, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.сохранитьКакToolStripMenuItem,
            this.toolStripMenuItem1,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.открытьToolStripMenuItem.Text = "Открыть...";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.Open_command);
            // 
            // сохранитьКакToolStripMenuItem
            // 
            this.сохранитьКакToolStripMenuItem.Name = "сохранитьКакToolStripMenuItem";
            this.сохранитьКакToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.сохранитьКакToolStripMenuItem.Text = "Сохранить как...";
            this.сохранитьКакToolStripMenuItem.Click += new System.EventHandler(this.Save_command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(164, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            // 
            // поездToolStripMenuItem
            // 
            this.поездToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новыйПоездToolStripMenuItem,
            this.toolStripMenuItem2,
            this.редактироватьToolStripMenuItem});
            this.поездToolStripMenuItem.Name = "поездToolStripMenuItem";
            this.поездToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.поездToolStripMenuItem.Text = "Поезд";
            // 
            // новыйПоездToolStripMenuItem
            // 
            this.новыйПоездToolStripMenuItem.Name = "новыйПоездToolStripMenuItem";
            this.новыйПоездToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.новыйПоездToolStripMenuItem.Text = "Новый поезд";
            this.новыйПоездToolStripMenuItem.Click += new System.EventHandler(this.recreateTrain);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(157, 6);
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.редактироватьToolStripMenuItem.Text = "Редактировать";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(95, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsb_add_wagon,
            this.tsb_delete_wagon,
            this.toolStripSeparator1,
            this.sortBySaleSeatsDesc,
            this.toolStripButton2,
            this.toolStripButton3});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1198, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tss_lbl_allWagonTrain,
            this.tss_lbl_infoAllWagonTrain,
            this.tss_lbl_AllSeatsTrain,
            this.tss_lbl_infoAllSeatsTrain,
            this.tss_pgb_seats});
            this.statusStrip1.Location = new System.Drawing.Point(0, 579);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1198, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tss_lbl_allWagonTrain
            // 
            this.tss_lbl_allWagonTrain.Name = "tss_lbl_allWagonTrain";
            this.tss_lbl_allWagonTrain.Size = new System.Drawing.Size(149, 17);
            this.tss_lbl_allWagonTrain.Text = "Всего вагонов в поезде :";
            // 
            // tss_lbl_infoAllWagonTrain
            // 
            this.tss_lbl_infoAllWagonTrain.Name = "tss_lbl_infoAllWagonTrain";
            this.tss_lbl_infoAllWagonTrain.Size = new System.Drawing.Size(14, 17);
            this.tss_lbl_infoAllWagonTrain.Text = "0";
            // 
            // tss_lbl_AllSeatsTrain
            // 
            this.tss_lbl_AllSeatsTrain.Name = "tss_lbl_AllSeatsTrain";
            this.tss_lbl_AllSeatsTrain.Size = new System.Drawing.Size(237, 17);
            this.tss_lbl_AllSeatsTrain.Text = "Всего мест в поезде/продано билетов : ";
            // 
            // tss_lbl_infoAllSeatsTrain
            // 
            this.tss_lbl_infoAllSeatsTrain.Name = "tss_lbl_infoAllSeatsTrain";
            this.tss_lbl_infoAllSeatsTrain.Size = new System.Drawing.Size(26, 17);
            this.tss_lbl_infoAllSeatsTrain.Text = "0/0";
            // 
            // tss_pgb_seats
            // 
            this.tss_pgb_seats.Name = "tss_pgb_seats";
            this.tss_pgb_seats.Size = new System.Drawing.Size(100, 16);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1198, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Информация о поезде";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 78);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1198, 501);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1190, 475);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tvr_train);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.Dgw_trainTicket);
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer1.Size = new System.Drawing.Size(1184, 469);
            this.splitContainer1.SplitterDistance = 394;
            this.splitContainer1.TabIndex = 2;
            // 
            // tvr_train
            // 
            this.tvr_train.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvr_train.ImageIndex = 1;
            this.tvr_train.ImageList = this.imageList1;
            this.tvr_train.Location = new System.Drawing.Point(0, 0);
            this.tvr_train.Name = "tvr_train";
            treeNode1.Name = "Train";
            treeNode1.Text = "Поезд";
            this.tvr_train.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.tvr_train.SelectedImageIndex = 1;
            this.tvr_train.Size = new System.Drawing.Size(394, 469);
            this.tvr_train.TabIndex = 0;
            this.tvr_train.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.selected_wagon);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "free-icon-trains-3117717.png");
            this.imageList1.Images.SetKeyName(1, "free-icon-trains-3117807.png");
            // 
            // Dgw_trainTicket
            // 
            this.Dgw_trainTicket.AllowDrop = true;
            this.Dgw_trainTicket.AllowUserToAddRows = false;
            this.Dgw_trainTicket.AllowUserToDeleteRows = false;
            this.Dgw_trainTicket.AllowUserToResizeRows = false;
            this.Dgw_trainTicket.AutoGenerateColumns = false;
            this.Dgw_trainTicket.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgw_trainTicket.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgw_trainTicket.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.Dgw_trainTicket.ContextMenuStrip = this.contextMenuStrip1;
            this.Dgw_trainTicket.DataSource = this.bns_view_trainticket;
            this.Dgw_trainTicket.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Dgw_trainTicket.Location = new System.Drawing.Point(0, 0);
            this.Dgw_trainTicket.MultiSelect = false;
            this.Dgw_trainTicket.Name = "Dgw_trainTicket";
            this.Dgw_trainTicket.ReadOnly = true;
            this.Dgw_trainTicket.RowHeadersVisible = false;
            this.Dgw_trainTicket.RowTemplate.Height = 24;
            this.Dgw_trainTicket.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgw_trainTicket.Size = new System.Drawing.Size(786, 469);
            this.Dgw_trainTicket.TabIndex = 2;
            this.Dgw_trainTicket.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DgvCarriageView_CellFormatting);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(786, 469);
            this.dataGridView1.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1190, 475);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Ofd_main
            // 
            this.Ofd_main.FileName = "openFileDialog1";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Number";
            this.dataGridViewTextBoxColumn1.HeaderText = "№ Вагона";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "WagonType";
            this.dataGridViewTextBoxColumn2.HeaderText = "Тип вагона";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "CompartmentNumber";
            this.dataGridViewTextBoxColumn3.HeaderText = "Номер купе";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "SeatNumber";
            this.dataGridViewTextBoxColumn4.HeaderText = "Номер места";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "State";
            this.dataGridViewTextBoxColumn5.HeaderText = "Состояние";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // bns_view_trainticket
            // 
            this.bns_view_trainticket.DataSource = typeof(TicketTrain_WPF_first.ViewModels.TrainTicket);
            // 
            // tsb_add_wagon
            // 
            this.tsb_add_wagon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_add_wagon.Image = global::TicketTrain_WPF_first.Properties.Resources.free_icon_add_icon_63747;
            this.tsb_add_wagon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_add_wagon.Name = "tsb_add_wagon";
            this.tsb_add_wagon.Size = new System.Drawing.Size(23, 22);
            this.tsb_add_wagon.Text = "toolStripButton1";
            this.tsb_add_wagon.ToolTipText = "Добавить вагон";
            this.tsb_add_wagon.Click += new System.EventHandler(this.AddWagon_command);
            // 
            // tsb_delete_wagon
            // 
            this.tsb_delete_wagon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_delete_wagon.Image = global::TicketTrain_WPF_first.Properties.Resources.premium_icon_recycle_bin_3156999;
            this.tsb_delete_wagon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_delete_wagon.Name = "tsb_delete_wagon";
            this.tsb_delete_wagon.Size = new System.Drawing.Size(23, 22);
            this.tsb_delete_wagon.Text = "toolStripButton2";
            this.tsb_delete_wagon.ToolTipText = "Удалить вагон";
            this.tsb_delete_wagon.Click += new System.EventHandler(this.Delete_Wagon_command);
            // 
            // sortBySaleSeatsDesc
            // 
            this.sortBySaleSeatsDesc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.sortBySaleSeatsDesc.Image = global::TicketTrain_WPF_first.Properties.Resources.glyphicons_halflings_256_trending_2x;
            this.sortBySaleSeatsDesc.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.sortBySaleSeatsDesc.Name = "sortBySaleSeatsDesc";
            this.sortBySaleSeatsDesc.Size = new System.Drawing.Size(23, 22);
            this.sortBySaleSeatsDesc.Text = "toolStripButton1";
            this.sortBySaleSeatsDesc.ToolTipText = "Сортировка вагонов по убыванию количества проданных мест";
            this.sortBySaleSeatsDesc.Click += new System.EventHandler(this.SortBySaleSeatDeck_command);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::TicketTrain_WPF_first.Properties.Resources.free_icon_ascending_sort_81996;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.SortByNumbWagon_command);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::TicketTrain_WPF_first.Properties.Resources.free_icon_descending_sort_81484;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.Click += new System.EventHandler(this.SortByNumbWagonDecs_command);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.купитьБилетToolStripMenuItem,
            this.вернутьБилетToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(159, 48);
            // 
            // купитьБилетToolStripMenuItem
            // 
            this.купитьБилетToolStripMenuItem.Name = "купитьБилетToolStripMenuItem";
            this.купитьБилетToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.купитьБилетToolStripMenuItem.Text = "Купить билет";
            this.купитьБилетToolStripMenuItem.Click += new System.EventHandler(this.SaleSeat_command);
            // 
            // вернутьБилетToolStripMenuItem
            // 
            this.вернутьБилетToolStripMenuItem.Name = "вернутьБилетToolStripMenuItem";
            this.вернутьБилетToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.вернутьБилетToolStripMenuItem.Text = "Вернуть билет";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1198, 601);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dgw_trainTicket)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bns_view_trainticket)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьКакToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поездToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новыйПоездToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsb_add_wagon;
        private System.Windows.Forms.ToolStripButton tsb_delete_wagon;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView tvr_train;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.DataGridView Dgw_trainTicket;
        private System.Windows.Forms.BindingSource bns_view_trainticket;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wagonTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn compartmentNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seatNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateDataGridViewTextBoxColumn;
        private System.Windows.Forms.OpenFileDialog Ofd_main;
        private System.Windows.Forms.SaveFileDialog Sfd_main;
        private System.Windows.Forms.ToolStripStatusLabel tss_lbl_allWagonTrain;
        private System.Windows.Forms.ToolStripStatusLabel tss_lbl_infoAllWagonTrain;
        private System.Windows.Forms.ToolStripStatusLabel tss_lbl_AllSeatsTrain;
        private System.Windows.Forms.ToolStripStatusLabel tss_lbl_infoAllSeatsTrain;
        private System.Windows.Forms.ToolStripProgressBar tss_pgb_seats;
        private System.Windows.Forms.ToolStripButton sortBySaleSeatsDesc;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem купитьБилетToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вернутьБилетToolStripMenuItem;
    }
}

