﻿using System;
using Main.Utilities.Menu;


namespace Main
{
	public sealed class App : MenuWrapper
	{
		private static readonly string ConnectionString =
			@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Catalan\Desktop\Homework_7\Main\Main\DB\EstateAgency.mdf;Integrated Security=True";

		private readonly Controller _controller = new(ConnectionString);

		public App() =>
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Первый запрос", Query1),
				new MenuItem("Второй запрос", Query2),
				new MenuItem("Третий запрос", Query3),
				new MenuItem("Четвертый запрос", Query4),
				new MenuItem("Пятый запрос", Query5),
				new MenuItem("Шестой запрос", Query6),
				new MenuItem("Седьмой запрос", Query7),
				new MenuItem("Восьмой запрос", Query8),
				new MenuItem("Девятый запрос", Query9),
			});


		private void Query1()
		{
			string street = "vel";
			int rooms = 5;

			Console.WriteLine(@$"
Выбирает информацию о {rooms}-комнатных квартирах, расположенных на улице ""{street}"". 
Значения задавать параметрами запроса");

			_controller.Query1(street, rooms);
		}


		private void Query2()
		{
			string surnamePattern = "B%";
			double dealPercent = 5;

			Console.WriteLine(@$"
Выбирает информацию о риэлторах, фамилия которых начинается с буквы ""{surnamePattern}"" и процент вознаграждения больше {dealPercent}%. 
Значения задавать параметрами запроса");

			_controller.Query2(surnamePattern, dealPercent);
		}


		private void Query3()
		{
			int min = 4000000, max = 8000000;

			Console.WriteLine(@$"
Выбирает информацию об 1-комнатных квартирах, цена на которые находится в диапазоне от 
{min:N} руб. до {max:N} руб. Значения задавать параметрами запроса");

			_controller.Query3(min, max);
		}


		private void Query4()
		{
			int rooms = 3;

			Console.WriteLine(@$"
Выбирает информацию о квартирах с заданным числом комнат ({rooms}). 
Значения задавать параметрами запроса");

			_controller.Query4(rooms);
		}


		private void Query5()
		{
			int rooms = 2;
			var area = (min: 40d, max: 79d);

			Console.WriteLine(@$"
Выбирает информацию обо всех {rooms}-комнатных квартирах, площадь которых есть 
значение из некоторого диапазона ({area.min} - {area.max}). Значения задавать параметрами запроса");

			_controller.Query5(rooms, area);
		}


		private void Query6()
		{
			Console.WriteLine(@"
Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. 
Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные. 
Сортировка по полю Дата сделки");

			_controller.Query6();
		}


		private void Query7()
		{
			Console.WriteLine(@"
Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора. 
Упорядочить выборку по убыванию суммы сделок.");

			_controller.Query7();
		}


		private void Query8()
		{
			Console.WriteLine(@"
Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки");

			_controller.Query8();
		}


		private void Query9()
		{
			var dates = (
							min: new DateTime(2021, 12, 1),
							max: new DateTime(2022, 2, 26));

			Console.WriteLine(@"
Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки. 
Диапазон задавать параметрами запроса");

			_controller.Query9(dates);
		}
	}
}