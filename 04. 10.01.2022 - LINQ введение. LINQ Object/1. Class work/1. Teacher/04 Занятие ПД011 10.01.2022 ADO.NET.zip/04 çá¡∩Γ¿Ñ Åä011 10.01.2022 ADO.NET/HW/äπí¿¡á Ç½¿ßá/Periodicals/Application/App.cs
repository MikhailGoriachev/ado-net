﻿using System;
using System.Configuration;
using Periodicals.Controllers;
using Periodicals.Helpers;

namespace Periodicals.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        QueriesController _queriesController;


        // конструктор с внедрением зависимостей
        public App(string connectingString) {
            _queriesController = new QueriesController(connectingString);
        } // App

        public void ProtectFileConfig() {
            // получение доступа к конфигурационному файлу
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (!section.SectionInformation.IsProtected) {
                // Зашифровать секцию.
                section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                // Сохранить файл конфигурации.
                config.Save();
            } // if
            Utils.WriteXY(45, 12, $"Конфигурационный файл зашифрован!", ConsoleColor.White);
        } // ProtectFileConfig


        public void UnprotectFileConfig() {
            // получение доступа к конфигурационному файлу
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (section.SectionInformation.IsProtected) {
                section.SectionInformation.UnprotectSection();
                config.Save();
            } // if

            Utils.WriteXY(45, 12, $"Конфигурационный файл расшифрован!", ConsoleColor.White);
        } // ProtectFileConfig
    } // class App
}