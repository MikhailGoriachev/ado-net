﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeriodicalsModels.Models
{
    public class TotalMinMax
    {
        public string PubType { get; set; }

        public int TotalPubType { get; set; }

        public int MaxPrice { get; set; }

        public int MinPrice { get; set; }

        public string ToTableRow() =>
            $"\t |{PubType,9} | {TotalPubType,11} | {MaxPrice,9} | {MinPrice,7}  |";
    }
}
