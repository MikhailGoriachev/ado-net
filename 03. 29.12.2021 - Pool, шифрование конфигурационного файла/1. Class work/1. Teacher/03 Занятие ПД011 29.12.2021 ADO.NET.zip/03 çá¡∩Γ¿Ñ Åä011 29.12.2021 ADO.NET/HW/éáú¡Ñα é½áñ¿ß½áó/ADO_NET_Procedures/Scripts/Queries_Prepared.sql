﻿-- Простая выборка сделок 

Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats.Number as nvarchar(11)) as Адрес -- Полный адрес
 ,Flats.Square_flat as Площадь 
 ,Flats.Rooms       as N'Кол-во комнат'
 ,Flats.Price       as Цена
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1)  as Риэлтор  
 ,P.Surname + N'.' + SUBSTRING(P.Person_name,1,1)+ N'.' + SUBSTRING(P.Patronymic,1,1)as Владелец
 ,Deals.Date_of_deal as N'Дата сделки' 
 , Flats.Price*Realtors.Per_cent as N'Комиссия риэлтора'

 from Deals join (Realtors join Person on Realtors.IdPerson = Person.id) on Deals.IdRealtor = Realtors.Id
			join (Flats join Adress on Flats.IdAdress = Adress.Id 
			            join (Owners join Person p on Owners.IdPerson = p.Id) 
			on Flats.IdOwner = Owners.Id) on IdFlat = Flats.Id -- Создаём общий агрегат 3-х свзязанных таблиц (адрес, владелец, персона)
order by 
	Flats.Price desc
go

-- 001 Выбрать из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах, 
-- расположенных на улице «Садовая». 
-- Значения задавать параметрами запроса

Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats.Number as nvarchar(11)) as Адрес -- Полный адрес
 ,Flats.Square_flat as Площадь 
 ,Flats.Rooms       as N'Кол-во комнат'
 ,Flats.Price       as Цена
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats.IdAdress = Adress.Id
where
	Adress.Street Like N'%С[ао]довая%' and Flats.Rooms = 3 -- Использую интервальные символы поскольку в первом заполнении таблицы не было нужной улицы

-- 002 Выбрать из таблицы РИЭЛТОРЫ информацию о риэлторах, 
-- фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%. 
-- Значения задавать параметрами запроса
Select 
   Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Риэлтор
  ,Realtors.Per_cent*100 as N'%'
from 
	Realtors join Person on Realtors.IdPerson = Person.Id
where 
   Person.Surname like N'И%' and Realtors.Per_cent > 0.01

-- 003 Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах, 
--     цена на которые находится в диапазоне от 12'400$. до 14'000$ - перевёл валюту в доллары США, поскольку в условии нигде не было
--     сказано об используемой валюте
--     Значения задавать параметрами запроса.

Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats.Number as nvarchar(11)) as Адрес -- Полный адрес
 ,Flats.Square_flat as Площадь 
 ,Flats.Rooms       as N'Кол-во комнат'
 ,Flats.Price       as Цена
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats.IdAdress = Adress.Id
where
 Flats.Price between 12400 and 14000

 --004 Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом комнат. 
 --    Значения задавать параметрами запроса.

 declare @rooms int = 2
 Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats.Number as nvarchar(11)) as Адрес -- Полный адрес
 ,Flats.Square_flat as Площадь 
 ,Flats.Rooms       as N'Кол-во комнат'
 ,Flats.Price       as Цена
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats.IdAdress = Adress.Id
where
	Flats.Rooms = @rooms
go

-- 005 Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах, 
--     площадь которых есть значение из некоторого диапазона. 
--     Значения задавать параметрами запроса.

 declare @rooms int = 2, @MinS float = 46, @MaxS float = 60
 Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats.Number as nvarchar(11)) as Адрес -- Полный адрес
 ,Flats.Square_flat as Площадь 
 ,Flats.Rooms       as N'Кол-во комнат'
 ,Flats.Price       as Цена
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats.IdAdress = Adress.Id
where
	Flats.Rooms = @rooms and Flats.Square_flat between @MinS and @MaxS

-- 006 Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. Включает поля Фамилия риэлтора, 
--     Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные. 
--     Сортировка по полю Дата сделки.

Select
  Person.Surname     as N'Фамилия риэлтора'
 ,Person.Person_name as  N'Имя риэлтора' 
 ,Person.Patronymic  as N'Отчество риэлтора'
 ,Deals.Date_of_deal as N'Дата сделки'
 ,Flats.Price        as N'Цена ($)'
 ,Flats.Price*Realtors.Per_cent as N'Комиссия риэлтора (%)'

 from Deals join (Realtors join Person on Realtors.IdPerson = Person.id) on Deals.IdRealtor = Realtors.Id
			join Flats on IdFlat = Flats.Id 
order by 
	Deals.Date_of_deal
go

-- 007 (Left join)
--    Выбрать всех риэлторов, количество клиентов,
--     оформивших с ним сделки и сумму сделок риэлтора.
--    Упорядочить выборку по убыванию суммы сделок.

-- Пробовал различные вариации связывания для улучшения понимания ↓ ↓ ↓

/*(Realtors join Person on Realtors.IdPerson = Person.id) left join Deals on Deals.IdRealtor = Realtors.Id
		  left join (Flats join (Owners join Person pers on Owners.IdPerson = pers.Id) on Flats.IdOwner = Owners.Id) 
			on Deals.IdFlat = Flats.Id*/ -- 1-й вариант левого соденения

/*(Realtors join Person on Realtors.IdPerson = Person.id) left join (Deals 
	        join (Flats join (Owners join Person pers on Owners.IdPerson = pers.Id) on Flats.IdOwner = Owners.Id) on Deals.IdFlat = Flats.Id) 
			on Deals.IdRealtor = Realtors.Id*/

/* Deals  left join (Realtors join Person on Realtors.IdPerson = Person.id)on Deals.IdRealtor = Realtors.Id
	       join (Flats join (Owners join Person pers on Owners.IdPerson = pers.Id) on Flats.IdOwner = Owners.Id) on Deals.IdFlat = Flats.Id
*/

Select

  Person.Surname   as N'Фамилия риэлтора'
  ,COUNT(Distinct pers.Person_name) as Клиенты
  ,COUNT(Flats.Id) as Сделки
from
	 (Realtors join Person on Realtors.IdPerson = Person.id) left join (Deals 
	        join (Flats join (Owners join Person pers on Owners.IdPerson = pers.Id) on Flats.IdOwner = Owners.Id) on Deals.IdFlat = Flats.Id) 
			on Deals.IdRealtor = Realtors.Id
			
 group by
  Person.Surname
 order by 
  Сделки Desc
go

 -- 008 Для всех улиц вывести сумму сделок, 
 --     упорядочить выборку по убыванию суммы сделки.

 Select 
 Adress.Street as Улица
 ,Count(IdFlat) as N'Сумма сделок'
 from 
  Adress left join (Deals join Flats on Deals.IdFlat = Flats.Id) on Flats.IdAdress = Adress.Id

  group by 
  Adress.Street
  order by 
   N'Сумма сделок' desc
go

-- 009 Для всех улиц вывести сумму сделок за заданный период, 
--     упорядочить выборку по убыванию суммы сделки.
--     Диапазон задавать параметрами запроса. 
	
 Select 
  Adress.Street as Улица
 ,Count(IdFlat) as N'Сумма сделок'
 from 
  Adress left join (Deals join Flats on Deals.IdFlat = Flats.Id) on Flats.IdAdress = Adress.Id

  where
  YEAR(Deals.Date_of_deal) between 2010 and 2021 -- Для читабельности перевёл дату в год
  group by 
	Adress.Street
  order by 
	N'Сумма сделок' desc
go

-- 010 Выполнить группировку по полю Количество комнат. 
--     Для каждой группы вычисляет среднее значение по полю Цена квартиры.

Select 
	Flats.Rooms as N'Количесвто комнат' 
	,ROUND(AVG(Flats.Price),2) as N'Средняя цена' -- Округлил цену до 2-х знаков
from Flats join (Owners join Person on Owners.IdPerson = Person.Id) on Flats.IdOwner = Owners.Id
		   join Adress on Flats.IdAdress = Adress.Id
group by 
	Flats.Rooms
go

-- 011 Выполнить группировку по полю Площадь квартиры. 
--     Для каждой группы вычисляет наибольшее и наименьшее значение по полю Цена квартиры.

select 
	Flats.Square_flat as N'Площадь квартиры'
	,COUNT(Flats.Id) as N'Кол-во квартир'    -- Задаём поле для лучшей видимости изменений
	,MIN(Flats.Price) as N'Минимальная цена'
	,MAX(Flats.Price) as N'Максимальная цена'
from 
	Flats
group by
	Flats.Square_flat
order by
	N'Кол-во квартир' Desc
go

-- 012 Создать таблицу КВАРТИРЫ_3_КОМН, 
--     содержащую информацию о 3-комнатных квартирах.

 drop table if exists Flats_3_Rooms;

 Select 
  *
 into Flats_3_Rooms

 from 
	Flats
where 
	Flats.Rooms = 3
go

-- Демонстрация результата

 Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats_3_Rooms.Number as nvarchar(11)) as Адрес -- Полный адрес
 ,Flats_3_Rooms.Square_flat as Площадь 
 ,Flats_3_Rooms.Rooms       as N'Кол-во комнат'
 ,Flats_3_Rooms.Price       as Цена
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats_3_Rooms join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats_3_Rooms.IdAdress = Adress.Id
go

-- 013 Создать копию таблицы КВАРТИРЫ с именем КОПИЯ_КВАРТИРЫ.

 drop table if exists Flats_Copy;

 Select 
  *
 into Flats_Copy

 from 
	Flats
go

Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats_Copy.Number as nvarchar(11)) as Адрес -- Полный адрес
 ,Flats_Copy.Square_flat as Площадь 
 ,Flats_Copy.Rooms       as N'Кол-во комнат'
 ,Flats_Copy.Price       as Цена
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats_Copy join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats_Copy.IdAdress = Adress.Id
go

-- 014 Удалить из таблицы КОПИЯ_КВАРТИРЫ записи, 
--     в которых значение в поле Цена квартиры больше 3 000 000 руб.

-- Вывод до удаления
Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats_Copy.Number as nvarchar(11)) as Адрес
  ,Flats_Copy.Price       as Цена
 ,Flats_Copy.Square_flat as Площадь 
 ,Flats_Copy.Rooms       as N'Кол-во комнат'
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats_Copy join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats_Copy.IdAdress = Adress.Id
order by
	Flats_Copy.Price Desc

declare @MaxPrice float = 41000 -- Доллары США

-- Удаление 

delete from 
	Flats_Copy
where 
	Flats_Copy.Price > @MaxPrice

--Вывод после удаления

Select 
	Flats_Copy.Price
   ,Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats_Copy.Number as nvarchar(8)) as Адрес
   ,Person.Surname + SUBSTRING(Person.Person_name,1,1) + N'.' + SUBSTRING(Person.Patronymic,1,1) as N'ФИО владельца'
   ,Flats_Copy.Square_flat as Площадь
   ,Flats_Copy.Rooms as N'Кол-во комнат'
from 
	Flats_Copy join (Owners join Person on Owners.IdPerson = Person.Id) on Flats_Copy.IdOwner = Owners.Id
			   join Adress on Flats_Copy.IdAdress = Adress.Id
order by 
	Flats_Copy.Price desc

-- 015 Увеличить значение в поле Цена квартиры таблицы 
--     КОПИЯ_КВАРТИРЫ на 10 процентов для 1-комнатных квартир

-- Вывод до изменения

Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats_Copy.Number as nvarchar(11)) as Адрес
 ,Flats_Copy.Price       as Цена
 ,Flats_Copy.Square_flat as Площадь 
 ,Flats_Copy.Rooms       as N'Кол-во комнат'
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats_Copy join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats_Copy.IdAdress = Adress.Id
 where Flats_Copy.Rooms = 1

order by
	Flats_Copy.Price Desc
go 

-- Изменение записи 

update
	Flats_Copy
set 
	Price += Price*0.1
where 
	Flats_Copy.Rooms = 1

-- Вывод после измения

Select
  Adress.Street + N' ' + Adress.House + N' кв.' + CAST(Flats_Copy.Number as nvarchar(11)) as Адрес
 ,Flats_Copy.Price       as Цена
 ,Flats_Copy.Square_flat as Площадь 
 ,Flats_Copy.Rooms       as N'Кол-во комнат'
 ,Person.Surname + N'.' + SUBSTRING(Person.Person_name,1,1)+ N'.' + SUBSTRING(Person.Patronymic,1,1) as Владелец

 from 
  Flats_Copy join (Owners join Person on Owners.IdPerson = Person.Id) on IdOwner = Owners.id
        join Adress on Flats_Copy.IdAdress = Adress.Id
 where Flats_Copy.Rooms = 1

order by
	Flats_Copy.Price Desc
go 