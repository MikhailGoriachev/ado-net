﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LinqIntro.Helpers;
using LinqIntro.Models;

namespace LinqIntro.Controllers
{
    /*
     * Решение задачи 1
     */
    public class Task1Controller
    {
        private List<Goods> _goodses;

        public Task1Controller():this(new List<Goods>()) {
            Initializer();
        } // Task1Controller

        public Task1Controller(List<Goods> goodses) {
            _goodses = goodses;
        } // Task1Controller


        // Инициализация коллекции товаров
        public void Initializer() => _goodses = Utils.ListGoods();

        // Вывод коллекции товаров в консоль
        public void ShowGoods(string caption) =>
            Console.WriteLine($"{Utils.ToTable(_goodses, caption)}");
        

        #region Задача 1. Расширяющий метод
        // Демонстрация расширяющего метода класса товаров
        public void ExtendMethodDemo() {
            Console.WriteLine(
                "\n\n\n\n\t\tВычисление скидки по возрасту товара расширяющим методом класса Goods\n" +    
                "\t┌───────┬──────────────────────────┬─────────────┬──────────────┬────────────┐\n" +
                "\t│ Номер │ Наименование товара      │ Год выпуска │ Возраст, лет │ Скидка, %  │\n" +
                "\t├───────┼──────────────────────────┼─────────────┼──────────────┼────────────┤"
            );

            int i = 0;
            foreach (var goods in _goodses) {
                int age = DateTime.Now.Year - goods.Year;
                Console.WriteLine(
                    $"\t│ {++i,5} │ {goods.GoodsName,-24} │ {goods.Year,11} " +
                    $"│ {age,12} │ {goods.Discount(),10:N2} │"
                );
            } // foreach
            Console.WriteLine("\t└───────┴──────────────────────────┴─────────────┴──────────────┴────────────┘");
        } // ExtendMethodDemo
        #endregion

    } // class Task1Controller
}
