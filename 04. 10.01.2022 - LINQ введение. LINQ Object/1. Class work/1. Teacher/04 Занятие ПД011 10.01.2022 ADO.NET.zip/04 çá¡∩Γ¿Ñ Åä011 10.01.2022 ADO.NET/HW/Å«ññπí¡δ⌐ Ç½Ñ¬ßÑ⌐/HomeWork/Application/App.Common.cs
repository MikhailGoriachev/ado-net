﻿using HomeWork.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Application
{
    public partial class App
    {
        private TaskController _taskController;
       

        // конструктор по умолчанию
        public App() : this(new TaskController()) { }
        //public App(string connectingString1, string connectingString2) : this(new ControllerTask1(connectingString1), new Task2Controller(connectingString2)) { }

        public App(TaskController taskController)
        {
            _taskController = taskController;            
        } // App

    }
}
