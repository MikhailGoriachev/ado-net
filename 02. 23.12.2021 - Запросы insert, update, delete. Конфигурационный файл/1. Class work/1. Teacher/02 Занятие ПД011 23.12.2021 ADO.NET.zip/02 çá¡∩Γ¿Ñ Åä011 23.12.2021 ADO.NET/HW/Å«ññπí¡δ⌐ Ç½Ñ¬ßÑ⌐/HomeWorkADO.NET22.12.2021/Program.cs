﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using HomeWorkADO.NET22._12._2021.Application;
using HomeWorkADO.NET22._12._2021.Utils;

namespace HomeWorkADO.NET22._12._2021
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.Title = "Домашние задание на 22.12.21";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Выбирает информацию о 3-комнатных квартирах, расположенных на улице «---»"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Выбирает информацию об 1-комнатных квартирах, цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Выбирает информацию о квартирах с заданным числом комнат"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Выбирает информацию обо всех 2-комнатных квартирах, площадь которых есть значение из некоторого диапазона"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. "},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки"},
                new MenuItem {HotKey = ConsoleKey.C, Text = "Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки"},
                
               
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();
            app.ConnectingString = @"
                 Data Source=(LocalDB)\MSSQLLocalDB;
                 AttachDbFilename=""D:\Students\ПД011\06 ADO.NET\02 Занятие ПД011 23.12.2021 ADO.NET\HW\Поддубный Алексей\HomeWorkADO.NET22.12.2021\App_Data\Accounting.mdf"";
                 Integrated Security=True";


            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.Utils.ShowNavBarTask("Делегаты, лямба выражения");
                    Utils.Utils.ShowMenu(12, 5, "Меню ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {
                        // ------------------------------------------------------------
                        




                        case ConsoleKey.Q:
                            app.Query01(3, "Артёма");
                            break;


                        case ConsoleKey.W:
                            app.Query02(10, "И");
                            break;
                       
                        case ConsoleKey.E:
                            app.Query03(1, 900000, 1000000);
                            break;

                        
                        case ConsoleKey.R:
                            app.Query04();
                            break;

                       
                        case ConsoleKey.A:
                            app.Query05(2);
                            break;

                      
                        case ConsoleKey.S:
                            app.Query06();
                            break;

                        
                        case ConsoleKey.D:
                            app.Query07();

                            break;

                        
                        case ConsoleKey.F:
                            app.Query08();

                            break;

                        case ConsoleKey.C:
                            app.Query09();

                            break;


                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while


        }
    }
}
