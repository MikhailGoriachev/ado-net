﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LINQ_Practice.Utilities;
using LINQ_Practice.Model;

namespace LINQ_Practice.App
{
    public partial class Application
    {
        Goods goods;

        Color color = new Color();
        public Application()
        {
            goods = new Goods();
        }

        //Вывод меню 
        public void ShowMenu(string title)
        {
            Palette.MainColor.EstablishColor();
            string MainTitle = title;

            //Add-up 19 symbols
            string Spaces = AddSymbols(19);

            //Массивы пунктов меню 
            MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Задание_1: формирование скидок на товар."},
                new MenuItem {key = " W ",Text = " - Задание_2: работа с одномерным массивом через LINQ."},
                new MenuItem {key = " E ",Text = " - Задание_3: использование возможностей LINQ для коллекции товаров."},
                new MenuItem {key = "ESC",Text = " - Выход"}
            };

            try
            {


                while (true)
                {
                    Console.Clear();
                    Utils.ShowBarMessage(MainTitle);
                    Console.CursorVisible = false;
                    Utils.ShowMenu(3, 3, "Выберете действие", FirstTaskMenu);

                    //Если задание сделано не до конца
                    /*
                    Console.ForegroundColor = Utils.colors.W;
                    Console.BackgroundColor = Utils.colors.R;
                    Console.SetCursorPosition(3, 12);
                    Console.Write("Ps.Задание в разработке. Методы не реализованы!");
                    Palette.MainColor.EstablishColor();*/
                    ConsoleKey key = Console.ReadKey().Key;

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            {
                                Console.Clear();
                                Task1();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.W:
                            {
                                Console.Clear();
                                Task2();
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.E:
                            {
                                Console.Clear();
                                Task3();
                                Console.ReadKey();
                                break;
                            }

                        default:
                            throw new Exception($"Клавиша {key} не поддерживается");
                    }//Switch

                }//While

            }//Try
             //Catсh блок
             //Обрабатываем общее исключение
            catch (Exception ex)
            {
                if (MessageBox.Show(ex.Message + $"\n\n{ex.StackTrace}", "Ошибка!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error) == DialogResult.OK)
                    ShowMenu(title);

            }//catch

        } //ShowMenu

        //Добавление пустых символов для вывода 
        private string AddSymbols(int count, string symbol = " ")
        {
            StringBuilder sb = new StringBuilder();

            //Добавление заданных символов
            for (int i = 0; i < count; i++)
                sb.Append(symbol);

            return sb.ToString();
        }

       

    }
}
