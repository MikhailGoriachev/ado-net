﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;        // для ADO.NET

namespace H_W1Ado.Application
{
    public class App
    {
        // Выбирает информацию о 3-комнатных квартирах, расположенных на улице «Садовая».
        // Значения задавать параметрами запроса
        public void Query01(string connectingString)
        {
            Console.WriteLine("\n Запрос 1\n Выбирает информацию о 3-комнатных" +
                " квартирах, расположенных на улице «Садовая».\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                     Streets.NameStreet
                     , Apartments.HouseNum
                     , Apartments.Flat
                     , Apartments.AreaApartment
                     , Apartments.NumberOfRooms
                     , Apartments.PriceApartment
                  from
                     Apartments join Streets on Apartments.IdNameStreet = Streets.Id
                  where
                     Streets.NameStreet = @namestreet and Apartments.NumberOfRooms = @numRooms"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@namestreet", "Садовая");
                cmd.Parameters.AddWithValue("@numRooms", 3);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0), -10} | {reader.GetName(1),-8} | " +
                        $"{reader.GetName(2), 6} | {reader.GetName(3),13} |" +
                        $" {reader.GetName(4),14} | {reader.GetName(5),14} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-10} | " +
                            $"{reader.GetString(1),-8} | {reader.GetInt32(2), 6} | " +
                            $"{reader.GetDouble(3),13:n2} | {reader.GetInt32(4),14} | " +
                            $"{reader.GetInt32(5),14} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query01

        // Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%.
        // Значения задавать параметрами запроса
        public void Query02(string connectingString)
        {
            Console.WriteLine("\n Запрос 2\n Выбирает информацию о риэлторах," +
                " фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                     Persons.Surname
                     , Persons.[Name]
                     , Persons.Patronymic
                     , Realtors.PercentRemuneration
                  from
                     Realtors join Persons on Realtors.IdPerson = Persons.Id
                  where
                     Persons.Surname like @surname and Realtors.PercentRemuneration > @percent"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@surname", "И%");
                cmd.Parameters.AddWithValue("@percent", 10);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-15} | {reader.GetName(1),-15} | " +
                        $"{reader.GetName(2),-15} | {reader.GetName(3),19} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-15} | " +
                            $"{reader.GetString(1),-15} | {reader.GetString(2),-15} | " +
                            $"{reader.GetInt32(3),19} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query02


        // Выбирает информацию об 1-комнатных квартирах,
        // цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб.
        // Значения задавать параметрами запроса
        public void Query03(string connectingString)
        {
            Console.WriteLine("\n Запрос 3\n Выбирает информацию об 1-комнатных квартирах,\n" +
                " цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                      Streets.NameStreet
                      , Apartments.HouseNum
                      , Apartments.Flat
                      , Apartments.AreaApartment
                      , Apartments.NumberOfRooms
                      , Apartments.PriceApartment
                  from
                     Apartments join Streets on Apartments.IdNameStreet = Streets.Id
                  where
                     Apartments.PriceApartment between @loPrice and @hiPrice"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@loPrice", 900_000);
                cmd.Parameters.AddWithValue("@hiPrice", 1_000_000);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-12} | {reader.GetName(1),-8} | " +
                        $"{reader.GetName(2),6} | {reader.GetName(3),13} |" +
                        $" {reader.GetName(4),14} | {reader.GetName(5),14} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-10} | " +
                            $"{reader.GetString(1),-8} | {reader.GetInt32(2),6} | " +
                            $"{reader.GetDouble(3),13:n2} | {reader.GetInt32(4),14} | " +
                            $"{reader.GetInt32(5),14} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query03


        // Выбирает информацию о квартирах с заданным числом комнат.
        // Значения задавать параметрами запроса
        public void Query04(string connectingString)
        {
            Console.WriteLine("\n Запрос 4\n Выбирает информацию о квартирах с заданным числом комнат.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                      Streets.NameStreet
                      , Apartments.HouseNum
                      , Apartments.Flat
                      , Apartments.AreaApartment
                      , Apartments.NumberOfRooms
                      , Apartments.PriceApartment
                  from
                     Apartments join Streets on Apartments.IdNameStreet = Streets.Id
                  where
                     Apartments.NumberOfRooms = @numRooms"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@numRooms", 2);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-16} | {reader.GetName(1),-8} | " +
                        $"{reader.GetName(2),6} | {reader.GetName(3),13} |" +
                        $" {reader.GetName(4),14} | {reader.GetName(5),14} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-16} | " +
                            $"{reader.GetString(1),-8} | {reader.GetInt32(2),6} | " +
                            $"{reader.GetDouble(3),13:n2} | {reader.GetInt32(4),14} | " +
                            $"{reader.GetInt32(5),14} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query04


        // Выбирает информацию обо всех 2-комнатных квартирах,
        // площадь которых есть значение из некоторого диапазона.
        // Значения задавать параметрами запроса
        public void Query05(string connectingString)
        {
            Console.WriteLine("\n Запрос 5\n Выбирает информацию обо всех 2-комнатных квартирах\n," +
                " площадь которых есть значение из некоторого диапазона.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                      Streets.NameStreet
                      , Apartments.HouseNum
                      , Apartments.Flat
                      , Apartments.AreaApartment
                      , Apartments.NumberOfRooms
                      , Apartments.PriceApartment
                  from
                     Apartments join Streets on Apartments.IdNameStreet = Streets.Id
                  where
                     Apartments.NumberOfRooms = @numRooms and Apartments.AreaApartment between @loArea and @hiArea"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@numRooms", 2);
                cmd.Parameters.AddWithValue("@loArea", 45.5);
                cmd.Parameters.AddWithValue("@hiArea", 50.5);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-16} | {reader.GetName(1),-8} | " +
                        $"{reader.GetName(2),6} | {reader.GetName(3),13} |" +
                        $" {reader.GetName(4),14} | {reader.GetName(5),14} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-16} | " +
                            $"{reader.GetString(1),-8} | {reader.GetInt32(2),6} | " +
                            $"{reader.GetDouble(3),13:n2} | {reader.GetInt32(4),14} | " +
                            $"{reader.GetInt32(5),14} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query05


        // Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.
        // Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные.
        // Сортировка по полю Дата сделки
        public void Query06(string connectingString)
        {
            Console.WriteLine("\n Запрос 6\n Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора\n." +
                " Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные.\n" +
                " Сортировка по полю Дата сделки\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                     Persons.Surname
                     , Persons.[Name]
                     , Persons.Patronymic
                     , Dealings.DateDeal
                     , Apartments.PriceApartment
                     , (Apartments.PriceApartment * Realtors.PercentRemuneration) / 100 as Commission
                  from 
                     Dealings join(Realtors join Persons on Realtors.IdPerson = Persons.Id)
                              on Dealings.IdRealtor = Realtors.Id
                              join(Apartments join Streets on Apartments.IdNameStreet = Streets.Id)
                              on Dealings.IdApartment = Apartments.Id
                  order by
                     Dealings.DateDeal"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-11} | {reader.GetName(1),-12} | " +
                        $"{reader.GetName(2),-12} | {reader.GetName(3),20} |" +
                        $" {reader.GetName(4),15} | {reader.GetName(5),13} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-11} | " +
                            $"{reader.GetString(1),-12} | {reader.GetString(2),-12} | " +
                            $"{reader.GetDateTime(3),20} | {reader.GetInt32(4),15} | {reader.GetInt32(5),13} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query06


        // Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора.
        // Упорядочить выборку по убыванию суммы сделок
        public void Query07(string connectingString)
        {
            Console.WriteLine("\n Запрос 7\n Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора.\n" +
                " Упорядочить выборку по убыванию суммы сделок\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                     Realtors.Id
                     , Persons.Surname
                     , Persons.[Name]
                     , Persons.Patronymic
                     , Count(Dealings.IdRealtor) as AmountRealtors
                     , SUM(Apartments.PriceApartment) as SumDeal
                  from 
                     Dealings left join(Realtors join Persons on Realtors.IdPerson = Persons.Id) 
                              on Dealings.IdRealtor = Realtors.Id
                              left join(Apartments join Streets on Apartments.IdNameStreet = Streets.Id)
                              on Dealings.IdApartment = Apartments.Id
                  group by
                     Realtors.Id, Persons.Surname, Persons.[Name], Persons.Patronymic
                  order by 
                     SumDeal desc"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"|{reader.GetName(0),6} | {reader.GetName(1),-12} | " +
                        $"{reader.GetName(2),-12} | " +
                        $"{reader.GetName(3),-12} | {reader.GetName(4),15} | {reader.GetName(5),10} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),5} | {reader.GetString(1),-12} | " +
                            $"{reader.GetString(2),-12} | {reader.GetString(3),-12} | " +
                            $"{reader.GetInt32(4),15} | {reader.GetInt32(5),10} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query07


        // Для всех улиц вывести сумму сделок,
        // упорядочить выборку по убыванию суммы сделки
        public void Query08(string connectingString)
        {
            Console.WriteLine("\n Запрос 8\n Для всех улиц вывести сумму сделок," +
                " упорядочить выборку по убыванию суммы сделки\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                     Streets.NameStreet
                     , Count(Dealings.IdRealtor) as DealAmount
                     , Sum(Apartments.PriceApartment) as DealSum
                  from
                     Streets left join (Apartments join Dealings on Apartments.Id = Dealings.IdApartment) 
                             on Streets.Id = Apartments.IdNameStreet
                  group by
                     Streets.NameStreet
                  order by 
                     DealSum desc"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-15} | " +
                        $"{reader.GetName(1),12} | {reader.GetName(2),12} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-15} | " +
                            $"{reader.GetInt32(1),12} | {reader.GetInt32(2),12} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query08


        // Для всех улиц вывести сумму сделок за заданный период,
        // упорядочить выборку по убыванию суммы сделки.
        // Диапазон задавать параметрами запроса
        public void Query09(string connectingString)
        {
            Console.WriteLine("\n Запрос 8\n Для всех улиц вывести сумму сделок за заданный период,\n" +
                " упорядочить выборку по убыванию суммы сделки.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select 
                     Streets.NameStreet
                     , Count(Dealings.IdRealtor) as DealAmount
                     , Sum(Apartments.PriceApartment) as DealSum
                  from
                     Streets left join (Apartments join Dealings on Apartments.Id = Dealings.IdApartment) 
                             on Streets.Id = Apartments.IdNameStreet
                  where
                     Dealings.DateDeal between @loDate and @hiDate
                  group by
                     Streets.NameStreet
                  order by 
                     DealSum desc"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@loDate", "12-05-2021");
                cmd.Parameters.AddWithValue("@hiDate", "02-01-2022");

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-15} | " +
                        $"{reader.GetName(1),12} | {reader.GetName(2),12} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-15} | " +
                            $"{reader.GetInt32(1),12} | {reader.GetInt32(2),12} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query09

    }// class App
}
