﻿/* База данных «Оптовый магазин. Учет продаж»  */

-- справочник единиц измерения
select
   *
from
    Units;
go

-- справочник номенклатуры товаров
select
    *
from
    Goods;
go


-- персональные данные
select
    *
from
    Persons;
go

-- продавцы
select
   Sellers.Id
   , Persons.Surname
   , Persons.[Name]
   , Persons.Patronymic
   , Sellers.Interest
from
    Sellers join Persons on Sellers.IdPerson = Persons.Id;
go

-- закупки товаров 
select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id;
go

-- факты продаж
select
    Sales.Id
    , Goods.Item
    , Units.Short
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Sales.SaleDate
    , Purchases.Price   as PurchasePrice
    , Sales.Price       as SalePrice
    , Sales.Amount
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id) on Sales.IdSeller = Sellers.IdPerson
          join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id;
go

-- запросы по заданию

-- Запрос  1. Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых 
-- является «шт» (штуки) и цена закупки составляет меньше 200 руб.
declare @unit nvarchar(6) = N'шт', @price int = 200;

select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id
where
    Units.Short = @unit and Purchases.Price < @price;
go

-- Запрос  2. Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах, цена закупки которых больше 
-- 500 руб. за единицу товара
declare @price int = 500;

select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id
where
    Purchases.Price > @price;
go

-- Запрос  3. Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием 
-- (например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
declare @item nvarchar(60) = N'чехол защитный', @price int = 1800;

select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id
where
    Goods.Item = @item and Purchases.Price < @price;
go


-- Запрос  4. Запрос с параметрами	
-- Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением
-- процента комиссионных.
declare @interest float = 8;

select
   Sellers.Id
   , Persons.Surname
   , Persons.[Name]
   , Persons.Patronymic
   , Sellers.Interest
from
    Sellers join Persons on Sellers.IdPerson = Persons.Id
where 
    Sellers.Interest = @interest;
go

-- Запрос  5. Запрос с параметрами	
-- Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех 
-- зафиксированных фактах продажи товаров (Наименование товара, Цена закупки, 
-- Цена продажи, дата продажи), для которых Цена продажи оказалась в некоторых 
-- заданных границах. 
declare @fromPrice int = 15000, @toPrice int = 150000;

select
    Sales.Id
    , Goods.Item
    , Units.Short
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Sales.SaleDate
    , Purchases.Price   as PurchasePrice
    , Sales.Price       as SalePrice
    , Sales.Amount
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id) on Sales.IdSeller = Sellers.IdPerson
          join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id
where
   Sales.Price between @fromPrice and @toPrice;
go

-- Запрос  6. Запрос с вычисляемыми полями	
-- Вычисляет прибыль от продажи за каждый проданный товар. Включает поля 
-- Дата продажи, Наименование товара, Цена закупки, Цена продажи, Количество 
-- проданных единиц, Прибыль. Сортировка по полю Наименование товара
select
    Sales.Id
    , Goods.Item
    , Units.Short
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Sales.SaleDate
    , Sales.Amount
    , Purchases.Price   as PurchasePrice
    , Sales.Price       as SalePrice
    , (Sales.Price - Purchases.Price) * Sales.Amount as Profit 
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id) on Sales.IdSeller = Sellers.IdPerson
          join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id
order by
    Goods.Item;
go


-- Запрос  7. Итоговый запрос	
-- Выполняет группировку по полю Наименование товара. Для каждого наименования
-- вычисляет среднюю цену закупки товара, количество закупок
select
    Goods.Item
    , Units.Long
    , count(Purchases.IdItem) as PurchasesAmount
    , avg(Purchases.Price)    as PurchasesAvg
from
    Goods join (Purchases join Units on Purchases.IdUnit = Units.Id) on Goods.Id = Purchases.IdItem
group by
    Goods.Item, Units.Long;
go


-- Запрос  8. Итоговый запрос	
-- Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ. Для каждого 
-- продавца вычисляет среднее значение по полю Цена продажи единицы товара, 
-- количество продаж
select
    Sales.IdSeller
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Persons.Passport
    , count(Sales.IdSeller) as SalesAmount
    , avg(Sales.Price)      as AvgPrice
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id)
          on Sales.IdSeller = Sellers.Id
group by
    Sales.IdSeller, Persons.Surname, Persons.[Name], Persons.Patronymic, Persons.Passport
order by
    AvgPrice desc;
go


