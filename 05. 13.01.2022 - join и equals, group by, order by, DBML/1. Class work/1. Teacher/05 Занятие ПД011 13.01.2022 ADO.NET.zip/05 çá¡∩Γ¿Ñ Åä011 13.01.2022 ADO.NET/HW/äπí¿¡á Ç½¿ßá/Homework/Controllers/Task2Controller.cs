﻿using Homework.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Homework.Models;

namespace Homework.Controllers
{
    class Task2Controller
    {
        // массив вещественных элементов
        private double[] _array;

        public Task2Controller() => Initialize();
        public Task2Controller(double[] array) =>
            _array = array;

        // формирование массивa
        public void Initialize(int n = 12, double lo = -10d, double hi = 25d) {
            _array = new double[n];
            int zero = Utils.Random.Next(0, n);

            for (int i = 0; i < n; i++) {
                _array[i] = i == zero
                    ? 0d 
                    : Utils.GetRandom(lo, hi);

                if (i > zero) zero = Utils.Random.Next(i + 1, n+ 2);
            } // for i
        } // Initialize

        // вывод массива
        public void Show(string title, double[] data, Predicate<double> predicate) {
            Console.Write($"    {title}");

            foreach (var item in data) {
                if (predicate(item)) Utils.SetColor(ConsoleColor.Cyan, ConsoleColor.DarkGray);

                Console.Write($"{item,7:f2}");

                Utils.RestoreColor();
            } // foreach item
            Console.WriteLine();
        } // Show
        public void Show(string title, Predicate<double> predicate) => Show(title, _array, predicate);
        public void Show(string title) => Show(title, _array, x => false);


        // Вычисление количества элементов массива, со значениями в диапазоне от A до B
        public void CountInRange(double lo, double hi) {
            Console.WriteLine();
            Show("Исходный массив:", x => lo <= x && x <= hi);

            int count;

            #region в синтаксисе LINQ
            /*
            var query =
                from item in _array
                where lo <= item && item <= hi
                select item;

            count = query.Count();
            */
            #endregion

            // в синтаксисе расширяющих методов
            count = _array.Count(x => lo <= x && x <= hi);

            Console.WriteLine($"\n    Кол-во элементов массива, со значениями в диапазоне {lo:f2} до {hi:f2}: {count}\n");

        } // CountInRange


        // Вычисление количества элементов массива, равных 0
        public void CountZeros() {
            Console.WriteLine();
            Show("Исходный массив:", x => x.CompareTo(0d) == 0);

            int count;

            #region в синтаксисе LINQ
            /*
            var query =
                from item in _array
                where item.CompareTo(0d) == 0
                select item;

            count = query.Count();
            */
            #endregion

            // в синтаксисе расширяющих методов
            count = _array.Count(x => x.CompareTo(0d) == 0);

            Console.WriteLine($"\n    Кол-во элементов массива, равных 0: {count}\n");
        } // CountZeros

        // Вычисление суммы элементов массива, расположенных после первого максимального элемента
        public void SumAfterMax() {
            Console.WriteLine();
            double sum, max = _array.Max();

            sum = _array
                .SkipWhile(item => item < max)  // пропуск элементов до первого максимального
                .Skip(1)                        // пропуск максимального
                .Sum();                       

            Show("Исходный массив:", x => x.CompareTo(max) == 0);

            Console.WriteLine($"\n    Cумма элементов, расположенных после первого максимального элемента: {sum:f2}\n");
        } // SumAfterMax


        // Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом
        public void SumBeforeMin() {
            Console.WriteLine();
            double sum, min = _array.Min(x => Math.Abs(x));
            
            sum = _array.Reverse()
                .SkipWhile(item => Math.Abs(item) > min)
                .Skip(1)
                .Sum();

            Show("Исходный массив:", x => x.CompareTo(min) == 0);

            Console.WriteLine($"\n    Cумма элементов, расположенных перед последним минимальным по модулю элементом: {sum:f2}\n");
        } // SumAfterMax

    }
}
