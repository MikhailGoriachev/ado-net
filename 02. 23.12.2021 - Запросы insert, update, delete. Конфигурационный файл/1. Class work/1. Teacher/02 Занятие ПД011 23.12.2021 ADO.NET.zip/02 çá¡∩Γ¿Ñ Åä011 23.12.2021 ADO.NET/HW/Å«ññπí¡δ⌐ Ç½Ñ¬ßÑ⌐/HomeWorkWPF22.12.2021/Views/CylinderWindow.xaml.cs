﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HomeWorkWPF22._12._2021.Models;

namespace HomeWorkWPF22._12._2021.Views
{
    /// <summary>
    /// Логика взаимодействия для CylinderWindow.xaml
    /// </summary>
    public partial class CylinderWindow : Window
    {
        // поле с фигурой
        private Cylinder _cylinder;

        // конструктор с зависимостями
        public CylinderWindow() : this(new Cylinder()) { }

        // конструктор по умолчанию
        public CylinderWindow(Cylinder cylinder)
        {
            InitializeComponent();

            _cylinder = cylinder;

            Txb_r.Text = $"{_cylinder.R}";
            Txb_h.Text = $"{_cylinder.H}";
            Txb_p.Text = $"{_cylinder.P}";

            // очистка поля вывода результата
            Res_S.Text = "";
            Res_V.Text = "";
            Res_M.Text = "";

            // фокус на первом поле ввода
            Txb_r.Focus();

        }

        // Calculate
        private void Calculate_Command(object sender, RoutedEventArgs e)
        {
            try
            {
                _cylinder.R = double.Parse(Txb_r.Text);
                _cylinder.H = double.Parse(Txb_h.Text);
                _cylinder.P = double.Parse(Txb_p.Text);


                double ResS, ResV, ResM;

                ResS = _cylinder.GetS();
                ResV = _cylinder.GetV();
                ResM = _cylinder.GetMass();


                Res_S.Text = $"{ResS:f3}";
                Res_V.Text = $"{ResV:f3}";
                Res_M.Text = $"{ResM:f3}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Geometric_Command


        // Очистка поля вывода результата при изменении значений в полях ввода
        private void TextChanged_Handler(object sender, TextChangedEventArgs e)
        {
            // очистка поля вывода результата
            Res_S.Text = "";
            Res_V.Text = "";
            Res_M.Text = "";
        } // TextChanged_Handler
    }
}

