﻿using Realestate.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Realestate.Application
{
    /* 
        * Методы для решения задачи 2
        */
    internal partial class App
    {

        // 1. Хранимая процедура	
        //    Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public void Task2ExecQuery01() {
            Utils.ShowNavBarTask("Запрос 1. Все факты проката автомобиля с заданным госномером");

            _task2Controller.Query01();
        } // Task2ExecQuery01

        // 2. Хранимая процедура	
        //    Выбирает информацию обо всех фактах проката автомобиля  с заданной моделью/брендом
        public void Task2ExecQuery02() {
            Utils.ShowNavBarTask("Запрос 2. Все факты проката автомобиля с заданной моделью/брендом");

            _task2Controller.Query02();
        } // Task2ExecQuery02


        // 3. Хранимая процедура
        //    Выбирает информацию об автомобиле с заданным госномером
        public void Task2ExecQuery03() {
            Utils.ShowNavBarTask("Запрос 3. Информация о автомобиле с заданным госномером");

            _task2Controller.Query03();
        } // Task2ExecQuery03


        // 4. Хранимая процедура
        //    Выбирает информацию о клиентах по серии и номеру паспорта
        public void Task2ExecQuery04() {
            Utils.ShowNavBarTask("Запрос 4. Информация о клиентах по серии и номеру паспорта");

            _task2Controller.Query04();
        } // Task2ExecQuery03


        // 5. Хранимая процедура	
        //    Выбирает информацию обо всех зафиксированных фактах проката автомобилей 
        //    в некоторый заданный интервал времени.
        public void Task2ExecQuery05() {
            Utils.ShowNavBarTask("Запрос 5. Информация о фактах проката в заданный интервал времени");

            _task2Controller.Query05(new DateTime(2021, 10, 1), new DateTime(2021, 10, 31));
        } // Task2ExecQuery05


        // 6. Хранимая процедура
        //    Вычисляет для каждого факта проката стоимость проката.
        //    Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
        //    Сортировка по полю Дата проката

        public void Task2ExecQuery06() {
            Utils.ShowNavBarTask("Запрос 6. Вычислить для каждого факта проката стоимость проката");

            _task2Controller.Query06();
        } // Task2ExecQuery06

        // 7. Хранимая процедура
        //    Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
        //    суммарное количество дней проката, упорядочивание по убыванию суммарного количества дней прокат
        public void Task2ExecQuery07() {
            Utils.ShowNavBarTask("Запрос 7. Вычислить для клиентов кол-во фактов проката и суммарное кол-во дней проката");

            _task2Controller.Query07();
        } // Task2ExecQuery07

        // 8. Хранимая процедура
        //    Выбирает информацию о фактах проката автомобилей по госномеру: 
        //    количество фактов проката, сумма за прокаты, суммарная длительность прокатов
        public void Task2ExecQuery08() {
            Utils.ShowNavBarTask("Запрос 8. Информация о фактах проката: кол-во фактов проката, сумма за прокаты, суммарная длительность прокатов");

            _task2Controller.Query08();
        } // Task2ExecQuery08
    } // App
}
