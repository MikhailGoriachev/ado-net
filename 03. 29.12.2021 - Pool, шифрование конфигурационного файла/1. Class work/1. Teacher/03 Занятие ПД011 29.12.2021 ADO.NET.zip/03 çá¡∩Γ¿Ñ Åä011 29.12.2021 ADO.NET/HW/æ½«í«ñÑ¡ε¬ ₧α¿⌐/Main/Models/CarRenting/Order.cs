﻿using System;
using Main.Utilities.TableFormatter;


namespace Main.Models.CarRenting
{
	public sealed class Order
	{
		[TableData("ID машины", "{0, -14}")]
		public int CarId { get; set; }

		[TableData("ID клиента", "{0, -14}")]
		public int ClientId { get; set; }

		[TableData("Длительность", "{0, -14}")]
		public int Duration { get; set; }

		[TableData("Дата начала", "{0, -17:d}")]
		public DateTime StartDate { get; set; }
	}
}