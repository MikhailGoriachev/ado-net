﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
	public class StoreQueriesController
	{
		// связь с базой данных
		private StoreDataContext _storeDb;


		#region Конструкторы

		public StoreQueriesController() : this(new StoreDataContext()) { }

		public StoreQueriesController(StoreDataContext storeDb)
		{
			_storeDb = storeDb;
		}

		#endregion


		#region Запросы

		// Tовары, единицей измерения которых является «шт» и цена закупки составляет меньше 200 руб.
		public IEnumerable Query01() => _storeDb.Purchases
			.Where(x => x.Units.Short.Contains("шт") && x.PurchasePrice < 200)
			.Select(x => new GoodsPurchaseViewModel()
			{
				Id = x.Id,
				Title = x.Goods.Name,
				Price = x.PurchasePrice,
			});

		// Товары, цена закупки которых больше 500 руб. за единицу товара
		public IEnumerable Query02() => _storeDb.Purchases
			.Where(x => x.PurchasePrice > 500)
			.Select(x => new GoodsPurchaseViewModel()
			{
				Id = x.Id,
				Title = x.Goods.Name,
				Price = x.PurchasePrice,
			});

		//Товары с заданным наименованием, для которых цена закупки меньше 1800 руб.
		public IEnumerable Query03() => _storeDb.Purchases
			.Where(x => x.PurchasePrice < 1800 && x.Goods.Name == "Гайка М 3 ЦБ")
			.Select(x => new GoodsPurchaseViewModel()
			{
				Id = x.Id,
				Title = x.Goods.Name,
				Price = x.PurchasePrice,
			});

		//Продавцы с заданным значением процента комиссионных.
		public IEnumerable Query04() =>
			_storeDb.Sellers
			.Where(s => s.Interest.Equals(9))
			.Select(s => new SellerViewModel
			{
				Id = s.Id,
				SurnameNP = s.Surname + " " + s.Name[0] + "." + s.Patronymic[0] + ".",
				Interest = s.Interest
			});


		//Все зафиксированные факты продажи товаров, с ценой продажи в заданных границах. 
		public IEnumerable Query05() =>
			_storeDb.Sales.Where(s => s.Price >= 300 && s.Price <= 600)
			.Select(s => new SaleViewModel
			{
				Title = s.Purchases.Goods.Name,
				PurchasePrice = s.Purchases.PurchasePrice,
				SalePrice = s.Price,
				SellDate = s.SellDate
			});


		// Прибыль от продажи за каждый проданный товар. Сортировка по полю Наименование товара
		public IEnumerable Query06() =>
			_storeDb.Sales.Select(s => new ProfitModelView()
			{
				Title = s.Purchases.Goods.Name,
				SellDate = s.SellDate,
				PurchasePrice = s.Purchases.PurchasePrice,
				SellPrice = s.Price,
				Amount = s.Amount,
				Profit = (s.Price - s.Purchases.PurchasePrice) * s.Amount
			})
				.OrderBy(s => s.Title);

		// Cредняя цена закупки товара для каждого наименования и количество закупок, группировка по наименованию товара:
		public IEnumerable Query07() =>
			_storeDb.Purchases.GroupBy(p => p.Goods.Name, (key, group) => new Query07ViewModel()
			{
				Title = key,
				AvgPurchasePrice = group.Average(p => p.PurchasePrice),
				SalesAmount = group.Count()
			});


		// Среднее значение цены продажи единицы товара для каждого продавца, количество продаж
		public IEnumerable Query08() =>
			_storeDb.Sales.GroupBy(s => s.IdSeller, (key, group) => new Query08ViewModel()
			{
				SurnameNP = group.Where(s => s.IdSeller == key).Select(s => s.Sellers.Surname + " " + s.Sellers.Name[0] + "." + s.Sellers.Patronymic[0] + ".").First(),
				AvgSalePrice = group.Average(s => s.Price),
				SalesAmount = group.Count()
			});

		#endregion
	}
}
