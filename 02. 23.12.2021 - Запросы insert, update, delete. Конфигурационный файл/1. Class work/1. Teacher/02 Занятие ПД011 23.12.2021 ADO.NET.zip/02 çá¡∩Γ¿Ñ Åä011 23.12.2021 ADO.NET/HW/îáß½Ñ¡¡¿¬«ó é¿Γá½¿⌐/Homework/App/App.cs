﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
	// класс определяющий логику работы приложения
	public class App
	{
		// строка подключения к БД 
		private string _connectingString;

		// конструкторы
		public App() : this(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = I:\Ado.net\Ado_HW1\Homework\App_Data\RealEstateDb.mdf; Integrated Security = True")
		{}

		public App(string connectingString)
		{
			_connectingString = connectingString;
		}

		// запуск работы логики приложения
		public void Run()
		{
			try
			{
				Query01(_connectingString);
				Utils.ReadyGo();

				Query02(_connectingString);
				Utils.ReadyGo();

				Query03(_connectingString);
				Utils.ReadyGo();

				Query04(_connectingString);
				Utils.ReadyGo();

				Query05(_connectingString);
				Utils.ReadyGo();

				Query06(_connectingString);
				Utils.ReadyGo();

				Query07(_connectingString);
				Utils.ReadyGo();

				Query08(_connectingString);
				Utils.ReadyGo();

				Query09(_connectingString);
				Utils.ReadyGo();
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}


		// выполнение запроса 1
		private void Query01(string connectingString)
		{
			Console.WriteLine("\n  Запрос 1");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
				@"select
					    Apartments.Id
					    , Streets.Street
					    , Apartments.Building
					    , Apartments.Flat
					    , Apartments.Area
					    , Apartments.RoomNum
					from
					    Apartments join Streets on Apartments.IdStreet = Streets.Id
					where
					    Apartments.RoomNum = @roomNum and Streets.Street = @street"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// задать параметры запроса
				cmd.Parameters.AddWithValue("@roomNum", 3);
				cmd.Parameters.AddWithValue("@street", "ул. Садовая");

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│ {reader.GetName(0)} " +			// Apartments.Id			// int
						$"│     {reader.GetName(1),-11} " +	// , Streets.Street			// string 30
						$"│     {reader.GetName(2),-11} " +	// , Apartments.Building	// string 10
						$"│     {reader.GetName(3),-11} " +	// , Apartments.Flat		// int
						$"│     {reader.GetName(4),-11} " +	// , Apartments.Area		// int
						$"│     {reader.GetName(5),-11} " +   // , Apartments.RoomNum		// int
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetInt32(0),2} " +    // Apartments.Id					// int
							$"│ {reader.GetString(1),-15} " + // , Streets.Street				// string 30
							$"│ {reader.GetString(2),15} " +  // , Apartments.Building			// string 10
							$"│ {reader.GetInt32(3),15} " +   // , Apartments.Flat				// int
							$"│ {reader.GetInt32(3),15} " +   // , Apartments.Area				// int
							$"│ {reader.GetInt32(3),15} " +   // , Apartments.RoomNum			// int
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}

		// выполнение запроса 2
		private void Query02(string connectingString)
		{
			Console.WriteLine("\n  Запрос 2");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
				@"select
					    Realtors.Id
					    , Persons.Surname
					    , Persons.[Name]
					    , Persons.Patronymic
					    , Realtors.[Percent]
					from
					    Realtors join Persons on Realtors.IdPerson = Persons.Id
					where
					    Persons.Surname like (@surname + N'%') and Realtors.[Percent] > @percent"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// задать параметры запроса
				cmd.Parameters.AddWithValue("@surname", "И");
				cmd.Parameters.AddWithValue("@percent", 10);

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│ {reader.GetName(0)} " +         // Realtors.Id
						$"│     {reader.GetName(1),-11} " + // , Persons.Surname
						$"│     {reader.GetName(2),-11} " + // , Persons.[Name]
						$"│     {reader.GetName(3),-11} " + // , Persons.Patronymic
						$"│     {reader.GetName(4),-11} " + // , Realtors.[Percent]
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetInt32(0),2} " +			// Realtors.Id
							$"│ {reader.GetString(1),-15} " + 		// , Persons.Surname
							$"│ {reader.GetString(2),-15} " +  	// , Persons.[Name]
							$"│ {reader.GetString(3),-15} " +   	// , Persons.Patronymic
							$"│ {reader.GetDouble(4),15} " +   	// , Realtors.[Percent]
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}


		// выполнение запроса 3
		private void Query03(string connectingString)
		{
			Console.WriteLine("\n  Запрос 3");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
				@"select
					    Apartments.Id
					    , Streets.Street
					    , Apartments.Building
					    , Apartments.Flat
					    , Apartments.Area
					    , Apartments.RoomNum
					    , Offers.Price
					from
					    Apartments join Streets on Apartments.IdStreet = Streets.Id
					               join Offers on Apartments.Id = Offers.IdApartment
					where
					    Apartments.RoomNum = @roomNum and Offers.Price between @lo and @hi"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// задать параметры запроса
				cmd.Parameters.AddWithValue("@roomNum", 1);
				cmd.Parameters.AddWithValue("@lo", 900000);
				cmd.Parameters.AddWithValue("@hi", 1000000);

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│ {reader.GetName(0)} " +         // Apartments.Id 
						$"│     {reader.GetName(1),-11} " + // , Streets.Street
						$"│     {reader.GetName(2),-11} " + // , Apartments.Building
						$"│     {reader.GetName(3),-11} " + // , Apartments.Flat
						$"│     {reader.GetName(4),-11} " + // , Apartments.Area
						$"│     {reader.GetName(5),-11} " + // , Apartments.RoomNum
						$"│     {reader.GetName(6),-11} " + // , Offers.Price
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetInt32(0),2} " +      // Apartments.Id
							$"│ {reader.GetString(1),-15} " +   // , Streets.Street
							$"│ {reader.GetString(2),15} " +   // , Apartments.Building
							$"│ {reader.GetInt32(3),15} " +   // , Apartments.Flat
							$"│ {reader.GetInt32(4),15} " +    // , Apartments.Area
							$"│ {reader.GetInt32(5),15} " +    // , Apartments.RoomNum
							$"│ {reader.GetInt32(6),15} " +    // , Offers.Price
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}

		// выполнение запроса 4
		private void Query04(string connectingString)
		{
			Console.WriteLine("\n  Запрос 4");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
				@"select
					    Apartments.Id
					    , Streets.Street
					    , Apartments.Building
					    , Apartments.Flat
					    , Apartments.Area
					    , Apartments.RoomNum
					    , Offers.Price
					from
					    Apartments join Streets on Apartments.IdStreet = Streets.Id
					               join Offers on Apartments.Id = Offers.IdApartment
					where
					    Apartments.RoomNum = @roomNum"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// задать параметры запроса
				cmd.Parameters.AddWithValue("@roomNum", 1);

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│ {reader.GetName(0)} " +         // Apartments.Id 
						$"│     {reader.GetName(1),-11} " + // , Streets.Street
						$"│     {reader.GetName(2),-11} " + // , Apartments.Building
						$"│     {reader.GetName(3),-11} " + // , Apartments.Flat
						$"│     {reader.GetName(4),-11} " + // , Apartments.Area
						$"│     {reader.GetName(5),-11} " + // , Apartments.RoomNum
						$"│     {reader.GetName(6),-11} " + // , Offers.Price
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetInt32(0),2} " +      // Apartments.Id
							$"│ {reader.GetString(1),-15} " +   // , Streets.Street
							$"│ {reader.GetString(2),15} " +   // , Apartments.Building
							$"│ {reader.GetInt32(3),15} " +   // , Apartments.Flat
							$"│ {reader.GetInt32(4),15} " +    // , Apartments.Area
							$"│ {reader.GetInt32(5),15} " +    // , Apartments.RoomNum
							$"│ {reader.GetInt32(6),15} " +    // , Offers.Price
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}


		// выполнение запроса 5
		private void Query05(string connectingString)
		{
			Console.WriteLine("\n  Запрос 5");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
				@"select
					    Apartments.Id
					    , Streets.Street
					    , Apartments.Building
					    , Apartments.Flat
					    , Apartments.Area
					    , Apartments.RoomNum
					    , Offers.Price
					from
						Apartments join Streets on Apartments.IdStreet = Streets.Id
							       join Offers on Apartments.Id = Offers.IdApartment
					where
						Apartments.RoomNum = @roomNum and Apartments.Area between @lo and @hi"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// задать параметры запроса
				cmd.Parameters.AddWithValue("@roomNum", 2);
				cmd.Parameters.AddWithValue("@lo", 80);
				cmd.Parameters.AddWithValue("@hi", 120);

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│ {reader.GetName(0)} " +         // Apartments.Id 
						$"│     {reader.GetName(1),-11} " + // , Streets.Street
						$"│     {reader.GetName(2),-11} " + // , Apartments.Building
						$"│     {reader.GetName(3),-11} " + // , Apartments.Flat
						$"│     {reader.GetName(4),-11} " + // , Apartments.Area
						$"│     {reader.GetName(5),-11} " + // , Apartments.RoomNum
						$"│     {reader.GetName(6),-11} " + // , Offers.Price
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetInt32(0),2} " +      // Apartments.Id
							$"│ {reader.GetString(1),-15} " +   // , Streets.Street
							$"│ {reader.GetString(2),15} " +   // , Apartments.Building
							$"│ {reader.GetInt32(3),15} " +   // , Apartments.Flat
							$"│ {reader.GetInt32(4),15} " +    // , Apartments.Area
							$"│ {reader.GetInt32(5),15} " +    // , Apartments.RoomNum
							$"│ {reader.GetInt32(6),15} " +    // , Offers.Price
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}

		// выполнение запроса 6
		private void Query06(string connectingString)
		{
			Console.WriteLine("\n  Запрос 6");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
				@"select
						    Persons.Surname
						    , Persons.[Name]
						    , Persons.Patronymic
						    , Deals.DealDate
						    , Deals.DealPrice
						    , Realtors.[Percent]
						    , Deals.DealPrice * Realtors.[Percent] / 100 as Fee
						from
						    Deals join (Realtors join Persons on Realtors.IdPerson = Persons.Id) 
						        on Deals.IdRealtor = Realtors.Id"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│     {reader.GetName(0),-11} " + // Persons.Surname
						$"│     {reader.GetName(1),-11} " + // , Persons.[Name]
						$"│     {reader.GetName(2),-11} " + // , Persons.Patronymic
						$"│     {reader.GetName(3),-11} " + // , Deals.DealDate
						$"│     {reader.GetName(4),-11} " + // , Deals.DealPrice
						$"│     {reader.GetName(5),-11} " + // , Realtors.[Percent]
						$"│     {reader.GetName(6),-11} " + // , Deals.DealPrice * Realtors.[Percent] / 100 as Fee
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetString(0),-15} " +			// Persons.Surname
							$"│ {reader.GetString(1),-15} " +			// , Persons.[Name]
							$"│ {reader.GetString(2),-15} " +			// , Persons.Patronymic
							$"│ {reader.GetDateTime(3),15:d} " +		// , Deals.DealDate
							$"│ {reader.GetInt32(4),15} " +			// , Deals.DealPrice
							$"│ {reader.GetDouble(5),15:n2} " +			// , Realtors.[Percent]
							$"│ {reader.GetDouble(6),15:n2} " +			// , Deals.DealPrice * Realtors.[Percent] / 100 as Fee
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}

		// выполнение запроса 7
		private void Query07(string connectingString)
		{
			Console.WriteLine("\n  Запрос 7");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
				@"select
					    Realtors.Id
					    , Persons.Surname
					    , Persons.[Name]
					    , Persons.Patronymic
					    , Count(Deals.IdOffer) as ClientTotal -- упрощение Deals.IdOffer это клиент
					    , isnull(Sum(Deals.DealPrice), N'') as RealtorSum
					from
					    (Realtors join Persons on Realtors.IdPerson = Persons.Id)
					        left join 
					    Deals on Realtors.Id = Deals.IdRealtor
					group by
					    Realtors.Id, Persons.Surname, Persons.[Name], Persons.Patronymic"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│ {reader.GetName(0)} " +	  // Realtors.Id
						$"│     {reader.GetName(1),-11} " + // , Persons.Surname
						$"│     {reader.GetName(2),-11} " + // , Persons.[Name]
						$"│     {reader.GetName(3),-11} " + // , Persons.Patronymic
						$"│     {reader.GetName(4),-11} " + // , Count(Deals.IdOffer) as ClientTotal -- упрощение Deals.IdOffer это клиент
						$"│     {reader.GetName(5),-11} " + // , Sum(Deals.DealPrice) as RealtorSum
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetInt32(0),2} " +           // Realtors.Id
							$"│ {reader.GetString(1),-15} " +        // , Persons.Surname
							$"│ {reader.GetString(2),-15} " +        // , Persons.[Name]
							$"│ {reader.GetString(3),-15} " +     // , Persons.Patronymic
							$"│ {reader.GetInt32(4),15} " +          // , Count(Deals.IdOffer) as ClientTotal -- упрощение Deals.IdOffer это клиент
							$"│ {reader.GetInt32(5),15} " +         // , Sum(Deals.DealPrice) as RealtorSum
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}


		// выполнение запроса 8
		private void Query08(string connectingString)
		{
			Console.WriteLine("\n  Запрос 8");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
				@"select
					    Streets.Street
					    , isnull(Sum(Deals.DealPrice),N'') as SumDeals
					from
					    Streets left join (Apartments join (Offers join Deals on Offers.Id = Deals.IdOffer) on Apartments.Id = Offers.IdApartment) 
					        on Streets.Id = Apartments.IdStreet
					group by
					    Streets.Street"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│     {reader.GetName(0),-11}   " +		// Streets.Street
						$"│     {reader.GetName(1),-11} " +		// , Sum(Deals.DealPrice) as SumDeals
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetString(0),-17} " +        // Streets.Street
							$"│ {reader.GetInt32(1),15} " +     // , Sum(Deals.DealPrice) as SumDeals
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}


		// выполнение запроса 9
		private void Query09(string connectingString)
		{
			Console.WriteLine("\n  Запрос 9");

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectingString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов
				Console.WriteLine("\n  Соединение открыто\n");

				// создание команды (запрос SQL), привязка к соединению
				SqlCommand cmd = new SqlCommand(
					@"select
						    Streets.Street
						    , isnull(COUNT(PeriodDeals.DealPrice), N'') as Amount
						    , isnull(SUM(PeriodDeals.DealPrice), N'') as Total
						from
						    Streets left join 
						        -- данные по сделкам за период извлекаем при помощи подзапроса, требуется назначить 
						        -- псевдоним этому подзапросу
						        (select Deals.DealDate, Deals.DealPrice, Apartments.IdStreet from (Deals join (Offers join Apartments on Offers.IdApartment = Apartments.Id) on Deals.IdOffer = Offers.Id)  
						         where Deals.DealDate between @from and @to) PeriodDeals
						    on Streets.Id = PeriodDeals.IdStreet
						group by
						    Streets.Street
						order by
						    Total desc"
				);

				// задать соединение с БД
				cmd.Connection = connection;

				// задать параметры запроса
				cmd.Parameters.AddWithValue("@from", "10-01-2021");
				cmd.Parameters.AddWithValue("@to", "10-31-2021");

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Если данные получены (есть строки в полученном ответе серврера)
				if (reader.HasRows)
				{
					// выводим имена столбцов
					Console.WriteLine(
						$"│     {reader.GetName(0),-11}   " +       // Streets.Street
						$"│     {reader.GetName(1),-11} " +         // , COUNT(PeriodDeals.DealPrice) as Amount
						$"│     {reader.GetName(2),-11} " +         // , SUM(PeriodDeals.DealPrice) as Total
						$"│");


					while (reader.Read())
					{
						Console.WriteLine(
							$"│ {reader.GetString(0),-17} " +			// Streets.Street
							$"│ {reader.GetInt32(1),15} " +			// 	   , COUNT(PeriodDeals.DealPrice) as Amount
							$"│ {reader.GetInt32(2),15} " +			// 	   , SUM(PeriodDeals.DealPrice) as Total
							$"│");
					}
				}
			}
			Console.WriteLine("\n  Соединение закрыто");
			Console.WriteLine();
		}
	}
}
