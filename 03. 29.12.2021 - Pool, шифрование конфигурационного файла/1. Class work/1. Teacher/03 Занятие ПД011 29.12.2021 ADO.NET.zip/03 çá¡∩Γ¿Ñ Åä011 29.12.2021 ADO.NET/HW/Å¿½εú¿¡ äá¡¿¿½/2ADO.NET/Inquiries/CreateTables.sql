﻿
--СКРИПТ СОЗДАНИЯ ТАБЛИЦ

drop table if exists Deals;
drop table if exists [Realtors];
drop table if exists [Buyers];
drop table if exists [Apartments];
drop table if exists Streets;
drop table if exists PPatronymics;
drop table if exists PSurnames;
drop table if exists PNames;

--создание таблицы имен
CREATE TABLE [dbo].PNames
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    PName NVARCHAR(40) NOT NULL
)

go

--создание таблицы фамилий
CREATE TABLE [dbo].PSurnames
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    PSurname NVARCHAR(40) NOT NULL
)

go

--создание таблицы отчеств
CREATE TABLE [dbo].PPatronymics
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    PPatronymic NVARCHAR(40) NOT NULL
)

go

--создание таблицы улиц
CREATE TABLE [dbo].Streets
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    Street NVARCHAR(60) NOT NULL
)

go


--создание таблицы квартир
CREATE TABLE [dbo].[Apartments] (
    [Id]               INT        IDENTITY (1, 1) NOT NULL,
    [idStreet]         INT          NOT NULL,
    [NumHouse]         NCHAR (10)   NOT NULL,
    [NumApartment]     INT          NOT NULL,
    [Square]           FLOAT        NOT NULL,
    [Rooms]            INT          NOT NULL,
    [Cost]             INT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Apartments_Streets] FOREIGN KEY ([idStreet]) REFERENCES [dbo].[Streets] ([Id]),
                   
    CONSTRAINT [CK_Apartments_Square] CHECK ([Square]>(0)),
    CONSTRAINT [CK_Apartments_Rooms] CHECK ([Rooms]>(0)),
    CONSTRAINT [CK_Apartments_Cost] CHECK ([Cost]>(0)),
    CONSTRAINT [CK_Apartments_idStreet] CHECK ([idStreet]>(0))
);

go

--создание таблицы покупателей
CREATE TABLE [dbo].[Buyers] (
    [Id]                INT                 IDENTITY (1, 1) NOT NULL,
    [idSurname]         INT                 NOT NULL,
    [idName]            INT                 NOT NULL,
    [idPatronymic]      INT                 NOT NULL,
    [Passport]          NVARCHAR(11)        NOT NULL,
    [DateOfDeal]        DATE                NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Buyers_idSurname] FOREIGN KEY ([idSurname]) REFERENCES [dbo].[PSurnames] ([Id]),
    CONSTRAINT [FK_Buyers_idName] FOREIGN KEY ([idName]) REFERENCES [dbo].[PNames] ([Id]),
    CONSTRAINT [FK_Buyers_idPatronymic] FOREIGN KEY (idPatronymic) REFERENCES [dbo].[PPatronymics] ([Id]),
                        
    CONSTRAINT [CK_Buyers_idSurname] CHECK ([idSurname]>(0)),
    CONSTRAINT [CK_Buyers_idName] CHECK ([idName]>(0)),
    CONSTRAINT [CK_Buyers_idPatronymic] CHECK ([idPatronymic]>(0))
);

go


--создание таблицы риэлторов
CREATE TABLE [dbo].[Realtors] (
    [Id]               INT        IDENTITY (1, 1) NOT NULL,
    [idSurname]        INT                 NOT NULL,
    [idName]           INT                 NOT NULL,
    [idPatronymic]     INT                 NOT NULL,
    [Percnt]           INT                 NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Realtors_idSurname] FOREIGN KEY ([idSurname]) REFERENCES [dbo].[PSurnames] ([Id]),
    CONSTRAINT [FK_Realtors_idName] FOREIGN KEY ([idName]) REFERENCES [dbo].[PNames] ([Id]),
    CONSTRAINT [FK_Realtors_idPatronymic] FOREIGN KEY (idPatronymic) REFERENCES [dbo].[PPatronymics] ([Id]),
                          
    CONSTRAINT [CK_Realtors_idSurname] CHECK ([idSurname]>(0)),
    CONSTRAINT [CK_Realtors_idName] CHECK ([idName]>(0)),
    CONSTRAINT [CK_Realtors_idPatronymic] CHECK ([idPatronymic]>(0)),
    CONSTRAINT [CK_Realtors_Percent] CHECK ([Percnt]>(0))
);

go

--создание таблицы сделок
CREATE TABLE [dbo].[Deals] (
    [Id]               INT        IDENTITY (1, 1) NOT NULL,
    [idApartment]      INT                 NOT NULL,
    [idBuyer]          INT                 NOT NULL,
    [idRealtor]        INT                 NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Realtor_idApartment]    FOREIGN KEY ([idApartment]) REFERENCES [dbo].[Apartments] ([Id]),
    CONSTRAINT [FK_Realtor_idBuyer]        FOREIGN KEY ([idBuyer]) REFERENCES [dbo].[Buyers] ([Id]),
    CONSTRAINT [FK_Realtor_idRealtor]      FOREIGN KEY ([idRealtor]) REFERENCES [dbo].[Realtors] ([Id]),
                   
    CONSTRAINT [CK_Deals_idApartment]  CHECK ([idApartment]>(0)),
    CONSTRAINT [CK_Deals_idBuyer]      CHECK ([idBuyer]>(0)),
    CONSTRAINT [CK_Deals_idRealtor]    CHECK ([idRealtor]>(0))
);

go