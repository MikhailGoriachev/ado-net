﻿using System;

namespace Realestate.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        string _connectingString;  // строка подключения к БД


        // конструктор с внедрением зависимостей
        public App(string connectingString) {
            _connectingString = connectingString;
        } // App

    } // class App
}