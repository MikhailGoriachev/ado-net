﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqIntro.Models
{
    // для хранения результата запроса 4 их задачи 3
    // нименование и год выпуска товара
    public class ResultQuery04
    {
        public string GoodsName { get; set; }
        public int Year { get; set; }
    } // class ResultQuery04
}
