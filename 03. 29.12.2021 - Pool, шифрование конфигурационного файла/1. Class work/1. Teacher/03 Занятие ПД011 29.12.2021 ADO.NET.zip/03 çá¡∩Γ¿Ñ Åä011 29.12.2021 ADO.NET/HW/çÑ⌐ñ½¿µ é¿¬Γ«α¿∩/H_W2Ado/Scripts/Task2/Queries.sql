﻿-- База данных «Прокат автомобилей»


-- создание представления для таблицы АВТОМОБИЛИ
create view ViewCars as
   select
      Models.Model
      , Colors.Color
      , Cars.CarNumber
      , Cars.[Year]
      , Cars.InsurancePay
      , Cars.PayRentalDay
from
   Cars join Models on Cars.IdModel = Models.Id
        join Colors on Cars.IdColor = Colors.Id;
go


-- использование представления для таблицы АВТОМОБИЛИ
select 
   *
from
   ViewCars;
go

-- alter
-- создание представления для таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА
create view ViewAllRentals as
   select
      Clients.Surname
      , Clients.[Name]
      , Clients.Patronymic
      , Models.Model
      , Cars.CarNumber
      , Rentals.RentalStartDate
      , Cars.PayRentalDay
      , Rentals.Duration
   from
      Rentals join(Cars join Models on Cars.IdModel = Models.Id)
              on Rentals.IdCar = Cars.Id
              join Clients on Rentals.IdClient = Clients.Id;
go


-- использование представления для таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ФАКТЫ_ПРОКАТА
select 
   *
from
   ViewAllRentals;
go


-- 1. Запрос к представлению
-- Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
declare @numCar nvarchar(10) = N'X739OC';

select
   *
from
   ViewAllRentals
where
   CarNumber = @numCar;
go


-- 2. Запрос к представлению
-- Выбирает информацию обо всех фактах проката автомобиля
-- с заданной моделью/брендом
declare @modelCar nvarchar(15) ='Lexus';

select
   *
from
   ViewAllRentals
where
   Model = @modelCar;
go


-- 3. Запрос к представлению
-- Выбирает информацию об автомобиле с заданным госномером
declare @numCar nvarchar(10) = N'H730CA';

select
   *
from
   ViewCars
where
   CarNumber = @numCar;
go


-- 4. Запрос с параметром
-- Выбирает информацию о клиентах по серии и номеру паспорта
declare @passportNum nvarchar(10) = N'OH830853';

select
   *
from
   Clients
where
   PassportNum = @passportNum;
go


-- 5. Запрос к представлению
-- Выбирает информацию обо всех зафиксированных фактах
-- проката автомобилей в некоторый заданный интервал времени.
declare @loDate date = '05-01-2021', @hiDate date = '10-01-2021';

select
   *
from
   ViewAllRentals
where
   RentalStartDate between @loDate and @hiDate;
go


-- 6. Запрос к представлению
-- Вычисляет для каждого факта проката стоимость проката.
-- Включает поля Дата проката, Госномер автомобиля,
-- Модель автомобиля, Стоимость проката.
-- Сортировка по полю Дата проката
select
   RentalStartDate
   , CarNumber
   , Model
   -- Стоимость проката автомобиля определяется как 
   -- Стоимость одного дня проката * Количество дней проката. 
   , (PayRentalDay * Duration) as CostRental 
from
   ViewAllRentals
order by
   RentalStartDate;
go


-- 7. Запрос с левым соединением
-- Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
-- суммарное количество дней проката,
-- упорядочивание по убыванию суммарного количества дней проката
select
   Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
          Substring(Clients.Patronymic, 1, 1) + N'.' as Client
   , Count(Rentals.Id) as AmountRental
   , IsNull(Sum(Rentals.Duration), 0) as SumRentalDays
from
    Clients left join Rentals on Clients.Id = Rentals.IdClient
group by
    Clients.Surname, Clients.[Name], Clients.Patronymic
order by
    SumRentalDays
go


-- 8. Итоговый запрос
-- Выполняет группировку по полю Модель автомобиля. 
-- Для каждой модели вычисляет количество фактов проката, сумму за прокат
select
   Models.Model
   , Count(Rentals.Id) as AmountRental
   , Sum(Cars.PayRentalDay * Rentals.Duration) as SumRental
from 
   Rentals join(Cars join Models on Cars.IdModel = Models.Id)
           on Rentals.IdCar = Cars.Id
group by
   Models.Model;
go


-- 9. Запрос на добавление
-- Добавляет данные о новом клиенте.
-- Данные передавайте параметрами
declare @surname nvarchar(50)     = N'Петров', 
        @name nvarchar(40)        = N'Петр',
        @patronymic nvarchar(60)  = N'Петрович', 
        @passportNum nvarchar(50) = N'CH869265';

insert into Clients
   (Surname, [Name], Patronymic, PassportNum)
values
   (@surname, @name, @patronymic, @passportNum);
go


-- 10. Запрос на обновление
-- Изменяет данные клиента (все поля, кроме идентификатора).
-- Данные передавайте параметрами
declare
	@surname    nvarchar(60) = N'Иванов',
	@name       nvarchar(50) = N'Иван',
	@patronymic nvarchar(60) = N'Иванович',
    @passport   nvarchar(15) = N'EI750542';
update
   Clients
set
   Surname = @surname
   , [Name] = @name
   , Patronymic = @patronymic
   , PassportNum = @passport
where
   Clients.Id = 5;
go


-- 11. Запрос на обновление
-- Изменяет данные автомобиля (все поля, кроме идентификатора).
-- Данные передавайте параметрами
declare @idmodel   int = 1,
        @idcolor   int = 3,
        @carNum    nvarchar(10) = N'CI850O',
        @year      int          = 2018,
        @insurance int          = 8000,
        @payday    int          = 500;
update
   Cars 
set
   IdModel      = @idmodel,
   IdColor      = @idcolor,
   CarNumber    = @carNum,
   [Year]       = @year,
   InsurancePay = @insurance,
   PayRentalDay = @payday
where
  Cars.Id = 4;
go


-- 12. Изучение T-SQL
-- Задача If13.
-- Даны три числа. Найти среднее из них (то есть число,
-- расположенное между наименьшим и наибольшим).
-- Числа формируйте генератором случайных чисел
declare @a int = -100 + 200*rand();
declare @b int = -100 + 200*rand();
declare @c int = -100 + 200*rand();

select @a as 'a', @b as 'b', @c as 'c';
print N'Случайные числа:' + char(10) +                           
      char(9) + 'a = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b = ' + ltrim(str(@b)) + char(10) +
      char(9) + 'c = ' + ltrim(str(@c)) + char(10);
 
begin
print N'результат:' + char(10);
  if 
    (@a < @b and @b < @c) or (@a < @b and @b < @c)
    print char(9) + 'b = ' + ltrim(str(@b))+ char(10);
  if  
    (@b < @a and @a < @c) or (@c < @a and @a < @b)
  print char(9) + 'a = ' + ltrim(str(@a))+ char(10);
    if  
    (@a < @c and @c < @b) or (@b < @c and @c < @a)
  print char(9) + 'c = ' + ltrim(str(@c))+ char(10);
end;


-- 13. Изучение T-SQL
-- Задача If14.
-- Даны три числа. Вывести вначале наименьшее,
-- а затем наибольшее их данных чисел.
-- Числа формируйте генератором случайных чисел
declare @a int = -100 + 200*rand();
declare @b int = -100 + 200*rand();
declare @c int = -100 + 200*rand();
declare @min int, @max int;

select @a as 'a', @b as 'b', @c as 'c';
print N'Случайные числа:' + char(10) +                           
      char(9) + 'a = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b = ' + ltrim(str(@b)) + char(10) +
      char(9) + 'c = ' + ltrim(str(@c)) + char(10);
begin
if (@a >= @b and @a >= @c) set @max = @a;
  else if (@b >= @a and @b >= @c) set @max = @b;
  else  set @max = @c;
  
  if (@a <= @b and @a <= @c) set @min = @a;
  else if (@b <= @a and @b <= @c) set @min = @b;
  else set @min = @c;
print N'Наименьшее число: ' + char(10) +
char(9) + 'min = ' + ltrim(str(@min)) + char(10) +
N'Наибольшее число: ' + char(10) +
char(9) + 'max = ' + ltrim(str(@max));
end;


-- 14. Изучение T-SQL
-- Задача If15.
-- Даны три числа. Найти сумму двух наибольших из них.
-- Числа формируйте генератором случайных чисел
declare @a int = -100 + 200*rand();
declare @b int = -100 + 200*rand();
declare @c int = -100 + 200*rand();
declare @sum int;

select @a as 'a', @b as 'b', @c as 'c';
print N'Случайные числа:' + char(10) +                           
      char(9) + 'a = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b = ' + ltrim(str(@b)) + char(10) +
      char(9) + 'c = ' + ltrim(str(@c)) + char(10);

begin
 if (@a <= @b and @a<= @c)  set @sum = (@b + @c)
  else if (@b <= @a and @b <= @c) set @sum = (@a + @c)
  else if (@c <= @a and @c <= @b) set @sum = (@a + @b);
print N'Сумма двух наибольших:' + char(10) +                           
      char(9) + ltrim(str(@sum)) + char(10);
end;


-- 14. Изучение T-SQL
-- Задача If17.
-- Даны три числа. Если их значения упорядочены по возрастанию или убыванию,
-- то удвоить их; в противном случае
-- заменить значение каждой переменной на противоположное.
-- Числа формируйте генератором случайных чисел или присваиванием
declare @a int = -100 + 200*rand();
declare @b int = -100 + 200*rand();
declare @c int = -100 + 200*rand();
declare @x int;

select @a as 'a', @b as 'b', @c as 'c';
print N'Случайные числа:' + char(10) +                           
      char(9) + 'a = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b = ' + ltrim(str(@b)) + char(10) +
      char(9) + 'c = ' + ltrim(str(@c)) + char(10);

begin
if((@a <= @b and @b <= @c) or (@a >= @b and @b >= @c))
        set @x *= 2;
     else 
        set @x = -1;

set @a *= @x;
set @b *= @x;
set @c *= @x;
print N'Числа после изменения:' + char(10) +                           
      char(9) + 'a = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b = ' + ltrim(str(@b)) + char(10) +
      char(9) + 'c = ' + ltrim(str(@c)) + char(10);
end;


