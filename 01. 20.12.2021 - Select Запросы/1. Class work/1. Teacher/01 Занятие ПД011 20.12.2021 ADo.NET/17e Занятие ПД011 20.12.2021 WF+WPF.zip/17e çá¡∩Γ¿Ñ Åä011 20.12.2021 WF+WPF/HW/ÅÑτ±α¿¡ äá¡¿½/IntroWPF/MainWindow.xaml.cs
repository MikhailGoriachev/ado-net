﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IntroWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AvgA_Click(object sender, RoutedEventArgs e)
        {
            double a = double.Parse(NumberA.Text);
            double b = double.Parse(NumberB.Text);
            double c = double.Parse(NumberC.Text);
            double result = (a + b + c) / 3;
            Result.Text = result.ToString("n2");
        }

        private void AvgG_Click(object sender, RoutedEventArgs e)
        {
            double a = double.Parse(NumberA.Text);
            double b = double.Parse(NumberB.Text);
            double c = double.Parse(NumberC.Text);
            double result = Math.Cbrt(a * b * c);
            Result.Text = result.ToString("n2");
        }

        private void Routes_Click(object sender, RoutedEventArgs e)
        {
            double a = double.Parse(NumberA.Text);
            double b = double.Parse(NumberB.Text);
            double c = double.Parse(NumberC.Text);
            double d = b * b - 4 * a * c;
            if(d>0)
            {
                double x1 = (-b + Math.Sqrt(b * b - 4 * a * c))/2*a;
                double x2 = (-b - Math.Sqrt(b * b - 4 * a * c))/2*a;
                Result.Text = $" {x1:n2} ; {x2:n2}";
            }
            else if (d==0)
            {
                double x3 = -b / 2 * a;
                Result.Text = $" {x3:n2} ";
            }
            else
            {
                Result.Text = $"корней нет";
            }
        }
    }
}
