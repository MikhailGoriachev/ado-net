﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	// класса описывающий Автора
	public class Author
	{
		// идентификатор
		public int Id { get; set; }

		// фамилия и инициалы
		public string Fullname { get; set; }

		// год рождения
		public int BirthYear { get; set; }

		public override string ToString() =>
			$"  Id:{Id}. {Fullname}, {BirthYear}г.р.";
	}
}
