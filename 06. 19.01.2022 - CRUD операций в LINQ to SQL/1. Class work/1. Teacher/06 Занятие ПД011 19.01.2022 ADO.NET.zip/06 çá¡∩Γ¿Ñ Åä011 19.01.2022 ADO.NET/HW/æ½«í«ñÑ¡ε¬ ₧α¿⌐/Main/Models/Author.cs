using System;


namespace Main.Models
{
	public sealed class Author
	{
		public string? Fullname { get; set; }
		public int BornYear { get; set; }
	}
}