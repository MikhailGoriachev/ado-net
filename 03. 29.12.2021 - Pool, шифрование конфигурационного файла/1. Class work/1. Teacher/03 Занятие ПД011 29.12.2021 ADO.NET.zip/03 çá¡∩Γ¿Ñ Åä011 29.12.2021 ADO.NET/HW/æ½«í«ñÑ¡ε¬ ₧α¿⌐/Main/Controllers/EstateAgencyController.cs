﻿using System;
using System.Data;
using Main.DataAccess;
using Main.Infrastructure;
using Main.Models;
using Main.Models.EstateAgency;
using Main.Utilities;
using Main.Utilities.TableFormatter;


namespace Main.Controllers
{
	public sealed class EstateAgencyController
	{
		private readonly ClearAdoDataAccess _dataAccess;


		public EstateAgencyController(string connectionString) =>
			_dataAccess = new(connectionString);


		public void Query1(string street, int rooms)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectApartmentsByStreetAndRooms";
				command.Parameters.AddWithValue("@rooms", rooms);
				command.Parameters.AddWithValue("@street", street);
			});

			ShowResultWithMappingTo<ApartmentModel>(result);
		}


		public void Query2(string surnamePattern, double dealPercent)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectAgentsBySurnameAndDealPercent";
				command.Parameters.AddWithValue("@surname", surnamePattern);
				command.Parameters.AddWithValue("@percent", dealPercent);
			});

			ShowResultWithMappingTo<AgentModel>(result);
		}


		public void Query3(int min, int max)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectApartmentsByPriceRange";
				command.Parameters.AddWithValue("@min", min);
				command.Parameters.AddWithValue("@max", max);
			});

			ShowResultWithMappingTo<ApartmentModel>(result);
		}


		public void Query4(int rooms)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectApartmentsByRooms";
				command.Parameters.AddWithValue("@rooms", rooms);
			});

			ShowResultWithMappingTo<ApartmentModel>(result);
		}


		public void Query5(int rooms, (double min, double max) area)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectApartmentsByRoomsAndAreaRange";
				command.Parameters.AddWithValue("@rooms", rooms);
				command.Parameters.AddWithValue("@areaMin", area.min);
				command.Parameters.AddWithValue("@areaMax", area.max);
			});

			ShowResultWithMappingTo<ApartmentModel>(result);
		}


		public void Query6()
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectDealsWithAgentAward";
			});

			ShowResultWithMappingTo<Query6Model>(result);
		}


		public void Query7()
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectAgentsWithDealsCountAndTotalSum";
			});

			ShowResultWithMappingTo<Query7Model>(result);
		}


		public void Query8()
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectStreetsWithDealsTotalSum";
			});

			ShowResultWithMappingTo<Query8Model>(result);
		}


		public void Query9(Range<DateTime> dates)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "SelectStreetsWithDealsTotalSumByDateRange";
				command.Parameters.AddWithValue("firstDate", dates.Min);
				command.Parameters.AddWithValue("secondDate", dates.Max);
			});

			ShowResultWithMappingTo<Query8Model>(result);
		}


		private void ShowResultWithMappingTo<TMap>(DataTable table) where TMap : IMappable<TMap>, new()
		{
			var items = _dataAccess.MapTo<TMap>(table);

			new TableFormatter<TMap>().Show(items);
		}
	}
}