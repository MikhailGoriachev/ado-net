﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6AdoLINQtoSQL.Models
{
    // Класс для Представления продаж
    public class SaleViewModel
    {
        public DateTime DateSale { get; set; }
        public string Name { get; set; }
        public int PricePurchase { get; set; }
        public int PriceSale { get; set; }       
        public int AmountSale { get; set; }
        public int Profit { get; set; }

    }// class SaleViewModel
}
