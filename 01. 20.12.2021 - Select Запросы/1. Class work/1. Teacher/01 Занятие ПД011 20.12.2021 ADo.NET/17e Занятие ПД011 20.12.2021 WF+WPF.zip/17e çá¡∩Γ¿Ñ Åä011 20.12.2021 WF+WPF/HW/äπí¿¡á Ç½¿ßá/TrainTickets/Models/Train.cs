﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrainTickets.Helpers;
using TrainTickets.ViewModels;

namespace TrainTickets.Models
{
    [DataContract]
    public class Train {
        // кол-во купе в вагоне
        const int CountTrainCars = 20;

        private string _number;
        [DataMember]
        public string Number {
            get => _number;
            set {
                if (String.IsNullOrWhiteSpace(value))
                    throw new Exception("Train: Некорректный номер пезда!");
                _number = value;
            } // set 
        } // Number

        // пункт отправления
        private string _departure;
        [DataMember]
        public string Departure {
            get => _departure;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Train: пункт отправления не указан");
                _departure = value;
            } // set
        } // Departure

        // пункт назначения
        private string _destination;
        [DataMember]
        public string Destination {
            get => _destination;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Train: пункт назначения не указан");
                _destination = value;
            } // set
        } // Destination

        private List<TrainCar> _trainCars;
        [DataMember]
        public List<TrainCar> TrainCars {
            get => _trainCars;
            set => _trainCars = value;
        } // TrainCars


        // получить вагон по номеру
        public TrainCar CarriageAt(int index) => _trainCars[index];

        // получить все вагоны
        public List<TrainCar> GetAllCarriages() => _trainCars;

        // конструкторы
        public Train() : this("126 4A", "Ясиноватая", "Луганск", new List<TrainCar>()) {
        } // Flat

        public Train(string number, string departure, string destination, List<TrainCar> trainCars) {
            _number = number;
            _departure = departure;
            _destination = destination;
            _trainCars = trainCars;
            Initialize(4);
        } // Train

        public void Initialize(int n) {
            _trainCars.Clear();
            int lastPlaceNum = 1;
            Utils.TrainCarType type;
            for (int i = 0; i < n; i++) {
                // генерация случайного типа вагона
                type = Utils.RandomEnum<Utils.TrainCarType>();
                // добавление вагона
                _trainCars.Add(new TrainCar(type, i + 1, lastPlaceNum));
                // запомнить номер последнего места в вагоне 
                lastPlaceNum = _trainCars[i].LastNum;
            } // for i
        } // Initialize

        // отбор данных из коллекции вагонов по номеру вагона в формате для отображения
        // в DataGridView
        public List<CarriageView> MapToCarriageView(int carriageNumber) {
            // итоговая коллекция
            List<CarriageView> carriageViews = new List<CarriageView>();

            // получили ссылку на вагон с номером carriageNumber
            TrainCar carriage = _trainCars.Find(x => x.Number == carriageNumber);

            // перебираем все купе вагона
            for (int i = 0; i < TrainCar.CountCompartment; i++) {
                for (int j = 0; j < (int)carriage.Type; j++) {
                    CarriageView carriageView = new CarriageView {
                        CarriageType = (int)carriage.Type == 2 ? "СП" : (int)carriage.Type == 4 ? "Купейный" : "Плацкартный",
                        Number = carriageNumber,
                        CompartmentNumber = i + 1,
                        SeatNumber = carriage[i].Seats[j].Number,
                        Sold = carriage[i].Seats[j].State ? "свободно" : "продано"
                    };
                    carriageViews.Add(carriageView);
                } // for j
            } // for i

            return carriageViews;
        } // MapToCarriageView

        // кол-во проданных билетов
        public int CountSales() {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].CountSales();
            return count;
        } // CountSales

        // кол-во билетов
        public int Count() {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].Count();
            return count;
        } // Count

        // кол-во проданных билетов
        public int CountSales(Utils.TrainCarType type) {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].CountSales(type);
            return count;
        } // CountSales

        // кол-во билетов
        public int Count(Utils.TrainCarType type) {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].Count(type);
            return count;
        } // Count

        // кол-во вагонов
        public int CountTrainCarsByType(Utils.TrainCarType type) {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].Type == type? 1: 0;
            return count;
        } // Count

        // Упорядочивание копии коллекции вагонов
        public void OrderBy(Comparison<TrainCar> comparison) =>
            _trainCars.Sort(comparison);
    } // Train
}
