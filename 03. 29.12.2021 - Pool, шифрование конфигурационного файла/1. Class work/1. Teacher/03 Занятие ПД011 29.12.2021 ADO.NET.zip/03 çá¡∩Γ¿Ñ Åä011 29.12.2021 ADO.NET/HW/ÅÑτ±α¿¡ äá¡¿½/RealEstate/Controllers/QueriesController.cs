﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace RealEstate.Controllers
{
    public class QueriesController
    {

        //строка подключения к базе данных
        private string _connectingstring; 

        public string Connectingstring
        {
            get => _connectingstring;
            set  {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Не указана строка подключения к базе данных");
                _connectingstring = value;

            }//set
        }// Connectingstring


        public QueriesController() : this(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=
                                     ""D:\Students\ПД011\06 ADO.NET\03 Занятие ПД011 29.12.2021 ADO.NET\HW\Печёрин Данил\RealEstate\App_Data\RealEstateDb.mdf"";Integrated Security=True") { }

        //public QueriesController() : this(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=
        //                             C:\Users\данил\source\repos\ADO\CrudAdo\RealEstate\App_Data\RealEstateDb.mdf;Integrated Security=True") { }

        public QueriesController(string connectionString)
        {
            Connectingstring = connectionString;
        }

        // Запрос  1. Запрос с параметрами	
        // Выбирает информацию о 3-комнатных квартирах, расположенных на улице 
        // «Садовая». Значения задавать параметрами запроса

        public void Query01(int roomNumber, string street)
        {
            Console.WriteLine("\n\n\n\nЗапрос 01.\n" +
                             $"\tКвартиры с количеством комнат {roomNumber} на {street}\n");

            //подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingstring))
            {
                // подключение к серверу, блокирующий вызов
                connection.Open();

                //создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"InformationAboutStreet");

                //задать соединение с БД
                cmd.Connection = connection;

                //задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNumber);
                cmd.Parameters.AddWithValue("@street", street);

                //выполнение запроса и вывод выборки данных из таблиц БД
                QueryToAppartment(cmd);

            }// using 

        }//Query01

        //Запрос 2. Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И»
        //и процент вознаграждения больше 10%. Значения задавать параметрами запроса
        public void Query02(string surname, double percent)
        {
            Console.WriteLine("\n\n\n Запрос 2.\n" +
                $"\tРиэлторы с фамилией на 'И' и процентной ставков больше 10%");

            // подключение к базе данных
            using (SqlConnection connection = new SqlConnection(_connectingstring))
            {
                // подключение к серверу, блокирующий вызов
                connection.Open();

                //создание команды Sql
                SqlCommand cmd = new SqlCommand(@"InformationAboutRealtors");

                //задать соединение с базой данных
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@surname", surname);
                cmd.Parameters.AddWithValue("@percent", percent);

                //выполняем запрос и вывод данных из таблиц БД
                QueryToRealtors(cmd);

            }//using 

            

        }
        // Запрос  3. Запрос с параметрами
        // Выбирает информацию о квартирах, с заданным количеством комнат
        // и ценой в заданном диапазоне
        public void Query03(int roomNumber, int loPrice, int hiPrice)
        {
            Console.WriteLine("\n\n\n Зарпрос 3. \n" +
                  $"\tКвартиры с заданным количеством комнат в ценовом диапазоне");

            // подключение к базе данных 
            using (SqlConnection connection = new SqlConnection(_connectingstring))
            {
                //подключение к серверу
                connection.Open();

                //создание запроса Sql 
                SqlCommand cmd = new SqlCommand(@"InformationAboutFlats");
                //задать соединение
                cmd.Connection = connection;

                //создание параметров запроса 
                cmd.Parameters.AddWithValue("@roomNum", roomNumber);
                cmd.Parameters.AddWithValue("@lo", loPrice);
                cmd.Parameters.AddWithValue("@hi", hiPrice);

                //вывод данных из таблиц БД
                QueryToAppartment(cmd);

            }//using
        }

        //Запрос 4. Выбирает информацию о квартирах с заданным числом комнат.
        //Значения задавать параметрами запроса

        public void Query04(int roomNum)
        {
            Console.WriteLine("\n\n\n Запрос 4\n" + 
                $"Квартиры с заданным числом комнат");

            // подключение к базе данных
            using (SqlConnection connection = new SqlConnection(_connectingstring))
            {

                //подключение к серверу
                connection.Open();

                //создание запроса Sql 
                SqlCommand cmd = new SqlCommand(@"InformationAboutRooms");

                //задать соединение
                cmd.Connection = connection;

                //создание параметров запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);

                //вывод данных из БД
                QueryToRooms(cmd);

            }// using
        }

        //Запрос 5. Выбирает информацию обо всех 2-комнатных квартирах,
        //площадь которых есть значение из некоторого диапазона. Значения задавать параметрами запроса
        public void Query05(int roomNum, int low, int high)
        {
            Console.WriteLine("\n\n\n Запрос 5\n" +
                $"Двухкомнатные квартиры из заданного диапазона");

            // подключение к базе данных
            using (SqlConnection connection = new SqlConnection(_connectingstring))
            {
                //подключение к серверу
                connection.Open();

                //создание sql запроса
                SqlCommand cmd = new SqlCommand(@"InformationAboutTwoRoomsFlats");

                //задать соединение
                cmd.Connection = connection;

                //задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", 2);
                cmd.Parameters.AddWithValue("@lo", 80);
                cmd.Parameters.AddWithValue("@hi", 120);

                //вывод данных из БД
                QueryToRooms(cmd);


            }//using 
        }

        //Запрос 6. Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.
        //Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки,
        //Цена квартиры, Комиссионные. Сортировка по полю Дата сделки
        public void Query06()
        {
            Console.WriteLine("\n\n\n Запрос 5\n" +
                $"Бонус реэлтора за продажи");

            using (SqlConnection connection = new SqlConnection(_connectingstring))
            {
                // подключение к серверу
                connection.Open();

                // создание sql запроса
                SqlCommand cmd = new SqlCommand(@"InformationAboutPercent");

                //задание на соединение
                cmd.Connection = connection;

                //вывод данных 
                QueryToDeals(cmd);
            }
        } 

        // вывод запроса, использующего данные квартиры
        private void QueryToAppartment(SqlCommand cmd)
        {
            //выполнение запроса, ссылка на выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // выводим имена столбцов 
            Console.WriteLine("\t" +
                             $"| {reader.GetName(0),11} | {reader.GetName(1),-15}" +
                             $"| {reader.GetName(2),-15}| {reader.GetName(3),4}" + 
                             $"| {reader.GetName(4),4}  | {reader.GetName(5), 7}" +
                             $"| {reader.GetName(6),5} |");
            //Если данные получены (есть ответ от сервера)
            if(reader.HasRows)
            {
                while(reader.Read())
                {
                    Console.WriteLine("\t" +
                            $"| {reader.GetInt32(0),12}" +
                            $"| {reader.GetString(1),-15}" +
                            $"| {reader.GetString(2),-15}" +
                            $"| {reader.GetInt32(3),4}" +
                            $"| {reader.GetInt32(4),6}" +
                            $"| {reader.GetInt32(5),7}" +
                            $"| {reader.GetInt32(6),3}" );
                }// while

            } else
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\tНет данных");
                Console.ForegroundColor = ConsoleColor.Gray;
            }//if
        }// QueryToApartment

        private void QueryToRealtors(SqlCommand cmd) 
        {
            //выполнение запроса, ссылка на выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // выводим имена столбцов 
            Console.WriteLine("\t" +
                             $"| {reader.GetName(0),11} | {reader.GetName(1),-15}" +
                             $"| {reader.GetName(2),-15}| {reader.GetName(3),4}" +
                             $"| {reader.GetName(4),4}");
            //Если получены данные от сервера
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Console.WriteLine("\t" +
                            $"| {reader.GetInt32(0),12}" +
                            $"| {reader.GetString(1),-15}" +
                            $"| {reader.GetString(2),-15}" +
                            $"| {reader.GetString(3),17}" +
                            $"| {reader.GetDouble(4),6} ");
                }// while

            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\tНет данных");
                Console.ForegroundColor = ConsoleColor.Gray;
            }//if

        }

        public void QueryToRooms(SqlCommand cmd)
        {
            //выполнение запроса, ссылка на выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // выводим имена столбцов 
            Console.WriteLine("\t" +
                             $"| {reader.GetName(0),11} | {reader.GetName(1),-15}" +
                             $"| {reader.GetName(2),-15}| {reader.GetName(3),4}" +
                             $"| {reader.GetName(4),4}  | {reader.GetName(5), 5}"+
                             $"| {reader.GetName(6), 5}" );
            //Если получены данные от сервера
            if(reader.HasRows)
            {
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                                $"| {reader.GetInt32(0),12}" +
                                $"| {reader.GetString(1),-15}" +
                                $"| {reader.GetString(2),-15}" +
                                $"| {reader.GetInt32(3),4}" +
                                $"| {reader.GetInt32(4),5} " +
                                $"| {reader.GetInt32(5),7}" +
                                $"| {reader.GetInt32(6),5}");
                    }// while

                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\tНет данных");
                    Console.ForegroundColor = ConsoleColor.Gray;
                }//if

            }//if

            
        }

        public void QueryToDeals(SqlCommand cmd)
        {
            //выполнение запроса, ссылка на выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // выводим имена столбцов 
            Console.WriteLine("\t" +
                             $"| {reader.GetName(0),11} | {reader.GetName(1),-15}" +
                             $"| {reader.GetName(2),-15}| {reader.GetName(3),4}" +
                             $"| {reader.GetName(4),4}  | {reader.GetName(5),5}" +
                             $"| {reader.GetName(6),5}");
            //Если получены данные от сервера

            if(reader.HasRows)
            {
                while (reader.Read())
                {
                    Console.WriteLine("\t" +
                            $"| {reader.GetString(0),12}" +
                            $"| {reader.GetString(1),-15}" +
                            $"| {reader.GetString(2),-15}" +
                            $"| {reader.GetDateTime(3),4}" +
                            $"| {reader.GetInt32(4),5} " +
                            $"| {reader.GetDouble(5),7}" +
                            $"| {reader.GetDouble(6),5}");
                }// while
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\tНет данных");
                Console.ForegroundColor = ConsoleColor.Gray;
            }//if
        }
    }
}
