﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AdoNetIntro.Application;
using AdoNetIntro.Helpers;

namespace AdoNetIntro
{
    class Program
    {
       static void Main(string[] args) {
            Console.Title = "Задание на 23.12.2021 - выполнение запросов в подключенном режиме";

            // строка подключения к БД - взята из свойств базы данных
            // Обозреватель серверов -> Свойства -> Строка подключения
            string connectingString = @"
                Data Source=(LocalDB)\MSSQLLocalDB;
                AttachDbFilename=""D:\Students\ПД011\06 ADO.NET\02 Занятие ПД011 23.12.2021 ADO.NET\HW\_HwE_IntroAdoNet\AdoNetIntro\App_Data\RealEstateDb.mdf"";
                Integrated Security=True";


            // простейшее меню приложения
            List<MenuItem> menu = new List<MenuItem>(new[]{
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Запрос 1. Квартиры с заданным количеством комнат на заданной улице" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Запрос 2. Риелторы с заданной фамилией и процентом вознаграждения" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Запрос 3. Однокомнатные квартиры со стоимостью в заданном диапазоне" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Запрос 4. Квартиры с заданным количеством комнат" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Запрос 5. 2-хкомнатные квартиры с площадью из заданного диапазона" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Запрос 6. Комиссия по всем оформленным сделкам риэлторов" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Запрос 7. Все риэлторы, их клиенты и сделки, по убыванию суммы сделки" },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Запрос 8. По всем улицам вывести сумму сделок, по убыванию суммы" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Запрос 9. По всем улицам вывести сумму сделок за заданный период, по убыванию суммы" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            });
            // Создание экземпляра класса приложения
            App app = new App(connectingString);

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 23.12.2021 - выполнение запросв в подключенном режиме");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {

                        // Запрос 1. Квартиры с заданным количеством комнат на заданной улице
                        case ConsoleKey.Q:
                            app.ExecQuery01();
                            break;

                        // Запрос 2. Риелторы с заданной фамилией и процентом вознаграждения
                        case ConsoleKey.W:
                            app.ExecQuery02();
                            break;

                        // Запрос 3. Однокомнатные квартиры со стоимостью в заданном диапазоне
                        case ConsoleKey.E:
                            app.ExecQuery03();
                            break;

                        // Запрос 4. Квартиры с заданным количеством комнат
                        case ConsoleKey.R:
                            app.ExecQuery04();
                            break;

                        // Запрос 5. 2-хкомнатные квартиры с площадью из заданного диапазона
                        case ConsoleKey.T:
                            app.ExecQuery05();
                            break;

                        // Запрос 6. Комиссия по всем оформленным сделкам риэлторов
                        case ConsoleKey.Y:
                            app.ExecQuery06();
                            break;

                        // Запрос 7. Все риэлторы, их клиенты и сделки, по убыванию суммы сделки
                        case ConsoleKey.U:
                            app.ExecQuery07();
                            break;

                        // Запрос 8. По всем улицам вывести сумму сделок, по убыванию суммы
                        case ConsoleKey.I:
                            app.ExecQuery08();
                            break;

                        // Запрос 9. По всем улицам вывести сумму сделок за заданный период, по убыванию суммы
                        case ConsoleKey.O:
                            app.ExecQuery09();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex)
                {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20,  9, $"                                                                                        ", ConsoleColor.White);
                    Utils.WriteXY(20, 10, $"  ┌──────────────────────────────────────────────────────────────────────────────────┐  ", ConsoleColor.White);
                    Utils.WriteXY(20, 11, $"  │                                   Исключение.                                    │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  │ {ex.Message,-79}  │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 13, $"  │                                                                                  │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 14, $"  └──────────────────────────────────────────────────────────────────────────────────┘  ", ConsoleColor.White);
                    Utils.WriteXY(20, 15, $"                                                                                        ", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally
                {
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
