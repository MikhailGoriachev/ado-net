﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqIntro.Helpers;

namespace LinqIntro.Application
{
    public partial class App
    {

        // Товары с заданным диапазоном цен
        public void GoodsPriceInRange() {
            Utils.ShowNavBarTask("   Товары с заданным диапазоном цен");

            double fromPrice = Utils.GetRandom(1, 120) * 100;
            double toPrice = fromPrice + Utils.GetRandom(1, 20)*100;

            // выполнение запросов
            var list1 = _task3Controller.Query01A(fromPrice, toPrice);
            var list2 = _task3Controller.Query01B(fromPrice, toPrice);

            // вывод результата
            Console.WriteLine(Utils.ToTable(list1, $"\n\n\n\n\t\tТовары с диапазоном цены от {fromPrice:N2} до {toPrice:N2} (LINQ):\n"));
            Console.WriteLine(Utils.ToTable(list2, $"\n\n\t\tТовары с диапазоном цены от {fromPrice:N2} до {toPrice:N2} (ExtM):\n"));
        } // GoodsPriceInRange


        // Сумма товаров с заданным годом выпуска
        public void SumGoodsYearIssue() {
            Utils.ShowNavBarTask("   Сумма товаров с заданным годом выпуска");

            int year = Utils.GetRandom(2017, DateTime.Now.Year);

            // вывод товаров с заданным годом выпуска
            Console.WriteLine(Utils.ToTable(_task3Controller.GoodsWhereYear(year), 
                $"\n\n\n\n\tТовары с годом выпуска {year}:\n"));
            Console.WriteLine($"\tСумма товаров с годом выпуска {year} (LINQ): {_task3Controller.Query02A(year):n2}");
            Console.WriteLine($"\tСумма товаров с годом выпуска {year} (ExtM): {_task3Controller.Query02B(year):n2}\n");
        } // SumGoodsYearIssue


        // Сумма товаров с заданным наименованием
        public void SumGoodsWhereName() {
            Utils.ShowNavBarTask("   Сумма товаров с заданным наименованием");

            string goodsName = _task3Controller.GetRandomName();

            Console.WriteLine(Utils.ToTable(_task3Controller.GoodsWhereName(goodsName), 
                $"\n\n\n\n\tТовары с наименованием, содержащим {goodsName}:\n"));
            Console.WriteLine($"\tСумма товаров (LINQ): {_task3Controller.Query03A(goodsName):n2}");
            Console.WriteLine($"\tСумма товаров (ExtM): {_task3Controller.Query03B(goodsName):n2}");
        } // SumGoodsWhereName


        // Наименование и год выпуска товаров с максимальным количеством
        public void NameAndYearWhereMaxAmount() {
            Utils.ShowNavBarTask("   Наименование и год выпуска товаров с максимальным количеством");

            // Выполнение запроса к коллекции данных
            var listA = _task3Controller.Query04A();
            var listB = _task3Controller.Query04B();

            // Вывод результатов
            _task3Controller.ShowQuery04(listA);
            _task3Controller.ShowQuery04(listB);
        } // NameAndYearWhereMaxAmount


        // Все товары, для которых произведение цены на количество находится в заданном диапазоне
        public void GoodsWhereCostInRange() {
            Utils.ShowNavBarTask("   Все товары, для которых произведение цены на количество находится в заданном диапазоне");

            double from = Utils.GetRandom(1, 20)*1000;
            double to = from + Utils.GetRandom(1, 10)*1000;

            var listA = _task3Controller.Query05A(from, to);
            var listB = _task3Controller.Query05B(from, to);

            Console.WriteLine(Utils.ToTable(listA, $"\n\n\n\n\tТовары c произведением цена x количество в интервале [{from:n2} ... {to:n2}] (LINQ):\n"));
            Console.WriteLine(Utils.ToTable(listB, $"\n\tТовары c произведением цена x количество в интервале [{from:n2} ... {to:n2}] (ExtM):\n"));
        } // GoodsWhereCostInRange

    } // class App.Task3
}
