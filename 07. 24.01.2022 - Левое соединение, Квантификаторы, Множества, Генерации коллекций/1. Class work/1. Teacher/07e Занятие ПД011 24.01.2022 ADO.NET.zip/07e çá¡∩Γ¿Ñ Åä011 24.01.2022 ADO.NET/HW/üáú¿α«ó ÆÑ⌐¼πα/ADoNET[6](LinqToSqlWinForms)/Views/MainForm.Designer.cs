﻿
namespace ADoNET_6__LinqToSqlWinForms_.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MinFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniQuery01 = new System.Windows.Forms.ToolStripMenuItem();
            this.MniQuery02 = new System.Windows.Forms.ToolStripMenuItem();
            this.MniQuery03 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniQuery04 = new System.Windows.Forms.ToolStripMenuItem();
            this.MniQuery05 = new System.Windows.Forms.ToolStripMenuItem();
            this.MniQuery06 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.TsbQueryOne = new System.Windows.Forms.ToolStripButton();
            this.TsbQueryTwo = new System.Windows.Forms.ToolStripButton();
            this.TsbQueryThree = new System.Windows.Forms.ToolStripButton();
            this.TsbQueryFour = new System.Windows.Forms.ToolStripButton();
            this.TsbQueryFive = new System.Windows.Forms.ToolStripButton();
            this.TsbQuerySix = new System.Windows.Forms.ToolStripButton();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpQuery01 = new System.Windows.Forms.TabPage();
            this.dgvQuery01 = new System.Windows.Forms.DataGridView();
            this.LblQuery01 = new System.Windows.Forms.Label();
            this.TbpQuery02 = new System.Windows.Forms.TabPage();
            this.dgvQuery02 = new System.Windows.Forms.DataGridView();
            this.LblQuery02 = new System.Windows.Forms.Label();
            this.TbpQuery03 = new System.Windows.Forms.TabPage();
            this.dgvQuery03 = new System.Windows.Forms.DataGridView();
            this.LblQuery03 = new System.Windows.Forms.Label();
            this.TbpQuery04 = new System.Windows.Forms.TabPage();
            this.dgvQuery04 = new System.Windows.Forms.DataGridView();
            this.LblQuery04 = new System.Windows.Forms.Label();
            this.TbpQuery05 = new System.Windows.Forms.TabPage();
            this.dgvQuery05 = new System.Windows.Forms.DataGridView();
            this.LblQuery05 = new System.Windows.Forms.Label();
            this.TbpQuery06 = new System.Windows.Forms.TabPage();
            this.dgvQuery06 = new System.Windows.Forms.DataGridView();
            this.LblQuery06 = new System.Windows.Forms.Label();
            this.imlNumbers = new System.Windows.Forms.ImageList(this.components);
            this.purchasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.goodDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasePriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salePriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleDateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.profitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultQuery06BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Good = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PurchaseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpQuery01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery01)).BeginInit();
            this.TbpQuery02.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery02)).BeginInit();
            this.TbpQuery03.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery03)).BeginInit();
            this.TbpQuery04.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery04)).BeginInit();
            this.TbpQuery05.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery05)).BeginInit();
            this.TbpQuery06.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery06BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MinFile,
            this.MniHelp,
            this.запросыToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(987, 36);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MinFile
            // 
            this.MinFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.MinFile.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MinFile.Name = "MinFile";
            this.MinFile.Size = new System.Drawing.Size(74, 32);
            this.MinFile.Text = "Файл";
            // 
            // MniExit
            // 
            this.MniExit.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.Exit;
            this.MniExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniExit.Name = "MniExit";
            this.MniExit.Size = new System.Drawing.Size(167, 38);
            this.MniExit.Text = "Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(103, 32);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.Help;
            this.MniHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(246, 38);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniQuery01,
            this.MniQuery02,
            this.MniQuery03,
            this.toolStripMenuItem1,
            this.MniQuery04,
            this.MniQuery05,
            this.MniQuery06});
            this.запросыToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(106, 32);
            this.запросыToolStripMenuItem.Text = "Запросы";
            // 
            // MniQuery01
            // 
            this.MniQuery01.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniQuery01.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryOne;
            this.MniQuery01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MniQuery01.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniQuery01.Name = "MniQuery01";
            this.MniQuery01.Size = new System.Drawing.Size(896, 38);
            this.MniQuery01.Text = "Информация о товарах, единица измерения которых «шт» (штуки) и цена закупки меньш" +
    "е 200 руб";
            this.MniQuery01.Click += new System.EventHandler(this.Query01View_Command);
            // 
            // MniQuery02
            // 
            this.MniQuery02.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniQuery02.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryTwo;
            this.MniQuery02.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniQuery02.Name = "MniQuery02";
            this.MniQuery02.Size = new System.Drawing.Size(896, 38);
            this.MniQuery02.Text = "Информация о товарах, цена закупки которых больше 500 руб";
            this.MniQuery02.Click += new System.EventHandler(this.Query02View_Command);
            // 
            // MniQuery03
            // 
            this.MniQuery03.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniQuery03.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryThree;
            this.MniQuery03.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniQuery03.Name = "MniQuery03";
            this.MniQuery03.Size = new System.Drawing.Size(896, 38);
            this.MniQuery03.Text = "Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1" +
    "800 руб";
            this.MniQuery03.Click += new System.EventHandler(this.Query03View_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(893, 6);
            // 
            // MniQuery04
            // 
            this.MniQuery04.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniQuery04.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryFour;
            this.MniQuery04.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniQuery04.Name = "MniQuery04";
            this.MniQuery04.Size = new System.Drawing.Size(896, 38);
            this.MniQuery04.Text = "Информация о продавцах с заданным значением процента комиссионных";
            this.MniQuery04.Click += new System.EventHandler(this.Query04View_Command);
            // 
            // MniQuery05
            // 
            this.MniQuery05.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniQuery05.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryFive;
            this.MniQuery05.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniQuery05.Name = "MniQuery05";
            this.MniQuery05.Size = new System.Drawing.Size(896, 38);
            this.MniQuery05.Text = "Информация о фактах продажи, для которых цена продажи в заданном диапазоне";
            this.MniQuery05.Click += new System.EventHandler(this.Query05View_Command);
            // 
            // MniQuery06
            // 
            this.MniQuery06.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniQuery06.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QuerySix;
            this.MniQuery06.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniQuery06.Name = "MniQuery06";
            this.MniQuery06.Size = new System.Drawing.Size(896, 38);
            this.MniQuery06.Text = "Вычислить прибыль от продажи за каждый проданный товар";
            this.MniQuery06.Click += new System.EventHandler(this.Query06View_Command);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbQueryOne,
            this.TsbQueryTwo,
            this.TsbQueryThree,
            this.TsbQueryFour,
            this.TsbQueryFive,
            this.TsbQuerySix});
            this.toolStrip1.Location = new System.Drawing.Point(0, 36);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(987, 39);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // TsbQueryOne
            // 
            this.TsbQueryOne.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQueryOne.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryOne;
            this.TsbQueryOne.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQueryOne.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQueryOne.Name = "TsbQueryOne";
            this.TsbQueryOne.Size = new System.Drawing.Size(36, 36);
            this.TsbQueryOne.Text = "Выполнение 1 запроса";
            this.TsbQueryOne.Click += new System.EventHandler(this.Query01View_Command);
            // 
            // TsbQueryTwo
            // 
            this.TsbQueryTwo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQueryTwo.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryTwo;
            this.TsbQueryTwo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQueryTwo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQueryTwo.Name = "TsbQueryTwo";
            this.TsbQueryTwo.Size = new System.Drawing.Size(36, 36);
            this.TsbQueryTwo.Text = "Выполнение 2 запроса";
            this.TsbQueryTwo.Click += new System.EventHandler(this.Query02View_Command);
            // 
            // TsbQueryThree
            // 
            this.TsbQueryThree.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQueryThree.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryThree;
            this.TsbQueryThree.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQueryThree.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQueryThree.Name = "TsbQueryThree";
            this.TsbQueryThree.Size = new System.Drawing.Size(36, 36);
            this.TsbQueryThree.Text = "toolStripButton1";
            this.TsbQueryThree.Click += new System.EventHandler(this.Query03View_Command);
            // 
            // TsbQueryFour
            // 
            this.TsbQueryFour.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQueryFour.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryFour;
            this.TsbQueryFour.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQueryFour.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQueryFour.Name = "TsbQueryFour";
            this.TsbQueryFour.Size = new System.Drawing.Size(36, 36);
            this.TsbQueryFour.Text = "toolStripButton2";
            this.TsbQueryFour.Click += new System.EventHandler(this.Query04View_Command);
            // 
            // TsbQueryFive
            // 
            this.TsbQueryFive.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQueryFive.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QueryFive;
            this.TsbQueryFive.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQueryFive.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQueryFive.Name = "TsbQueryFive";
            this.TsbQueryFive.Size = new System.Drawing.Size(36, 36);
            this.TsbQueryFive.Text = "toolStripButton3";
            this.TsbQueryFive.Click += new System.EventHandler(this.Query05View_Command);
            // 
            // TsbQuerySix
            // 
            this.TsbQuerySix.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbQuerySix.Image = global::ADoNET_6__LinqToSqlWinForms_.Properties.Resources.QuerySix;
            this.TsbQuerySix.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbQuerySix.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbQuerySix.Name = "TsbQuerySix";
            this.TsbQuerySix.Size = new System.Drawing.Size(36, 36);
            this.TsbQuerySix.Text = "toolStripButton4";
            this.TsbQuerySix.Click += new System.EventHandler(this.Query06View_Command);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpQuery01);
            this.TbcMain.Controls.Add(this.TbpQuery02);
            this.TbcMain.Controls.Add(this.TbpQuery03);
            this.TbcMain.Controls.Add(this.TbpQuery04);
            this.TbcMain.Controls.Add(this.TbpQuery05);
            this.TbcMain.Controls.Add(this.TbpQuery06);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 75);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(987, 543);
            this.TbcMain.TabIndex = 2;
            // 
            // TbpQuery01
            // 
            this.TbpQuery01.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TbpQuery01.Controls.Add(this.dgvQuery01);
            this.TbpQuery01.Controls.Add(this.LblQuery01);
            this.TbpQuery01.Location = new System.Drawing.Point(4, 34);
            this.TbpQuery01.Name = "TbpQuery01";
            this.TbpQuery01.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery01.Size = new System.Drawing.Size(979, 505);
            this.TbpQuery01.TabIndex = 0;
            this.TbpQuery01.Text = "Запрос №1";
            // 
            // dgvQuery01
            // 
            this.dgvQuery01.AllowUserToAddRows = false;
            this.dgvQuery01.AllowUserToDeleteRows = false;
            this.dgvQuery01.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvQuery01.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvQuery01.AutoGenerateColumns = false;
            this.dgvQuery01.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQuery01.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuery01.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuery01.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Good,
            this.Unit,
            this.PurchaseDate,
            this.Price,
            this.Amount});
            this.dgvQuery01.DataSource = this.purchasBindingSource;
            this.dgvQuery01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvQuery01.Location = new System.Drawing.Point(3, 56);
            this.dgvQuery01.MultiSelect = false;
            this.dgvQuery01.Name = "dgvQuery01";
            this.dgvQuery01.ReadOnly = true;
            this.dgvQuery01.RowHeadersVisible = false;
            this.dgvQuery01.RowHeadersWidth = 51;
            this.dgvQuery01.RowTemplate.Height = 24;
            this.dgvQuery01.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvQuery01.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQuery01.Size = new System.Drawing.Size(973, 446);
            this.dgvQuery01.TabIndex = 0;
            // 
            // LblQuery01
            // 
            this.LblQuery01.BackColor = System.Drawing.Color.PaleTurquoise;
            this.LblQuery01.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblQuery01.Location = new System.Drawing.Point(0, 0);
            this.LblQuery01.Name = "LblQuery01";
            this.LblQuery01.Size = new System.Drawing.Size(976, 48);
            this.LblQuery01.TabIndex = 8;
            this.LblQuery01.Text = "Информация о товарах, единица измерения которых «шт» (штуки)\r\nцена закупки меньше" +
    " 200 руб.";
            // 
            // TbpQuery02
            // 
            this.TbpQuery02.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TbpQuery02.Controls.Add(this.dgvQuery02);
            this.TbpQuery02.Controls.Add(this.LblQuery02);
            this.TbpQuery02.Location = new System.Drawing.Point(4, 34);
            this.TbpQuery02.Name = "TbpQuery02";
            this.TbpQuery02.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery02.Size = new System.Drawing.Size(979, 505);
            this.TbpQuery02.TabIndex = 1;
            this.TbpQuery02.Text = "Запрос №2";
            // 
            // dgvQuery02
            // 
            this.dgvQuery02.AllowUserToAddRows = false;
            this.dgvQuery02.AllowUserToDeleteRows = false;
            this.dgvQuery02.AllowUserToResizeColumns = false;
            this.dgvQuery02.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvQuery02.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvQuery02.AutoGenerateColumns = false;
            this.dgvQuery02.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQuery02.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvQuery02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuery02.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dgvQuery02.DataSource = this.purchasBindingSource;
            this.dgvQuery02.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvQuery02.Location = new System.Drawing.Point(3, 40);
            this.dgvQuery02.MultiSelect = false;
            this.dgvQuery02.Name = "dgvQuery02";
            this.dgvQuery02.ReadOnly = true;
            this.dgvQuery02.RowHeadersVisible = false;
            this.dgvQuery02.RowHeadersWidth = 51;
            this.dgvQuery02.RowTemplate.Height = 24;
            this.dgvQuery02.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvQuery02.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQuery02.Size = new System.Drawing.Size(973, 462);
            this.dgvQuery02.TabIndex = 11;
            // 
            // LblQuery02
            // 
            this.LblQuery02.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblQuery02.Location = new System.Drawing.Point(1, 1);
            this.LblQuery02.Name = "LblQuery02";
            this.LblQuery02.Size = new System.Drawing.Size(976, 48);
            this.LblQuery02.TabIndex = 10;
            this.LblQuery02.Text = "Информация о товарах, цена закупки которых больше 500 руб";
            // 
            // TbpQuery03
            // 
            this.TbpQuery03.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TbpQuery03.Controls.Add(this.dgvQuery03);
            this.TbpQuery03.Controls.Add(this.LblQuery03);
            this.TbpQuery03.Location = new System.Drawing.Point(4, 34);
            this.TbpQuery03.Name = "TbpQuery03";
            this.TbpQuery03.Size = new System.Drawing.Size(979, 505);
            this.TbpQuery03.TabIndex = 2;
            this.TbpQuery03.Text = "Запрос №3";
            // 
            // dgvQuery03
            // 
            this.dgvQuery03.AllowUserToAddRows = false;
            this.dgvQuery03.AllowUserToDeleteRows = false;
            this.dgvQuery03.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvQuery03.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvQuery03.AutoGenerateColumns = false;
            this.dgvQuery03.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQuery03.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuery03.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvQuery03.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuery03.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.dgvQuery03.DataSource = this.purchasBindingSource;
            this.dgvQuery03.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvQuery03.Location = new System.Drawing.Point(0, 59);
            this.dgvQuery03.MultiSelect = false;
            this.dgvQuery03.Name = "dgvQuery03";
            this.dgvQuery03.ReadOnly = true;
            this.dgvQuery03.RowHeadersVisible = false;
            this.dgvQuery03.RowHeadersWidth = 51;
            this.dgvQuery03.RowTemplate.Height = 24;
            this.dgvQuery03.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvQuery03.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQuery03.Size = new System.Drawing.Size(979, 446);
            this.dgvQuery03.TabIndex = 9;
            // 
            // LblQuery03
            // 
            this.LblQuery03.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblQuery03.Location = new System.Drawing.Point(0, 0);
            this.LblQuery03.Name = "LblQuery03";
            this.LblQuery03.Size = new System.Drawing.Size(976, 48);
            this.LblQuery03.TabIndex = 10;
            this.LblQuery03.Text = "Информация о товарах, с заданным наименованием, \r\nдля которых цена закупки меньше" +
    " 1800 руб";
            // 
            // TbpQuery04
            // 
            this.TbpQuery04.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TbpQuery04.Controls.Add(this.dgvQuery04);
            this.TbpQuery04.Controls.Add(this.LblQuery04);
            this.TbpQuery04.Location = new System.Drawing.Point(4, 34);
            this.TbpQuery04.Name = "TbpQuery04";
            this.TbpQuery04.Size = new System.Drawing.Size(979, 505);
            this.TbpQuery04.TabIndex = 3;
            this.TbpQuery04.Text = "Запрос №4";
            // 
            // dgvQuery04
            // 
            this.dgvQuery04.AllowUserToAddRows = false;
            this.dgvQuery04.AllowUserToDeleteRows = false;
            this.dgvQuery04.AllowUserToResizeRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvQuery04.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvQuery04.AutoGenerateColumns = false;
            this.dgvQuery04.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQuery04.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuery04.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvQuery04.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuery04.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.nameDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.patronymicDataGridViewTextBoxColumn,
            this.interestDataGridViewTextBoxColumn});
            this.dgvQuery04.DataSource = this.sellerBindingSource;
            this.dgvQuery04.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvQuery04.Location = new System.Drawing.Point(0, 40);
            this.dgvQuery04.MultiSelect = false;
            this.dgvQuery04.Name = "dgvQuery04";
            this.dgvQuery04.ReadOnly = true;
            this.dgvQuery04.RowHeadersVisible = false;
            this.dgvQuery04.RowHeadersWidth = 51;
            this.dgvQuery04.RowTemplate.Height = 24;
            this.dgvQuery04.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvQuery04.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQuery04.Size = new System.Drawing.Size(979, 465);
            this.dgvQuery04.TabIndex = 9;
            // 
            // LblQuery04
            // 
            this.LblQuery04.BackColor = System.Drawing.Color.PaleTurquoise;
            this.LblQuery04.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblQuery04.Location = new System.Drawing.Point(0, 0);
            this.LblQuery04.Name = "LblQuery04";
            this.LblQuery04.Size = new System.Drawing.Size(976, 48);
            this.LblQuery04.TabIndex = 10;
            this.LblQuery04.Text = "Информация о продавцах с заданным значением процента комиссионных.";
            // 
            // TbpQuery05
            // 
            this.TbpQuery05.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TbpQuery05.Controls.Add(this.dgvQuery05);
            this.TbpQuery05.Controls.Add(this.LblQuery05);
            this.TbpQuery05.Location = new System.Drawing.Point(4, 34);
            this.TbpQuery05.Name = "TbpQuery05";
            this.TbpQuery05.Size = new System.Drawing.Size(979, 505);
            this.TbpQuery05.TabIndex = 4;
            this.TbpQuery05.Text = "Запрос №5";
            // 
            // dgvQuery05
            // 
            this.dgvQuery05.AllowUserToAddRows = false;
            this.dgvQuery05.AllowUserToDeleteRows = false;
            this.dgvQuery05.AllowUserToResizeRows = false;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvQuery05.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvQuery05.AutoGenerateColumns = false;
            this.dgvQuery05.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQuery05.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuery05.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvQuery05.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuery05.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.goodDataGridViewTextBoxColumn2,
            this.unitDataGridViewTextBoxColumn2,
            this.amountDataGridViewTextBoxColumn2,
            this.sellerDataGridViewTextBoxColumn,
            this.purchasePriceDataGridViewTextBoxColumn,
            this.salePriceDataGridViewTextBoxColumn,
            this.saleDateDataGridViewTextBoxColumn});
            this.dgvQuery05.DataSource = this.saleBindingSource;
            this.dgvQuery05.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvQuery05.Location = new System.Drawing.Point(0, 40);
            this.dgvQuery05.MultiSelect = false;
            this.dgvQuery05.Name = "dgvQuery05";
            this.dgvQuery05.ReadOnly = true;
            this.dgvQuery05.RowHeadersVisible = false;
            this.dgvQuery05.RowHeadersWidth = 51;
            this.dgvQuery05.RowTemplate.Height = 24;
            this.dgvQuery05.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvQuery05.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQuery05.Size = new System.Drawing.Size(979, 465);
            this.dgvQuery05.TabIndex = 9;
            // 
            // LblQuery05
            // 
            this.LblQuery05.BackColor = System.Drawing.Color.PaleTurquoise;
            this.LblQuery05.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblQuery05.Location = new System.Drawing.Point(0, 0);
            this.LblQuery05.Name = "LblQuery05";
            this.LblQuery05.Size = new System.Drawing.Size(976, 48);
            this.LblQuery05.TabIndex = 10;
            this.LblQuery05.Text = "Информация о фактах продажи, для которых цена продажи в заданном диапазоне";
            // 
            // TbpQuery06
            // 
            this.TbpQuery06.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TbpQuery06.Controls.Add(this.dgvQuery06);
            this.TbpQuery06.Controls.Add(this.LblQuery06);
            this.TbpQuery06.Location = new System.Drawing.Point(4, 34);
            this.TbpQuery06.Name = "TbpQuery06";
            this.TbpQuery06.Size = new System.Drawing.Size(979, 505);
            this.TbpQuery06.TabIndex = 5;
            this.TbpQuery06.Text = "Запрос №6";
            // 
            // dgvQuery06
            // 
            this.dgvQuery06.AllowUserToAddRows = false;
            this.dgvQuery06.AllowUserToDeleteRows = false;
            this.dgvQuery06.AllowUserToResizeRows = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvQuery06.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvQuery06.AutoGenerateColumns = false;
            this.dgvQuery06.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQuery06.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuery06.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvQuery06.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuery06.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.goodDataGridViewTextBoxColumn3,
            this.purchasePriceDataGridViewTextBoxColumn1,
            this.salePriceDataGridViewTextBoxColumn1,
            this.saleDateDataGridViewTextBoxColumn1,
            this.amountDataGridViewTextBoxColumn3,
            this.profitDataGridViewTextBoxColumn});
            this.dgvQuery06.DataSource = this.resultQuery06BindingSource;
            this.dgvQuery06.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvQuery06.Location = new System.Drawing.Point(0, 40);
            this.dgvQuery06.MultiSelect = false;
            this.dgvQuery06.Name = "dgvQuery06";
            this.dgvQuery06.ReadOnly = true;
            this.dgvQuery06.RowHeadersVisible = false;
            this.dgvQuery06.RowHeadersWidth = 51;
            this.dgvQuery06.RowTemplate.Height = 24;
            this.dgvQuery06.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvQuery06.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQuery06.Size = new System.Drawing.Size(979, 465);
            this.dgvQuery06.TabIndex = 9;
            // 
            // LblQuery06
            // 
            this.LblQuery06.BackColor = System.Drawing.Color.PaleTurquoise;
            this.LblQuery06.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblQuery06.Location = new System.Drawing.Point(0, 0);
            this.LblQuery06.Name = "LblQuery06";
            this.LblQuery06.Size = new System.Drawing.Size(976, 48);
            this.LblQuery06.TabIndex = 10;
            this.LblQuery06.Text = "Вычислить прибыль от продажи за каждый проданный товар";
            // 
            // imlNumbers
            // 
            this.imlNumbers.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlNumbers.ImageStream")));
            this.imlNumbers.TransparentColor = System.Drawing.Color.Transparent;
            this.imlNumbers.Images.SetKeyName(0, "QueryFive.png");
            this.imlNumbers.Images.SetKeyName(1, "QueryFour.png");
            this.imlNumbers.Images.SetKeyName(2, "QueryOne.png");
            this.imlNumbers.Images.SetKeyName(3, "QuerySix.png");
            this.imlNumbers.Images.SetKeyName(4, "QueryThree.png");
            this.imlNumbers.Images.SetKeyName(5, "QueryTwo.png");
            // 
            // purchasBindingSource
            // 
            this.purchasBindingSource.DataSource = typeof(ADoNET_6__LinqToSqlWinForms_.Models.Purchase);
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.FillWeight = 91.57755F;
            this.idDataGridViewTextBoxColumn2.HeaderText = "Идент.";
            this.idDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.FillWeight = 91.57755F;
            this.nameDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.FillWeight = 91.57755F;
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // patronymicDataGridViewTextBoxColumn
            // 
            this.patronymicDataGridViewTextBoxColumn.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn.FillWeight = 91.57755F;
            this.patronymicDataGridViewTextBoxColumn.HeaderText = "Отчество";
            this.patronymicDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.patronymicDataGridViewTextBoxColumn.Name = "patronymicDataGridViewTextBoxColumn";
            this.patronymicDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // interestDataGridViewTextBoxColumn
            // 
            this.interestDataGridViewTextBoxColumn.DataPropertyName = "Interest";
            this.interestDataGridViewTextBoxColumn.FillWeight = 133.6898F;
            this.interestDataGridViewTextBoxColumn.HeaderText = "Процент за продажу";
            this.interestDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.interestDataGridViewTextBoxColumn.Name = "interestDataGridViewTextBoxColumn";
            this.interestDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sellerBindingSource
            // 
            this.sellerBindingSource.DataSource = typeof(ADoNET_6__LinqToSqlWinForms_.Models.Seller);
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn3.FillWeight = 62.8166F;
            this.idDataGridViewTextBoxColumn3.HeaderText = "Идент.";
            this.idDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            this.idDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // goodDataGridViewTextBoxColumn2
            // 
            this.goodDataGridViewTextBoxColumn2.DataPropertyName = "Good";
            this.goodDataGridViewTextBoxColumn2.FillWeight = 119.7861F;
            this.goodDataGridViewTextBoxColumn2.HeaderText = "Товар";
            this.goodDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.goodDataGridViewTextBoxColumn2.Name = "goodDataGridViewTextBoxColumn2";
            this.goodDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // unitDataGridViewTextBoxColumn2
            // 
            this.unitDataGridViewTextBoxColumn2.DataPropertyName = "Unit";
            this.unitDataGridViewTextBoxColumn2.FillWeight = 102.8996F;
            this.unitDataGridViewTextBoxColumn2.HeaderText = "Ед. измерения";
            this.unitDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.unitDataGridViewTextBoxColumn2.Name = "unitDataGridViewTextBoxColumn2";
            this.unitDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn2
            // 
            this.amountDataGridViewTextBoxColumn2.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn2.FillWeight = 102.8996F;
            this.amountDataGridViewTextBoxColumn2.HeaderText = "Кол-во";
            this.amountDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn2.Name = "amountDataGridViewTextBoxColumn2";
            this.amountDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // sellerDataGridViewTextBoxColumn
            // 
            this.sellerDataGridViewTextBoxColumn.DataPropertyName = "Seller";
            this.sellerDataGridViewTextBoxColumn.FillWeight = 102.8996F;
            this.sellerDataGridViewTextBoxColumn.HeaderText = "Продавец";
            this.sellerDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sellerDataGridViewTextBoxColumn.Name = "sellerDataGridViewTextBoxColumn";
            this.sellerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // purchasePriceDataGridViewTextBoxColumn
            // 
            this.purchasePriceDataGridViewTextBoxColumn.DataPropertyName = "PurchasePrice";
            this.purchasePriceDataGridViewTextBoxColumn.FillWeight = 102.8996F;
            this.purchasePriceDataGridViewTextBoxColumn.HeaderText = "Цена закупки";
            this.purchasePriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.purchasePriceDataGridViewTextBoxColumn.Name = "purchasePriceDataGridViewTextBoxColumn";
            this.purchasePriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // salePriceDataGridViewTextBoxColumn
            // 
            this.salePriceDataGridViewTextBoxColumn.DataPropertyName = "SalePrice";
            this.salePriceDataGridViewTextBoxColumn.FillWeight = 102.8996F;
            this.salePriceDataGridViewTextBoxColumn.HeaderText = "Цена продажи";
            this.salePriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.salePriceDataGridViewTextBoxColumn.Name = "salePriceDataGridViewTextBoxColumn";
            this.salePriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // saleDateDataGridViewTextBoxColumn
            // 
            this.saleDateDataGridViewTextBoxColumn.DataPropertyName = "SaleDate";
            this.saleDateDataGridViewTextBoxColumn.FillWeight = 102.8996F;
            this.saleDateDataGridViewTextBoxColumn.HeaderText = "Дата продажи";
            this.saleDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.saleDateDataGridViewTextBoxColumn.Name = "saleDateDataGridViewTextBoxColumn";
            this.saleDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // saleBindingSource
            // 
            this.saleBindingSource.DataSource = typeof(ADoNET_6__LinqToSqlWinForms_.Models.Sale);
            // 
            // goodDataGridViewTextBoxColumn3
            // 
            this.goodDataGridViewTextBoxColumn3.DataPropertyName = "Good";
            this.goodDataGridViewTextBoxColumn3.FillWeight = 160.4278F;
            this.goodDataGridViewTextBoxColumn3.HeaderText = "Товар";
            this.goodDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.goodDataGridViewTextBoxColumn3.Name = "goodDataGridViewTextBoxColumn3";
            this.goodDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // purchasePriceDataGridViewTextBoxColumn1
            // 
            this.purchasePriceDataGridViewTextBoxColumn1.DataPropertyName = "PurchasePrice";
            this.purchasePriceDataGridViewTextBoxColumn1.FillWeight = 87.91444F;
            this.purchasePriceDataGridViewTextBoxColumn1.HeaderText = "Цена закупки";
            this.purchasePriceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.purchasePriceDataGridViewTextBoxColumn1.Name = "purchasePriceDataGridViewTextBoxColumn1";
            this.purchasePriceDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // salePriceDataGridViewTextBoxColumn1
            // 
            this.salePriceDataGridViewTextBoxColumn1.DataPropertyName = "SalePrice";
            this.salePriceDataGridViewTextBoxColumn1.FillWeight = 87.91444F;
            this.salePriceDataGridViewTextBoxColumn1.HeaderText = "Цена продажи";
            this.salePriceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.salePriceDataGridViewTextBoxColumn1.Name = "salePriceDataGridViewTextBoxColumn1";
            this.salePriceDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // saleDateDataGridViewTextBoxColumn1
            // 
            this.saleDateDataGridViewTextBoxColumn1.DataPropertyName = "SaleDate";
            this.saleDateDataGridViewTextBoxColumn1.FillWeight = 87.91444F;
            this.saleDateDataGridViewTextBoxColumn1.HeaderText = "Дата продажи";
            this.saleDateDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.saleDateDataGridViewTextBoxColumn1.Name = "saleDateDataGridViewTextBoxColumn1";
            this.saleDateDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn3
            // 
            this.amountDataGridViewTextBoxColumn3.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn3.FillWeight = 87.91444F;
            this.amountDataGridViewTextBoxColumn3.HeaderText = "Кол-во";
            this.amountDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn3.Name = "amountDataGridViewTextBoxColumn3";
            this.amountDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // profitDataGridViewTextBoxColumn
            // 
            this.profitDataGridViewTextBoxColumn.DataPropertyName = "Profit";
            this.profitDataGridViewTextBoxColumn.FillWeight = 87.91444F;
            this.profitDataGridViewTextBoxColumn.HeaderText = "Прибыль";
            this.profitDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.profitDataGridViewTextBoxColumn.Name = "profitDataGridViewTextBoxColumn";
            this.profitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // resultQuery06BindingSource
            // 
            this.resultQuery06BindingSource.DataSource = typeof(ADoNET_6__LinqToSqlWinForms_.Models.ResultQuery06);
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.FillWeight = 97.54011F;
            this.Id.HeaderText = "Идентиф.";
            this.Id.MinimumWidth = 6;
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // Good
            // 
            this.Good.DataPropertyName = "Good";
            this.Good.FillWeight = 97.54011F;
            this.Good.HeaderText = "Товар";
            this.Good.MinimumWidth = 6;
            this.Good.Name = "Good";
            this.Good.ReadOnly = true;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Unit";
            this.Unit.FillWeight = 112.2995F;
            this.Unit.HeaderText = "Ед. измерения";
            this.Unit.MinimumWidth = 6;
            this.Unit.Name = "Unit";
            this.Unit.ReadOnly = true;
            // 
            // PurchaseDate
            // 
            this.PurchaseDate.DataPropertyName = "PurchaseDate";
            this.PurchaseDate.FillWeight = 97.54011F;
            this.PurchaseDate.HeaderText = "Дата закупки";
            this.PurchaseDate.MinimumWidth = 6;
            this.PurchaseDate.Name = "PurchaseDate";
            this.PurchaseDate.ReadOnly = true;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.FillWeight = 97.54011F;
            this.Price.HeaderText = "Цена";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.FillWeight = 97.54011F;
            this.Amount.HeaderText = "Кол-во";
            this.Amount.MinimumWidth = 6;
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Идентиф.";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Good";
            this.dataGridViewTextBoxColumn2.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn3.FillWeight = 112.2995F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "PurchaseDate";
            this.dataGridViewTextBoxColumn4.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn5.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn6.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Кол-во";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn7.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Идентиф.";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Good";
            this.dataGridViewTextBoxColumn8.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn8.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn9.FillWeight = 112.2995F;
            this.dataGridViewTextBoxColumn9.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "PurchaseDate";
            this.dataGridViewTextBoxColumn10.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn10.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn11.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn11.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn12.FillWeight = 97.54011F;
            this.dataGridViewTextBoxColumn12.HeaderText = "Кол-во";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(987, 618);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 24.01.22";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpQuery01.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery01)).EndInit();
            this.TbpQuery02.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery02)).EndInit();
            this.TbpQuery03.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery03)).EndInit();
            this.TbpQuery04.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery04)).EndInit();
            this.TbpQuery05.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery05)).EndInit();
            this.TbpQuery06.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuery06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery06BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MinFile;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton TsbQueryOne;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpQuery01;
        private System.Windows.Forms.TabPage TbpQuery02;
        private System.Windows.Forms.DataGridView dgvQuery01;
        private System.Windows.Forms.TabPage TbpQuery03;
        private System.Windows.Forms.TabPage TbpQuery04;
        private System.Windows.Forms.TabPage TbpQuery05;
        private System.Windows.Forms.TabPage TbpQuery06;
        private System.Windows.Forms.Label LblQuery01;
        private System.Windows.Forms.Label LblQuery02;
        private System.Windows.Forms.ToolStripButton TsbQueryTwo;
        private System.Windows.Forms.BindingSource purchasBindingSource;
        private System.Windows.Forms.DataGridView dgvQuery02;
        private System.Windows.Forms.ToolStripButton TsbQueryThree;
        private System.Windows.Forms.ToolStripButton TsbQueryFour;
        private System.Windows.Forms.ToolStripButton TsbQueryFive;
        private System.Windows.Forms.ToolStripButton TsbQuerySix;
        private System.Windows.Forms.DataGridView dgvQuery03;
        private System.Windows.Forms.Label LblQuery03;
        private System.Windows.Forms.BindingSource saleBindingSource;
        private System.Windows.Forms.BindingSource sellerBindingSource;
        private System.Windows.Forms.BindingSource resultQuery06BindingSource;
        private System.Windows.Forms.DataGridView dgvQuery04;
        private System.Windows.Forms.Label LblQuery04;
        private System.Windows.Forms.DataGridView dgvQuery05;
        private System.Windows.Forms.Label LblQuery05;
        private System.Windows.Forms.DataGridView dgvQuery06;
        private System.Windows.Forms.Label LblQuery06;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasePriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salePriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasePriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn salePriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleDateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn profitDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniQuery01;
        private System.Windows.Forms.ToolStripMenuItem MniQuery02;
        private System.Windows.Forms.ToolStripMenuItem MniQuery03;
        private System.Windows.Forms.ToolStripMenuItem MniQuery04;
        private System.Windows.Forms.ToolStripMenuItem MniQuery05;
        private System.Windows.Forms.ToolStripMenuItem MniQuery06;
        private System.Windows.Forms.ImageList imlNumbers;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Good;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn PurchaseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
    }
}

