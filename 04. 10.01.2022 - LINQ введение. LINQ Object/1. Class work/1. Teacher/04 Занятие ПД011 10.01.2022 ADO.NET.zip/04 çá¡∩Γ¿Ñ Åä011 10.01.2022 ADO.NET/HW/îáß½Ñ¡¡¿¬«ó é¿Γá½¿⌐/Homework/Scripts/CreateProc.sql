﻿-- ФАЙЛ СОЗДАНИЯ ПРОЦЕДУР


-- пакет удаления процедур при их наличии
drop proc if exists ProcQuery01;
drop proc if exists ProcQuery02;
drop proc if exists ProcQuery03;
drop proc if exists ProcQuery04;
drop proc if exists ProcQuery05;
drop proc if exists ProcQuery06;
drop proc if exists ProcQuery07;
drop proc if exists ProcQuery08;
drop proc if exists ProcQuery09;
go


-- 01 Хранимая процедура	
-- Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях 
-- заданного типа, стоимость 1 экземпляра для которых меньше заданной
create proc ProcQuery01 @pubType nvarchar(30), @price int 
as begin
    select
       *
    from 
        ViewPublications
    where
        PubType = @pubType and Price < @price
end;
go


-- 02 Хранимая процедура	
-- Выбирает из таблиц информацию о подписчиках, проживающих на заданной 
-- параметром улице и номере дома, которые оформили подписку на издание 
-- с заданным параметром наименованием

create proc ProcQuery02 @street nvarchar(30), @building nvarchar(10), @title nvarchar(80)
as begin
    select
       ViewSubscribers.Id
       ,Surname
       , Name
       , Patronymic
       , Passport
       , Street
       , Building
       , Flat
    from 
        Deliveries join ViewPublications on Deliveries.IdPublication = ViewPublications.Id
                    join ViewSubscribers on Deliveries.IdSubscriber = ViewSubscribers.Id
    where
        Street = @street and Building = @building and Title = @title;
end;
go


-- 03 Хранимая процедура	
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение
-- в поле Цена 1 экземпляра находится в заданном диапазоне значений

create proc ProcQuery03 @loPrice int, @hiPrice int
as begin
    select
       *
    from 
        ViewPublications
    where
        Price between @loPrice and @hiPrice;
end;
go


-- 04 Хранимая процедура	
-- Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный 
-- параметром тип издания

create proc ProcQuery04 @pubType nvarchar(30)
as begin
    select
       ViewSubscribers.Id
       ,Surname
       , Name
       , Patronymic
       , Passport
       , Street
       , Building
       , Flat
    from 
        Deliveries join ViewPublications on Deliveries.IdPublication = ViewPublications.Id
                    join ViewSubscribers on Deliveries.IdSubscriber = ViewSubscribers.Id
    where
       PubType = @pubType;
end;
go

-- 05 Хранимая процедура	
-- Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКИ информацию обо всех оформленных 
-- подписках, для которых срок подписки есть значение из некоторого диапазона. 
-- Нижняя и верхняя границы диапазона задаются при выполнении запроса
create proc ProcQuery05 @loDuration int, @hiDuration int
as begin
    select
        Deliveries.Id
        , Surname
       , Name
       , Patronymic
       , Passport
       , Street
       , Building
       , Flat
       , PubType
       , Title
       , Deliveries.Duration
       , Deliveries.DateStart
    from 
        Deliveries join ViewPublications on Deliveries.IdPublication = ViewPublications.Id
                    join ViewSubscribers on Deliveries.IdSubscriber = ViewSubscribers.Id
    where
        Deliveries.Duration between @loDuration and @hiDuration;
end;
go

-- 06 Хранимая процедура	
-- Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС 
-- Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата 
-- начала подписки, Срок подписки, Стоимость подписки без НДС. Сортировка по 
-- полю Индекс издания
create proc ProcQuery06
as begin
    select
        Deliveries.Id
        , PubIndex
        , Title
        , Price
        , Deliveries.DateStart
        , Deliveries.Duration
        -- стоимость подписки с доставкой (1%) и без НДС 
        , 1.01 * (Price * Deliveries.Duration) as SubscribeCost
    from 
        Deliveries join ViewPublications on Deliveries.IdPublication = ViewPublications.Id
                    join ViewSubscribers on Deliveries.IdSubscriber = ViewSubscribers.Id
    order by
        PubIndex;
end;
go

-- 07 Хранимая процедура - Итоговый запрос	
-- Выполняет группировку по полю Вид издания. Для каждого вида вычисляет 
-- максимальную и минимальную цену 1 экземпляра
create proc ProcQuery07
as begin
    select
        PubType
        , Count(Id) as TotalPubType
        , Max(Price) as MaxPrice
        , Min(Price) as MinPrice
    from 
        ViewPublications
    group by
        PubType
end;
go

-- 08 Хранимая процедура - Итоговый запрос с левым соединением	
-- Выполняет группировку по полю Улица. Для всех улиц вычисляет количество 
-- подписчиков, проживающих на данной улице (итоги по полю Код получателя)
create proc ProcQuery08
as begin
select
    Streets.Street
    , Count(Deliveries.IdSubscriber) as SubscriberAmount
from
    Streets left join (Subscribers join Deliveries on Subscribers.Id = Deliveries.IdSubscriber)
        on Streets.Id = Subscribers.IdStreet
group by
    Streets.Street;
end;
go

-- 09 Хранимая процедура - Итоговый запрос с левым соединением	
-- Для всех изданий выводит количество оформленных подписок

create proc ProcQuery09
as begin
select
    PubTypes.PubType
    , Count(Deliveries.Id) as DeliveriesAmount
from
    PubTypes left join (Deliveries join Publications on Deliveries.IdPublication = Publications.Id) 
                       on PubTypes.Id = Publications.IdPubType
group by
    PubTypes.PubType;
end;
go
