﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _4ADO.NET.Utilits;
using _4ADO.NET.Application;

namespace _4ADO.NET
{
    class Program
    {
        static void Main(string[] args)
        {
            App app = new App();

            // простейшее меню приложения
            List<MenuItem> menu = new List<MenuItem>(new[]{
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 2." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 3." },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.L, Text = "Выход" },
            });

            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {

                        // Задача 1. 
                        case ConsoleKey.Q:
                            app.Task1();
                            break;

                        // Задача 2. 
                        case ConsoleKey.W:
                            app.Task2();
                            break;

                        // Задача 3. 
                        case ConsoleKey.E:
                            app.Task3   ();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.L:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");

                    } // switch

                    Console.ReadKey();

                }
                catch (Exception ex)
                {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(5, 9, $"                                                                                        ", ConsoleColor.White);
                    Utils.WriteXY(5, 10, $"  ┌──────────────────────────────────────────────────────────────────────────────────┐  ", ConsoleColor.White);
                    Utils.WriteXY(5, 11, $"  │                                   Исключение.                                    │  ", ConsoleColor.White);
                    Utils.WriteXY(5, 12, $"  │ {ex.Message,-79}  │  ", ConsoleColor.White);
                    Utils.WriteXY(5, 13, $"  │                                                                                  │  ", ConsoleColor.White);
                    Utils.WriteXY(5, 14, $"  └──────────────────────────────────────────────────────────────────────────────────┘  ", ConsoleColor.White);
                    Utils.WriteXY(5, 15, $"                                                                                        ", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                    Console.ReadKey();

                }
            }
        }
    }
}
