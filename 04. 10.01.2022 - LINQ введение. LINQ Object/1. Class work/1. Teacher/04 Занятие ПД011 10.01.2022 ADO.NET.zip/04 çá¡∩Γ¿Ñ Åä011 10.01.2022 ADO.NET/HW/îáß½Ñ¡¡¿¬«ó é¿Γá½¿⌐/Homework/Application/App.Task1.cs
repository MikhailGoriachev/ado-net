﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
	internal partial class App
	{
		// 1. Хранимая процедура
		//Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа, 
		//стоимость 1 экземпляра для которых меньше заданной.
		private void Task1MenuItem1()
		{
			Utilities.ShowNavBar("Запрос 1.");

			string pubType = "Журнал";
			int price = 250;

			Console.WriteLine($"\n\n\tДоступные для подписки издания типа {pubType}, стоимость 1 экземпляра для которых меньше {price}:\n\n");

			_task1Controller.Query01(pubType, price);
		}

		// 2. Запрос с параметрами	
		//Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома, 
		//которые оформили подписку на издание с заданным параметром наименованием
		public void Task1MenuItem2()
		{
			Utilities.ShowNavBar(
				"Запрос 2.");

			string street = "ул. Садовая";
			string building = "118";
			string title = "Юный техник";

			Console.WriteLine($"\n\n\tПодписчики, проживающие по адресу {street}, {building}, оформившие подписку на {title}:\n\n");
			
			_task1Controller.Query02(street, building, title);
		}


		// 3. Запрос с параметрами	
		//Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле Цена 1 экземпляра
		//находится в заданном диапазоне значений
		public void Task1MenuItem3()
		{
			Utilities.ShowNavBar("Запрос 3.");

			int loPrice = 100;
			int hiPrice = 150;

			Console.WriteLine($"\n\n\tИздания, для которых цена 1 экземпляра в пределе {loPrice} и {hiPrice}:\n\n");

			_task1Controller.Query03(loPrice, hiPrice);
		}


		// 4. Запрос с параметрами
		//Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания
		public void Task1MenuItem4()
		{
			Utilities.ShowNavBar("Запрос 4.");

			string pubType = "газета";

			Console.WriteLine($"\n\n\tПодписчики, оформившие подписку на тип издания {pubType}:\n\n");

			_task1Controller.Query04(pubType);
		}


		// 5. Запрос с параметрами	
		//Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках, 
		//для которых срок подписки есть значение из некоторого диапазона
		public void Task1MenuItem5()
		{
			Utilities.ShowNavBar(
				"Запрос 5.");

			int loDuration = 3;
			int hiDuration = 4;

			Console.WriteLine($"\t\n\n\tПодписки со сроком действия от {loDuration} до {hiDuration}:\n\n");

			_task1Controller.Query05(loDuration, hiDuration);
		}


		// 6. Запрос с вычисляемыми полями	
		//Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. Включает поля 
		//Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки, Срок подписки, 
		//Стоимость подписки без НДС. Сортировка по полю Индекс издания
		public void Task1MenuItem6()
		{
			Utilities.ShowNavBar(
				"Запрос 6.");

			Console.WriteLine($"\n\n\tCтоимость для каждой оформленной подписки с доставкой и без НДС:\n\n");

			_task1Controller.Query06();
		}


		// 7. Запрос на левое соединение	
		//Выполняет группировку по полю Вид издания. Для каждого вида вычисляет максимальную и
		//минимальную цену 1 экземпляра
		public void Task1MenuItem7()
		{
			Utilities.ShowNavBar(
				"Запрос 7.");

			Console.WriteLine($"\n\n\tГруппировка по виду издания с максимальной и минимальной ценой за экземпляр:\n\n");

			_task1Controller.Query07();
		}


		// 8. Запрос на левое соединение	
		//Выполняет группировку по полю Улица. Для всех улиц вычисляет количество подписчиков, проживающих на
		//данной улице (итоги по полю Код получателя)
		public void Task1MenuItem8()
		{
			Utilities.ShowNavBar(
				"Запрос 8.");

			Console.WriteLine($"\n\n\t Улицы, с количеством проживающих на них подписчиках:\n\n");

			_task1Controller.Query08();
		}


		// 9. Запрос на левое соединение	
		//Для всех изданий выводит количество оформленных подписок
		public void Task1MenuItem9()
		{
			Utilities.ShowNavBar(
				"Запрос 9.");

			Console.WriteLine($"\n\n\t Количество оформленных сделок для всех изданий:\n\n");

			_task1Controller.Query09();
		}
	}
}
