﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HomeWorkWPF22._12._2021.Models;

namespace HomeWorkWPF22._12._2021
{
    /// <summary>
    /// Логика взаимодействия для ConoidWindow.xaml
    /// </summary>
    public partial class ConoidWindow : Window
    {
        // поле с фигурой
        private Conoid _conoid;

        // конструктор с зависимостями
        public ConoidWindow() : this(new Conoid()) { }

        // конструктор по умолчанию
        public ConoidWindow(Conoid conoid)
        {
            InitializeComponent();

            _conoid = conoid;

            Txb_r1.Text = $"{_conoid.R1}";
            Txb_r2.Text = $"{_conoid.R2}";
            Txb_h.Text = $"{_conoid.H}";
            Txb_p.Text = $"{_conoid.P}";

            // очистка поля вывода результата
            Res_S.Text = "";
            Res_V.Text = "";
            Res_M.Text = "";

            // фокус на первом поле ввода
            Txb_r1.Focus();

        }

        // Calculate
        private void Calculate_Command(object sender, RoutedEventArgs e)
        {
            try
            {
                _conoid.R1 = double.Parse(Txb_r1.Text);
                _conoid.R2 = double.Parse(Txb_r2.Text);
                _conoid.H = double.Parse(Txb_h.Text);
                _conoid.P = double.Parse(Txb_p.Text);
      

                double ResS, ResV, ResM;

                ResS = _conoid.GetS();
                ResV = _conoid.GetV();
                ResM = _conoid.GetMass();


                Res_S.Text = $"{ResS:f3}";
                Res_V.Text = $"{ResV:f3}";
                Res_M.Text = $"{ResM:f3}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Geometric_Command


        // Очистка поля вывода результата при изменении значений в полях ввода
        private void TextChanged_Handler(object sender, TextChangedEventArgs e)
        {
            // очистка поля вывода результата
            Res_S.Text = "";
            Res_V.Text = "";
            Res_M.Text = "";
        } // TextChanged_Handler
    }
}
