﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using LINQIntro.Helpers;
using LINQIntro.Controllers;

namespace LINQIntro.App_Data
{
    public partial class App
    {
        //метод, возвращающий процент скидки в зависимости от возраста товара 
        public void Task1_1()
        {
            Utils.ShowNavBarTask(" Выполнение Задачи 1 ");

            Console.WriteLine("\n\n\t Возвращает процент скидки в зависимости от возраста товара – \n" +
                              "\tдо 3х лет скидка не представляется, от 3х до 10 лет скидка 3%, свыше 10 лет – скидка 7%. \n");
            Controller.ShowCollection();

            //демонстраци расширяющего метода
            Console.WriteLine($" \nСкидка для товара:  {List[2].Name} равна {List[2].Discount()}\n");

            Console.WriteLine($"\nСкидка для товара:  {List[9].Name} равна {List[9].Discount()}\n"); 

            Console.WriteLine($"\nСкидка для товара:  {List[10].Name} равна {List[10].Discount()}\n"); 


            Console.ReadKey();
        }

        //Вычисление количества элементов массива, со значениями в диапазоне от A до B
        public void Task2_1()
        {
            Utils.ShowNavBarTask(" Выполнение Задачи 2 пункт 1");

            Console.WriteLine("\n\n \tВычисление количества элементов массива, со значениями в диапазоне от A до B\n");

            Console.WriteLine("\t Синтаксис LINQ");
            //демонстрация метода в синтаксисе LINQ
            Console.WriteLine(Controller.NumberOfElements());

            Console.WriteLine("\n\n");

            Console.WriteLine("\t Синтаксис расширяющих методов\n");
            //демонстрация метода синтаксисе расширяющих методов 
            Console.WriteLine((Controller.NumberOfElementsExtension()));

            Console.ReadKey();
        }

        //Вычисление количества элементов массива, равных 0
        public void Task2_2()
        {
            Utils.ShowNavBarTask(" Выполнение Задачи 2 пункт 2");

            Console.WriteLine("\n\nВычисление количества элементов массива, равных 0\n");

            Console.WriteLine("\t Синтаксис LINQ\n");
            //демонстрация метода в синтаксисе LINQ
            Console.WriteLine(Controller.NumberOfNulls());


            Console.WriteLine("\t Синтаксис расширяющих методов\n");
            //демонстрация метода синтаксисе расширяющих методов 
            Console.WriteLine(Controller.NumberOfNullsExtension());

            Console.ReadKey();
        }

        //товары с заданным диапазоном цен
        public void Task3_1()
        {
            Utils.ShowNavBarTask(" Выполнение Задачи 3 пункт 1");

            Console.WriteLine("\n\nВычисление количества товаров с заданным диапазоном цен от 20 до 40\n");

            Controller.ShowCollection();


            Console.WriteLine("\t Синтаксис расширяющих методов\n");
            //демонстрация метода синтаксисе расширяющих методов 
            Controller.DiapasonePriceGoods();

            Console.ReadKey(); 
        }

        public void Task3_2()
        {
            Utils.ShowNavBarTask(" Выполнение Задачи 3 пункт 2");

            Console.WriteLine("\n\nCумма товаров с заданным годом выпуска\n");

            Controller.ShowCollection();


            Console.WriteLine("\t Синтаксис расширяющих методов\n");
            //демонстрация метода синтаксисе расширяющих методов 
            Controller.SumOfGoods();

            Console.ReadKey();

        }

        //сумма товаров с заданным наименованием 
        public void Task3_3()
        {
            Utils.ShowNavBarTask(" Выполнение Задачи 3 пункт 3");

            Console.WriteLine("\n\no	сумма товаров с заданным наименованием ");

            Controller.ShowCollection();

            Console.WriteLine("\t Синтаксис расширяющих методов\n");
            //демонстрация метода синтаксисе расширяющих методов 
            Controller.NameOfGoods();

            Console.ReadKey();

        }

        //наименование и год выпуска товаров с максимальным количеством

        public void Task3_4()
        {
            Utils.ShowNavBarTask(" Выполнение Задачи 3 пункт 4");

            Console.WriteLine("\n\n Наименование и год выпуска товаров с максимальным количеством");

            Controller.ShowCollection();

            Console.WriteLine("\t Синтаксис расширяющих методов\n");
            //демонстрация метода синтаксисе расширяющих методов 

            Controller.NameAndYear();

            Console.ReadKey();
        }

        //все товары, для которых произведение цены на количество находится в заданном диапазоне

        public void Task3_5()
        {
            Utils.ShowNavBarTask(" Выполнение Задачи 3 пункт 5");

            Console.WriteLine("\n\n все товары, для которых произведение цены на количество находится в заданном диапазоне от 10000 до 50000");

            Controller.ShowCollection();

            Console.WriteLine("\t Синтаксис расширяющих методов\n");
            //демонстрация метода синтаксисе расширяющих методов 

            Controller.MultiplyPriceAndNumber();

            Console.ReadKey();

        }
    }
}
