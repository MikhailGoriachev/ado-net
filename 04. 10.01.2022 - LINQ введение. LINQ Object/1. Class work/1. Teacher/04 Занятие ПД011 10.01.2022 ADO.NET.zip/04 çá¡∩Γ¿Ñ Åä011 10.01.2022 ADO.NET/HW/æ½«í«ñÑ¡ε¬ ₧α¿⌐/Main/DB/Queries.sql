﻿-- 1
-- Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа, 
-- стоимость 1 экземпляра для которых меньше заданной.

-- EditionsByPriceLesserThan
declare @price money = 1000

select * from Editions
where Price < @price
go


-- 2
-- Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома, 
-- которые оформили подписку на издание с заданным параметром наименованием

-- DeliveriesByStreetHouseAndPublicationTitle
declare 
@street nvarchar(max) = 'Praesent',
@house int = 173,
@title nvarchar(max) = 'ultrices a,'

select * from DeliveriesWithAllKeys
where 
	Street = @street and
	House = @house and
	Title = @title	
go


-- 3
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле
-- Цена 1 экземпляра находится в заданном диапазоне значений

-- EditionsByPriceInRange
declare 
	@min money = 500,
	@max money = 1000

select * from Editions
where Price between @min and @max
go


-- 4
-- Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания

-- DeliveriesByPublicationType
declare @type nvarchar(max) = (select [Type] from EditionTypes where Id = 1)

select 
	[Name],
	Surname,
	Patronymic,
	PassportNumber,
	Street,
	House,
	Apartment
from DeliveriesWithAllKeys
where [Type] = @type
go


-- 5
-- Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных подписках, для 
-- которых срок подписки есть значение из некоторого диапазона. 
-- Нижняя и верхняя границы диапазона задаются при выполнении запроса

-- DeliveriesByTermRange
declare
	@min int = 3,
	@max int = 7

select *
from DeliveriesWithAllKeys
where Term between @min and @max
go


-- 6
-- Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
-- Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки,
-- Срок подписки, Стоимость подписки без НДС. Сортировка по полю Индекс издания

-- DeliveriesWithSubscriptionPrice
select 
	[Index], 
	Title, 
	Price as OneCopyPrice,
	StartSubscribe,
	Term,
	dbo.CalculateSubscriptionPrice(Price, Term, 1) as SubscriptionPrice
from DeliveriesWithAllKeys
order by [Index]
go


-- 7
-- Выполняет группировку по полю Вид издания. 
-- Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра

-- EditionsGroupingTypeWithMinMaxPrice
select 
	Type,
	Min(Price) as MinPrice,
	Max(Price) as MaxPrice
from EditionsWithTypes
group by [Type]
go


-- 8
-- Выполняет группировку по полю Улица. Для всех улиц вычисляет количество подписчиков,
-- проживающих на данной улице (итоги по полю Код получателя)

-- DeliveriesGroupingStreetWithSubscribersCount
select 
	Street, 
	Count(Street) as SubscribersCount
from DeliveriesWithAllKeys
group by Street
go


-- 9
-- Для всех изданий выводит количество оформленных подписок

-- DeliveriesGroupingTypeWithSubscribersCount
select 
	[Type],
	Count ([Type]) as SubscribesCount
from DeliveriesWithAllKeys
group by [Type]
go

