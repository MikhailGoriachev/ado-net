﻿namespace DemoLinqToSql.Models.Task1
{
    // Книга имеет следующие поля: идентификатор, идентификатор автора, 
    // название книги, год издания, цена.
    public class Book
    {
        // идентификатор книги
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        // идентификатор автора
        private int _idAuthor;
        public int IdAuthor
        {
            get { return _idAuthor; }
            set { _idAuthor = value; }
        }

        // название книги
        private string _title;

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        // год издания
        private int _pubYear;

        public int PubYear
        {
            get { return _pubYear; }
            set { _pubYear = value; }
        }

        // цена
        private int _price;

        public int Price
        {
            get { return _price; }
            set { _price = value; }
        }

    } // class Book
}
