﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW.Application;
using HW.Helpers;
using Microsoft.VisualBasic;

namespace HW
{
    internal class Program{
        static void Main(string[] args)
        {
            Console.Title = "Задание на 13.01.2022. Гайдаш Дмитрий";

            // простейшее меню приложения
            List<MenuItem> menu = new List<MenuItem>(new[]{
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Разработать расширяющий метод для класса товар" },
                //-----------------------------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.O, Text = "Separator" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Вычисление кол-ва элементов массива, со значениями в дипазоне от A до B" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Вычисление кол-ва элементов массива, равных 0" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Вычисление суммы элементов массива, расположенных после первого макс. элемента" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Вычисление суммы элементов массива, расположенных перед посл. мин. по модулю эл." },
                //------------------------------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.O, Text = "Separator" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            });

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.Black);
                    Console.Clear();

                    switch (key){

                        // Задача 1
                        case ConsoleKey.Q:
                            app.Task1_1();
                            break;

                        // Задача 2. Вычисление кол-ва элементов массива, со значениями в дипазоне от A до B
                        case ConsoleKey.A:
                            app.Task2_1();
                            break;

                        // Задача 2. Вычисление кол-ва элементов массива, равных 0
                        case ConsoleKey.S:
                            app.Task2_2();
                            break;

                        // Задача 2. Вычисление суммы элементов массива, расположенных после первого максимального элемента
                        case ConsoleKey.D:
                            Utils.ShowUnderConstruction();
                            break;

                        // Задача 2. Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом
                        case ConsoleKey.F:
                            Utils.ShowUnderConstruction();
                            break;

                        // Выход из приложения назначен на клавишу F10 или клавишу Z или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex){
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}
