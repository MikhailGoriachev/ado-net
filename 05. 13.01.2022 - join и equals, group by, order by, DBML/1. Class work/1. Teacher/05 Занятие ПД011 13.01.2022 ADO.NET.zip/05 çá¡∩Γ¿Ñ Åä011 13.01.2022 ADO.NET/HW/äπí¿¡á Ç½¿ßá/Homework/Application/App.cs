﻿using System;
using System.Configuration;
using Homework.Controllers;
using Homework.Helpers;

namespace Homework.Application
{

    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    internal partial class App {
        Task2Controller _task2Controller;
        GoodsController _goodsController;


        // конструктор
        public App() {
            _task2Controller = new Task2Controller();
            _goodsController = new GoodsController();
        } // App

    } // class App
}