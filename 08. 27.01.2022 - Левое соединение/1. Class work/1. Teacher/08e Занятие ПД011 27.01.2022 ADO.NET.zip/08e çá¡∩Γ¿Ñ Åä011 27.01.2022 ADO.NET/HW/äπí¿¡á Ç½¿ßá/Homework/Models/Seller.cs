﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
    internal class Seller {
        // идентификатор
        public int Id { get; set; } // Id

        // Имя продавца
        public string Name { get; set; } // Name

        // Фамилия продавца
        public string Surname { get; set; } // Surname

        // Отчество продавца
        public string Patronymic { get; set; } // Patronymic

        // процент комиссионного вознаграждения за продажу
        public double Interest { get; set; } // Interest

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {Id,3} │ {Surname, 15} │ {Name,11} │ {Patronymic,15} │ {Interest,20:f2} % │";

        // статический метод для вывода шапки таблицы
        public static string Header() =>
                $"  ┌─────┬─────────────────┬─────────────┬─────────────────┬────────────────────────┐\n" +
                $"  │ ID  │ Фамилия         │ Имя         │ Отчество        │ Процент вознаграждения │\n" +
                $"  ├─────┼─────────────────┼─────────────┼─────────────────┼────────────────────────┤";

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────┴─────────────────┴─────────────┴─────────────────┴────────────────────────┘\n";
    } // Seller
}
