﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Homework.Models;
using Homework.Views;

namespace Homework.Controllers
{
	public class Task1Controller
	{
		private List<Author> _authors;
		private List<Book> _books;

		public Task1Controller()
		{
			_authors = new List<Author>
			{
				new() {Id = 1, Fullname = "Шилдт Г."		,BirthYear=1951},
				new() {Id = 2, Fullname = "Кент Дж."		,BirthYear=1961},
				new() {Id = 3, Fullname = "Абрамян М.Э."	,BirthYear=1965},
				new() {Id = 4, Fullname = "Дейтел П."		,BirthYear=1964},
				new() {Id = 5, Fullname = "Кузнецов И.А." ,BirthYear=1958},
				new() {Id = 6, Fullname = "Егоренко В.Н." ,BirthYear=1966},
				new() {Id = 7, Fullname = "Кравец С.А."   ,BirthYear=1957}
			};

			_books = new List<Book>
			{
				new(){Id=1, IdAuthor = 2, Title = "Экстремальное программирование", Year = 2001, Price =150 },
				new(){Id=2, IdAuthor = 3, Title = "Задачник по программированию", Year = 2005, Price =350 },
				new(){Id=3, IdAuthor = 4, Title = "Как программировать на Android", Year = 2011, Price =520 },
				new(){Id=4, IdAuthor = 5, Title = "Мои походы за бугор", Year = 1988, Price =15 },
				new(){Id=5, IdAuthor = 4, Title = "Как программировать на C++", Year = 1995, Price =590 },
				new(){Id=6, IdAuthor = 6, Title = "WPF - введение в технологию", Year = 2007, Price =890 },
				new(){Id=7, IdAuthor = 7, Title = "Andriod для профессионалов", Year = 2016, Price =510 },
				new(){Id=8, IdAuthor = 4, Title = "Как программировать в C#.NET", Year = 2009, Price =480 },
				new(){Id=9, IdAuthor = 3, Title = "Сборник задач по LINQ", Year = 2012, Price =390 },
				new(){Id=10, IdAuthor = 5, Title = "С хоббитом туда и обратно", Year = 2011, Price =35 },
				new(){Id=11, IdAuthor = 1, Title = "Базовый курс C++", Year = 2010, Price =280 },
				new(){Id=12, IdAuthor = 6, Title = "WCF - технология распреденных приложений", Year = 2012, Price =360 },
				new(){Id=13, IdAuthor = 1, Title = "Полное руководство Java SE 8", Year = 2014, Price =490 },
				new(){Id=14, IdAuthor = 4, Title = "Руководство по разработке под Android", Year = 2016, Price =680 },
				new(){Id=15, IdAuthor = 6, Title = "Типичные задачи по LINQ в оперативном учете", Year = 2012, Price =350 },
				new(){Id=16, IdAuthor = 4, Title = "Взгляд на Android для профессионалов", Year = 2016, Price =580 },
				new(){Id=17, IdAuthor = 6, Title = "Практикум по Python 3.7", Year = 2019, Price =410 },
			};
		}

		public List<BookView> Query01A() =>
				(from book in _books
				join author in _authors on book.IdAuthor equals author.Id
				select new BookView
				{
					Id = book.Id,
					Title = book.Title,
					Author = author.Fullname,
					Year = book.Year,
					Price = book.Price
				}).ToList();

		public List<BookView> Query01B() =>
			_books.Join(_authors, book => book.IdAuthor, author => author.Id,
			(book, author) => new BookView
			{
				Id = book.Id,
				Title = book.Title,
				Author = author.Fullname,
				Year = book.Year,
				Price = book.Price
			}).ToList();

		// Вывести книги авторов, год рождения которых принадлежит заданном диапазону
		public List<BookView> Query02A(int from = 1955, int to = 1960) =>
			(from book in _books
				join author in _authors on book.IdAuthor equals author.Id
			    where author.BirthYear >= @from && author.BirthYear <= to
				select new BookView
				{
					Id = book.Id,
					Title = book.Title,
					Author = author.Fullname,
					Year = book.Year,
					Price = book.Price
				}).ToList();

		public List<BookView> Query02B(int from = 1955, int to = 1960) => 
			_books.Join(_authors.Where(a => a.BirthYear >= from && a.BirthYear <= to),
			book => book.IdAuthor, author => author.Id,
			(book, author) => new BookView
			{
				Id = book.Id,
				Title = book.Title,
				Author = author.Fullname,
				Year = book.Year,
				Price = book.Price
			}).ToList();

		// Вывести книги, в названии которых содержится заданная подстрока и цена не превышает заданного значения
		public List<BookView> Query03A(string substr, int price) => 
			(from book in _books
			join author in _authors on book.IdAuthor equals author.Id
			where book.Title.ToUpper().Contains(substr.ToUpper()) && book.Price <= price
			select new BookView
		{
			Id = book.Id,
			Title = book.Title,
			Author = author.Fullname,
			Year = book.Year,
			Price = book.Price
		}).ToList();

	public List<BookView> Query03B(string substr, int price) =>
		_books.Where(b => b.Title.ToUpper().Contains(substr.ToUpper()) && b.Price <= price)
			.Join(_authors, book => book.IdAuthor, author => author.Id,
			(book, author) => new BookView
			{
				Id = book.Id,
				Title = book.Title,
				Author = author.Fullname,
				Year = book.Year,
				Price = book.Price
			}).ToList();

		// Список авторов и количество их книг в коллекции
		public List<ResultQuery04> Query04A() =>
			(from book in _books
				join author in _authors on book.IdAuthor equals author.Id
				group author by author.Fullname
				into groupAuthors
				select new ResultQuery04
				{
					Fullname = groupAuthors.Key,
					Amount = groupAuthors.Count()
				}).ToList();
				

		public List<ResultQuery04> Query04B() =>
			_books.Join(_authors, book => book.IdAuthor, author => author.Id,
					(book, author) => new BookView
					{
						Id = book.Id,
						Title = book.Title,
						Author = author.Fullname,
						Year = book.Year,
						Price = book.Price
					})
				.GroupBy(b => b.Author, 
					(key, group) => new ResultQuery04
					{
						Fullname = key,
						Amount = group.Count()
					}).ToList();

		// Средняя цена книг по годам издания
		public List<ResultQuery05> Query05A() =>
					(from book in _books
						group book by book.Year
						into groupBooks
						select new ResultQuery05
					{
						Year = groupBooks.Key,
						AvgPrice = groupBooks.Average(b => b.Price),
						Amount = groupBooks.Count()
					}).ToList();

		public List<ResultQuery05> Query05B() => _books.GroupBy(b => b.Year, (key, group) => new ResultQuery05()
					{
						Year = key,
						AvgPrice = group.Average(b => b.Price),
						Amount = group.Count()
					}).ToList();

		// Список авторов по убыванию количества их книг в коллекции
		public List<ResultQuery04> Query06A() =>
			(from book in _books
				join author in _authors on book.IdAuthor equals author.Id
				group author by author.Fullname
				into groupAuthors
				orderby groupAuthors.Count() descending
			 select new ResultQuery04()
				{
					Fullname = groupAuthors.Key,
					Amount = groupAuthors.Count(),
				}).ToList();

		public List<ResultQuery04> Query06B() =>
			_books.Join(_authors, book => book.IdAuthor, author => author.Id,
					(book, author) => new BookView
					{
						Id = book.Id,
						Title = book.Title,
						Author = author.Fullname,
						Year = book.Year,
						Price = book.Price
					})
				.GroupBy(b => b.Author,
					(key, group) => new ResultQuery04
					{
						Fullname = key,
						Amount = group.Count()
					}).OrderByDescending(x => x.Amount).ToList();

		// Средний возраст книг по авторам, с упорядочиванием фамилий и инициалов авторов по алфавиту
		public List<ResultQuery07> Query07A() =>
			(from book in _books
			 join author in _authors on book.IdAuthor equals author.Id
			 select new BookView
			 {
				 Id = book.Id,
				 Title = book.Title,
				 Author = author.Fullname,
				 Year = book.Year,
				 Price = book.Price
			 } into list
			 group list by list.Author
				into groupAuthors
			 orderby groupAuthors.Key
			 select new ResultQuery07
			 {
				 Fullname = groupAuthors.Key,
				 AvgAge = groupAuthors.Average(b => DateTime.Now.Year - b.Year),
				 Amount = groupAuthors.Count()
			 }).ToList();

		public List<ResultQuery07> Query07B() => 
			_books.Join(_authors, book => book.IdAuthor, author => author.Id,
				(book, author) => new BookView
				{
					Id = book.Id,
					Title = book.Title,
					Author = author.Fullname,
					Year = book.Year,
					Price = book.Price
				})
			.GroupBy(b => b.Author,
				(key, group) => new ResultQuery07
				{
					Fullname = key,
					AvgAge = group.Average(b => DateTime.Now.Year - b.Year),
					Amount = group.Count()
				}).OrderBy(x => x.Fullname).ToList();
	}

}
