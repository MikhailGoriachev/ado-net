﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Controllers;

namespace Homework.Application
{
	internal partial class App
	{
		private Menu _mainMenu;

		private Task1Controller _task1Controller;
		private Task2Controller _task2Controller;
		private Task3Controller _task3Controller;

		public App() 
		{
			_task1Controller = new Task1Controller();
			_task2Controller = new Task2Controller();
			_task3Controller = new Task3Controller();
			InitMenu();
		}
		

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem {Text = "Задача 1. Демонстрация работы расширяющего метода.", Callback = Task1Item1},
					new Menu.MenuItem {Text = "Задача 2. Кол-во элеметов со значениями в диапазоне от A до B.", Callback = Task2Item1},
					new Menu.MenuItem {Text = "Задача 2. Кол-во элеметов массива, равыных нулю.", Callback = Task2Item2},
					new Menu.MenuItem {Text = "Задача 2. Сумма элементов массива, расположенных после первого максимального элемента.", Callback = Task2Item3},
					new Menu.MenuItem {Text = "Задача 2. Сумма элементов массива, расположенных перед последним минимальным по модулю элементом.", Callback = Task2Item4},
					new Menu.MenuItem {Text = "Задача 3. Товары с заданным диапазоном цен.", Callback = Task3Item1},
					new Menu.MenuItem {Text = "Задача 3. Сумма товаров с заданным годом выпуска.", Callback = Task3Item2},
					new Menu.MenuItem {Text = "Задача 3. Сумма товаров с заданным наименованием.", Callback = Task3Item3},
					new Menu.MenuItem {Text = "Задача 3. Наименование и год выпуска товаров с максимальным количеством.", Callback = Task3Item4},
					new Menu.MenuItem {Text = "Задача 3. Товары, для которых произведение цены на количество находится в заданном диапазоне.", Callback = Task3Item5},
					new Menu.MenuItem {Text = "Выход"}
				}, new Point(5, 5),
				"Меню приложения");
		}
		public void Run() =>_mainMenu.Run();

	}
}
