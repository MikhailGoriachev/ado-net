﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;        // для ADO.NET
using System.Data;

namespace H_W2Ado.Application
{
    internal partial class App
    {
        // Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public void Task2Query01(string connectingString)
        {
            Console.WriteLine("\n Запрос 1\n Выбирает информацию обо всех фактах проката" +
                " автомобиля с заданным госномером.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery01");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@numCar", "X739OC");

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-10} | {reader.GetName(1),-7} | " +
                        $"{reader.GetName(2),-10} | {reader.GetName(3),-6} |" +
                        $" {reader.GetName(4),-10} | {reader.GetName(5),15} | " +
                        $"{reader.GetName(6),12} | {reader.GetName(7),9} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-10} | {reader.GetString(1),-7} | " +
                            $"{reader.GetString(2),-10} | {reader.GetString(3),-6} | " +
                            $"{reader.GetString(4),-10} | {reader.GetDateTime(5),15:d} | " +
                            $"{reader.GetInt32(6),12} | {reader.GetInt32(7),9} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Task2Query01


        // Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
        public void Task2Query02(string connectingString)
        {
            Console.WriteLine("\n Запрос 2\n Выбирает информацию обо всех фактах проката" +
                " автомобиля с заданной моделью/брендом\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery02");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@modelCar", "Lexus");

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-10} | {reader.GetName(1),-7} | " +
                        $"{reader.GetName(2),-10} | {reader.GetName(3),-6} |" +
                        $" {reader.GetName(4),-10} | {reader.GetName(5),15} | " +
                        $"{reader.GetName(6),12} | {reader.GetName(7),9} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-10} | {reader.GetString(1),-7} | " +
                            $"{reader.GetString(2),-10} | {reader.GetString(3),-6} | " +
                            $"{reader.GetString(4),-10} | {reader.GetDateTime(5),15:d} | " +
                            $"{reader.GetInt32(6),12} | {reader.GetInt32(7),9} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Task2Query02


        // Выбирает информацию об автомобиле с заданным госномером
        public void Task2Query03(string connectingString)
        {
            Console.WriteLine("\n Запрос 3\n Выбирает информацию об автомобиле с заданным госномером.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery03");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@numCar", "H730CA");

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-10} | {reader.GetName(1),-7} | " +
                        $"{reader.GetName(2),-10} | {reader.GetName(3), 6} |" +
                        $" {reader.GetName(4), 12} | {reader.GetName(5),12} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-10} | {reader.GetString(1),-7} | " +
                            $"{reader.GetString(2),-10} | {reader.GetInt32(3), 6} | " +
                            $"{reader.GetInt32(4), 12} | {reader.GetInt32(5),12} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Task2Query03


        // Выбирает информацию о клиентах по серии и номеру паспорта
        public void Task2Query04(string connectingString)
        {
            Console.WriteLine("\n Запрос 4\n Выбирает информацию о клиентах по серии и номеру паспорта.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery04");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@passportNum", "OH830853");

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0), 6} | {reader.GetName(1),-10} | " +
                        $"{reader.GetName(2),-10} | {reader.GetName(3),-10} |" +
                        $" {reader.GetName(4),-12} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetInt32(0), 6} | {reader.GetString(1),-10} | " +
                            $"{reader.GetString(2),-10} | {reader.GetString(3),-10} | " +
                            $"{reader.GetString(4),-12} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Task2Query04


        // Выбирает информацию обо всех зафиксированных фактах проката автомобилей в
        // некоторый заданный интервал времени
        public void Task2Query05(string connectingString)
        {
            Console.WriteLine("\n Запрос 5\n Выбирает информацию обо всех зафиксированных фактах проката автомобилей в\n" +
                " некоторый заданный интервал времени.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery05");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@fromDate", "05-01-2021");
                cmd.Parameters.AddWithValue("@toDate", "10-01-2021");

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-10} | {reader.GetName(1),-7} | " +
                        $"{reader.GetName(2),-10} | {reader.GetName(3),-7} |" +
                        $" {reader.GetName(4),-10} | {reader.GetName(5),15} | " +
                        $"{reader.GetName(6),12} | {reader.GetName(7),9} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-10} | {reader.GetString(1),-7} | " +
                            $"{reader.GetString(2),-10} | {reader.GetString(3),-7} | " +
                            $"{reader.GetString(4),-10} | {reader.GetDateTime(5),15:d} | " +
                            $"{reader.GetInt32(6),12} | {reader.GetInt32(7),9} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Task2Query05


        // Вычисляет для каждого факта проката стоимость проката.
        // Включает поля Дата проката, Госномер автомобиля, Модель автомобиля,
        // Стоимость проката. Сортировка по полю Дата проката
        public void Task2Query06(string connectingString)
        {
            Console.WriteLine("\n Запрос 6\n Вычисляет для каждого факта проката стоимость проката.\n" +
                " Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.\n" +
                " Сортировка по полю Дата проката.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery06");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0), 15} | {reader.GetName(1),-10} | " +
                        $"{reader.GetName(2),-10} | {reader.GetName(3), 11} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetDateTime(0), 15:d} | {reader.GetString(1),-10} | " +
                            $"{reader.GetString(2),-10} | {reader.GetInt32(3),11} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Task2Query06


        // Для всех клиентов прокатной фирмы вычисляет количество фактов проката, суммарное количество дней проката,
        // упорядочивание по убыванию суммарного количества дней проката
        public void Task2Query07(string connectingString)
        {
            Console.WriteLine("\n Запрос 7\n Для всех клиентов прокатной фирмы вычисляет количество фактов проката,\n" +
                " суммарное количество дней проката, упорядочивание по\n" +
                " убыванию суммарного количества дней проката.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery07");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-15} | {reader.GetName(1),12} | " +
                        $"{reader.GetName(2),13} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-15} | " +
                            $"{reader.GetInt32(1),12} | {reader.GetInt32(2),13} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Task2Query07


        // Выбирает информацию о фактах проката автомобилей по госномеру:
        // количество фактов проката, сумма за прокаты, суммарная длительность прокатов
        public void Task2Query08(string connectingString)
        {
            Console.WriteLine("\n Запрос 8\n Выбирает информацию о фактах проката автомобилей по госномеру:\n" +
                " количество фактов проката, сумма за прокаты, суммарная длительность прокатов.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery08");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-12} | {reader.GetName(1),12} | " +
                        $"{reader.GetName(2),10} | {reader.GetName(3),13} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-12} | {reader.GetInt32(1),12} | " +
                            $"{reader.GetInt32(2),10} | {reader.GetInt32(3),13} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Task2Query08

    }// class App
}
