﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using TrainTickets.Helpers;

namespace TrainTickets.Models
{
    // Класс купе - свойства: тип, количество мест, список мест
    [DataContract]
    public class Compartment
    {
        private Utils.TrainCarType _type;
        [DataMember]
        public Utils.TrainCarType Type {
            get => _type;
            set => _type = value;
        } // Type


        private Seat[] _seats;
        [DataMember]
        public Seat[] Seats { 
            get => _seats;
            set => _seats = value;
        } // Seats

        public int LastNum { get; private set; }

        public Compartment(Utils.TrainCarType type, int lastPlaceNum) {
            _type = type;
            Initialize(lastPlaceNum);
        } // Compartment

        public void Initialize(int lastPlaceNum) {
            _seats = new Seat[(int)_type];
            for (int i = 0; i < _seats.Length; i++) {
                _seats[i] = new Seat(lastPlaceNum, Utils.GetRandom(0, 1) == 0);
                lastPlaceNum++;
            } // for i
            LastNum = _seats[_seats.Length - 1].Number + 1;
        } // Initialize

        // кол-во проданных билетов
        public int CountSales(Utils.TrainCarType type) {
            if (_type != type) return 0;
            int count = 0;
            for (int i = 0; i < _seats.Length; i++)
                count += _seats[i].State ? 0 : 1;
            return count;
        } // CountSales

        // кол-во билетов
        public int Count(Utils.TrainCarType type) {
            if (_type != type) return 0;
            return _seats.Length;
        } // Count

        // кол-во проданных билетов
        public int CountSales(){
            int count = 0;
            for (int i = 0; i < _seats.Length; i++)
                count += _seats[i].State ? 0 : 1;
            return count;
        } // CountSales

        // кол-во билетов
        public int Count() => _seats.Length;

    } // Compartment
}
