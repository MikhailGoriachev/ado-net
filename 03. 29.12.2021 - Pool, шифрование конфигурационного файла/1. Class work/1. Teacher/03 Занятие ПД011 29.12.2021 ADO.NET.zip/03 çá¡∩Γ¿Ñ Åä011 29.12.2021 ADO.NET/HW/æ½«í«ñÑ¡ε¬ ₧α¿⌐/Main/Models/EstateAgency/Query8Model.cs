﻿using System;
using System.Data;
using Main.Infrastructure;
using Main.Utilities.TableFormatter;


namespace Main.Models.EstateAgency
{
	public class Query8Model : IMappable<Query8Model>
	{
		/*
		select
			a.Street,
			Sum(a.Price) as Total
		from Apartments a
		left join Deals d on d.ApartmentId = a.ApartmentsId
		group by a.Street
		order by Total desc 
		*/

		[TableData("Улица", "{0, -25}")]
		public string? Street { get; set; }

		[TableData("Сумма сделок", "{0, -18:N0}")]
		public decimal Total { get; set; }

		public Query8Model Map(DataRow row) =>
			new()
			{
				Street = (string)row["Street"],
				Total = (decimal)(Convert.IsDBNull(row["Total"]) ? 0m : row["Total"]),
			};
	}
}