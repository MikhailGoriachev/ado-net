﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	public class SellerViewModel
	{
		public int Id { get; set; }

		public string SurnameNP { get; set; }

		public double Interest { get; set; }
	}
}
