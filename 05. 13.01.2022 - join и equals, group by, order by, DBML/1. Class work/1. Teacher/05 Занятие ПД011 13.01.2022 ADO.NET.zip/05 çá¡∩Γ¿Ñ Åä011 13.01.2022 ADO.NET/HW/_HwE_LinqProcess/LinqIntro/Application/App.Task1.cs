﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqIntro.Helpers;

namespace LinqIntro.Application
{
    /*
     * Методы для решения задачи 1
     */
    public partial class App
    {

        // Вывести список товаров в коллекции для задач 1 и 3
        public void ShowGoods() {
            Utils.ShowNavBarTask("   Список товаров в коллекции для задач 1 и 3");
            
            _task1Controller.ShowGoods("\n\n\n\n    Товары для обработки\n");
        } // ShowGoods


        // Демонстрация расширяющего метода класса Goods
        public void ExtentionMethodDemo() {
            Utils.ShowNavBarTask("    Демонстрация расширяющего метода класса Goods");

            _task1Controller.ExtendMethodDemo();
        } // ExtentionMethodDemo

    } // class App
}
