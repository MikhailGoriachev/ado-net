﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2ADO.NET.Controllers
{
    class QueriesController
    {
        private string _stringConnection;   //строка подключения к базе данных
        public string StringConnection
        {
            get { return _stringConnection; }
            set { _stringConnection = value; }
        }

        //конструктор
        public QueriesController() 
            => _stringConnection = @"
            Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Students\ПД011\06 ADO.NET\03 Занятие ПД011 29.12.2021 ADO.NET\HW\Пилюгин Даниил\2ADO.NET\App_Data\DB.mdf"";Integrated Security=True";
  //public QueriesController() 
  //          => _stringConnection = @"
  //          Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Мои программы\ADO.NET\2ADO.NET\2ADO.NET\App_Data\DB.mdf"";Integrated Security=True";

        public void Query01(string street, int rooms)
        {
            string query = "ShowByStreetsAndRooms";

            using (SqlConnection connection = new SqlConnection(_stringConnection))
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@street", street);
                cmd.Parameters.AddWithValue("@rooms", rooms);

                connection.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    Console.WriteLine("\n\n\t _______________________________________________________________________________\n" +
                                      $"\t│ {reader.GetName(0),-11} │     {reader.GetName(1),-11} " +
                                      $"│  {reader.GetName(2),-14} │ {reader.GetName(3),4} " +
                                      $"│ {reader.GetName(4),4} │ {reader.GetName(5),7}    │"
                                      + "\n\t│_____________│_________________│_________________│________│_______│____________│");

                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetString(0),-11} " +
                            $"│      {reader.GetString(1),-8} " +
                            $"│         {reader.GetInt32(2),-7} " +
                            $"│   {reader.GetDouble(3),-4} " +
                            $"│   {reader.GetInt32(4),-3} " +
                            $"│    {reader.GetInt32(5),-7} │");
                    }
                    Console.WriteLine("\t│_____________│_________________│_________________│________│_______│____________│");
                }
            }
        }
        public void Query02(string surname, int percent)
        {
            string query = "ShowBySurnameAndPercent";

            using (SqlConnection connection = new SqlConnection(_stringConnection))
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@surname", surname);
                cmd.Parameters.AddWithValue("@percent", percent);

                connection.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    Console.WriteLine("\n\n\t __________________________________________________________\n" +
                                      $"\t│ {reader.GetName(0),-11} │     {reader.GetName(1),-11} " +
                                      $"│  {reader.GetName(2),-14} │ {reader.GetName(3),4} │" +
                                       "\n\t│_____________│_________________│_________________│________│");

                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetString(0),-11} " +
                            $"│ {reader.GetString(1),-15} " +
                            $"│ {reader.GetString(2),-15} " +
                            $"│   {reader.GetInt32(3),-5}│");
                    }
                    Console.WriteLine("\t│_____________│_________________│_________________│________│");
                }
            }
        }

        public void Query03(int rooms, int lo, int hi)
        {
            string query = "ShowByRoomsAndCost";

            using (SqlConnection connection = new SqlConnection(_stringConnection))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection)
                    { CommandType = System.Data.CommandType.StoredProcedure };
                cmd.Parameters.AddWithValue("@rooms", rooms);
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                SqlDataReader reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    Console.WriteLine("\n\n\t _____________________________________________________________________________\n" +
                                      $"\t│ {reader.GetName(0),-11} │     {reader.GetName(1),-11} " +
                                      $"│  {reader.GetName(2),-14} │ {reader.GetName(3),4} " +
                                      $"│  {reader.GetName(4),4} │ {reader.GetName(5),-7} │"
                                      + "\n\t│_____________│_________________│_________________│_______│_________│_________│");

                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetString(0),-11} " +
                            $"│ {reader.GetString(1),-15} " +
                            $"│ {reader.GetInt32(2),-15} " +
                            $"│   {reader.GetInt32(3),-3} " +
                            $"│   {reader.GetDouble(4),-5} " +
                            $"│ {reader.GetInt32(5),-6}  │");
                    }
                    Console.WriteLine("\t│_____________│_________________│_________________│_______│_________│_________│");

                }
            }
        }
        public void Query04(int rooms)
        {
            string query = "ShowByRooms";

            using (SqlConnection connection = new SqlConnection(_stringConnection))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection)
                    { CommandType = System.Data.CommandType.StoredProcedure };

                cmd.Parameters.AddWithValue("@rooms", rooms);

                SqlDataReader reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    Console.WriteLine("\n\n\t _____________________________________________________________________________\n" +
                                      $"\t│ {reader.GetName(0),-11} │     {reader.GetName(1),-11} " +
                                      $"│  {reader.GetName(2),-14} │ {reader.GetName(3),4} " +
                                      $"│  {reader.GetName(4),4} │ {reader.GetName(5),-7} │"
                                      + "\n\t│_____________│_________________│_________________│_______│_________│_________│");

                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetString(0),-11} " +
                            $"│ {reader.GetString(1),-15} " +
                            $"│ {reader.GetInt32(2),-15} " +
                            $"│   {reader.GetInt32(3),-3} " +
                            $"│   {reader.GetDouble(4),-5} " +
                            $"│ {reader.GetInt32(5),-6}  │");
                    }
                    Console.WriteLine("\t│_____________│_________________│_________________│_______│_________│_________│");

                }
            }
        }
        public void Query05(int rooms, int lo, int hi)
        {
            string query = "ShowByRoomsAndSquare";

            using (SqlConnection connection = new SqlConnection(_stringConnection))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection)
                    { CommandType = System.Data.CommandType.StoredProcedure };

                cmd.Parameters.AddWithValue("@rooms", rooms);
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                SqlDataReader reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    Console.WriteLine("\n\n\t _____________________________________________________________________________\n" +
                                      $"\t│ {reader.GetName(0),-11} │     {reader.GetName(1),-11} " +
                                      $"│  {reader.GetName(2),-14} │ {reader.GetName(3),4} " +
                                      $"│  {reader.GetName(4),4} │ {reader.GetName(5),-7} │"
                                      + "\n\t│_____________│_________________│_________________│_______│_________│_________│");

                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetString(0),-11} " +
                            $"│ {reader.GetString(1),-15} " +
                            $"│ {reader.GetInt32(2),-15} " +
                            $"│   {reader.GetInt32(3),-3} " +
                            $"│   {reader.GetDouble(4),-5} " +
                            $"│ {reader.GetInt32(5),-6}  │");
                    }
                    Console.WriteLine("\t│_____________│_________________│_________________│_______│_________│_________│");

                }
            }
        }
        public void Query06()
        {
            string query = "ShowByCom";

            using (SqlConnection connection = new SqlConnection(_stringConnection))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection)
                    { CommandType = System.Data.CommandType.StoredProcedure };

                SqlDataReader reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    Console.WriteLine("\n\n\t _____________________________________________________________________________________\n" +
                                      $"\t│ {reader.GetName(0),-11} │     {reader.GetName(1),-11} " +
                                      $"│  {reader.GetName(2),-14} │ {reader.GetName(3),4} " +
                                      $"│  {reader.GetName(4),4} │ {reader.GetName(5),-7} │"
                                      + "\n\t│_____________│_________________│_________________│____________│_______│______________│");

                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetString(0),-11} " +
                            $"│ {reader.GetString(1),-15} " +
                            $"│ {reader.GetString(2),-15} " +
                            $"│ {reader.GetDateTime(3).ToShortDateString(),-3} " +
                            $"│ {reader.GetInt32(4),-5} " +
                            $"│     {reader.GetInt32(5),-7}  │");
                    }
                    Console.WriteLine("\t│_____________│_________________│_________________│____________│_______│______________│");

                }
            }
        }

    }
}

