﻿namespace Main
{
	internal static class Program
	{
		public static void Main(string[] args) =>
			new App().Run();
	}
}