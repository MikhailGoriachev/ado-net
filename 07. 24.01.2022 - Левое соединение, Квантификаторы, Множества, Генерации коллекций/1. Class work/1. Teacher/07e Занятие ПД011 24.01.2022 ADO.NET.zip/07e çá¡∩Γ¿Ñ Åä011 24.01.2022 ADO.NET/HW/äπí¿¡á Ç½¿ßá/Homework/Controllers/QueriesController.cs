﻿using Homework.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
    class QueriesController
    {
        // контекст данных - подключение к базе данных
        private WholesaleDataContext _db;
        public QueriesController() { 
            _db = new WholesaleDataContext();
        } // Task2Controller

        public List<Persons> GetPersons() => _db.Persons.ToList();
        public List<Goods> GetGoods() => _db.Goods.ToList();
        public List<Units> GetUnits() => _db.Units.ToList();
        public List<Purchase> GetPurchases() {
            return _db.Purchases
                .Select(purchase => new Purchase {
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                }).ToList();
        } // GetPurchases

        public List<Seller> GetSellers() =>
            _db.Sellers
                .Select(seller => new Seller {
                    Id = seller.Id,
                    Interest = seller.Interest,
                    Name = seller.Persons.Name,
                    Surname = seller.Persons.Surname,
                    Patronymic = seller.Persons.Patronymic,
                }).ToList();

        public List<Sale> GetSales() =>
            _db.Sales
                .Select(sale => new Sale {
                    Id = sale.Id,
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    Unit = sale.Units.Short,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                    Seller = sale.Sellers.Persons.Surname + " " +
                    sale.Sellers.Persons.Name.Substring(0, 1) + ". " +
                    sale.Sellers.Persons.Patronymic.Substring(0, 1) + "."
                }).ToList();

        // Информация о товарах, единица измерения которых «шт» (штуки) и цена закупки меньше 200 руб
        public List<Purchase> Query01(string unit = "шт", int price = 200) =>
            _db.Purchases
                .Where(purchase => purchase.Units.Short == unit && purchase.Price < price)
                .Select(purchase => new Purchase {
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                }).ToList();


        // Информация о товарах, цена закупки которых больше 500 руб
        public List<Purchase> Query02(int price = 500) =>
             _db.Purchases
                .Where(purchase => purchase.Price > price)
                .Select(purchase => new Purchase {
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                }).ToList();


        // Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1800 руб
        public List<Purchase> Query03(string good, int price = 1800) =>
            _db.Purchases
                .Where(purchase => purchase.Price > price && purchase.Goods.Item == good)
                .Select(purchase => new Purchase {
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                }).ToList();


        // Информация о продавцах с заданным значением процента комиссионных.
        public List<Seller> Query04(double interest) =>
            _db.Sellers
                .Where(seller => seller.Interest == interest)
                .Select(seller => new Seller {
                    Id = seller.Id,
                    Interest = seller.Interest,
                    Name = seller.Persons.Name,
                    Surname = seller.Persons.Surname,
                    Patronymic = seller.Persons.Patronymic,
                }).ToList();


        // Информация о фактах продажи, для которых цена продажи в заданном диапазоне
        public List<Sale> Query05(int lo, int hi) =>
            _db.Sales
                .Where(sale => sale.Price >= lo && sale.Price <= hi)
                .Select(sale => new Sale {
                    Id = sale.Id,
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    Unit = sale.Units.Short,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                    Seller = sale.Sellers.Persons.Surname + " " +
                    sale.Sellers.Persons.Name.Substring(0, 1) + ". " +
                    sale.Sellers.Persons.Patronymic.Substring(0, 1) + "."
                }).ToList();


        
        // Вычислить прибыль от продажи за каждый проданный товар
        public List<ResultQuery06> Query06() =>
            _db.Sales
                .Select(sale => new ResultQuery06 {
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                }).ToList();


        // Вычислить среднюю цену закупки товара и количество закупок для каждого товара
        public List<ResultQuery07and08> Query07() =>
            _db.Purchases
                .Select(purchase => new { 
                    purchase.Goods.Item,
                    purchase.Price,
                    purchase.Amount
                }).GroupBy(item => item.Item,
                    (key, group) => new ResultQuery07and08{
                        Title = key,
                        Amount = group.Sum(x => x.Amount),
                        Average = group.Average(x => x.Price)
                    }).ToList();

        // Вычислить среднее значение по полю Цена продажи единицы товара и кол-во продаж для каждого продавца
        public List<ResultQuery07and08> Query08() =>
            _db.Sales
                .Select(sale => new {
                    Saller = sale.Sellers.Persons.Surname + " " + 
                        sale.Sellers.Persons.Name.Substring(0, 1) + ". " +
                        sale.Sellers.Persons.Patronymic.Substring(0, 1) + ".",
                    sale.Price,
                    sale.Amount
                }).GroupBy(item => item.Saller,
                    (key, group) => new ResultQuery07and08{
                        Title = key,
                        Amount = group.Sum(x => x.Amount),
                        Average = group.Average(x => x.Price)
                    }).ToList();


    } // Task2Controller
}
