﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
using Realestate.Helpers;
using Realestate.Application;

namespace Realestate
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создание экземпляра класса приложения
            App app = new App(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\ШАГ\ПД011\006 ADO.NET\Homework\Realestate\App_Data\RealstateDb.mdf"";Integrated Security=True");


            Console.Title = "Задание на 23.12.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Запрос 1. 3-комнатные квартиры, расположенные на улице \"Садовая\"" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Запрос 2. Риэлторы, фамилия которых начинается с буквы \"И\" и процент вознаграждения больше 10%" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Запрос 3. 1-комнатные квартиры, цена которых от 900 000 руб. до 1000 000 руб" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Запрос 4. Квартиры с заданным числом комнат" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Запрос 5. 2-комнатные квартиры, площадь которых есть значение из некоторого диапазона" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Запрос 6. Вычислить для каждой оформленной сделки размер комиссионного вознаграждения риэлтора" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Запрос 7. Все риэлторы, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Запрос 8. Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Запрос 9. Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            
            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 23.12.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Запрос 1. 3-комнатные квартиры, расположенные на улице "Садовая"
                        case ConsoleKey.Q:
                            app.Query01();
                            break;

                        // Запрос 2. Риэлторы, фамилия которых начинается с буквы "И" и процент вознаграждения больше 10%"
                        case ConsoleKey.W:
                            app.Query02();
                            break;

                        // Запрос 3. 1-комнатные квартиры, цена которых от 900 000 руб. до 1000 000 руб
                        case ConsoleKey.E:
                            app.Query03();
                            break;

                        // Запрос 4. Квартиры с заданным числом комнат
                        case ConsoleKey.R:
                            app.Query04(Utils.Random.Next(1, 5));
                            break;

                        // Запрос 5. 2-комнатные квартиры, площадь которых есть значение из некоторого диапазона
                        case ConsoleKey.T:
                            app.Query05();
                            break;

                        // Запрос 6. Вычислить для каждой оформленной сделки размер комиссионного вознаграждения риэлтора
                        case ConsoleKey.A:
                            app.Query06();
                            break;

                        // Запрос 7. Все риэлторы, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора
                        case ConsoleKey.S:
                            app.Query07();
                            break;

                        // Запрос 8. Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
                        case ConsoleKey.D:
                            app.Query08();
                            break;

                        // Запрос 9. Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки
                        case ConsoleKey.F:
                            app.Query09(new DateTime(2021, 10, 1), new DateTime(2021, 10, 31));
                            break;


                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
