﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Homework.Controllers;
using Homework.Helpers;
using Homework.Models;

namespace Homework.Views
{
    public partial class MainForm : Form
    {
        QueriesController _queriesController;
        public MainForm() {
            InitializeComponent();
             _queriesController = new QueriesController();

            LblMain.Text = "Таблица товаров:";
            DgvGoods.Visible = true;
            DgvGoods.DataSource = _queriesController.GetGoods();
        } // MainForm

        // Таблица персон
        private void ShowPersons_Command(object sender, EventArgs e) {
            LblMain.Text = "Таблица персон:";
            DgvGoods.Visible = DgvUnits.Visible = DgvSellers.Visible = DgvPurchases.Visible = DgvSales.Visible = false;
            DgvPersons.Visible = true;
            DgvPersons.DataSource = _queriesController.GetPersons();
            TbcMain.SelectedTab = TbpMain;
        } // ShowPersons_Command

        // Таблица товаров
        private void ShowGoods_Command(object sender, EventArgs e) {
            LblMain.Text = "Таблица товаров:";
            DgvPersons.Visible = DgvUnits.Visible = DgvSellers.Visible = DgvPurchases.Visible = DgvSales.Visible = false;
            DgvGoods.Visible = true;
            DgvGoods.DataSource = _queriesController.GetGoods();
            TbcMain.SelectedTab = TbpMain;
        } // ShowGoods_Command

        // Таблица единиц измерения
        private void ShowUnits_Command(object sender, EventArgs e) {
            LblMain.Text = "Таблица единиц измерения:";
            DgvPersons.Visible = DgvGoods.Visible = DgvSellers.Visible = DgvPurchases.Visible = DgvSales.Visible = false;
            DgvUnits.Visible = true;
            DgvUnits.DataSource = _queriesController.GetUnits();
            TbcMain.SelectedTab = TbpMain;
        } // ShowUnits_Command

        // Таблица продавцов
        private void ShowSellers_Command(object sender, EventArgs e) {
            LblMain.Text = "Таблица продавцов:";
            DgvPersons.Visible = DgvGoods.Visible = DgvUnits.Visible = DgvPurchases.Visible = DgvSales.Visible = false;
            DgvSellers.Visible = true;
            DgvSellers.DataSource = _queriesController.GetSellers();
            TbcMain.SelectedTab = TbpMain;
        } // ShowSellers_Command

        // Таблица закупок
        private void ShowPurchases_Command(object sender, EventArgs e) {
            LblMain.Text = "Таблица закупок:";
            DgvPersons.Visible = DgvGoods.Visible = DgvUnits.Visible = DgvSellers.Visible = DgvSales.Visible = false;
            DgvPurchases.Visible = true;
            DgvPurchases.DataSource = _queriesController.GetPurchases();
            TbcMain.SelectedTab = TbpMain;
        } // ShowPurchases_Command

        // Таблица продаж
        private void ShowSales_Command(object sender, EventArgs e) {
            LblMain.Text = "Таблица продаж:";
            DgvPersons.Visible = DgvGoods.Visible = DgvUnits.Visible = DgvSellers.Visible = DgvPurchases.Visible = false;
            DgvSales.Visible = true;
            DgvSales.DataSource = _queriesController.GetSales();
            TbcMain.SelectedTab = TbpMain;
        } // ShowSales_Command

        private void Query01_Command(object sender, EventArgs e) {
            DgvQuery01.DataSource = _queriesController.Query01();
            TbcMain.SelectedTab = TbpQuery01;
        } // Query01_Command

        private void Query02_Command(object sender, EventArgs e) {
            DgvQuery02.DataSource = _queriesController.Query02();
            TbcMain.SelectedTab = TbpQuery02;
        } // Query02_Command

        private void Query03_Command(object sender, EventArgs e) {
            string good = "чехол защитный";
            LblQuery03.Text = $"Информация о товарах, с наименованием \"{good}\", для которых цена закупки меньше 1800 руб";
            DgvQuery03.DataSource = _queriesController.Query03(good);
            TbcMain.SelectedTab = TbpQuery03;
        } // Query03_Command

        private void Query04_Command(object sender, EventArgs e) {
            double interest = 10d;

            LblQuery04.Text = $"Информация о продавцах у которых процент комиссионных равен {interest}";
            DgvQuery04.DataSource = _queriesController.Query04(interest);
            TbcMain.SelectedTab = TbpQuery04;
        } // Query04_Command

        private void Query05_Command(object sender, EventArgs e) {
            int lo = Utils.Random.Next(500, 1000), hi = Utils.Random.Next(lo + 500, 3000);

            LblQuery05.Text = $"Информация о фактах продажи, для которых цена продажи в диапазоне: от {lo} до {hi}";
            DgvQuery05.DataSource = _queriesController.Query05(lo, hi);
            TbcMain.SelectedTab = TbpQuery05;
        } // Query05_Command

        private void Query06_Command(object sender, EventArgs e) {
            DgvQuery06.DataSource = _queriesController.Query06();
            TbcMain.SelectedTab = TbpQuery06;
        } // Query06_Command
        
        private void Query07_Command(object sender, EventArgs e) {
            DgvQuery07.DataSource = _queriesController.Query07();
            TbcMain.SelectedTab = TbpQuery07;
        } // Query07_Command

        
        private void Query08_Command(object sender, EventArgs e) {
            DgvQuery08.DataSource = _queriesController.Query08();
            TbcMain.SelectedTab = TbpQuery08;
        } // Query08_Command

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e)  {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command
    }
}
