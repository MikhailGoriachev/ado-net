﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;

namespace Homework.Application
{
    /* 
    * Методы для решения задачи 2
    */
    internal partial class App {

        // Вычислить количество элементов массива, со значениями в диапазоне
        public void ExecCountInRange() {
            Utils.ShowNavBarTask("    Вычислить количество элементов массива, со значениями в диапазоне");

            // генерация диапазона
            double lo = Utils.GetRandom(-10d, 10d);
            double hi = lo + Utils.GetRandom(3d, 10d);

            _task2Controller.CountInRange(lo, hi);
        } // ExecCountInRange

        // Вычислить количество элементов массива, равных 0
        public void ExecCountZeros() {
            Utils.ShowNavBarTask("    Вычислить количество элементов массива, равных 0");

            _task2Controller.CountZeros();
        } // ExecCountZeros

        // Сумма элементов, расположенных после первого максимального элемента
        public void ExecSumAfterMax() {
            Utils.ShowNavBarTask("    Сумма элементов, расположенных после первого максимального элемента");

            _task2Controller.SumAfterMax();
        } // ExecSumAfterMax

        // Сумма элементов, расположенных перед последним минимальным по модулю элементом
        public void ExecSumBeforeMin() {
            Utils.ShowNavBarTask("    Сумма элементов, перед последним минимальным по модулю элементом");

            _task2Controller.SumBeforeMin();
        } // ExecSumAfterMax


    } // App
}
