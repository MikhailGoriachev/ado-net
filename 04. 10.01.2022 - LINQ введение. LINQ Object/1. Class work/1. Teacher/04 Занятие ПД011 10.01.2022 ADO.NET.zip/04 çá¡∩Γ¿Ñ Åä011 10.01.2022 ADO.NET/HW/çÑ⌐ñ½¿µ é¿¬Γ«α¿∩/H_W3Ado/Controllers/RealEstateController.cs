﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W3Ado.Models;

namespace H_W3Ado.Controllers
{
    public class RealEstateController
    {
        // строка подключения к базе данных
        private string _connectingString;
        public string ConnectingString
        {
            get => _connectingString;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Не указана строка подключения к базе данных");

                _connectingString = value;
            } 
        } // ConnectionString

        public RealEstateController(string connectingString)
        {
            ConnectingString = connectingString;
        } // RealEstateController

        // 1.Хранимая процедура	
        // Выбирает из таблицы ИЗДАНИЯ информацию о доступных для
        // подписки изданиях заданного типа,
        // стоимость 1 экземпляра для которых меньше заданной.
        public List<Publication> Query01(double price)
        {
            List<Publication> listPublications = new List<Publication>();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery01");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@price", price);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        listPublications.Add(new Publication {
                            PublicationId = reader.GetInt32(0),
                            IndexPublication = reader.GetString(1),
                            TypePublication = reader.GetString(2),
                            TitlePublication = reader.GetString(3),
                            PricePublication = reader.GetDouble(4)
                        });
                    } // while
                } // if
            } // using

            return listPublications;
        }// Query01


        // 2. Хранимая процедура
        // 	Выбирает из таблиц информацию о подписчиках, проживающих на заданной
        // 	параметром улице и номере дома, которые оформили подписку на издание с
        // 	заданным параметром наименованием
        public List<Subscriber> Query02(string street, string numhouse, string namepublication)
        {
            List<Subscriber> listSubscribers = new List<Subscriber>();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery02");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@namestreet", street);
                cmd.Parameters.AddWithValue("@numHouse", numhouse);
                cmd.Parameters.AddWithValue("@namePubl", namepublication);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        listSubscribers.Add(new Subscriber
                        {
                            SubscriberId = reader.GetInt32(0),
                            Surname = reader.GetString(1),
                            NameSubscriber = reader.GetString(2),
                            Patronymic = reader.GetString(3),
                            PassportNum = reader.GetString(4),
                            NameStreet = reader.GetString(5),
                            HouseNum = reader.GetString(6),
                            ApartmentNum = reader.GetString(7),
                            TypeSubscribers = reader.GetString(8),
                            TitleSubscribers = reader.GetString(9)
                        });
                    } // while
                } // if
            } // using

            return listSubscribers;
        }// Query02


        // 3. Хранимая процедура
        // 	Выбирает из таблицы ИЗДАНИЯ информацию об изданиях,
        // 	для которых значение в поле Цена 1 экземпляра находится в заданном диапазоне значений
        public List<Publication> Query03(double loprice, double hiprice)
        {
            List<Publication> listPublications = new List<Publication>();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery03");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@loPrice", loprice);
                cmd.Parameters.AddWithValue("@hiPrice", hiprice);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        listPublications.Add(new Publication
                        {
                            PublicationId = reader.GetInt32(0),
                            IndexPublication = reader.GetString(1),
                            TypePublication = reader.GetString(2),
                            TitlePublication = reader.GetString(3),
                            PricePublication = reader.GetDouble(4)
                        });
                    } // while
                } // if
            } // using

            return listPublications;
        }// Query03


        // 4. Хранимая процедура.
        // Выбирает из таблиц информацию о подписчиках,
        // подписавшихся на заданный параметром тип издания
        public List<Subscriber> Query04(string type)
        {
            List<Subscriber> listSubscribers = new List<Subscriber>();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery04");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@typeEdition", type);


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        listSubscribers.Add(new Subscriber
                        {
                            SubscriberId = reader.GetInt32(0),
                            Surname = reader.GetString(1),
                            NameSubscriber = reader.GetString(2),
                            Patronymic = reader.GetString(3),
                            PassportNum = reader.GetString(4),
                            NameStreet = reader.GetString(5),
                            HouseNum = reader.GetString(6),
                            ApartmentNum = reader.GetString(7),
                            TypeSubscribers = reader.GetString(8),
                            TitleSubscribers = reader.GetString(9)
                        });
                    } // while
                } // if
            } // using

            return listSubscribers;
        }// Query04


        // 5. Хранимая процедура.
        // Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках,
        // для которых срок подписки есть значение из некоторого диапазона
        public void Query05(int lotermin, int hitermin)
        {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery05");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@loTermin", lotermin);
                cmd.Parameters.AddWithValue("@hiTermin", hitermin);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    Console.WriteLine("\t┌────────────────┬──────────────────────┬─────────────┬───────────────┐");
                    Console.WriteLine(
                        $"\t│ Индекс издания │ " +
                        $"  Название издания   │ " +
                        $"Тип издания │ " +
                        $"Срок подписки │");
                    Console.WriteLine("\t├────────────────┼──────────────────────┼─────────────┼───────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-14} │ " +
                            $"{reader.GetString(1),-20} │ " +
                            $"{reader.GetString(2),-11} │ " +
                            $"{reader.GetInt32(3),13} │");
                    } // while
                    Console.WriteLine("\t└────────────────┴──────────────────────┴─────────────┴───────────────┘");
                } // if
            } // using
            Console.WriteLine();
        }// Query05


        // 6. Хранимая процедура.
        // Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС.
        // Включает поля Индекс издания, Наименование издания,
        // Цена 1 экземпляра, Дата начала подписки,
        // Срок подписки, Стоимость подписки без НДС.
        // Сортировка по полю Индекс издания
        public void Query06()
        {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery06");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    Console.WriteLine("  ┌────────────────┬────────────────────────┬──────────────┬───────────────┬───────────────┬────────────────────┐");
                    Console.WriteLine(
                        $"  │ Индекс издания │ " +
                        $"   Название издания    │ " +
                        $"Цена издания │ " +
                        $"Дата подписки │ " +
                        $"Срок подписки │ " +
                        $"Стоимость подписки │");
                    Console.WriteLine("  ├────────────────┼────────────────────────┼──────────────┼───────────────┼───────────────┼────────────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"  │ {reader.GetString(0), -14} │ " +
                            $"{reader.GetString(1), -22} │ " +
                            $"{reader.GetDouble(2), 12:f2} │ " +
                            $"{reader.GetDateTime(3), 13:d} │ " +
                            $"{reader.GetInt32(4),13} │ " +
                            $"{reader.GetDouble(5),18:f2} │");
                    } // while
                    Console.WriteLine("  └────────────────┴────────────────────────┴──────────────┴───────────────┴───────────────┴────────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        }// Query06


        // 7. Итоговый запрос. Хранимая процедура.
        // Выполняет группировку по полю Вид издания.
        // Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
        public void Query07()
        {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery07");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    Console.WriteLine("\t┌─────────────┬────────────────┬───────────────────┬────────────────────┐");
                    Console.WriteLine(
                        $"\t│ Тип издания │ " +
                        $"Кол-во издания │ " +
                        $"Мин-ная цена экз. │ " +
                        $"Макс-ная цена экз. │");
                    Console.WriteLine("\t├─────────────┼────────────────┼───────────────────┼────────────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-11} │ " +
                            $"{reader.GetInt32(1), 14} │ " +
                            $"{reader.GetDouble(2), 17:f2} │ " +
                            $"{reader.GetDouble(3), 18:f2} │");
                    } // while
                    Console.WriteLine("\t└─────────────┴────────────────┴───────────────────┴────────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        }// Query07


        // 8. Итоговый запрос с левым соединением. Хранимая процедура.
        // Выполняет группировку по полю Улица.
        // Для всех улиц вычисляет количество подписчиков,
        // проживающих на данной улице(итоги по полю Код получателя)
        public void Query08()
        {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery08");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    Console.WriteLine("\t┌─────────────────┬────────────────────┐");
                    Console.WriteLine(
                        $"\t│ Название улицы  │ " +
                        $"Кол-во подписчиков │");
                    Console.WriteLine("\t├─────────────────┼────────────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-15} │ " +
                            $"{reader.GetInt32(1), 18} │");
                    } // while
                    Console.WriteLine("\t└─────────────────┴────────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        }// Query08


        // 9. Итоговый запрос с левым соединением. Хранимая процедура.
        // Для всех изданий выводит количество оформленных подписок
        public void Query09()
        {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery09");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    Console.WriteLine("\t┌─────────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ Тип издания │ " +
                        $"Кол-во подписок │");
                    Console.WriteLine("\t├─────────────┼─────────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-11} │ " +
                            $"{reader.GetInt32(1),15} │");
                    } // while
                    Console.WriteLine("\t└─────────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        }// Query09

    }// class RealEstateController
}
