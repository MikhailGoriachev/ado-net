﻿using System;


namespace Main.Utilities
{
	public readonly struct Range<T> where T : unmanaged, IComparable<T>
	{
		public T Min { get; }
		public T Max { get; }
		public Func<T, T, T>? RandomFunc { private get; init; }


		public T RandomBetween => RandomFunc?.Invoke(Min, Max) ?? default;


		public Range(T min, T max)
		{
			if (min.CompareTo(max) is 1 or 0)
				throw new ArgumentOutOfRangeException(nameof(min));

			Min        = min;
			Max        = max;
			RandomFunc = null;
		}


		public bool IsInRangeExclusive(T value) => value.CompareTo(Min) is 1 && value.CompareTo(Max) is -1;


		public bool IsInRangeInclusive(T value) =>
			value.CompareTo(Min) is 1 or 0 && value.CompareTo(Max) is -1 or 0;
	}
}