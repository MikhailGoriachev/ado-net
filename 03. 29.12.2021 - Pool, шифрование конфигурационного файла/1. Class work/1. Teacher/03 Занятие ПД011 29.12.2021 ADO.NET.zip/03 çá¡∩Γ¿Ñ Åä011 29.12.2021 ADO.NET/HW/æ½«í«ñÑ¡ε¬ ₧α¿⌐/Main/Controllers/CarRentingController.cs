﻿using System;
using System.Data;
using Main.DataAccess;
using Main.Models.CarRenting;
using Main.Utilities;
using Main.Utilities.TableFormatter;


namespace Main.Controllers
{
	public sealed class CarRentingController
	{
		private readonly DapperDataAccess _dataAccess;


		public CarRentingController(string connectionString) =>
			_dataAccess = new(connectionString);


		public void Query1(string licenseNumber)
		{
			var result = _dataAccess.Query<Order>(new(
				"GetAllOrdersWithLicenseNumber",
				new { licenseNumber },
				commandType: CommandType.StoredProcedure
			));

			new TableFormatter<Order>().Show(result);
		}


		public void Query2(int brandId)
		{
			var result = _dataAccess.Query<Order>(new(
				"GetAllOrdersWithBrandId",
				new { brandId },
				commandType: CommandType.StoredProcedure
			));

			new TableFormatter<Order>().Show(result);
		}


		public void Query3(string licenseNumber)
		{
			var result = _dataAccess.Query<Car>(new(
				"GetCarWithLicenseNumber",
				new { licenseNumber },
				commandType: CommandType.StoredProcedure
			));

			new TableFormatter<Car>().Show(result);
		}


		public void Query4(string passport)
		{
			var result = _dataAccess.Query<Client>(new(
				"GetClientsByPassport",
				new { passport },
				commandType: CommandType.StoredProcedure
			));

			new TableFormatter<Client>().Show(result);
		}


		public void Query5(Range<DateTime> dates)
		{
			var result = _dataAccess.Query<Order>(new(
				"GetOrdersForCertainPeriod",
				new
				{
					from = dates.Min,
					to   = dates.Max
				},
				commandType: CommandType.StoredProcedure
			));

			new TableFormatter<Order>().Show(result);
		}


		public void Query6()
		{
			var result = _dataAccess.Query<RentTotalForAllOrders>(new(
				"GetRentTotalForAllOrders",
				commandType: CommandType.StoredProcedure
			));

			new TableFormatter<RentTotalForAllOrders>().Show(result);
		}


		public void Query7()
		{
			var result = _dataAccess.Query<ClientsWithOrdersCountAndDuration>(new(
				"GetAllClientsWithOrdersCountAndDuration",
				commandType: CommandType.StoredProcedure
			));

			new TableFormatter<ClientsWithOrdersCountAndDuration>().Show(result);
		}


		public void Query8(string licenseNumber)
		{
			var result = _dataAccess.Query<CarInfo>(new(
				"GetInfoAboutCarWithLicenseNumber",
				new { licenseNumber },
				commandType: CommandType.StoredProcedure
			));

			new TableFormatter<CarInfo>().Show(result);
		}
	}
}