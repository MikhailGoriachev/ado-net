﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	public class Query07ViewModel
	{
		// Наименование товара
		public string Title { get; set; }

		// Средняя цена закупки товара
		public double AvgPurchasePrice { get; set; }

		// Количество закупок товара
		public int SalesAmount { get; set; }
	}
}
