using System;
using System.Collections.Generic;
using System.Linq;
using Main.Models;
using Main.Utilities;
using Main.Utilities.Menu;
using Main.Utilities.TableFormatter;


namespace Main.Controllers
{
	public sealed class Task3Controller : MenuWrapper
	{
		private static readonly Func<double> ValueProvider = () => General.Rand.RealNextDouble(-10, 10);
		private readonly ICollection<Good> _goods = CreateGoods();


		public Task3Controller() =>
			Menu = new("Третья задача", new[]
			{
				new MenuItem("Товары с заданным диапазоном цен", SelectBetween),
				new MenuItem("Сумма товаров с заданным годом выпуска", SumCountOfChosenYear),
				new MenuItem("Сумма товаров с заданным наименованием (наименование товара может быть задано частично)", SumWithName),
				new MenuItem("Наименование и год выпуска товаров с максимальным количеством", SelectWithMaxCount),
				new MenuItem("Все товары, для которых произведение цены на количество находится в заданном диапазоне", PriceByCountRange),
			});


		private static ICollection<Good> CreateGoods()
		{
			var size = General.Rand.Next(12, 16);
			int filler = 0;

			return new List<Good>().Fill(() =>
			{
				filler++;

				return new()
				{
					Count = filler,
					Name  = $"Name{filler}",
					Price = filler,
					Year  = filler
				};
			}, size);
		}


		private static void ShowTable(IEnumerable<Good> values) => new TableFormatter<Good>().Show(values);


		/// Товары с заданным диапазоном цен
		private void SelectBetween()
		{
			var range = Range<decimal>.CreateWithRandom(() => (decimal)ValueProvider.Invoke());

			var filtered = _goods.Where(g => range.IsInRangeInclusive(g.Price));

			Console.WriteLine($"Диапазон: {range:f}\n\n");
			ShowTable(filtered);
		}


		/// Сумма товаров с заданным годом выпуска
		private void SumCountOfChosenYear()
		{
			var year = _goods.Select(g => g.Year).Distinct().ToArray().Random();

			var selectedYear = _goods
							   .Where(g => g.Year == year)
							   .ToArray();

			var sum = selectedYear.Sum(g => g.Count);

			Console.WriteLine($"Сумма товаров {year} года: {sum}\n\n");
			ShowTable(selectedYear);
		}


		/// Сумма товаров с заданным наименованием (наименование товара может быть задано частично)
		private void SumWithName()
		{
			//var name = _goods.Select(g => g.Name).Distinct().ToArray().Random();
			var name = "ame";

			var filtered = _goods
						   .Where(g => g.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
						   .ToArray();

			var sum = filtered.Sum(g => g.Price * g.Count);

			Console.WriteLine($"Сумма товаров \"{name}\" наименования: {sum}\n\n");
			ShowTable(filtered);
		}


		/// Наименование и год выпуска товаров с максимальным количеством
		private void SelectWithMaxCount()
		{
			var maxCount = _goods.Max(g => g.Count);

			var selected = _goods
						   .Where(g => g.Count == maxCount)
						   .Select(g => new { g.Name, g.Year })
						   .ToArray();

			Console.WriteLine($"Максимальное количество: {maxCount}\n");
			Console.WriteLine($"{"Наименование".Center(30)} {"Год".Center(15)}");
			foreach (var item in selected)
				Console.WriteLine($"{item.Name, -30} {item.Year, -15}");
		}


		/// Все товары, для которых произведение цены на количество находится в заданном диапазоне
		private void PriceByCountRange()
		{
			var range = Range<decimal>.CreateWithRandom(() => (decimal)ValueProvider.Invoke());

			var filtered = _goods
				.Where(g => range.IsInRangeInclusive(g.Price * g.Count))
				.ToArray();

			Console.WriteLine($"Диапазон: {range:f}\n\n");
			ShowTable(filtered);
		}
	}
}