﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketTrain_WPF_first.ViewModels
{
    public class TrainTicket
    {

        // модель для отображения данных вагона в DataGridView
        //     • номер вагона
        //     • тип вагона
        //     • номер купе
        //     • номер места
        //     • признак продано/свободно

        public int Number { get; set; }                   // номер вагона
        public string WagonType { get; set; }          // тип вагона
        public int CompartmentNumber { get; set; }        // номер купе
        public string SeatNumber { get; set; }               // номер места
        public string State { get; set; }                     // продано / свободно



    }
}
