﻿-- 1. Запрос с параметрами
-- Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах,
-- расположенных на улице «Садовая».
-- Значения задавать параметрами запроса
declare @namestreet nvarchar(30) = N'Садовая', @numRooms int = 3;
select 
    Streets.NameStreet
   , Apartments.HouseNum
   , Apartments.Flat
   , Apartments.AreaApartment
   , Apartments.NumberOfRooms
   , Apartments.PriceApartment
from
   Apartments join Streets on Apartments.IdNameStreet = Streets.Id
where
   Streets.NameStreet = @namestreet and Apartments.NumberOfRooms = @numRooms;
go


-- 2. Запрос с параметрами
-- Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах,
-- фамилия которых начинается с буквы «И» и 
-- процент вознаграждения больше 10%.
-- Значения задавать параметрами запроса
declare @surname nvarchar(30) = N'И%';
declare @percent int = 10;
select 
   Persons.Surname
   , Persons.[Name]
   , Persons.Patronymic
   , Realtors.PercentRemuneration
from
   Realtors join Persons on Realtors.IdPerson = Persons.Id
where
   Persons.Surname like @surname and Realtors.PercentRemuneration > @percent;
go

-- 2. Запрос с параметрами (!c подзапросом!)
-- Выбирает из таблицы РИЭЛТОРЫ информацию о риэлторах,
-- фамилия которых начинается с буквы «И» и 
-- процент вознаграждения больше 10%.
-- Значения задавать параметрами запроса
declare @surname nvarchar(30) = N'И%';
declare @percent int = 10;
select 
   Persons.Surname
   , Persons.[Name]
   , Persons.Patronymic
   , Realtors.PercentRemuneration
from
   Realtors join Persons on Realtors.IdPerson = Persons.Id
where
   Persons.Surname in (select Persons.Surname from Persons where Persons.Surname like @surname)
                   and Realtors.PercentRemuneration > @percent;
go


-- 3. Запрос с параметрами
-- Выбирает из таблицы КВАРТИРЫ информацию об 1-комнатных квартирах,
-- цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб.
-- Значения задавать параметрами запроса
declare @loPrice int = 900000, @hiPrice int = 1000000;
select 
    Streets.NameStreet
   , Apartments.HouseNum
   , Apartments.Flat
   , Apartments.AreaApartment
   , Apartments.NumberOfRooms
   , Apartments.PriceApartment
from
   Apartments join Streets on Apartments.IdNameStreet = Streets.Id
where
   Apartments.PriceApartment between @loPrice and @hiPrice;
go

-- 4. Запрос с параметрами
-- Выбирает из таблицы КВАРТИРЫ информацию о квартирах с заданным числом комнат.
-- Значения задавать параметрами запроса
declare @numRooms int = 2;
select 
    Streets.NameStreet
   , Apartments.HouseNum
   , Apartments.Flat
   , Apartments.AreaApartment
   , Apartments.NumberOfRooms
   , Apartments.PriceApartment
from
   Apartments join Streets on Apartments.IdNameStreet = Streets.Id
where
   Apartments.NumberOfRooms = @numRooms;
go

-- 5. Запрос с параметрами
-- Выбирает из таблицы КВАРТИРЫ информацию обо всех 2-комнатных квартирах,
-- площадь которых есть значение из некоторого диапазона.
-- Значения задавать параметрами запроса
declare @loArea float = 45.5, @hiArea float = 50.5;
declare @numRooms int = 2;
select 
    Streets.NameStreet
   , Apartments.HouseNum
   , Apartments.Flat
   , Apartments.AreaApartment
   , Apartments.NumberOfRooms
   , Apartments.PriceApartment
from
   Apartments join Streets on Apartments.IdNameStreet = Streets.Id
where
   Apartments.NumberOfRooms = @numRooms and Apartments.AreaApartment between @loArea and @hiArea;
go

-- 6. Запрос с вычисляемыми полями
-- Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.
-- Включает поля Фамилия риэлтора, Имя риэлтора,
-- Отчество риэлтора, Дата сделки,
-- Цена квартиры, Комиссионные.
-- Сортировка по полю Дата сделки
select
   Persons.Surname
   , Persons.[Name]
   , Persons.Patronymic
   , Dealings.DateDeal
   , Apartments.PriceApartment
   -- Риэлтор, оформивший сделку купли-продажи,
   -- получает комиссионное вознаграждение, которое вычисляется как 
   -- Стоимость квартиры * Процент вознаграждения
   , (Apartments.PriceApartment * Realtors.PercentRemuneration) / 100 as Commission
from 
   Dealings join(Realtors join Persons on Realtors.IdPerson = Persons.Id)
            on Dealings.IdRealtor = Realtors.Id
            join(Apartments join Streets on Apartments.IdNameStreet = Streets.Id)
            on Dealings.IdApartment = Apartments.Id
order by
   Dealings.DateDeal;
go


-- 7. Запрос на левое соединение
-- Выбрать всех риэлторов, количество клиентов,
-- оформивших с ним сделки и сумму сделок риэлтора.
-- Упорядочить выборку по убыванию суммы сделок.
select
   Dealings.IdRealtor
   , Count(Dealings.IdRealtor) as AmountRealtors
   , SUM(Apartments.PriceApartment) as SumDeal
from 
     Dealings left join(Realtors join Persons on Realtors.IdPerson = Persons.Id) 
             on Dealings.IdRealtor = Realtors.Id
             left join(Apartments join Streets on Apartments.IdNameStreet = Streets.Id)
             on Dealings.IdApartment = Apartments.Id
group by
    Dealings.IdRealtor
order by 
    SumDeal
go
  
-- 8. Запрос на левое соединение 
-- Для всех улиц вывести сумму сделок, 
-- упорядочить выборку по убыванию суммы сделки
select
    Streets.NameStreet
    , Count(Dealings.IdRealtor) as DealAmount
    , Sum(Apartments.PriceApartment) as DealSum
from
     Dealings left join(Realtors join Persons on Realtors.IdPerson = Persons.Id) 
             on Dealings.IdRealtor = Realtors.Id
             left join(Apartments join Streets on Apartments.IdNameStreet = Streets.Id)
             on Dealings.IdApartment = Apartments.Id
group by
    Streets.NameStreet
order by 
    DealSum desc
go


-- 9. Запрос на левое соединение
-- Для всех улиц вывести сумму сделок за заданный период,
-- упорядочить выборку по убыванию суммы сделки.
-- Диапазон задавать параметрами запроса
declare @loDate date = '12-05-2021', @hiDate date = '02-01-2022';
select
    Streets.NameStreet
    , Count(Dealings.IdRealtor) as DealAmount
    , Sum(Apartments.PriceApartment) as DealSum
from
    Dealings left join(Realtors join Persons on Realtors.IdPerson = Persons.Id) 
             on Dealings.IdRealtor = Realtors.Id
             left join(Apartments join Streets on Apartments.IdNameStreet = Streets.Id)
             on Dealings.IdApartment = Apartments.Id
where
    Dealings.DateDeal between @loDate and @hiDate
group by
    Streets.NameStreet
order by 
    DealSum desc
go


-- 10. Итоговый запрос
-- Выполняет группировку по полю Количество комнат.
-- Для каждой группы вычисляет среднее значение по полю Цена квартиры
select
   Apartments.NumberOfRooms
   , AVG(Apartments.PriceApartment) as AvgPriceApartment
   , MIN(Apartments.PriceApartment) as MinPriceApartment
   , MAX(Apartments.PriceApartment) as MaxPriceApartment
from
   Apartments join Streets on Apartments.IdNameStreet = Streets.Id
group by
   Apartments.NumberOfRooms
go


-- 11. Итоговый запрос
-- Выполняет группировку по полю Площадь квартиры.
-- Для каждой группы вычисляет наибольшее и наименьшее значение по полю Цена квартиры
select
   Apartments.AreaApartment
   , MIN(Apartments.PriceApartment) as MinPriceApartment
   , MAX(Apartments.PriceApartment) as MaxPriceApartment
from
   Apartments join Streets on Apartments.IdNameStreet = Streets.Id
group by
   Apartments.AreaApartment
go

-- 12. Запрос на создание базовой таблицы
-- Создает таблицу КВАРТИРЫ_3_КОМН,
-- содержащую информацию о 3-комнатных квартирах
select
   *
into
   Apartments_Three_Room
from
   Apartments
where 
   Apartments.NumberOfRooms = 3;

-- показать выбранные в таблицу Apartments_Three_Room данные 
select * from Apartments_Three_Room;
go


-- 13. Запрос на создание базовой таблицы
-- Создает копию таблицы КВАРТИРЫ с именем КОПИЯ_КВАРТИРЫ
select
   *
into
   Copy_Apartments
from
   Apartments

-- показать выбранные в таблицу Copy_Apartments данные 
select * from Copy_Apartments;
go
 
-- 14. Запрос на удаление 
-- Удаляет из таблицы КОПИЯ_КВАРТИРЫ записи,
-- в которых значение в поле Цена квартиры больше 3 000 000 руб.
delete from
   Copy_Apartments
where
   Copy_Apartments.PriceApartment > 3000000;


-- 15. Запрос на обновление
-- Увеличивает значение в поле Цена квартиры
-- таблицы КОПИЯ_КВАРТИРЫ на 10 процентов для 1-комнатных квартир
update
   Copy_Apartments
set
   Copy_Apartments.PriceApartment *= 1.1
where
   Copy_Apartments.NumberOfRooms = 1;
   
