﻿-- 1. Хранимая процедура	
--    Выбирает информацию о 3-комнатных квартирах, расположенных на улице «Садовая». 
--    Значения задавать параметрами запроса
drop proc if exists ProcQuery01;
go

create proc ProcQuery01
    @roomNum int,
    @street nvarchar(30)
as
begin
	select
        Apartments.Id
        , Streets.Street
        , Apartments.Building
        , Apartments.Flat
        , Apartments.Area
        , Apartments.RoomNum
    from
        Apartments join Streets on Apartments.IdStreet = Streets.Id
    where
        Apartments.RoomNum = @roomNum and Streets.Street = @street;
end;
go

exec ProcQuery01 3,  N'ул. Садовая';
go


-- 2. Хранимая процедура	
--    Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И» 
--    и процент вознаграждения больше 10%. Значения задавать параметрами запроса
drop proc if exists ProcQuery02;
go

create proc ProcQuery02
    @percent float,
    @surname nvarchar(60)
as
begin
    select
        Realtors.Id
        , Persons.Surname
        , Persons.[Name]
        , Persons.Patronymic
        , Realtors.[Percent]
    from
        Realtors join Persons on Realtors.IdPerson = Persons.Id
    where
        Persons.Surname like (@surname + N'%') and Realtors.[Percent] > @percent;
end;
go

exec ProcQuery02 10,  N'И';
go

-- 3. Хранимая процедура	
--    Выбирает информацию об 1-комнатных квартирах, цена на которые находится 
--    в диапазоне от 900 000 руб. до 1000 000 руб. Значения задавать параметрами запроса
drop proc if exists ProcQuery03;
go

create proc ProcQuery03
    @roomNum int,
    @lo int,
    @hi int
as
begin
    select
        Apartments.Id
        , Streets.Street
        , Apartments.Building
        , Apartments.Flat
        , Apartments.Area
        , Apartments.RoomNum
        , Offers.Price
    from
        Apartments join Streets on Apartments.IdStreet = Streets.Id
                   join Offers on Apartments.Id = Offers.IdApartment
    where
        Apartments.RoomNum = @roomNum and Offers.Price between @lo and @hi;
end;
go

exec ProcQuery03 1,  900000, 1000000;
go

-- 4. Хранимая процедура	
--    Выбирает информацию о квартирах с заданным числом комнат. 
--    Значения задавать параметрами запроса
drop proc if exists ProcQuery04;
go

create proc ProcQuery04
    @roomNum int
as
begin
    select
        Apartments.Id
        , Streets.Street
        , Apartments.Building
        , Apartments.Flat
        , Apartments.Area
        , Apartments.RoomNum
        , Offers.Price
    from
        Apartments join Streets on Apartments.IdStreet = Streets.Id
                   join Offers on Apartments.Id = Offers.IdApartment
    where
        Apartments.RoomNum = @roomNum;;
end;
go

exec ProcQuery04 4;
go


-- 5. Хранимая процедура	
--    Выбирает информацию обо всех 2-комнатных квартирах, площадь которых 
--    есть значение из некоторого диапазона. Значения задавать параметрами запроса
drop proc if exists ProcQuery05;
go

create proc ProcQuery05
    @roomNum int,
    @lo float,
    @hi float
as
begin
    select
        Apartments.Id
        , Streets.Street
        , Apartments.Building
        , Apartments.Flat
        , Apartments.Area
        , Apartments.RoomNum
        , Offers.Price
    from
        Apartments join Streets on Apartments.IdStreet = Streets.Id
                   join Offers on Apartments.Id = Offers.IdApartment
    where
        Apartments.RoomNum = @roomNum and Apartments.Area between @lo and @hi;
end;
go

exec ProcQuery05 2,  80, 120;
go


-- 6. Хранимая процедура	
--    Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора. 
--    Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные. 
--    Сортировка по полю Дата сделки
drop proc if exists ProcQuery06;
go

create proc ProcQuery06
as
begin
    select
        Persons.Surname
        , Persons.[Name]
        , Persons.Patronymic
        , Deals.DealDate
        , Deals.DealPrice
        , Realtors.[Percent]
        , Deals.DealPrice * Realtors.[Percent] / 100 as Fee
    from
        Deals join (Realtors join Persons on Realtors.IdPerson = Persons.Id) 
            on Deals.IdRealtor = Realtors.Id
    order by
        Deals.DealDate;
end;
go

exec ProcQuery06;
go

-- 7. Хранимая процедура	
--    Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора. 
--    Упорядочить выборку по убыванию суммы сделок.
drop proc if exists ProcQuery07;
go

create proc ProcQuery07
as
begin
    select
        -- данные риелтора - группа
        Realtors.Id
        , Persons.Surname
        , Persons.[Name]
        , Persons.Patronymic
        -- агрегатные функции
        , ISNULL(Count(Deals.IdOffer), 0) as ClientTotal 
        , ISNULL(Sum(Deals.DealPrice), 0) as RealtorSum
    from
        (Realtors join Persons on Realtors.IdPerson = Persons.Id)
            left join 
        Deals on Realtors.Id = Deals.IdRealtor
    group by
        Realtors.Id, Persons.Surname, Persons.[Name], Persons.Patronymic;
end;
go

exec ProcQuery07;
go


-- 8. Хранимая процедура	
--    Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
drop proc if exists ProcQuery08;
go

create proc ProcQuery08
as
begin
    select
        Streets.Street
        , ISNULL(Sum(Deals.DealPrice), 0) as SumDeals
    from
        Streets left join (Apartments join (Offers join Deals on Offers.Id = Deals.IdOffer) on Apartments.Id = Offers.IdApartment) 
            on Streets.Id = Apartments.IdStreet
    group by
        Streets.Street
    order by 
        SumDeals desc;
end;
go

exec ProcQuery08;
go


-- 9. Хранимая процедура	
--    Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки. 
--    Диапазон задавать параметрами запроса
drop proc if exists ProcQuery09;
go

create proc ProcQuery09
    @from date,
    @to date
as
begin
    select
        Streets.Street
        , ISNULL(COUNT(PeriodDeals.DealPrice), 0) as Amount
        , ISNULL(SUM(PeriodDeals.DealPrice), 0) as Total
    from
        Streets left join 
            -- данные по сделкам за период извлекаем при помощи подзапроса, требуется назначить 
            -- псевдоним этому подзапросу
            (select Deals.DealDate, Deals.DealPrice, Apartments.IdStreet from (Deals join (Offers join Apartments on Offers.IdApartment = Apartments.Id) on Deals.IdOffer = Offers.Id)  
             where Deals.DealDate between @from and @to) PeriodDeals
        on Streets.Id = PeriodDeals.IdStreet
    group by
        Streets.Street
    order by
        Total desc;
end;
go

exec ProcQuery09 '10-01-2021', '10-31-2021';
go
