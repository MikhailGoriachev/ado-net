﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6AdoLINQtoSQL.Models
{
    // Класс для Представления для вычисления закупок товара
    public class CalculationViewModel
    {
        public string Name { get; set; }        
        public int AvgPricepurchase { get; set; }
        public int AmountPurchase { get; set; }

    }// class CalculationViewModel
}
