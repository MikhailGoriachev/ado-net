﻿namespace LINQ_LeftJoin_Shop_DB.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Tbc_Main = new System.Windows.Forms.TabControl();
            this.Tab_Query_1 = new System.Windows.Forms.TabPage();
            this.Tbx_Selected = new System.Windows.Forms.TextBox();
            this.Gbx_Tab_Query1 = new System.Windows.Forms.GroupBox();
            this.Lbl_Query_1 = new System.Windows.Forms.Label();
            this.Dgv_Query_1 = new System.Windows.Forms.DataGridView();
            this.Tab_Query_2 = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Gbx_Tab_Query2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Dgv_Query_2 = new System.Windows.Forms.DataGridView();
            this.purchasesViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Tab_Sales_Table = new System.Windows.Forms.TabPage();
            this.Gbx_Tab_Sales = new System.Windows.Forms.GroupBox();
            this.Lbl_Sales_Tables = new System.Windows.Forms.Label();
            this.Dgv_Sales_Table = new System.Windows.Forms.DataGridView();
            this.Tab_Purchases_Table = new System.Windows.Forms.TabPage();
            this.Dgv_Purchases = new System.Windows.Forms.DataGridView();
            this.sellersViewModelBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.Gbx_Query_Purchases = new System.Windows.Forms.GroupBox();
            this.Lbl_Purchases = new System.Windows.Forms.Label();
            this.Tab_Sellers_table = new System.Windows.Forms.TabPage();
            this.DG_Sellers = new System.Windows.Forms.DataGridView();
            this.Gbx_Sellers = new System.Windows.Forms.GroupBox();
            this.Lbl_Sellers = new System.Windows.Forms.Label();
            this.StatusStr = new System.Windows.Forms.StatusStrip();
            this.Lbl_Status_Qantity = new System.Windows.Forms.ToolStripStatusLabel();
            this.Lbl_Query_Num = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sellersViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sellersViewModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.Tbc_Main.SuspendLayout();
            this.Tab_Query_1.SuspendLayout();
            this.Gbx_Tab_Query1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_1)).BeginInit();
            this.Tab_Query_2.SuspendLayout();
            this.Gbx_Tab_Query2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchasesViewModelBindingSource)).BeginInit();
            this.Tab_Sales_Table.SuspendLayout();
            this.Gbx_Tab_Sales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Sales_Table)).BeginInit();
            this.Tab_Purchases_Table.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Purchases)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource2)).BeginInit();
            this.Gbx_Query_Purchases.SuspendLayout();
            this.Tab_Sellers_table.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DG_Sellers)).BeginInit();
            this.Gbx_Sellers.SuspendLayout();
            this.StatusStr.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // Tbc_Main
            // 
            this.Tbc_Main.Controls.Add(this.Tab_Query_1);
            this.Tbc_Main.Controls.Add(this.Tab_Query_2);
            this.Tbc_Main.Controls.Add(this.Tab_Sales_Table);
            this.Tbc_Main.Controls.Add(this.Tab_Purchases_Table);
            this.Tbc_Main.Controls.Add(this.Tab_Sellers_table);
            this.Tbc_Main.Location = new System.Drawing.Point(0, 50);
            this.Tbc_Main.Name = "Tbc_Main";
            this.Tbc_Main.SelectedIndex = 0;
            this.Tbc_Main.Size = new System.Drawing.Size(798, 528);
            this.Tbc_Main.TabIndex = 0;
            // 
            // Tab_Query_1
            // 
            this.Tab_Query_1.Controls.Add(this.Tbx_Selected);
            this.Tab_Query_1.Controls.Add(this.Gbx_Tab_Query1);
            this.Tab_Query_1.Controls.Add(this.Dgv_Query_1);
            this.Tab_Query_1.Location = new System.Drawing.Point(4, 22);
            this.Tab_Query_1.Name = "Tab_Query_1";
            this.Tab_Query_1.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_Query_1.Size = new System.Drawing.Size(790, 502);
            this.Tab_Query_1.TabIndex = 0;
            this.Tab_Query_1.Text = "Запрос 1";
            this.Tab_Query_1.ToolTipText = "Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых являе" +
    "тся «шт» (штуки) и цена закупки составляет меньше 20000 руб";
            this.Tab_Query_1.UseVisualStyleBackColor = true;
            this.Tab_Query_1.Enter += new System.EventHandler(this.Tab_Query_1_Enter);
            // 
            // Tbx_Selected
            // 
            this.Tbx_Selected.Location = new System.Drawing.Point(382, 10);
            this.Tbx_Selected.Multiline = true;
            this.Tbx_Selected.Name = "Tbx_Selected";
            this.Tbx_Selected.Size = new System.Drawing.Size(402, 73);
            this.Tbx_Selected.TabIndex = 3;
            // 
            // Gbx_Tab_Query1
            // 
            this.Gbx_Tab_Query1.AutoSize = true;
            this.Gbx_Tab_Query1.Controls.Add(this.Lbl_Query_1);
            this.Gbx_Tab_Query1.Location = new System.Drawing.Point(8, 6);
            this.Gbx_Tab_Query1.Name = "Gbx_Tab_Query1";
            this.Gbx_Tab_Query1.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Tab_Query1.Size = new System.Drawing.Size(368, 77);
            this.Gbx_Tab_Query1.TabIndex = 2;
            this.Gbx_Tab_Query1.TabStop = false;
            this.Gbx_Tab_Query1.Text = "Запрос 1";
            // 
            // Lbl_Query_1
            // 
            this.Lbl_Query_1.AutoSize = true;
            this.Lbl_Query_1.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Query_1.Location = new System.Drawing.Point(9, 16);
            this.Lbl_Query_1.Name = "Lbl_Query_1";
            this.Lbl_Query_1.Size = new System.Drawing.Size(323, 45);
            this.Lbl_Query_1.TabIndex = 1;
            this.Lbl_Query_1.Text = "Выбирает всех продавцов, \r\nколичество и суммы их продаж за заданный период, \r\nупо" +
    "рядочивает по фамилиям и инициалам. ";
            // 
            // Dgv_Query_1
            // 
            this.Dgv_Query_1.AllowUserToAddRows = false;
            this.Dgv_Query_1.AllowUserToDeleteRows = false;
            this.Dgv_Query_1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Query_1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.Dgv_Query_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Query_1.Location = new System.Drawing.Point(8, 93);
            this.Dgv_Query_1.MultiSelect = false;
            this.Dgv_Query_1.Name = "Dgv_Query_1";
            this.Dgv_Query_1.ReadOnly = true;
            this.Dgv_Query_1.RowHeadersVisible = false;
            this.Dgv_Query_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Query_1.Size = new System.Drawing.Size(776, 391);
            this.Dgv_Query_1.TabIndex = 0;
            // 
            // Tab_Query_2
            // 
            this.Tab_Query_2.Controls.Add(this.textBox1);
            this.Tab_Query_2.Controls.Add(this.Gbx_Tab_Query2);
            this.Tab_Query_2.Controls.Add(this.Dgv_Query_2);
            this.Tab_Query_2.Location = new System.Drawing.Point(4, 22);
            this.Tab_Query_2.Name = "Tab_Query_2";
            this.Tab_Query_2.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_Query_2.Size = new System.Drawing.Size(790, 502);
            this.Tab_Query_2.TabIndex = 1;
            this.Tab_Query_2.Text = "Запрос 2";
            this.Tab_Query_2.ToolTipText = "Выбирает из таблицы ТОВАРЫ информацию о товарах, цена закупки которых больше 500 " +
    "руб. за единицу товара";
            this.Tab_Query_2.UseVisualStyleBackColor = true;
            this.Tab_Query_2.Enter += new System.EventHandler(this.Tab_Query_2_Enter);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(382, 16);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(402, 73);
            this.textBox1.TabIndex = 5;
            // 
            // Gbx_Tab_Query2
            // 
            this.Gbx_Tab_Query2.Controls.Add(this.label1);
            this.Gbx_Tab_Query2.Location = new System.Drawing.Point(7, 12);
            this.Gbx_Tab_Query2.Name = "Gbx_Tab_Query2";
            this.Gbx_Tab_Query2.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Tab_Query2.Size = new System.Drawing.Size(369, 77);
            this.Gbx_Tab_Query2.TabIndex = 4;
            this.Gbx_Tab_Query2.TabStop = false;
            this.Gbx_Tab_Query2.Text = "Запрос 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(9, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "Выбирает все товары, \r\nколичество и сумму продаж по этим товарам. \r\nУпорядочивает" +
    " по убыванию суммы продаж.";
            // 
            // Dgv_Query_2
            // 
            this.Dgv_Query_2.AllowUserToAddRows = false;
            this.Dgv_Query_2.AllowUserToDeleteRows = false;
            this.Dgv_Query_2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Query_2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.Dgv_Query_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Query_2.Location = new System.Drawing.Point(7, 99);
            this.Dgv_Query_2.MultiSelect = false;
            this.Dgv_Query_2.Name = "Dgv_Query_2";
            this.Dgv_Query_2.ReadOnly = true;
            this.Dgv_Query_2.RowHeadersVisible = false;
            this.Dgv_Query_2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Query_2.Size = new System.Drawing.Size(776, 391);
            this.Dgv_Query_2.TabIndex = 3;
            // 
            // Tab_Sales_Table
            // 
            this.Tab_Sales_Table.Controls.Add(this.Gbx_Tab_Sales);
            this.Tab_Sales_Table.Controls.Add(this.Dgv_Sales_Table);
            this.Tab_Sales_Table.Location = new System.Drawing.Point(4, 22);
            this.Tab_Sales_Table.Name = "Tab_Sales_Table";
            this.Tab_Sales_Table.Size = new System.Drawing.Size(790, 502);
            this.Tab_Sales_Table.TabIndex = 2;
            this.Tab_Sales_Table.Text = "Таблица продаж";
            this.Tab_Sales_Table.ToolTipText = "Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием (наприме" +
    "р, «чехол защитный»), для которых цена закупки меньше 18 000 руб.";
            this.Tab_Sales_Table.UseVisualStyleBackColor = true;
            this.Tab_Sales_Table.Enter += new System.EventHandler(this.Tab_Sales_Enter);
            // 
            // Gbx_Tab_Sales
            // 
            this.Gbx_Tab_Sales.Controls.Add(this.Lbl_Sales_Tables);
            this.Gbx_Tab_Sales.Location = new System.Drawing.Point(7, 12);
            this.Gbx_Tab_Sales.Name = "Gbx_Tab_Sales";
            this.Gbx_Tab_Sales.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Tab_Sales.Size = new System.Drawing.Size(368, 43);
            this.Gbx_Tab_Sales.TabIndex = 4;
            this.Gbx_Tab_Sales.TabStop = false;
            // 
            // Lbl_Sales_Tables
            // 
            this.Lbl_Sales_Tables.AutoSize = true;
            this.Lbl_Sales_Tables.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Sales_Tables.Location = new System.Drawing.Point(9, 16);
            this.Lbl_Sales_Tables.Name = "Lbl_Sales_Tables";
            this.Lbl_Sales_Tables.Size = new System.Drawing.Size(163, 15);
            this.Lbl_Sales_Tables.TabIndex = 1;
            this.Lbl_Sales_Tables.Text = "Итоговая таблица продаж";
            // 
            // Dgv_Sales_Table
            // 
            this.Dgv_Sales_Table.AllowUserToAddRows = false;
            this.Dgv_Sales_Table.AllowUserToDeleteRows = false;
            this.Dgv_Sales_Table.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Sales_Table.BackgroundColor = System.Drawing.SystemColors.Control;
            this.Dgv_Sales_Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Sales_Table.Location = new System.Drawing.Point(7, 61);
            this.Dgv_Sales_Table.MultiSelect = false;
            this.Dgv_Sales_Table.Name = "Dgv_Sales_Table";
            this.Dgv_Sales_Table.ReadOnly = true;
            this.Dgv_Sales_Table.RowHeadersVisible = false;
            this.Dgv_Sales_Table.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Sales_Table.Size = new System.Drawing.Size(776, 429);
            this.Dgv_Sales_Table.TabIndex = 3;
            // 
            // Tab_Purchases_Table
            // 
            this.Tab_Purchases_Table.Controls.Add(this.Dgv_Purchases);
            this.Tab_Purchases_Table.Controls.Add(this.Gbx_Query_Purchases);
            this.Tab_Purchases_Table.Location = new System.Drawing.Point(4, 22);
            this.Tab_Purchases_Table.Name = "Tab_Purchases_Table";
            this.Tab_Purchases_Table.Size = new System.Drawing.Size(790, 502);
            this.Tab_Purchases_Table.TabIndex = 3;
            this.Tab_Purchases_Table.Text = "Таблица закупок";
            this.Tab_Purchases_Table.ToolTipText = "Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением процента" +
    " комиссионных. ";
            this.Tab_Purchases_Table.UseVisualStyleBackColor = true;
            this.Tab_Purchases_Table.Enter += new System.EventHandler(this.Tab_Query_4_Enter);
            // 
            // Dgv_Purchases
            // 
            this.Dgv_Purchases.AllowUserToAddRows = false;
            this.Dgv_Purchases.AllowUserToDeleteRows = false;
            this.Dgv_Purchases.AutoGenerateColumns = false;
            this.Dgv_Purchases.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Purchases.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Dgv_Purchases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Purchases.DataSource = this.sellersViewModelBindingSource2;
            this.Dgv_Purchases.Location = new System.Drawing.Point(9, 59);
            this.Dgv_Purchases.Name = "Dgv_Purchases";
            this.Dgv_Purchases.ReadOnly = true;
            this.Dgv_Purchases.RowHeadersVisible = false;
            this.Dgv_Purchases.Size = new System.Drawing.Size(776, 432);
            this.Dgv_Purchases.TabIndex = 7;
            // 
            // Gbx_Query_Purchases
            // 
            this.Gbx_Query_Purchases.Controls.Add(this.Lbl_Purchases);
            this.Gbx_Query_Purchases.Location = new System.Drawing.Point(9, 12);
            this.Gbx_Query_Purchases.Name = "Gbx_Query_Purchases";
            this.Gbx_Query_Purchases.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Query_Purchases.Size = new System.Drawing.Size(368, 41);
            this.Gbx_Query_Purchases.TabIndex = 6;
            this.Gbx_Query_Purchases.TabStop = false;
            // 
            // Lbl_Purchases
            // 
            this.Lbl_Purchases.AutoSize = true;
            this.Lbl_Purchases.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Purchases.Location = new System.Drawing.Point(9, 16);
            this.Lbl_Purchases.Name = "Lbl_Purchases";
            this.Lbl_Purchases.Size = new System.Drawing.Size(149, 15);
            this.Lbl_Purchases.TabIndex = 1;
            this.Lbl_Purchases.Text = "Вывод таблицы закупок";
            // 
            // Tab_Sellers_table
            // 
            this.Tab_Sellers_table.Controls.Add(this.DG_Sellers);
            this.Tab_Sellers_table.Controls.Add(this.Gbx_Sellers);
            this.Tab_Sellers_table.Location = new System.Drawing.Point(4, 22);
            this.Tab_Sellers_table.Name = "Tab_Sellers_table";
            this.Tab_Sellers_table.Size = new System.Drawing.Size(790, 502);
            this.Tab_Sellers_table.TabIndex = 4;
            this.Tab_Sellers_table.Text = "Таблица продавцов";
            this.Tab_Sellers_table.UseVisualStyleBackColor = true;
            // 
            // DG_Sellers
            // 
            this.DG_Sellers.AllowUserToAddRows = false;
            this.DG_Sellers.AllowUserToDeleteRows = false;
            this.DG_Sellers.AutoGenerateColumns = false;
            this.DG_Sellers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DG_Sellers.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DG_Sellers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DG_Sellers.DataSource = this.sellersViewModelBindingSource2;
            this.DG_Sellers.Location = new System.Drawing.Point(7, 59);
            this.DG_Sellers.Name = "DG_Sellers";
            this.DG_Sellers.ReadOnly = true;
            this.DG_Sellers.RowHeadersVisible = false;
            this.DG_Sellers.Size = new System.Drawing.Size(776, 432);
            this.DG_Sellers.TabIndex = 9;
            // 
            // Gbx_Sellers
            // 
            this.Gbx_Sellers.Controls.Add(this.Lbl_Sellers);
            this.Gbx_Sellers.Location = new System.Drawing.Point(7, 12);
            this.Gbx_Sellers.Name = "Gbx_Sellers";
            this.Gbx_Sellers.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Sellers.Size = new System.Drawing.Size(368, 41);
            this.Gbx_Sellers.TabIndex = 8;
            this.Gbx_Sellers.TabStop = false;
            // 
            // Lbl_Sellers
            // 
            this.Lbl_Sellers.AutoSize = true;
            this.Lbl_Sellers.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Sellers.Location = new System.Drawing.Point(9, 16);
            this.Lbl_Sellers.Name = "Lbl_Sellers";
            this.Lbl_Sellers.Size = new System.Drawing.Size(166, 15);
            this.Lbl_Sellers.TabIndex = 1;
            this.Lbl_Sellers.Text = "Вывод таблицы продавцов";
            // 
            // StatusStr
            // 
            this.StatusStr.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Lbl_Status_Qantity,
            this.Lbl_Query_Num});
            this.StatusStr.Location = new System.Drawing.Point(0, 581);
            this.StatusStr.Name = "StatusStr";
            this.StatusStr.Size = new System.Drawing.Size(800, 22);
            this.StatusStr.TabIndex = 1;
            this.StatusStr.Text = "statusStrip1";
            // 
            // Lbl_Status_Qantity
            // 
            this.Lbl_Status_Qantity.Name = "Lbl_Status_Qantity";
            this.Lbl_Status_Qantity.Size = new System.Drawing.Size(13, 17);
            this.Lbl_Status_Qantity.Text = "1";
            // 
            // Lbl_Query_Num
            // 
            this.Lbl_Query_Num.Name = "Lbl_Query_Num";
            this.Lbl_Query_Num.Size = new System.Drawing.Size(13, 17);
            this.Lbl_Query_Num.Text = "2";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 603);
            this.Controls.Add(this.StatusStr);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.Tbc_Main);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Tbc_Main.ResumeLayout(false);
            this.Tab_Query_1.ResumeLayout(false);
            this.Tab_Query_1.PerformLayout();
            this.Gbx_Tab_Query1.ResumeLayout(false);
            this.Gbx_Tab_Query1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_1)).EndInit();
            this.Tab_Query_2.ResumeLayout(false);
            this.Tab_Query_2.PerformLayout();
            this.Gbx_Tab_Query2.ResumeLayout(false);
            this.Gbx_Tab_Query2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchasesViewModelBindingSource)).EndInit();
            this.Tab_Sales_Table.ResumeLayout(false);
            this.Gbx_Tab_Sales.ResumeLayout(false);
            this.Gbx_Tab_Sales.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Sales_Table)).EndInit();
            this.Tab_Purchases_Table.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Purchases)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource2)).EndInit();
            this.Gbx_Query_Purchases.ResumeLayout(false);
            this.Gbx_Query_Purchases.PerformLayout();
            this.Tab_Sellers_table.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DG_Sellers)).EndInit();
            this.Gbx_Sellers.ResumeLayout(false);
            this.Gbx_Sellers.PerformLayout();
            this.StatusStr.ResumeLayout(false);
            this.StatusStr.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl Tbc_Main;
        private System.Windows.Forms.TabPage Tab_Query_1;
        private System.Windows.Forms.TabPage Tab_Query_2;
        private System.Windows.Forms.StatusStrip StatusStr;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.TabPage Tab_Sales_Table;
        private System.Windows.Forms.TabPage Tab_Purchases_Table;
        private System.Windows.Forms.DataGridView Dgv_Query_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitShortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource purchasesViewModelBindingSource;
        private System.Windows.Forms.Label Lbl_Query_1;
        private System.Windows.Forms.TextBox Tbx_Selected;
        private System.Windows.Forms.GroupBox Gbx_Tab_Query1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox Gbx_Tab_Query2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView Dgv_Query_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridView Dgv_Sales_Table;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.ToolStripStatusLabel Lbl_Status_Qantity;
        private System.Windows.Forms.ToolStripStatusLabel Lbl_Query_Num;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.GroupBox Gbx_Query_Purchases;
        private System.Windows.Forms.Label Lbl_Purchases;
        private System.Windows.Forms.BindingSource sellersViewModelBindingSource;
        private System.Windows.Forms.BindingSource sellersViewModelBindingSource1;
        private System.Windows.Forms.BindingSource sellersViewModelBindingSource2;
        private System.Windows.Forms.DataGridView Dgv_Purchases;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellerSNPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox Gbx_Tab_Sales;
        private System.Windows.Forms.Label Lbl_Sales_Tables;
        private System.Windows.Forms.TabPage Tab_Sellers_table;
        private System.Windows.Forms.DataGridView DG_Sellers;
        private System.Windows.Forms.GroupBox Gbx_Sellers;
        private System.Windows.Forms.Label Lbl_Sellers;
    }
}