﻿-- представления к базе данных


-- представление для персоны
drop view if exists ViewPerson;
go

create view ViewPerson as
    select 
        Persons.Surname    as Surname
        , Persons.[Name]     as [Name]
        , Persons.Patronymic as Patronymic
from
    Person
go


-- представление для адресса
drop view if exists ViewAddress;
go

create view ViewAddress as
    select 
        [Address].Id
        ,StreetType.TypeOfStreet    as StreetType
        , StreetName.NameOfStreet    as StreetName
        , HouseNumber     
        , ApartmentNumber
from
    [Address] join  StreetType on [Address].IdStreetType = StreetType.id
              join  StreetName on [Address].IdStreetName = StreetName.id
go

-- представление для квартиры
drop view if exists ViewApartment;
go

create view ViewApartment as
    select 
        Apartment.Id
        , StreetType
        , StreetName
        , HouseNumber     
        , ApartmentNumber
        , Area
        , CountRooms
        , Price
from
    Apartment join ViewAddress on Apartment.IdAddress = ViewAddress.Id
go


-- Seller
-- представление для продовца
drop view if exists ViewSeller;
go

create view ViewSeller as
    select 
        Seller.Id
        , StreetType
        , StreetName
        , HouseNumber     
        , ApartmentNumber
        , Area
        , CountRooms
        , Price
        , Person.[Surname] as SellerSurname
        , Person.[Name] as SellerName
        , Person.[Patronymic] as SellerPatronymic
        , PassportID as Passport
from
    Seller join ViewApartment on Seller.IdApartment = ViewApartment.Id
           join Person on Seller.IdPerson = Person.Id
go


-- представление для риелтора
drop view if exists ViewRealtor;
go

create view ViewRealtor as
    select 
        Realtor.Id     
        , Person.[Surname] as RealtorSurname
        , Person.[Name] as RealtorName
        , Person.[Patronymic] as RealtorPatronymic
        , [Percent] 
from
     Realtor join Person on Realtor.IdPerson = Person.Id
go


-- представление для сделки
drop view if exists ViewDeals;
go

create view ViewDeals as
    select 
        Deals.Id    
        , StreetType
        , StreetName
        , HouseNumber     
        , ApartmentNumber
        , Area
        , CountRooms
        , Price
        , ViewSeller.SellerSurname as SellerSurname
        , ViewSeller.SellerName as SellerName
        , ViewSeller.SellerPatronymic as SellerPatronymic     
        , ViewSeller.Passport as SellerPassport
        , ViewRealtor.RealtorSurname as RealtorSurname
        , ViewRealtor.RealtorName as RealtorName
        , ViewRealtor.RealtorPatronymic as RealtorPatronymic    
        , [Date]
        , ViewRealtor.[Percent] as [Percent]
from
     Deals join ViewRealtor on Deals.IdRealtor = ViewRealtor.Id
           join ViewSeller on Deals.IdSeller = ViewSeller.Id
go
