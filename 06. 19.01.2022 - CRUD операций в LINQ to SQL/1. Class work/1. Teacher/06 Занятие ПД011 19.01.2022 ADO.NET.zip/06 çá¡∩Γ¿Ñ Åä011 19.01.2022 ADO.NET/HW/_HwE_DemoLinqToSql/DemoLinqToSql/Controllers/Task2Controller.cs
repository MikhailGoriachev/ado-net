﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using DemoLinqToSql.Models.Task2;

namespace DemoLinqToSql.Controllers
{
    public class Task2Controller
    {
        // для связи с БД
        private WholesaleDataContext _wholesaleDataContext;

        public Task2Controller() : this(new WholesaleDataContext()) { }

        public Task2Controller(WholesaleDataContext wholesaleDataContext) {
            _wholesaleDataContext = wholesaleDataContext;
        } // Task2Controller

        private List<Sales> GetAllSales() => _wholesaleDataContext.Sales.ToList();


        // TODO: перенести в Application
        public void ShowAllSells() {
            Console.WriteLine("\n\n\n\n\tВсе продажи");

            var allSales = GetAllSales();
            allSales.ForEach(s => Console.WriteLine(
                $"\t│ {s.Id,3} │ {s.Purchases.Goods.Item, -25} │ {s.Units.Short, 5} │ {s.Price, 12:n2} │ {s.SaleDate:d} " +
                $"│ {$"{s.Sellers.Persons.Surname} {s.Sellers.Persons.Name[0]}.{s.Sellers.Persons.Patronymic[0]}.", -20} │"));
        } // ShowAllSells


        // Запрос 3	Запрос с параметрами
        // Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием
        // (например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
        public List<Purchases> Query03Ext(string item, int price) {
            return _wholesaleDataContext.Purchases
                .Where(p => p.Goods.Item == item && p.Price < price)
                .ToList();
        } // Query03Ext

        public List<Purchases> Query03Linq(string item, int price) {
            var query =
                from p in _wholesaleDataContext.Purchases
                where p.Goods.Item == item && p.Price < price
                select p;

            return query.ToList();
        } // Query03Ext


        // TODO: перенести в Application
        public void RunAndShowQuery03Ext() {
            string item = "чехол защитный";
            int price = 1800;
            var result = Query03Ext(item, price);

            Console.WriteLine($"\n\n\n\tТовар \"{item}\" с ценой закупки < {price} руб.");

            result.ForEach(p => Console.WriteLine(
                $"\t│ {p.Id, 3} │ {p.Goods.Item, -25} │ {p.Price, 12:n2} │"));
        } // RunAndShowQuery03Ext


        // TODO: перенести в Application
        public void RunAndShowQuery03Linq() {
            string item = "чехол защитный";
            int price = 1800;
            var result = Query03Linq(item, price);

            Console.WriteLine($"\n\n\n\tТовар \"{item}\" с ценой закупки < {price} руб.");

            result.ForEach(p => Console.WriteLine(
                $"\t│ {p.Id, 3} │ {p.Goods.Item, -25} │ {p.Price, 12:n2} │"));
        } // RunAndShowQuery03Linq
    } // class Task2Controller
}
