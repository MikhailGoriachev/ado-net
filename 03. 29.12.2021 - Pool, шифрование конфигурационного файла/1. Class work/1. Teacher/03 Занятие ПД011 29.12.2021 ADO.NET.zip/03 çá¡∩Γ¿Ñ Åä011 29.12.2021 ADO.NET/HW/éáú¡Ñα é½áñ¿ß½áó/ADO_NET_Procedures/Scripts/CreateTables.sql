﻿
-- Удаление всех таблиц
drop table if exists Deals;
drop table if exists Realtors;
drop table if exists Flats;
drop table if exists Owners;

-- Таблицы без связей
drop table if exists Person;
drop table if exists Adress;
go

-- Таблица риелторов
create table dbo.Person(
	Id         int not null primary key identity (1, 1), 
	Person_name nvarchar(60) not null,    -- Фамилия 
	Surname		nvarchar(50) not null,    -- Имя 
	Patronymic	nvarchar(60) not null,    -- Отчество 
);
go

-- Таблица адресов
create table dbo.Adress(
	Id         int not null primary key identity (1, 1), 
	Street nvarchar(60) not null,  -- Улица 
	House  nvarchar(10) not null,  -- Номер дома (В строковом типе поскольку возможна комбинация букв и цифр в номере)
);
go

-- Таблица владельцев
create table dbo.Owners(
	Id       int not null primary key identity (1, 1), 
	IdPerson int not null,
	Passport nvarchar(60) not null,    -- Номер паспорта

	-- Связи с таблицами
	constraint FK_Owners_Person foreign key (IdPerson) references dbo.Person(Id),
);
go

-- Таблица квартир
create table dbo.Flats(
	Id          int not null primary key identity (1, 1), 
	Square_flat float not null, -- Площадь квартиры
	Rooms       int not null,	-- Количество комнат
	Price       float not null,	-- Стоимость 
	Number      int not null,   -- Номер квартиры
	IdAdress    int not null,   -- Адрес местонахождения 
	IdOwner		int not null,   -- Владелец квартиры

	-- Связь с таблицами 
	constraint FK_Flats_Aderess foreign key (IdAdress) references Adress (Id),
	constraint FK_Flats_Owners foreign key (IdOwner) references Owners (Id),

	-- Ограничения
	constraint CK_Flats_Price  check (Price >0 ),
	constraint CK_Flats_Rooms  check (Rooms >0 ),
	constraint CK_Flats_Square check (Price >19 ), --Минимальная площадь квартиры
	constraint CK_Flats_Number check (Number > 0)
);
go


--
-- Таблица риелторов
create table dbo.Realtors(
	Id         int not null primary key identity (1, 1), 
	IdPerson int not null,
	Per_cent float not null -- Процент вознаграждения в вещественном типе
);
go	

-- Таблица сделок
create table dbo.Deals (
	Id int not null primary key identity (1,1),
	Date_of_deal  Date not null,
	IdRealtor int not null,
	IdFlat    int not null, -- Продаваемая квартира

	-- Связи с другими таблицами
	constraint FK_Deals_Realtors foreign key (IdRealtor) references dbo.Realtors(Id) ,
	constraint FK_Deals_Flats   foreign key (IdFlat)    references dbo.Flats (Id)
);
go	

