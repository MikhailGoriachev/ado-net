﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _3ADO.NET.Controllers;
using _3ADO.NET.Models;

namespace _3ADO.NET.Application
{
    class App
    {
        //контроллер запросов
        private QueryController queryController;
        //конструктор по умолчанию
        public App()
        {
            queryController = new QueryController();
        }
        
        
        #region запросы
        public void Query1()
        {
            List<Publication> pubs = queryController.Query1("Газета", 400);
            Console.WriteLine("\t1. Выбирает из таблицы ИЗДАНИЯ информацию о доступных для\n" +
                "\tподписки изданиях заданного типа, стоимость 1 экземпляра\n" +
                "\tдля которых меньше заданной.\n" +
                "\tТребуется модель для вывода данных – данные выборки помещать\n" +
                "\tв коллекцию\n");
            Console.WriteLine(Publication.HeaderOfTable());
            foreach (var item in pubs)
                Console.WriteLine(item.ToTableRow());
            Console.WriteLine(Publication.BottomOfTable());
        }
        public void Query2()
        {
            List<Subscriber> subs = queryController.Query2("Свободы", "23B", "Утренний Донецк");
            Console.WriteLine("\t2. Выбирает из таблиц информацию о подписчиках,\n" +
                "\tпроживающих на заданной параметром улице и номере дома,\n" +
                "\tкоторые оформили подписку на издание с заданным параметром наименованием.");
            Console.WriteLine(Subscriber.HeaderOfTable());
            foreach (var item in subs)
                Console.WriteLine(item.ToTableRow());
            Console.WriteLine(Subscriber.BottomOfTable());
        }
        public void Query3()
        {
            List<Publication> pubs = queryController.Query3(300, 400);
            Console.WriteLine("\t3. Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение\n" +
                "\tв поле Цена 1 экземпляра находится в заданном диапазоне значений.");
            Console.WriteLine(Publication.HeaderOfTable());
            foreach (var item in pubs)
                Console.WriteLine(item.ToTableRow());
            Console.WriteLine(Publication.BottomOfTable());
        }
        public void Query4()
        {
            List<Subscriber> pubs = queryController.Query4("Утренний Донецк");
            Console.WriteLine("\t4.Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный\n" +
                "\tпараметром тип издания");
            Console.WriteLine(Subscriber.HeaderOfTable());
            foreach (var item in pubs)
                Console.WriteLine(item.ToTableRow());
            Console.WriteLine(Subscriber.BottomOfTable());
        }
        public void Query5()
        {
            Console.WriteLine("\t5.Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных\n" +
                "\tподписках, для которых срок подписки есть значение из некоторого диапазона.\n" +
                "\tНижняя и верхняя границы диапазона задаются при выполнении запросa");
            queryController.Query5(new DateTime(2021,11,1), new DateTime(2021, 11, 04));
        }
        public void Query6()
        {
            Console.WriteLine("\t6.Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС.");
            queryController.Query6();
        }
        public void Query7()
        {
            Console.WriteLine("\t7.Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра");
            queryController.Query7();
        }
        public void Query8()
        {
            Console.WriteLine("\t8.Для всех улиц вычисляет количество подписчиков,\n"
                + "\tпроживающих на данной улице (итоги по полю Код получателя)");
            queryController.Query8();
        }
        public void Query9()
        {
            Console.WriteLine("\t9.Для всех изданий выводит количество оформленных подписок");
            queryController.Query9();
        }
        #endregion


        #region шифровка
        //шифровка
        public void Protect() 
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (!section.SectionInformation.IsProtected)
            {
                // Зашифровать секцию.
                section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                // Сохранить файл конфигурации.
                config.Save();
            } // if

            Console.WriteLine($"Protected={section.SectionInformation.IsProtected}\n");
        //расшифровка
        }
        //расшифровка
        public void Unprotect() 
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;
            //расшифровкa секции
            section.SectionInformation.UnprotectSection();
            config.Save();

            Console.WriteLine($"Protected={section.SectionInformation.IsProtected}\n");
        }
        #endregion

    }
}
