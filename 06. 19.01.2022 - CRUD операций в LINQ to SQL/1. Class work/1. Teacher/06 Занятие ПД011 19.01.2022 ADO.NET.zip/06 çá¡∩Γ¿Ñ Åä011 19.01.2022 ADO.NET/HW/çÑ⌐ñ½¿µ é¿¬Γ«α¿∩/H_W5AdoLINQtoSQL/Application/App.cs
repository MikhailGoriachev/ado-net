﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W5AdoLINQtoSQL.Models.Task1;
using H_W5AdoLINQtoSQL.Models.Task2;

namespace H_W5AdoLINQtoSQL.Application
{
    // Класс приложения - обработка по заданию
    internal partial class App
    {
        private CollectionBooks _collectionBooks;

        private WholesaleStore _wholesale;

        // конструктор с внедрением зависимостей
        public App() : this(new CollectionBooks(), new WholesaleStore()) { }

        public App(CollectionBooks books, WholesaleStore store)
        {
            _collectionBooks = books;
            _wholesale = store;

        } // App

    }// class App
}
