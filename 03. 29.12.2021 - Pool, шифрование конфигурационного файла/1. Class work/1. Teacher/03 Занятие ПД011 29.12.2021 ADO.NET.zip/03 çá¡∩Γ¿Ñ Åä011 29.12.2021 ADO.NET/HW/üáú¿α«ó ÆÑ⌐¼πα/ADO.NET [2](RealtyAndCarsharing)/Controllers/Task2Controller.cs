﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// для работы с технологией ADO.NET
using System.Configuration;   // добавить сборку System.Configuration.dll
using System.Data;
using System.Data.SqlClient;

namespace ADO.NET__2__RealtyAndCarsharing_.Controllers
{
    public class Task2Controller{

        private string _connectingString;
        public string ConnectingString
        {
            get => _connectingString;
            set => _connectingString = string.IsNullOrWhiteSpace(value)
                ? throw new Exception("Строка подключения к базе данных не указана") : value;
        }

        public Task2Controller() : this(ConfigurationManager.ConnectionStrings["CarsharingConnectionSQLServer"].ConnectionString) { }

        public Task2Controller(string connectingString) => ConnectingString = connectingString;

        //			-> Запрос №1 [Запрос с параметром] <-
        // Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public void Query1(string plate)
        {
            Console.WriteLine("\n\n\n\tЗапрос 1.\n" +
                                $"\tФакты проката автомобиля с госномером {plate}\n");

            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                	*
                from
                	ViewRentals
                where
                	Plate = @plate;"
                );

                cmd.Connection = connection;

                cmd.Parameters.AddWithValue("@plate", plate); 

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToRentals(cmd);
            } // using
        } // Query1


        //			-> Запрос №2 [Запрос с параметром] <-
        // Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
        public void Query2(string brandModel)
        {
            Console.WriteLine("\n\n\n\tЗапрос 2.\n" +
                                $"\tФакты проката автомобиля с данной моделью/брендом {brandModel}\n");

            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                	*
                from
                	ViewRentals
                where
                	BrandModelCar = @brandModel;"
                );

                cmd.Connection = connection;

                cmd.Parameters.AddWithValue("@brandModel", brandModel);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToRentals(cmd);
            } // using
        } // Query2

        //			-> Запрос №3 [Запрос с параметром] <-
        // Выбирает информацию об автомобиле с заданным госномером
        public void Query3(string plate)
        {
            Console.WriteLine("\n\n\n\tЗапрос 3.\n" +
                                $"Информация об автомобиле с заданным госномером {plate}\n");

            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                	*
                from
                	ViewCars
                where
                	Plate = @plate;"
                );

                cmd.Connection = connection;

                cmd.Parameters.AddWithValue("@plate", plate);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // выводим имена столбцов (это не обязательно)
                Console.WriteLine("\t" +
                                  $"│ {reader.GetName(0),4} │ {reader.GetName(1),-22} " +
                                  $"│ {reader.GetName(2),-12} │ {reader.GetName(3),-12} " +
                                  $"│ {reader.GetName(4),-10} │ {reader.GetName(5),-11} " +
                                  $"│ {reader.GetName(6),8} |");


                // Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetInt32(0),4} " +
                            $"│ {reader.GetString(1),-22} " +
                            $"│ {reader.GetString(2),-12} " +
                            $"│ {reader.GetString(3),-12} " +
                            $"│ {reader.GetInt32(4),10} " +
                            $"│ {reader.GetInt32(5),12:n0} " +
                            $"│ {reader.GetInt32(6),8} │");
                    } // while
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\tНет данных");
                    Console.ForegroundColor = ConsoleColor.Gray;
                } // if

            } // using
        } // Query3


        //			-> Запрос №4 [Запрос с параметром] <-
        // Выбирает информацию о клиентах по серии и номеру паспорта
        public void Query4(string passport)
        {
            Console.WriteLine("\n\n\n\tЗапрос 4.\n" +
                                $"Клиент с серией и номером паспорта {passport}\n");

            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                	 *
                from
                	Clients
                where
                	Passport = @passport;"
                );

                cmd.Connection = connection;

                cmd.Parameters.AddWithValue("@passport", passport);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // выводим имена столбцов (это не обязательно)
                Console.WriteLine("\t" +
                                  $"│ {reader.GetName(0),4} │ {reader.GetName(1),-22} " +
                                  $"│ {reader.GetName(2),-12} │ {reader.GetName(3),-12} " +
                                  $"│ {reader.GetName(4),-13}|");


                // Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetInt32(0),4} " +
                            $"│ {reader.GetString(1),-22} " +
                            $"│ {reader.GetString(2),-12} " +
                            $"│ {reader.GetString(3),-12} " +
                            $"│ {reader.GetString(4),10} │");
                    } // while
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\tНет данных");
                    Console.ForegroundColor = ConsoleColor.Gray;
                } // if

            } // using
        } // Query4

        // Вывод запроса, использующего данные фактов проката
        private void QueryToRentals(SqlCommand cmd)
        {
            // выполнение запроса, ссылка на  выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // выводим имена столбцов (это не обязательно)
            Console.WriteLine("\t" +
                              $"│ {reader.GetName(0),4} │ {reader.GetName(1),-22} " +
                              $"│ {reader.GetName(2),-12} │ {reader.GetName(3),-26} " +
                              $"│ {reader.GetName(4),-10} │ {reader.GetName(5),-11} " +
                              $"│ {reader.GetName(6),4} │ {reader.GetName(7),18} " +
                              $"│ {reader.GetName(8),8} │ {reader.GetName(9),7} │ { reader.GetName(10),7} |");


            // Если данные получены (есть строки в полученном ответе сервера)
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Console.WriteLine("\t" +
                        $"│ {reader.GetInt32(0),4} " +
                        $"│ {reader.GetString(1),-22} " +
                        $"│ {reader.GetString(2),-12} " +
                        $"│ {reader.GetString(3),-26} " +
                        $"│ {reader.GetString(4),-10} " +
                        $"│ {reader.GetString(5),-11} " +
                        $"│ {reader.GetInt32(6),12} " +
                        $"│ {reader.GetDateTime(7),11} " +
                        $"│ {reader.GetInt32(8),14} " +
                        $"│ {reader.GetInt32(9),17} " +
                        $"│ {reader.GetInt32(10),12} │");
                } // while
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\tНет данных");
                Console.ForegroundColor = ConsoleColor.Gray;
            } // if
        } // QueryToApartment

    }
}
