﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wholesale.Controllers;
using Wholesale.Helpers;

namespace Wholesale
{
    public partial class MainForm : Form
    {
        // контроллер для выполнения запросов к базе данных по заданию
        private WholesaleController _wholesaleController;

        public MainForm() {
            InitializeComponent();

            _wholesaleController = new WholesaleController();

            // начальное заполнение вкладок с таблицами БД
            DgvGoods.DataSource = _wholesaleController.GetGoodsAll();
            DgvSellers.DataSource = _wholesaleController.GetSellersAll();

            TbcResults.SelectedTab = TbpGoods;
        } // MainWindow

        
        // выполнение команды "Вывод сведений о товарах"
        private void ViewGoods_Command(object sender, EventArgs e) {
            // делаем вкладку запроса текущей
            TbcResults.SelectedTab = TbpGoods;

            DgvGoods.DataSource = _wholesaleController.GetGoodsAll();

            // Вывод сведений в строку состояния
            TslInfo.Text = $"Сведения о наименованиях товаров получены, всего записей: {DgvGoods.RowCount}";
        } // ViewGoods_Command

        // выполнение команды "Вывод сведений о продавцах"
        private void ViewSellers_Command(object sender, EventArgs e) {
            // делаем вкладку запроса текущей
            TbcResults.SelectedTab = TbpSellers;

            DgvSellers.DataSource = _wholesaleController.GetSellersAll();

            // Вывод сведений в строку состояния
            TslInfo.Text = $"Сведения о продавцах получены, всего записей: {DgvSellers.RowCount}";
        } // ViewSellers_Command


        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        // выполнение запроса 1
        private void Query01_Command(object sender, EventArgs e) {
            // формируем параметры запроса
            var units = _wholesaleController.GetUnitsAll();
            string unit = units[Utils.GetRandom(0, units.Count-1)].Short;
            int price = Utils.GetRandom(1, 100) * 100;

            // делаем вкладку запроса текущей
            TbcResults.SelectedTab = TbpQuery01;

            // выполнение запроса, запись запроса в DataGridView
            DgvQuery01.DataSource = _wholesaleController.Query01(unit, price);

            // Вывод параметров и состояния запроса
            TslInfo.Text = $"Товары с единицей измерения \"{unit}\" и ценой закупки, меньшей {price} руб., получено записей: {DgvQuery01.RowCount}";
        } // Query01_Command


        // выполнение запроса 2
        private void Query02_Command(object sender, EventArgs e) {
            // формируем параметр запроса
            int price = Utils.GetRandom(1, 100) * 100;

            // делаем вкладку запроса текущей
            TbcResults.SelectedTab = TbpQuery02;

            // выполнение запроса, запись запроса в DataGridView
            DgvQuery02.DataSource = _wholesaleController.Query02(price);

            // Вывод параметров и состояния запроса
            TslInfo.Text = $"Товары с  ценой закупки, больше {price} руб., получено записей: {DgvQuery02.RowCount}";
        } // Query02_Command
        
        
        // выполнение запроса 6
        private void Query06_Command(object sender, EventArgs e) {
            // делаем вкладку запроса текущей
            TbcResults.SelectedTab = TbpQuery06;

            // выполнение запроса, запись запроса в DataGridView
            DgvQuery06.DataSource = _wholesaleController.Query06();

            // Вывод параметров и состояния запроса
            TslInfo.Text = $"Прибыль от продажи за каждый проданный товар, получено записей: {DgvQuery06.RowCount}";
        } // Query06_Command        
        

        // выполнение запроса 7
        private void Query07_Command(object sender, EventArgs e) {
            // делаем вкладку запроса текущей
            TbcResults.SelectedTab = TbpQuery07;

            // выполнение запроса, запись запроса в DataGridView
            DgvQuery07.DataSource = _wholesaleController.Query07();

            // Вывод параметров и состояния запроса
            TslInfo.Text = $"Получена статистика по закупкам, всего записей: {DgvQuery07.RowCount}";
        } // Query07_Command        


        // выполнение запроса 8
        private void Query08_Command(object sender, EventArgs e) {
            // делаем вкладку запроса текущей
            TbcResults.SelectedTab = TbpQuery08;

            // выполнение запроса, запись запроса в DataGridView
            DgvQuery08.DataSource = _wholesaleController.Query08();

            // Вывод параметров и состояния запроса
            TslInfo.Text = $"Получена статистика по работе продавцов, всего записей: {DgvQuery08.RowCount}";
        } // Query07_Command


    } // class MainForm 
}
