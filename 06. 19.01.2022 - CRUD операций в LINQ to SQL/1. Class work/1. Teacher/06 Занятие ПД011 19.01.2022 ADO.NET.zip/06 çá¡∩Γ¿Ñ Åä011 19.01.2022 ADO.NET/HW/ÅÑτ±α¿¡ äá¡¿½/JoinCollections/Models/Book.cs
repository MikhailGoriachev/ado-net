﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoinCollections.Models
{
    //класс Книга
    public class Book
    {
        public int Id { get; set; } // идентификатор

        public string Title { get; set; } // название книги

        public int Price { get; set; }   // цена

        public int IdAuthor { get; set; } // идентификатор автора

        public int Published { get; set; } // год издания

        public override string ToString() => $" | Название: {Title,15} | Цена: {Price,4}";

    }
}
