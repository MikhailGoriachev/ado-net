﻿namespace Main.Utilities.Menu
{
	internal static class Palette
	{
		public static Color Title => Utilities.Palette.Info;

		public static Color Normal => Utilities.Palette.Default;

		public static Color Current => Utilities.Palette.AccentDedicated;

		public static Color Navbar => Utilities.Palette.TertiaryDedicated;
	}
}