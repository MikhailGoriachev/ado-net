﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NET_Framework_WPF__1___ArithmeticOperations_
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Цвет шрифта при 
        Brush mainBrush;    // основной цвет
        Brush errorBrush;   // цвет при выводе ошибки
        public MainWindow()
        {
            InitializeComponent();
            mainBrush = TbxFirstArgument.Foreground;
            errorBrush = Brushes.PaleVioletRed;
        }

        // Нахождение среднего арифметического трех чисел
        private void AVG_Click(object sender, RoutedEventArgs e){
            // Ставим курсор ожидания.
            this.Cursor = Cursors.Wait;

            // задаем основной цвет шрифта 
            TbkResult.Foreground = mainBrush;

            // Делаем задержку, для создания эффекта того, что программа задумалась.
            Thread.Sleep(TimeSpan.FromSeconds(1));

            // объявление переменных, данные которых будут записаны из TextBox-ов
            float a = 0f, 
                  b = 0f, 
                  c = 0f;

            // TODO: Временное решение
            bool result = float.TryParse(TbxFirstArgument.Text, out a);
            if (result) 
                result = float.TryParse(TbxSecondArgument.Text, out b);
            if (result)
                result = float.TryParse(TbxThridArgument.Text, out c);
            if (!result){
                TbkResult.Foreground = errorBrush;
                TbkResult.Text = "ERROR: Невозможно выполнить операцию, введенны неверные данные!";
                this.Cursor = null;
                return;
            }

            TbkResult.Text = $"Средне арифметическое a({a:f2}); b({b:f2}); c({c:f2}) = {(a + b + c) / 3f:f2}";

            this.Cursor = null;
        }

        // Нахождение среднего геометрического трех чисел
        // по формуле: 3√abc.
        private void GeomMean_Click(object sender, RoutedEventArgs e) {
            // Ставим курсор ожидания.
            this.Cursor = Cursors.Wait;

            // задаем основной цвет шрифта 
            TbkResult.Foreground = mainBrush;

            // Делаем задержку, для создания эффекта того, что программа задумалась.
            Thread.Sleep(TimeSpan.FromSeconds(1));

            // объявление переменных, данные которых будут записаны из TextBox-ов
            float a = 0f,
                  b = 0f,
                  c = 0f;

            // TODO: Временное решение
            bool result = float.TryParse(TbxFirstArgument.Text, out a);
            if (result)
                result = float.TryParse(TbxSecondArgument.Text, out b);
            if (result)
                result = float.TryParse(TbxThridArgument.Text, out c);
            if (!result)
            {
                TbkResult.Foreground = errorBrush;
                TbkResult.Text = "ERROR: Невозможно выполнить операцию, введенны неверные данные!";
                this.Cursor = null;
                return;
            }
                                                                                        // Формула 3√abc.
            TbkResult.Text = $"Среднeе геометрическое a({a:f2}); b({b:f2}); c({c:f2}) = {Math.Pow(a * b * c, 1f/3f):f2}";

            this.Cursor = null;
        }

        // Нахождение корня квадратного уравнения
        private void RootQuadraticEquation_Click(object sender, RoutedEventArgs e) {
            // Ставим курсор ожидания.
            this.Cursor = Cursors.Wait;

            // задаем основной цвет шрифта 
            TbkResult.Foreground = mainBrush;

            // Делаем задержку, для создания эффекта того, что программа задумалась.
            Thread.Sleep(TimeSpan.FromSeconds(1));

            // объявление переменных, данные которых будут записаны из TextBox-ов
            double a = 0f,
                  b = 0f,
                  c = 0f;

            // TODO: Временное решение
            bool result = double.TryParse(TbxFirstArgument.Text, out a);
            if (result)
                result = double.TryParse(TbxSecondArgument.Text, out b);
            if (result)
                result = double.TryParse(TbxThridArgument.Text, out c);
            if (!result)
            {
                TbkResult.Foreground = errorBrush;
                TbkResult.Text = "ERROR: Невозможно выполнить операцию, введенны неверные данные!";
                this.Cursor = null;
                return;
            }
            // Формула 3√abc.

            double D = b * b - 4 * a * c;  // находим дискриминант
            double sqrtD = Math.Sqrt(D);   // извлекаем квадратный корень дискриминанта
            double x1 = 0f;                // задаем базовое значение для 1-го корня 
            double x2 = 0f;                // задаем базовое значение для 2-го корня
            string resStr;                 // строка выводящая итог операции в зависимости от кол-во корней
            if (sqrtD > 0){
                x1 = (-b + sqrtD) / (a * 2);
                x2 = (-b - sqrtD) / (a * 2);
                resStr = $"Корни квадратного уравнение x1({x1:f2}); x2({x2:f2})";
            }
            else if (sqrtD == 0){
                x1 = -b / (a * 2);
                resStr = $"Корни квадратного уравнение x1({x1:f2}); x2 - отсутствует";
            }
            else resStr = $"Квадратное уравнение не имеет корней"; 
            
            // Вывод парамметров и итог операции
            // т.к. компилятор сам подстовляет в sqrtD строку:"не число" - если мы пытаемся извлечь
            // квадратный корень из отрицательного числа, я никак не обробатываю этот момент.
            TbkResult.Text = $"Коэфиценты уравнения: a({a:f2}); b({b:f2}); c({c:f2})\n"
                               + $"Дискриминант(D): {D:f2}; √D: {sqrtD:f2}\n"
                               + $"Итог: " + resStr;

            this.Cursor = null;
        }
    }
}
