﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W3Ado.Controllers;

namespace H_W3Ado.Application
{
    // Класс приложения - обработка по заданию
    internal partial class App
    {
        RealEstateController _realEstateController;

        // конструктор с внедрением зависимостей
        public App(string connectingStringTask)
        {
            _realEstateController = new RealEstateController(connectingStringTask);

        } // App

    }// class App
}
