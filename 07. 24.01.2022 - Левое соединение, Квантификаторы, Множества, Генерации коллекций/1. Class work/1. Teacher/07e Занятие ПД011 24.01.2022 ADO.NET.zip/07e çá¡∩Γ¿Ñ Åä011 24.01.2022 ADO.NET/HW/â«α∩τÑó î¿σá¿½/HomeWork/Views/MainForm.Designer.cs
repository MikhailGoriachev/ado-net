﻿namespace HomeWork.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpUnits = new System.Windows.Forms.TabPage();
            this.GbxUnits = new System.Windows.Forms.GroupBox();
            this.DgvUnits = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.longDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpGoods = new System.Windows.Forms.TabPage();
            this.GbxGoods = new System.Windows.Forms.GroupBox();
            this.DgvGoods = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpSellers = new System.Windows.Forms.TabPage();
            this.GbxSellers = new System.Windows.Forms.GroupBox();
            this.DgvSellers = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.TbpPurchases = new System.Windows.Forms.TabPage();
            this.GbxPurchases = new System.Windows.Forms.GroupBox();
            this.DgvPurchases = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseViewModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.TbpSales = new System.Windows.Forms.TabPage();
            this.GbxSales = new System.Windows.Forms.GroupBox();
            this.DgvSales = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery1 = new System.Windows.Forms.TabPage();
            this.GrbQuery1 = new System.Windows.Forms.GroupBox();
            this.TbxQuery1 = new System.Windows.Forms.TextBox();
            this.GbxResult1 = new System.Windows.Forms.GroupBox();
            this.DgvQuery1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datePurchaseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpQuery2 = new System.Windows.Forms.TabPage();
            this.GrbQuery2 = new System.Windows.Forms.GroupBox();
            this.TbxQuery2 = new System.Windows.Forms.TextBox();
            this.GbxResult2 = new System.Windows.Forms.GroupBox();
            this.DgvQuery2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpQuery3 = new System.Windows.Forms.TabPage();
            this.GrbQuery3 = new System.Windows.Forms.GroupBox();
            this.TbxQuery3 = new System.Windows.Forms.TextBox();
            this.GbxResult3 = new System.Windows.Forms.GroupBox();
            this.DgvQuery3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpQuery4 = new System.Windows.Forms.TabPage();
            this.GrbQuery4 = new System.Windows.Forms.GroupBox();
            this.TbxQuery4 = new System.Windows.Forms.TextBox();
            this.GbxResult4 = new System.Windows.Forms.GroupBox();
            this.DgvQuery4 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery5 = new System.Windows.Forms.TabPage();
            this.GrbQuery5 = new System.Windows.Forms.GroupBox();
            this.TbxQuery5 = new System.Windows.Forms.TextBox();
            this.GbxResult5 = new System.Windows.Forms.GroupBox();
            this.DgvQuery5 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateSellDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpQuery6 = new System.Windows.Forms.TabPage();
            this.GrbQuery6 = new System.Windows.Forms.GroupBox();
            this.TbxQuery6 = new System.Windows.Forms.TextBox();
            this.GbxResult6 = new System.Windows.Forms.GroupBox();
            this.DgvQuery6 = new System.Windows.Forms.DataGridView();
            this.CmnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnDateSell = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnGoods = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnSeller = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnSumPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BdsData = new System.Windows.Forms.BindingSource(this.components);
            this.TbpQuery7 = new System.Windows.Forms.TabPage();
            this.GrbQuery7 = new System.Windows.Forms.GroupBox();
            this.TbxQuery7 = new System.Windows.Forms.TextBox();
            this.GbxResult7 = new System.Windows.Forms.GroupBox();
            this.DgvQuery7 = new System.Windows.Forms.DataGridView();
            this.CmnIdGoods = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnGoodsKey = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnCountGoods = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnAvgPriceGoods = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpQuery8 = new System.Windows.Forms.TabPage();
            this.GrbQuery8 = new System.Windows.Forms.GroupBox();
            this.TbxQuery8 = new System.Windows.Forms.TextBox();
            this.GbxResult8 = new System.Windows.Forms.GroupBox();
            this.DgvQuery8 = new System.Windows.Forms.DataGridView();
            this.CmnIdSeller = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnSurnameSeller = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnNameSeller = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnPatronymicSeller = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnCountGoodsSeller = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnAvgPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TspMain = new System.Windows.Forms.ToolStrip();
            this.TsiExit = new System.Windows.Forms.ToolStripButton();
            this.TsiInfo = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.purchaseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sellerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.CmsMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiMainInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiMainExit = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.saleViewModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.MnsMain.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpUnits.SuspendLayout();
            this.GbxUnits.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvUnits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitBindingSource)).BeginInit();
            this.TbpGoods.SuspendLayout();
            this.GbxGoods.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvGoods)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodBindingSource)).BeginInit();
            this.TbpSellers.SuspendLayout();
            this.GbxSellers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSellers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource2)).BeginInit();
            this.TbpPurchases.SuspendLayout();
            this.GbxPurchases.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPurchases)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseViewModelBindingSource1)).BeginInit();
            this.TbpSales.SuspendLayout();
            this.GbxSales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSales)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource)).BeginInit();
            this.TbpQuery1.SuspendLayout();
            this.GrbQuery1.SuspendLayout();
            this.GbxResult1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery1)).BeginInit();
            this.TbpQuery2.SuspendLayout();
            this.GrbQuery2.SuspendLayout();
            this.GbxResult2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery2)).BeginInit();
            this.TbpQuery3.SuspendLayout();
            this.GrbQuery3.SuspendLayout();
            this.GbxResult3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery3)).BeginInit();
            this.TbpQuery4.SuspendLayout();
            this.GrbQuery4.SuspendLayout();
            this.GbxResult4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource1)).BeginInit();
            this.TbpQuery5.SuspendLayout();
            this.GrbQuery5.SuspendLayout();
            this.GbxResult5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery5)).BeginInit();
            this.TbpQuery6.SuspendLayout();
            this.GrbQuery6.SuspendLayout();
            this.GbxResult6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BdsData)).BeginInit();
            this.TbpQuery7.SuspendLayout();
            this.GrbQuery7.SuspendLayout();
            this.GbxResult7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery7)).BeginInit();
            this.TbpQuery8.SuspendLayout();
            this.GrbQuery8.SuspendLayout();
            this.GbxResult8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery8)).BeginInit();
            this.TspMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).BeginInit();
            this.CmsMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.BackColor = System.Drawing.Color.DarkGray;
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.MnsMain.Size = new System.Drawing.Size(1146, 40);
            this.MnsMain.TabIndex = 0;
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.MniFile.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MniFile.Image = global::HomeWork.Properties.Resources.page;
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(91, 36);
            this.MniFile.Text = "&Файл";
            // 
            // MniExit
            // 
            this.MniExit.Image = global::HomeWork.Properties.Resources.door_out;
            this.MniExit.Name = "MniExit";
            this.MniExit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MniExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.MniExit.Size = new System.Drawing.Size(182, 26);
            this.MniExit.Text = "&Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniInfo});
            this.MniHelp.Image = global::HomeWork.Properties.Resources.help;
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(115, 36);
            this.MniHelp.Text = "&Помощь";
            // 
            // MniInfo
            // 
            this.MniInfo.Image = global::HomeWork.Properties.Resources.information;
            this.MniInfo.Name = "MniInfo";
            this.MniInfo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.MniInfo.Size = new System.Drawing.Size(258, 38);
            this.MniInfo.Text = "&О программе...";
            this.MniInfo.Click += new System.EventHandler(this.Info_Command);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpUnits);
            this.TbcMain.Controls.Add(this.TbpGoods);
            this.TbcMain.Controls.Add(this.TbpSellers);
            this.TbcMain.Controls.Add(this.TbpPurchases);
            this.TbcMain.Controls.Add(this.TbpSales);
            this.TbcMain.Controls.Add(this.TbpQuery1);
            this.TbcMain.Controls.Add(this.TbpQuery2);
            this.TbcMain.Controls.Add(this.TbpQuery3);
            this.TbcMain.Controls.Add(this.TbpQuery4);
            this.TbcMain.Controls.Add(this.TbpQuery5);
            this.TbcMain.Controls.Add(this.TbpQuery6);
            this.TbcMain.Controls.Add(this.TbpQuery7);
            this.TbcMain.Controls.Add(this.TbpQuery8);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 79);
            this.TbcMain.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1146, 420);
            this.TbcMain.TabIndex = 1;
            this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
            // 
            // TbpUnits
            // 
            this.TbpUnits.BackColor = System.Drawing.Color.Gray;
            this.TbpUnits.Controls.Add(this.GbxUnits);
            this.TbpUnits.Location = new System.Drawing.Point(4, 25);
            this.TbpUnits.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpUnits.Name = "TbpUnits";
            this.TbpUnits.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpUnits.Size = new System.Drawing.Size(1138, 391);
            this.TbpUnits.TabIndex = 9;
            this.TbpUnits.Text = "Единицы измерения";
            // 
            // GbxUnits
            // 
            this.GbxUnits.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxUnits.Controls.Add(this.DgvUnits);
            this.GbxUnits.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxUnits.ForeColor = System.Drawing.Color.White;
            this.GbxUnits.Location = new System.Drawing.Point(8, 8);
            this.GbxUnits.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxUnits.Name = "GbxUnits";
            this.GbxUnits.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxUnits.Size = new System.Drawing.Size(1119, 376);
            this.GbxUnits.TabIndex = 1;
            this.GbxUnits.TabStop = false;
            this.GbxUnits.Text = " Содержание таблицы \"Единицы измерения\" ";
            // 
            // DgvUnits
            // 
            this.DgvUnits.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvUnits.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvUnits.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvUnits.AutoGenerateColumns = false;
            this.DgvUnits.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvUnits.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvUnits.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvUnits.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvUnits.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.longDataGridViewTextBoxColumn,
            this.shortDataGridViewTextBoxColumn});
            this.DgvUnits.DataSource = this.unitBindingSource;
            this.DgvUnits.Location = new System.Drawing.Point(8, 24);
            this.DgvUnits.Name = "DgvUnits";
            this.DgvUnits.ReadOnly = true;
            this.DgvUnits.RowHeadersVisible = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.DgvUnits.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DgvUnits.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvUnits.Size = new System.Drawing.Size(1102, 344);
            this.DgvUnits.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn3.FillWeight = 15F;
            this.idDataGridViewTextBoxColumn3.HeaderText = "Идентификатор";
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            this.idDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // longDataGridViewTextBoxColumn
            // 
            this.longDataGridViewTextBoxColumn.DataPropertyName = "Long";
            this.longDataGridViewTextBoxColumn.FillWeight = 50F;
            this.longDataGridViewTextBoxColumn.HeaderText = "Название";
            this.longDataGridViewTextBoxColumn.Name = "longDataGridViewTextBoxColumn";
            this.longDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // shortDataGridViewTextBoxColumn
            // 
            this.shortDataGridViewTextBoxColumn.DataPropertyName = "Short";
            this.shortDataGridViewTextBoxColumn.FillWeight = 30F;
            this.shortDataGridViewTextBoxColumn.HeaderText = "Сокращённое название";
            this.shortDataGridViewTextBoxColumn.Name = "shortDataGridViewTextBoxColumn";
            this.shortDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // unitBindingSource
            // 
            this.unitBindingSource.DataSource = typeof(HomeWork.Models.Unit);
            // 
            // TbpGoods
            // 
            this.TbpGoods.BackColor = System.Drawing.Color.Gray;
            this.TbpGoods.Controls.Add(this.GbxGoods);
            this.TbpGoods.Location = new System.Drawing.Point(4, 25);
            this.TbpGoods.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpGoods.Name = "TbpGoods";
            this.TbpGoods.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpGoods.Size = new System.Drawing.Size(1138, 391);
            this.TbpGoods.TabIndex = 10;
            this.TbpGoods.Text = "Товары";
            // 
            // GbxGoods
            // 
            this.GbxGoods.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxGoods.Controls.Add(this.DgvGoods);
            this.GbxGoods.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxGoods.ForeColor = System.Drawing.Color.White;
            this.GbxGoods.Location = new System.Drawing.Point(8, 8);
            this.GbxGoods.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxGoods.Name = "GbxGoods";
            this.GbxGoods.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxGoods.Size = new System.Drawing.Size(1119, 376);
            this.GbxGoods.TabIndex = 1;
            this.GbxGoods.TabStop = false;
            this.GbxGoods.Text = " Содержание таблицы \"Товары\" ";
            // 
            // DgvGoods
            // 
            this.DgvGoods.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvGoods.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.DgvGoods.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvGoods.AutoGenerateColumns = false;
            this.DgvGoods.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvGoods.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvGoods.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvGoods.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvGoods.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn4,
            this.nameDataGridViewTextBoxColumn1});
            this.DgvGoods.DataSource = this.goodBindingSource;
            this.DgvGoods.Location = new System.Drawing.Point(8, 24);
            this.DgvGoods.Name = "DgvGoods";
            this.DgvGoods.ReadOnly = true;
            this.DgvGoods.RowHeadersVisible = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.DgvGoods.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DgvGoods.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvGoods.Size = new System.Drawing.Size(1102, 344);
            this.DgvGoods.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn4
            // 
            this.idDataGridViewTextBoxColumn4.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn4.FillWeight = 15F;
            this.idDataGridViewTextBoxColumn4.HeaderText = "Идентификатор";
            this.idDataGridViewTextBoxColumn4.Name = "idDataGridViewTextBoxColumn4";
            this.idDataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn1.FillWeight = 85F;
            this.nameDataGridViewTextBoxColumn1.HeaderText = "Название";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            this.nameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // goodBindingSource
            // 
            this.goodBindingSource.DataSource = typeof(HomeWork.Models.Good);
            // 
            // TbpSellers
            // 
            this.TbpSellers.BackColor = System.Drawing.Color.Gray;
            this.TbpSellers.Controls.Add(this.GbxSellers);
            this.TbpSellers.Location = new System.Drawing.Point(4, 25);
            this.TbpSellers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpSellers.Name = "TbpSellers";
            this.TbpSellers.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpSellers.Size = new System.Drawing.Size(1138, 391);
            this.TbpSellers.TabIndex = 11;
            this.TbpSellers.Text = "Продавцы";
            // 
            // GbxSellers
            // 
            this.GbxSellers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxSellers.Controls.Add(this.DgvSellers);
            this.GbxSellers.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxSellers.ForeColor = System.Drawing.Color.White;
            this.GbxSellers.Location = new System.Drawing.Point(8, 8);
            this.GbxSellers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxSellers.Name = "GbxSellers";
            this.GbxSellers.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxSellers.Size = new System.Drawing.Size(1118, 376);
            this.GbxSellers.TabIndex = 1;
            this.GbxSellers.TabStop = false;
            this.GbxSellers.Text = " Содержание таблицы \"Продавцы\" ";
            // 
            // DgvSellers
            // 
            this.DgvSellers.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvSellers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DgvSellers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvSellers.AutoGenerateColumns = false;
            this.DgvSellers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvSellers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvSellers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvSellers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSellers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn5,
            this.surnameDataGridViewTextBoxColumn1,
            this.nameDataGridViewTextBoxColumn2,
            this.patronymicDataGridViewTextBoxColumn1,
            this.interestDataGridViewTextBoxColumn1});
            this.DgvSellers.DataSource = this.sellerBindingSource2;
            this.DgvSellers.Location = new System.Drawing.Point(8, 24);
            this.DgvSellers.Name = "DgvSellers";
            this.DgvSellers.ReadOnly = true;
            this.DgvSellers.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.DgvSellers.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.DgvSellers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvSellers.Size = new System.Drawing.Size(1101, 344);
            this.DgvSellers.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn5
            // 
            this.idDataGridViewTextBoxColumn5.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn5.FillWeight = 15F;
            this.idDataGridViewTextBoxColumn5.HeaderText = "Идентификатор";
            this.idDataGridViewTextBoxColumn5.Name = "idDataGridViewTextBoxColumn5";
            this.idDataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // surnameDataGridViewTextBoxColumn1
            // 
            this.surnameDataGridViewTextBoxColumn1.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn1.FillWeight = 20F;
            this.surnameDataGridViewTextBoxColumn1.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn1.Name = "surnameDataGridViewTextBoxColumn1";
            this.surnameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn2
            // 
            this.nameDataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn2.FillWeight = 20F;
            this.nameDataGridViewTextBoxColumn2.HeaderText = "Имя";
            this.nameDataGridViewTextBoxColumn2.Name = "nameDataGridViewTextBoxColumn2";
            this.nameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // patronymicDataGridViewTextBoxColumn1
            // 
            this.patronymicDataGridViewTextBoxColumn1.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn1.FillWeight = 20F;
            this.patronymicDataGridViewTextBoxColumn1.HeaderText = "Отчество";
            this.patronymicDataGridViewTextBoxColumn1.Name = "patronymicDataGridViewTextBoxColumn1";
            this.patronymicDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // interestDataGridViewTextBoxColumn1
            // 
            this.interestDataGridViewTextBoxColumn1.DataPropertyName = "Interest";
            this.interestDataGridViewTextBoxColumn1.FillWeight = 15F;
            this.interestDataGridViewTextBoxColumn1.HeaderText = "Комиссионные (%)";
            this.interestDataGridViewTextBoxColumn1.Name = "interestDataGridViewTextBoxColumn1";
            this.interestDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // sellerBindingSource2
            // 
            this.sellerBindingSource2.DataSource = typeof(HomeWork.Models.Seller);
            // 
            // TbpPurchases
            // 
            this.TbpPurchases.BackColor = System.Drawing.Color.Gray;
            this.TbpPurchases.Controls.Add(this.GbxPurchases);
            this.TbpPurchases.Location = new System.Drawing.Point(4, 25);
            this.TbpPurchases.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpPurchases.Name = "TbpPurchases";
            this.TbpPurchases.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpPurchases.Size = new System.Drawing.Size(1138, 391);
            this.TbpPurchases.TabIndex = 12;
            this.TbpPurchases.Text = "Закупки";
            // 
            // GbxPurchases
            // 
            this.GbxPurchases.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxPurchases.Controls.Add(this.DgvPurchases);
            this.GbxPurchases.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxPurchases.ForeColor = System.Drawing.Color.White;
            this.GbxPurchases.Location = new System.Drawing.Point(8, 8);
            this.GbxPurchases.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxPurchases.Name = "GbxPurchases";
            this.GbxPurchases.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxPurchases.Size = new System.Drawing.Size(1119, 376);
            this.GbxPurchases.TabIndex = 1;
            this.GbxPurchases.TabStop = false;
            this.GbxPurchases.Text = " Содержание таблицы \"Закупки\" ";
            // 
            // DgvPurchases
            // 
            this.DgvPurchases.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvPurchases.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.DgvPurchases.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvPurchases.AutoGenerateColumns = false;
            this.DgvPurchases.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvPurchases.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvPurchases.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvPurchases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvPurchases.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.DgvPurchases.DataSource = this.purchaseViewModelBindingSource1;
            this.DgvPurchases.Location = new System.Drawing.Point(8, 24);
            this.DgvPurchases.Name = "DgvPurchases";
            this.DgvPurchases.ReadOnly = true;
            this.DgvPurchases.RowHeadersVisible = false;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            this.DgvPurchases.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.DgvPurchases.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvPurchases.Size = new System.Drawing.Size(1102, 341);
            this.DgvPurchases.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn13.FillWeight = 15F;
            this.dataGridViewTextBoxColumn13.HeaderText = "Идентификатор";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Goods";
            this.dataGridViewTextBoxColumn14.FillWeight = 30F;
            this.dataGridViewTextBoxColumn14.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn15.FillWeight = 15F;
            this.dataGridViewTextBoxColumn15.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn16.FillWeight = 15F;
            this.dataGridViewTextBoxColumn16.HeaderText = "Цена (руб.)";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn17.FillWeight = 10F;
            this.dataGridViewTextBoxColumn17.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "DatePurchase";
            this.dataGridViewTextBoxColumn18.FillWeight = 15F;
            this.dataGridViewTextBoxColumn18.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // purchaseViewModelBindingSource1
            // 
            this.purchaseViewModelBindingSource1.DataSource = typeof(HomeWork.Models.ViewModels.PurchaseViewModel);
            // 
            // TbpSales
            // 
            this.TbpSales.BackColor = System.Drawing.Color.Gray;
            this.TbpSales.Controls.Add(this.GbxSales);
            this.TbpSales.Location = new System.Drawing.Point(4, 25);
            this.TbpSales.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpSales.Name = "TbpSales";
            this.TbpSales.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpSales.Size = new System.Drawing.Size(1138, 391);
            this.TbpSales.TabIndex = 13;
            this.TbpSales.Text = "Продажи";
            // 
            // GbxSales
            // 
            this.GbxSales.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxSales.Controls.Add(this.DgvSales);
            this.GbxSales.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxSales.ForeColor = System.Drawing.Color.White;
            this.GbxSales.Location = new System.Drawing.Point(8, 8);
            this.GbxSales.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxSales.Name = "GbxSales";
            this.GbxSales.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxSales.Size = new System.Drawing.Size(1119, 380);
            this.GbxSales.TabIndex = 1;
            this.GbxSales.TabStop = false;
            this.GbxSales.Text = " Содержание таблицы \"Продажи\" ";
            // 
            // DgvSales
            // 
            this.DgvSales.AllowUserToResizeRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvSales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.DgvSales.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvSales.AutoGenerateColumns = false;
            this.DgvSales.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvSales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvSales.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.DgvSales.DataSource = this.saleViewModelBindingSource;
            this.DgvSales.Location = new System.Drawing.Point(8, 24);
            this.DgvSales.Name = "DgvSales";
            this.DgvSales.ReadOnly = true;
            this.DgvSales.RowHeadersVisible = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.DgvSales.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DgvSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvSales.Size = new System.Drawing.Size(1102, 348);
            this.DgvSales.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn19.FillWeight = 15F;
            this.dataGridViewTextBoxColumn19.HeaderText = "Идентификатор";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "DateSell";
            this.dataGridViewTextBoxColumn20.FillWeight = 15F;
            this.dataGridViewTextBoxColumn20.HeaderText = "Дата продажи";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Seller";
            this.dataGridViewTextBoxColumn21.FillWeight = 20F;
            this.dataGridViewTextBoxColumn21.HeaderText = "Продавец";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Purchase";
            this.dataGridViewTextBoxColumn22.FillWeight = 20F;
            this.dataGridViewTextBoxColumn22.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn23.FillWeight = 15F;
            this.dataGridViewTextBoxColumn23.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn24.FillWeight = 15F;
            this.dataGridViewTextBoxColumn24.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn25.FillWeight = 15F;
            this.dataGridViewTextBoxColumn25.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            // 
            // saleViewModelBindingSource
            // 
            this.saleViewModelBindingSource.DataSource = typeof(HomeWork.Models.ViewModels.SaleViewModel);
            // 
            // TbpQuery1
            // 
            this.TbpQuery1.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery1.Controls.Add(this.GrbQuery1);
            this.TbpQuery1.Controls.Add(this.GbxResult1);
            this.TbpQuery1.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery1.Name = "TbpQuery1";
            this.TbpQuery1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery1.Size = new System.Drawing.Size(1138, 391);
            this.TbpQuery1.TabIndex = 1;
            this.TbpQuery1.Text = "Запрос №1";
            // 
            // GrbQuery1
            // 
            this.GrbQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery1.Controls.Add(this.TbxQuery1);
            this.GrbQuery1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery1.ForeColor = System.Drawing.Color.White;
            this.GrbQuery1.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery1.Name = "GrbQuery1";
            this.GrbQuery1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery1.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery1.TabIndex = 0;
            this.GrbQuery1.TabStop = false;
            this.GrbQuery1.Text = " Информация о запросе ";
            // 
            // TbxQuery1
            // 
            this.TbxQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery1.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery1.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery1.Multiline = true;
            this.TbxQuery1.Name = "TbxQuery1";
            this.TbxQuery1.ReadOnly = true;
            this.TbxQuery1.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery1.TabIndex = 0;
            this.TbxQuery1.TabStop = false;
            this.TbxQuery1.Text = "1.Запрос с параметрами. Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей" +
    " измерения которых является «шт» (штуки) и цена закупки составляет меньше 200 ру" +
    "б.";
            // 
            // GbxResult1
            // 
            this.GbxResult1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult1.Controls.Add(this.DgvQuery1);
            this.GbxResult1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult1.ForeColor = System.Drawing.Color.White;
            this.GbxResult1.Location = new System.Drawing.Point(8, 152);
            this.GbxResult1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult1.Name = "GbxResult1";
            this.GbxResult1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult1.Size = new System.Drawing.Size(1119, 232);
            this.GbxResult1.TabIndex = 1;
            this.GbxResult1.TabStop = false;
            this.GbxResult1.Text = " Результат ";
            // 
            // DgvQuery1
            // 
            this.DgvQuery1.AllowUserToResizeRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.DgvQuery1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery1.AutoGenerateColumns = false;
            this.DgvQuery1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.goodsDataGridViewTextBoxColumn,
            this.unitDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn,
            this.datePurchaseDataGridViewTextBoxColumn});
            this.DgvQuery1.DataSource = this.purchaseViewModelBindingSource1;
            this.DgvQuery1.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery1.Name = "DgvQuery1";
            this.DgvQuery1.ReadOnly = true;
            this.DgvQuery1.RowHeadersVisible = false;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery1.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.DgvQuery1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery1.Size = new System.Drawing.Size(1102, 200);
            this.DgvQuery1.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Идентификатор";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // goodsDataGridViewTextBoxColumn
            // 
            this.goodsDataGridViewTextBoxColumn.DataPropertyName = "Goods";
            this.goodsDataGridViewTextBoxColumn.HeaderText = "Товар";
            this.goodsDataGridViewTextBoxColumn.Name = "goodsDataGridViewTextBoxColumn";
            this.goodsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // unitDataGridViewTextBoxColumn
            // 
            this.unitDataGridViewTextBoxColumn.DataPropertyName = "Unit";
            this.unitDataGridViewTextBoxColumn.HeaderText = "Ед. измерения";
            this.unitDataGridViewTextBoxColumn.Name = "unitDataGridViewTextBoxColumn";
            this.unitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Цена (руб.)";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "Количество";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // datePurchaseDataGridViewTextBoxColumn
            // 
            this.datePurchaseDataGridViewTextBoxColumn.DataPropertyName = "DatePurchase";
            this.datePurchaseDataGridViewTextBoxColumn.HeaderText = "Дата закупки";
            this.datePurchaseDataGridViewTextBoxColumn.Name = "datePurchaseDataGridViewTextBoxColumn";
            this.datePurchaseDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // TbpQuery2
            // 
            this.TbpQuery2.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery2.Controls.Add(this.GrbQuery2);
            this.TbpQuery2.Controls.Add(this.GbxResult2);
            this.TbpQuery2.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery2.Name = "TbpQuery2";
            this.TbpQuery2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery2.Size = new System.Drawing.Size(1138, 391);
            this.TbpQuery2.TabIndex = 2;
            this.TbpQuery2.Text = "Запрос №2";
            // 
            // GrbQuery2
            // 
            this.GrbQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery2.Controls.Add(this.TbxQuery2);
            this.GrbQuery2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery2.ForeColor = System.Drawing.Color.White;
            this.GrbQuery2.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery2.Name = "GrbQuery2";
            this.GrbQuery2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery2.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery2.TabIndex = 0;
            this.GrbQuery2.TabStop = false;
            this.GrbQuery2.Text = " Информация о запросе ";
            // 
            // TbxQuery2
            // 
            this.TbxQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery2.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery2.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery2.Multiline = true;
            this.TbxQuery2.Name = "TbxQuery2";
            this.TbxQuery2.ReadOnly = true;
            this.TbxQuery2.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery2.TabIndex = 0;
            this.TbxQuery2.Text = "2. Запрос с параметрами. Выбирает из таблицы ТОВАРЫ информацию о товарах, цена за" +
    "купки которых больше 500 руб. за единицу товара";
            // 
            // GbxResult2
            // 
            this.GbxResult2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult2.Controls.Add(this.DgvQuery2);
            this.GbxResult2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult2.ForeColor = System.Drawing.Color.White;
            this.GbxResult2.Location = new System.Drawing.Point(8, 152);
            this.GbxResult2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult2.Name = "GbxResult2";
            this.GbxResult2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult2.Size = new System.Drawing.Size(1119, 232);
            this.GbxResult2.TabIndex = 1;
            this.GbxResult2.TabStop = false;
            this.GbxResult2.Text = " Результат ";
            // 
            // DgvQuery2
            // 
            this.DgvQuery2.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.DgvQuery2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery2.AutoGenerateColumns = false;
            this.DgvQuery2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.DgvQuery2.DataSource = this.purchaseViewModelBindingSource1;
            this.DgvQuery2.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery2.Name = "DgvQuery2";
            this.DgvQuery2.ReadOnly = true;
            this.DgvQuery2.RowHeadersVisible = false;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery2.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.DgvQuery2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery2.Size = new System.Drawing.Size(1102, 200);
            this.DgvQuery2.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Идентификатор";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Goods";
            this.dataGridViewTextBoxColumn2.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn3.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn4.HeaderText = "Цена (руб.)";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn5.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "DatePurchase";
            this.dataGridViewTextBoxColumn6.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // TbpQuery3
            // 
            this.TbpQuery3.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery3.Controls.Add(this.GrbQuery3);
            this.TbpQuery3.Controls.Add(this.GbxResult3);
            this.TbpQuery3.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery3.Name = "TbpQuery3";
            this.TbpQuery3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery3.Size = new System.Drawing.Size(1138, 391);
            this.TbpQuery3.TabIndex = 3;
            this.TbpQuery3.Text = "Запрос №3";
            // 
            // GrbQuery3
            // 
            this.GrbQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery3.Controls.Add(this.TbxQuery3);
            this.GrbQuery3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery3.ForeColor = System.Drawing.Color.White;
            this.GrbQuery3.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery3.Name = "GrbQuery3";
            this.GrbQuery3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery3.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery3.TabIndex = 0;
            this.GrbQuery3.TabStop = false;
            this.GrbQuery3.Text = " Информация о запросе ";
            // 
            // TbxQuery3
            // 
            this.TbxQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery3.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery3.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery3.Multiline = true;
            this.TbxQuery3.Name = "TbxQuery3";
            this.TbxQuery3.ReadOnly = true;
            this.TbxQuery3.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery3.TabIndex = 0;
            this.TbxQuery3.TabStop = false;
            this.TbxQuery3.Text = resources.GetString("TbxQuery3.Text");
            // 
            // GbxResult3
            // 
            this.GbxResult3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult3.Controls.Add(this.DgvQuery3);
            this.GbxResult3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult3.ForeColor = System.Drawing.Color.White;
            this.GbxResult3.Location = new System.Drawing.Point(8, 152);
            this.GbxResult3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult3.Name = "GbxResult3";
            this.GbxResult3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult3.Size = new System.Drawing.Size(1119, 232);
            this.GbxResult3.TabIndex = 1;
            this.GbxResult3.TabStop = false;
            this.GbxResult3.Text = " Результат ";
            // 
            // DgvQuery3
            // 
            this.DgvQuery3.AllowUserToResizeRows = false;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle15;
            this.DgvQuery3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery3.AutoGenerateColumns = false;
            this.DgvQuery3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.DgvQuery3.DataSource = this.purchaseViewModelBindingSource1;
            this.DgvQuery3.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery3.Name = "DgvQuery3";
            this.DgvQuery3.ReadOnly = true;
            this.DgvQuery3.RowHeadersVisible = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery3.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.DgvQuery3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery3.Size = new System.Drawing.Size(1102, 200);
            this.DgvQuery3.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn7.HeaderText = "Идентификатор";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Goods";
            this.dataGridViewTextBoxColumn8.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn9.HeaderText = "Ед. измерения";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn10.HeaderText = "Цена (руб.)";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn11.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "DatePurchase";
            this.dataGridViewTextBoxColumn12.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // TbpQuery4
            // 
            this.TbpQuery4.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery4.Controls.Add(this.GrbQuery4);
            this.TbpQuery4.Controls.Add(this.GbxResult4);
            this.TbpQuery4.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery4.Name = "TbpQuery4";
            this.TbpQuery4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery4.Size = new System.Drawing.Size(1138, 391);
            this.TbpQuery4.TabIndex = 4;
            this.TbpQuery4.Text = "Запрос №4";
            // 
            // GrbQuery4
            // 
            this.GrbQuery4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery4.Controls.Add(this.TbxQuery4);
            this.GrbQuery4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery4.ForeColor = System.Drawing.Color.White;
            this.GrbQuery4.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery4.Name = "GrbQuery4";
            this.GrbQuery4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery4.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery4.TabIndex = 0;
            this.GrbQuery4.TabStop = false;
            this.GrbQuery4.Text = " Информация о запросе ";
            // 
            // TbxQuery4
            // 
            this.TbxQuery4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery4.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery4.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery4.Multiline = true;
            this.TbxQuery4.Name = "TbxQuery4";
            this.TbxQuery4.ReadOnly = true;
            this.TbxQuery4.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery4.TabIndex = 0;
            this.TbxQuery4.TabStop = false;
            this.TbxQuery4.Text = "4. Запрос с параметрами. Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с за" +
    "данным значением процента комиссионных. \r\n\r\nЗаданный процент коммисионных: значе" +
    "ние";
            // 
            // GbxResult4
            // 
            this.GbxResult4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult4.Controls.Add(this.DgvQuery4);
            this.GbxResult4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult4.ForeColor = System.Drawing.Color.White;
            this.GbxResult4.Location = new System.Drawing.Point(8, 152);
            this.GbxResult4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult4.Name = "GbxResult4";
            this.GbxResult4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult4.Size = new System.Drawing.Size(1119, 232);
            this.GbxResult4.TabIndex = 1;
            this.GbxResult4.TabStop = false;
            this.GbxResult4.Text = " Результат ";
            // 
            // DgvQuery4
            // 
            this.DgvQuery4.AllowUserToResizeRows = false;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.DgvQuery4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery4.AutoGenerateColumns = false;
            this.DgvQuery4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.surnameDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.patronymicDataGridViewTextBoxColumn,
            this.interestDataGridViewTextBoxColumn});
            this.DgvQuery4.DataSource = this.sellerBindingSource1;
            this.DgvQuery4.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery4.Name = "DgvQuery4";
            this.DgvQuery4.ReadOnly = true;
            this.DgvQuery4.RowHeadersVisible = false;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery4.RowsDefaultCellStyle = dataGridViewCellStyle18;
            this.DgvQuery4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery4.Size = new System.Drawing.Size(1102, 200);
            this.DgvQuery4.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Идентификатор";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // patronymicDataGridViewTextBoxColumn
            // 
            this.patronymicDataGridViewTextBoxColumn.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn.HeaderText = "Отчество";
            this.patronymicDataGridViewTextBoxColumn.Name = "patronymicDataGridViewTextBoxColumn";
            this.patronymicDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // interestDataGridViewTextBoxColumn
            // 
            this.interestDataGridViewTextBoxColumn.DataPropertyName = "Interest";
            this.interestDataGridViewTextBoxColumn.HeaderText = "Комиссионные";
            this.interestDataGridViewTextBoxColumn.Name = "interestDataGridViewTextBoxColumn";
            this.interestDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sellerBindingSource1
            // 
            this.sellerBindingSource1.DataSource = typeof(HomeWork.Models.Seller);
            // 
            // TbpQuery5
            // 
            this.TbpQuery5.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery5.Controls.Add(this.GrbQuery5);
            this.TbpQuery5.Controls.Add(this.GbxResult5);
            this.TbpQuery5.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery5.Name = "TbpQuery5";
            this.TbpQuery5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery5.Size = new System.Drawing.Size(1138, 391);
            this.TbpQuery5.TabIndex = 5;
            this.TbpQuery5.Text = "Запрос №5";
            // 
            // GrbQuery5
            // 
            this.GrbQuery5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery5.Controls.Add(this.TbxQuery5);
            this.GrbQuery5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery5.ForeColor = System.Drawing.Color.White;
            this.GrbQuery5.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery5.Name = "GrbQuery5";
            this.GrbQuery5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery5.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery5.TabIndex = 0;
            this.GrbQuery5.TabStop = false;
            this.GrbQuery5.Text = " Информация о запросе ";
            // 
            // TbxQuery5
            // 
            this.TbxQuery5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery5.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery5.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery5.Multiline = true;
            this.TbxQuery5.Name = "TbxQuery5";
            this.TbxQuery5.ReadOnly = true;
            this.TbxQuery5.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery5.TabIndex = 0;
            this.TbxQuery5.TabStop = false;
            this.TbxQuery5.Text = resources.GetString("TbxQuery5.Text");
            // 
            // GbxResult5
            // 
            this.GbxResult5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult5.Controls.Add(this.DgvQuery5);
            this.GbxResult5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult5.ForeColor = System.Drawing.Color.White;
            this.GbxResult5.Location = new System.Drawing.Point(8, 152);
            this.GbxResult5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult5.Name = "GbxResult5";
            this.GbxResult5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult5.Size = new System.Drawing.Size(1119, 232);
            this.GbxResult5.TabIndex = 1;
            this.GbxResult5.TabStop = false;
            this.GbxResult5.Text = " Результат ";
            // 
            // DgvQuery5
            // 
            this.DgvQuery5.AllowUserToResizeRows = false;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery5.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.DgvQuery5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery5.AutoGenerateColumns = false;
            this.DgvQuery5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.dateSellDataGridViewTextBoxColumn,
            this.sellerDataGridViewTextBoxColumn,
            this.purchaseDataGridViewTextBoxColumn,
            this.unitDataGridViewTextBoxColumn1,
            this.amountDataGridViewTextBoxColumn1,
            this.priceDataGridViewTextBoxColumn1});
            this.DgvQuery5.DataSource = this.saleViewModelBindingSource;
            this.DgvQuery5.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery5.Name = "DgvQuery5";
            this.DgvQuery5.ReadOnly = true;
            this.DgvQuery5.RowHeadersVisible = false;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery5.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.DgvQuery5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery5.Size = new System.Drawing.Size(1102, 200);
            this.DgvQuery5.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "Идентификатор";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dateSellDataGridViewTextBoxColumn
            // 
            this.dateSellDataGridViewTextBoxColumn.DataPropertyName = "DateSell";
            this.dateSellDataGridViewTextBoxColumn.HeaderText = "Дата продажи";
            this.dateSellDataGridViewTextBoxColumn.Name = "dateSellDataGridViewTextBoxColumn";
            this.dateSellDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sellerDataGridViewTextBoxColumn
            // 
            this.sellerDataGridViewTextBoxColumn.DataPropertyName = "Seller";
            this.sellerDataGridViewTextBoxColumn.HeaderText = "Продавец";
            this.sellerDataGridViewTextBoxColumn.Name = "sellerDataGridViewTextBoxColumn";
            this.sellerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // purchaseDataGridViewTextBoxColumn
            // 
            this.purchaseDataGridViewTextBoxColumn.DataPropertyName = "Purchase";
            this.purchaseDataGridViewTextBoxColumn.HeaderText = "Товар";
            this.purchaseDataGridViewTextBoxColumn.Name = "purchaseDataGridViewTextBoxColumn";
            this.purchaseDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // unitDataGridViewTextBoxColumn1
            // 
            this.unitDataGridViewTextBoxColumn1.DataPropertyName = "Unit";
            this.unitDataGridViewTextBoxColumn1.HeaderText = "Ед. измерения";
            this.unitDataGridViewTextBoxColumn1.Name = "unitDataGridViewTextBoxColumn1";
            this.unitDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn1
            // 
            this.amountDataGridViewTextBoxColumn1.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn1.HeaderText = "Количество";
            this.amountDataGridViewTextBoxColumn1.Name = "amountDataGridViewTextBoxColumn1";
            this.amountDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn1
            // 
            this.priceDataGridViewTextBoxColumn1.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn1.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn1.Name = "priceDataGridViewTextBoxColumn1";
            this.priceDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // TbpQuery6
            // 
            this.TbpQuery6.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery6.Controls.Add(this.GrbQuery6);
            this.TbpQuery6.Controls.Add(this.GbxResult6);
            this.TbpQuery6.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery6.Name = "TbpQuery6";
            this.TbpQuery6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery6.Size = new System.Drawing.Size(1138, 391);
            this.TbpQuery6.TabIndex = 6;
            this.TbpQuery6.Text = "Запрос №6";
            // 
            // GrbQuery6
            // 
            this.GrbQuery6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery6.Controls.Add(this.TbxQuery6);
            this.GrbQuery6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery6.ForeColor = System.Drawing.Color.White;
            this.GrbQuery6.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery6.Name = "GrbQuery6";
            this.GrbQuery6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery6.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery6.TabIndex = 0;
            this.GrbQuery6.TabStop = false;
            this.GrbQuery6.Text = " Информация о запросе ";
            // 
            // TbxQuery6
            // 
            this.TbxQuery6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery6.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery6.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery6.Multiline = true;
            this.TbxQuery6.Name = "TbxQuery6";
            this.TbxQuery6.ReadOnly = true;
            this.TbxQuery6.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery6.TabIndex = 0;
            this.TbxQuery6.TabStop = false;
            this.TbxQuery6.Text = resources.GetString("TbxQuery6.Text");
            // 
            // GbxResult6
            // 
            this.GbxResult6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult6.Controls.Add(this.DgvQuery6);
            this.GbxResult6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult6.ForeColor = System.Drawing.Color.White;
            this.GbxResult6.Location = new System.Drawing.Point(8, 152);
            this.GbxResult6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult6.Name = "GbxResult6";
            this.GbxResult6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult6.Size = new System.Drawing.Size(1119, 232);
            this.GbxResult6.TabIndex = 1;
            this.GbxResult6.TabStop = false;
            this.GbxResult6.Text = " Результат ";
            // 
            // DgvQuery6
            // 
            this.DgvQuery6.AllowUserToResizeRows = false;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery6.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.DgvQuery6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery6.AutoGenerateColumns = false;
            this.DgvQuery6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery6.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CmnId,
            this.CmnDateSell,
            this.CmnGoods,
            this.CmnUnit,
            this.CmnSeller,
            this.CmnAmount,
            this.CmnPrice,
            this.CmnSumPrice});
            this.DgvQuery6.DataSource = this.BdsData;
            this.DgvQuery6.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery6.Name = "DgvQuery6";
            this.DgvQuery6.ReadOnly = true;
            this.DgvQuery6.RowHeadersVisible = false;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery6.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.DgvQuery6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery6.Size = new System.Drawing.Size(1102, 200);
            this.DgvQuery6.TabIndex = 0;
            // 
            // CmnId
            // 
            this.CmnId.DataPropertyName = "Id";
            this.CmnId.HeaderText = "Идентификатор";
            this.CmnId.Name = "CmnId";
            this.CmnId.ReadOnly = true;
            // 
            // CmnDateSell
            // 
            this.CmnDateSell.DataPropertyName = "DateSell";
            this.CmnDateSell.HeaderText = "Дата продажи";
            this.CmnDateSell.Name = "CmnDateSell";
            this.CmnDateSell.ReadOnly = true;
            // 
            // CmnGoods
            // 
            this.CmnGoods.DataPropertyName = "Goods";
            this.CmnGoods.HeaderText = "Товар";
            this.CmnGoods.Name = "CmnGoods";
            this.CmnGoods.ReadOnly = true;
            // 
            // CmnUnit
            // 
            this.CmnUnit.DataPropertyName = "Unit";
            this.CmnUnit.HeaderText = "Ед. измерения";
            this.CmnUnit.Name = "CmnUnit";
            this.CmnUnit.ReadOnly = true;
            // 
            // CmnSeller
            // 
            this.CmnSeller.DataPropertyName = "Seller";
            this.CmnSeller.HeaderText = "Продавец";
            this.CmnSeller.Name = "CmnSeller";
            this.CmnSeller.ReadOnly = true;
            // 
            // CmnAmount
            // 
            this.CmnAmount.DataPropertyName = "Amount";
            this.CmnAmount.HeaderText = "Количество";
            this.CmnAmount.Name = "CmnAmount";
            this.CmnAmount.ReadOnly = true;
            // 
            // CmnPrice
            // 
            this.CmnPrice.DataPropertyName = "Price";
            this.CmnPrice.HeaderText = "Цена";
            this.CmnPrice.Name = "CmnPrice";
            this.CmnPrice.ReadOnly = true;
            // 
            // CmnSumPrice
            // 
            this.CmnSumPrice.DataPropertyName = "SumPrice";
            this.CmnSumPrice.HeaderText = "Суммарная стоимость";
            this.CmnSumPrice.Name = "CmnSumPrice";
            this.CmnSumPrice.ReadOnly = true;
            // 
            // TbpQuery7
            // 
            this.TbpQuery7.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery7.Controls.Add(this.GrbQuery7);
            this.TbpQuery7.Controls.Add(this.GbxResult7);
            this.TbpQuery7.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery7.Name = "TbpQuery7";
            this.TbpQuery7.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery7.Size = new System.Drawing.Size(1138, 391);
            this.TbpQuery7.TabIndex = 7;
            this.TbpQuery7.Text = "Запрос №7";
            // 
            // GrbQuery7
            // 
            this.GrbQuery7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery7.Controls.Add(this.TbxQuery7);
            this.GrbQuery7.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery7.ForeColor = System.Drawing.Color.White;
            this.GrbQuery7.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery7.Name = "GrbQuery7";
            this.GrbQuery7.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery7.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery7.TabIndex = 0;
            this.GrbQuery7.TabStop = false;
            this.GrbQuery7.Text = " Информация о запросе ";
            // 
            // TbxQuery7
            // 
            this.TbxQuery7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery7.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery7.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery7.Multiline = true;
            this.TbxQuery7.Name = "TbxQuery7";
            this.TbxQuery7.ReadOnly = true;
            this.TbxQuery7.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery7.TabIndex = 0;
            this.TbxQuery7.TabStop = false;
            this.TbxQuery7.Text = "7. Итоговый запрос. Выполняет группировку по полю Наименование товара. Для каждог" +
    "о наименования вычисляет среднюю цену закупки товара, количество закупок";
            // 
            // GbxResult7
            // 
            this.GbxResult7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult7.Controls.Add(this.DgvQuery7);
            this.GbxResult7.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult7.ForeColor = System.Drawing.Color.White;
            this.GbxResult7.Location = new System.Drawing.Point(8, 152);
            this.GbxResult7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult7.Name = "GbxResult7";
            this.GbxResult7.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult7.Size = new System.Drawing.Size(1119, 232);
            this.GbxResult7.TabIndex = 1;
            this.GbxResult7.TabStop = false;
            this.GbxResult7.Text = " Результат ";
            // 
            // DgvQuery7
            // 
            this.DgvQuery7.AllowUserToResizeRows = false;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery7.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle23;
            this.DgvQuery7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery7.AutoGenerateColumns = false;
            this.DgvQuery7.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery7.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CmnIdGoods,
            this.CmnGoodsKey,
            this.CmnCountGoods,
            this.CmnAvgPriceGoods});
            this.DgvQuery7.DataSource = this.BdsData;
            this.DgvQuery7.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery7.Name = "DgvQuery7";
            this.DgvQuery7.ReadOnly = true;
            this.DgvQuery7.RowHeadersVisible = false;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery7.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.DgvQuery7.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery7.Size = new System.Drawing.Size(1102, 200);
            this.DgvQuery7.TabIndex = 0;
            // 
            // CmnIdGoods
            // 
            this.CmnIdGoods.DataPropertyName = "Id";
            this.CmnIdGoods.FillWeight = 15F;
            this.CmnIdGoods.HeaderText = "Идентификатор";
            this.CmnIdGoods.Name = "CmnIdGoods";
            this.CmnIdGoods.ReadOnly = true;
            // 
            // CmnGoodsKey
            // 
            this.CmnGoodsKey.DataPropertyName = "Goods";
            this.CmnGoodsKey.FillWeight = 35F;
            this.CmnGoodsKey.HeaderText = "Товар";
            this.CmnGoodsKey.Name = "CmnGoodsKey";
            this.CmnGoodsKey.ReadOnly = true;
            // 
            // CmnCountGoods
            // 
            this.CmnCountGoods.DataPropertyName = "Count";
            this.CmnCountGoods.FillWeight = 20F;
            this.CmnCountGoods.HeaderText = "Количество закупок";
            this.CmnCountGoods.Name = "CmnCountGoods";
            this.CmnCountGoods.ReadOnly = true;
            // 
            // CmnAvgPriceGoods
            // 
            this.CmnAvgPriceGoods.DataPropertyName = "Avarage";
            this.CmnAvgPriceGoods.FillWeight = 20F;
            this.CmnAvgPriceGoods.HeaderText = "Средння цена закупки";
            this.CmnAvgPriceGoods.Name = "CmnAvgPriceGoods";
            this.CmnAvgPriceGoods.ReadOnly = true;
            // 
            // TbpQuery8
            // 
            this.TbpQuery8.BackColor = System.Drawing.Color.Gray;
            this.TbpQuery8.Controls.Add(this.GrbQuery8);
            this.TbpQuery8.Controls.Add(this.GbxResult8);
            this.TbpQuery8.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery8.Name = "TbpQuery8";
            this.TbpQuery8.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TbpQuery8.Size = new System.Drawing.Size(1138, 391);
            this.TbpQuery8.TabIndex = 8;
            this.TbpQuery8.Text = "Запрос №8";
            // 
            // GrbQuery8
            // 
            this.GrbQuery8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrbQuery8.Controls.Add(this.TbxQuery8);
            this.GrbQuery8.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbQuery8.ForeColor = System.Drawing.Color.White;
            this.GrbQuery8.Location = new System.Drawing.Point(8, 8);
            this.GrbQuery8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery8.Name = "GrbQuery8";
            this.GrbQuery8.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GrbQuery8.Size = new System.Drawing.Size(1119, 136);
            this.GrbQuery8.TabIndex = 0;
            this.GrbQuery8.TabStop = false;
            this.GrbQuery8.Text = " Информация о запросе ";
            // 
            // TbxQuery8
            // 
            this.TbxQuery8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TbxQuery8.BackColor = System.Drawing.Color.DarkGray;
            this.TbxQuery8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxQuery8.Location = new System.Drawing.Point(8, 24);
            this.TbxQuery8.Multiline = true;
            this.TbxQuery8.Name = "TbxQuery8";
            this.TbxQuery8.ReadOnly = true;
            this.TbxQuery8.Size = new System.Drawing.Size(1102, 104);
            this.TbxQuery8.TabIndex = 0;
            this.TbxQuery8.Text = "8. Итоговый запрос. Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ" +
    ". Для каждого продавца вычисляет среднее значение по полю Цена продажи единицы т" +
    "овара, количество продаж";
            // 
            // GbxResult8
            // 
            this.GbxResult8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GbxResult8.Controls.Add(this.DgvQuery8);
            this.GbxResult8.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxResult8.ForeColor = System.Drawing.Color.White;
            this.GbxResult8.Location = new System.Drawing.Point(8, 152);
            this.GbxResult8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult8.Name = "GbxResult8";
            this.GbxResult8.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.GbxResult8.Size = new System.Drawing.Size(1119, 245);
            this.GbxResult8.TabIndex = 1;
            this.GbxResult8.TabStop = false;
            this.GbxResult8.Text = " Результат ";
            // 
            // DgvQuery8
            // 
            this.DgvQuery8.AllowUserToResizeRows = false;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvQuery8.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.DgvQuery8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgvQuery8.AutoGenerateColumns = false;
            this.DgvQuery8.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvQuery8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvQuery8.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.DgvQuery8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CmnIdSeller,
            this.CmnSurnameSeller,
            this.CmnNameSeller,
            this.CmnPatronymicSeller,
            this.CmnCountGoodsSeller,
            this.CmnAvgPrice});
            this.DgvQuery8.DataSource = this.BdsData;
            this.DgvQuery8.Location = new System.Drawing.Point(8, 24);
            this.DgvQuery8.Name = "DgvQuery8";
            this.DgvQuery8.ReadOnly = true;
            this.DgvQuery8.RowHeadersVisible = false;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.Black;
            this.DgvQuery8.RowsDefaultCellStyle = dataGridViewCellStyle26;
            this.DgvQuery8.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery8.Size = new System.Drawing.Size(1100, 226);
            this.DgvQuery8.TabIndex = 0;
            // 
            // CmnIdSeller
            // 
            this.CmnIdSeller.DataPropertyName = "Id";
            this.CmnIdSeller.HeaderText = "Идентификатор";
            this.CmnIdSeller.Name = "CmnIdSeller";
            this.CmnIdSeller.ReadOnly = true;
            // 
            // CmnSurnameSeller
            // 
            this.CmnSurnameSeller.DataPropertyName = "Surname";
            this.CmnSurnameSeller.HeaderText = "Фамилия";
            this.CmnSurnameSeller.Name = "CmnSurnameSeller";
            this.CmnSurnameSeller.ReadOnly = true;
            // 
            // CmnNameSeller
            // 
            this.CmnNameSeller.DataPropertyName = "Name";
            this.CmnNameSeller.HeaderText = "Имя";
            this.CmnNameSeller.Name = "CmnNameSeller";
            this.CmnNameSeller.ReadOnly = true;
            // 
            // CmnPatronymicSeller
            // 
            this.CmnPatronymicSeller.DataPropertyName = "Patronymic";
            this.CmnPatronymicSeller.HeaderText = "Отчество";
            this.CmnPatronymicSeller.Name = "CmnPatronymicSeller";
            this.CmnPatronymicSeller.ReadOnly = true;
            // 
            // CmnCountGoodsSeller
            // 
            this.CmnCountGoodsSeller.DataPropertyName = "Count";
            this.CmnCountGoodsSeller.HeaderText = "Количество";
            this.CmnCountGoodsSeller.Name = "CmnCountGoodsSeller";
            this.CmnCountGoodsSeller.ReadOnly = true;
            // 
            // CmnAvgPrice
            // 
            this.CmnAvgPrice.DataPropertyName = "AvgPrice";
            this.CmnAvgPrice.HeaderText = "Средння цена";
            this.CmnAvgPrice.Name = "CmnAvgPrice";
            this.CmnAvgPrice.ReadOnly = true;
            // 
            // TspMain
            // 
            this.TspMain.BackColor = System.Drawing.Color.Gray;
            this.TspMain.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.TspMain.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.TspMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsiExit,
            this.TsiInfo});
            this.TspMain.Location = new System.Drawing.Point(0, 40);
            this.TspMain.Name = "TspMain";
            this.TspMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.TspMain.Size = new System.Drawing.Size(1146, 39);
            this.TspMain.TabIndex = 2;
            this.TspMain.Text = "toolStrip1";
            // 
            // TsiExit
            // 
            this.TsiExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsiExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsiExit.Image = global::HomeWork.Properties.Resources.door_out;
            this.TsiExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsiExit.Margin = new System.Windows.Forms.Padding(0, 1, 15, 2);
            this.TsiExit.Name = "TsiExit";
            this.TsiExit.Size = new System.Drawing.Size(36, 36);
            this.TsiExit.Text = "Выход";
            this.TsiExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TsiInfo
            // 
            this.TsiInfo.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsiInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsiInfo.Image = global::HomeWork.Properties.Resources.information;
            this.TsiInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsiInfo.Margin = new System.Windows.Forms.Padding(0, 1, 5, 2);
            this.TsiInfo.Name = "TsiInfo";
            this.TsiInfo.Size = new System.Drawing.Size(36, 36);
            this.TsiInfo.Text = "О программе...";
            this.TsiInfo.Click += new System.EventHandler(this.Info_Command);
            // 
            // StsMain
            // 
            this.StsMain.BackColor = System.Drawing.Color.DarkGray;
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Location = new System.Drawing.Point(0, 499);
            this.StsMain.Name = "StsMain";
            this.StsMain.Padding = new System.Windows.Forms.Padding(1, 0, 16, 0);
            this.StsMain.Size = new System.Drawing.Size(1146, 22);
            this.StsMain.TabIndex = 3;
            // 
            // purchaseBindingSource
            // 
            this.purchaseBindingSource.DataSource = typeof(HomeWork.Models.Purchase);
            // 
            // sellerBindingSource
            // 
            this.sellerBindingSource.DataSource = typeof(HomeWork.Models.Seller);
            // 
            // CmsMain
            // 
            this.CmsMain.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.CmsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiMainInfo,
            this.toolStripMenuItem3,
            this.CmiMainExit});
            this.CmsMain.Name = "CmsMain";
            this.CmsMain.Size = new System.Drawing.Size(218, 86);
            // 
            // CmiMainInfo
            // 
            this.CmiMainInfo.Image = global::HomeWork.Properties.Resources.information;
            this.CmiMainInfo.Name = "CmiMainInfo";
            this.CmiMainInfo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.CmiMainInfo.Size = new System.Drawing.Size(217, 38);
            this.CmiMainInfo.Text = "&О программе...";
            this.CmiMainInfo.Click += new System.EventHandler(this.Info_Command);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(214, 6);
            // 
            // CmiMainExit
            // 
            this.CmiMainExit.Image = global::HomeWork.Properties.Resources.door_out;
            this.CmiMainExit.Name = "CmiMainExit";
            this.CmiMainExit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CmiMainExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.CmiMainExit.Size = new System.Drawing.Size(217, 38);
            this.CmiMainExit.Text = "&Выход";
            this.CmiMainExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // purchaseViewModelBindingSource
            // 
            this.purchaseViewModelBindingSource.DataSource = typeof(HomeWork.Models.ViewModels.PurchaseViewModel);
            // 
            // saleViewModelBindingSource1
            // 
            this.saleViewModelBindingSource1.DataSource = typeof(HomeWork.Models.ViewModels.SaleViewModel);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1146, 521);
            this.ContextMenuStrip = this.CmsMain;
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.TspMain);
            this.Controls.Add(this.MnsMain);
            this.Controls.Add(this.StsMain);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnsMain;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание на 24.01.2022";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpUnits.ResumeLayout(false);
            this.GbxUnits.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvUnits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitBindingSource)).EndInit();
            this.TbpGoods.ResumeLayout(false);
            this.GbxGoods.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvGoods)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodBindingSource)).EndInit();
            this.TbpSellers.ResumeLayout(false);
            this.GbxSellers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvSellers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource2)).EndInit();
            this.TbpPurchases.ResumeLayout(false);
            this.GbxPurchases.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvPurchases)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseViewModelBindingSource1)).EndInit();
            this.TbpSales.ResumeLayout(false);
            this.GbxSales.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvSales)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource)).EndInit();
            this.TbpQuery1.ResumeLayout(false);
            this.GrbQuery1.ResumeLayout(false);
            this.GrbQuery1.PerformLayout();
            this.GbxResult1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery1)).EndInit();
            this.TbpQuery2.ResumeLayout(false);
            this.GrbQuery2.ResumeLayout(false);
            this.GrbQuery2.PerformLayout();
            this.GbxResult2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery2)).EndInit();
            this.TbpQuery3.ResumeLayout(false);
            this.GrbQuery3.ResumeLayout(false);
            this.GrbQuery3.PerformLayout();
            this.GbxResult3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery3)).EndInit();
            this.TbpQuery4.ResumeLayout(false);
            this.GrbQuery4.ResumeLayout(false);
            this.GrbQuery4.PerformLayout();
            this.GbxResult4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource1)).EndInit();
            this.TbpQuery5.ResumeLayout(false);
            this.GrbQuery5.ResumeLayout(false);
            this.GrbQuery5.PerformLayout();
            this.GbxResult5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery5)).EndInit();
            this.TbpQuery6.ResumeLayout(false);
            this.GrbQuery6.ResumeLayout(false);
            this.GrbQuery6.PerformLayout();
            this.GbxResult6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BdsData)).EndInit();
            this.TbpQuery7.ResumeLayout(false);
            this.GrbQuery7.ResumeLayout(false);
            this.GrbQuery7.PerformLayout();
            this.GbxResult7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery7)).EndInit();
            this.TbpQuery8.ResumeLayout(false);
            this.GrbQuery8.ResumeLayout(false);
            this.GrbQuery8.PerformLayout();
            this.GbxResult8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery8)).EndInit();
            this.TspMain.ResumeLayout(false);
            this.TspMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).EndInit();
            this.CmsMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.purchaseViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleViewModelBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStripMenuItem MniInfo;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpQuery1;
        private System.Windows.Forms.ToolStrip TspMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.GroupBox GrbQuery1;
        private System.Windows.Forms.GroupBox GbxResult1;
        private System.Windows.Forms.DataGridView DgvQuery1;
        private System.Windows.Forms.TextBox TbxQuery1;
        private System.Windows.Forms.BindingSource purchaseBindingSource;
        private System.Windows.Forms.BindingSource purchaseViewModelBindingSource;
        private System.Windows.Forms.BindingSource purchaseViewModelBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datePurchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage TbpQuery2;
        private System.Windows.Forms.GroupBox GrbQuery2;
        private System.Windows.Forms.TextBox TbxQuery2;
        private System.Windows.Forms.GroupBox GbxResult2;
        private System.Windows.Forms.DataGridView DgvQuery2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.TabPage TbpQuery3;
        private System.Windows.Forms.GroupBox GrbQuery3;
        private System.Windows.Forms.TextBox TbxQuery3;
        private System.Windows.Forms.GroupBox GbxResult3;
        private System.Windows.Forms.DataGridView DgvQuery3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.TabPage TbpQuery4;
        private System.Windows.Forms.GroupBox GrbQuery4;
        private System.Windows.Forms.TextBox TbxQuery4;
        private System.Windows.Forms.GroupBox GbxResult4;
        private System.Windows.Forms.DataGridView DgvQuery4;
        private System.Windows.Forms.TabPage TbpQuery5;
        private System.Windows.Forms.GroupBox GrbQuery5;
        private System.Windows.Forms.TextBox TbxQuery5;
        private System.Windows.Forms.GroupBox GbxResult5;
        private System.Windows.Forms.DataGridView DgvQuery5;
        private System.Windows.Forms.TabPage TbpQuery6;
        private System.Windows.Forms.GroupBox GrbQuery6;
        private System.Windows.Forms.TextBox TbxQuery6;
        private System.Windows.Forms.GroupBox GbxResult6;
        private System.Windows.Forms.DataGridView DgvQuery6;
        private System.Windows.Forms.TabPage TbpQuery7;
        private System.Windows.Forms.GroupBox GrbQuery7;
        private System.Windows.Forms.TextBox TbxQuery7;
        private System.Windows.Forms.GroupBox GbxResult7;
        private System.Windows.Forms.DataGridView DgvQuery7;
        private System.Windows.Forms.TabPage TbpQuery8;
        private System.Windows.Forms.GroupBox GrbQuery8;
        private System.Windows.Forms.TextBox TbxQuery8;
        private System.Windows.Forms.GroupBox GbxResult8;
        private System.Windows.Forms.DataGridView DgvQuery8;
        private System.Windows.Forms.TabPage TbpUnits;
        private System.Windows.Forms.GroupBox GbxUnits;
        private System.Windows.Forms.DataGridView DgvUnits;
        private System.Windows.Forms.TabPage TbpGoods;
        private System.Windows.Forms.GroupBox GbxGoods;
        private System.Windows.Forms.DataGridView DgvGoods;
        private System.Windows.Forms.TabPage TbpSellers;
        private System.Windows.Forms.GroupBox GbxSellers;
        private System.Windows.Forms.DataGridView DgvSellers;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sellerBindingSource1;
        private System.Windows.Forms.BindingSource sellerBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateSellDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource saleViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnDateSell;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnSumPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnIdSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnSurnameSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnNameSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnPatronymicSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnCountGoodsSeller;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnAvgPrice;
        private System.Windows.Forms.TabPage TbpPurchases;
        private System.Windows.Forms.GroupBox GbxPurchases;
        private System.Windows.Forms.DataGridView DgvPurchases;
        private System.Windows.Forms.TabPage TbpSales;
        private System.Windows.Forms.GroupBox GbxSales;
        private System.Windows.Forms.BindingSource unitBindingSource;
        private System.Windows.Forms.BindingSource goodBindingSource;
        private System.Windows.Forms.BindingSource sellerBindingSource2;
        private System.Windows.Forms.DataGridView DgvSales;
        private System.Windows.Forms.BindingSource saleViewModelBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn longDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnIdGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnGoodsKey;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnCountGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmnAvgPriceGoods;
        private System.Windows.Forms.BindingSource BdsData;
        private System.Windows.Forms.ToolStripButton TsiInfo;
        private System.Windows.Forms.ContextMenuStrip CmsMain;
        private System.Windows.Forms.ToolStripMenuItem CmiMainInfo;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem CmiMainExit;
        private System.Windows.Forms.ToolStripButton TsiExit;
    }
}

