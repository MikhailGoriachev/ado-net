﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	public class SubscribersModel
	{
		public int Id { get; set; }
		public string Surname { get; set; }
		public string Name { get; set; }
		public string Patronymic { get; set; }
		public string Passport { get; set; }
		public string Street { get; set; }
		public string Building { get; set; }
		public int Flat { get; set; }

		public static string Header() =>
			$"\t┌────┬──────────────────────┬─────────────────┬─────────────────┬──────────────┬─────────────────┬───────┬──────┐\n" +
			$"\t│ Id │        Фамилия       │       Имя       │     Отчество    │    Паспорт   │     Улица       │  Дом  │  Кв  │\n" +
			$"\t├────┼──────────────────────┼─────────────────┼─────────────────┼──────────────┼─────────────────┼───────┼──────┤\n";

		public string ToTableRow() =>
			$"\t│ {Id,2} │ {Surname,-20} │ {Name,-15} │ {Patronymic,-15} │ {Passport,-12} │ {Street,-15} │ {Building,5} │ {Flat,4} │";

		public static string Footer() =>
			$"\t└────┴──────────────────────┴─────────────────┴─────────────────┴──────────────┴─────────────────┴───────┴──────┘";
	}
}
