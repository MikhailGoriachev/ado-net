﻿using System;
using System.Collections.Generic;
using System.Globalization;
using HW.Models;
using HW.Helpers;

using System.Linq;
using System.Net.Sockets;

namespace HW.Controllers
{
    public class Task2Controller
    {
        // кол-во эдементов в массиве
        private const int _n = 20;

        private double[] _array = new double[_n];

        // конструктор
        public Task2Controller()
        { Init(); }

        // функция для начального заполнения массива данных
        private void Init()
        {
            for (int i = 0; i < _n; i++)
                _array[i] = Utils.GetRandom(-25.5, 25.5);
        } // Init


        // Задание 1. Вычисление количества элементов массива, со значениями в диапазоне от A до B
        public void Task1()
        {
            // переменные для задания
            int indexA = Utils.GetRandom(0, _array.Length-1);
            int indexB = Utils.GetRandom(indexA, _array.Length-1);

            double a = _array[indexA], b = _array[indexB];

            Console.WriteLine($"Исходный массив: ");
            ConsoleColor fColor = Console.ForegroundColor;
            Array.ForEach(_array, x =>
            {
                if (a <= x && x <= b) Console.ForegroundColor = ConsoleColor.Red; // если x находится между a и b, то меняем цвет, если нет, то меняем цвет на основной
                else Console.ForegroundColor = fColor;
                Console.Write($"{Math.Round(x, 2)} ");
            });
            Console.ForegroundColor = fColor;
            Console.WriteLine($"\n\nA = {Math.Round(a, 2)}\nB = {Math.Round(b, 2)}\n");

            // переменная для подсчета сколько элементов находится между a и b
            int count = 0;

            // запрос к массиву - Вычисление количества элементов массива, со значениями в диапазоне от A до B
            // используем синтаксис LINQ - Language INtegrated Queries
            count = (from item in _array where a <= item && item <= b select item).Count();
            Console.Write("В синтаксисе LINQ:\n");
           
            Console.WriteLine($"{count}");
            count = 0;

            // тот же запрос, но с использованием синтаксиса методов расширения
            count = (_array
                .Where(x => a <= x && x <= b)
                .Select(x => x)).Count();
            Console.Write("\nВ синтаксисе расширяющих методов:\n");
            Console.WriteLine($"{count}");

        } // Task1

        // Задание 2. Вычисление количества элементов массива, равных 0
        public void Task2(){
            for (int i = 0; i < _n; i++)
                _array[i] = Utils.GetRandom(-2, 2);

            Console.WriteLine($"Исходный массив: ");
            ConsoleColor fColor = Console.ForegroundColor;
            Array.ForEach(_array, x =>
            {
                if (x==0) Console.ForegroundColor = ConsoleColor.Red; // если x = 0, то меняем цвет, если нет, то меняем цвет на основной
                else Console.ForegroundColor = fColor;
                Console.Write($"{Math.Round(x, 2)} ");
            });
            Console.ForegroundColor = fColor;

            // переменная для подсчета сколько элементов = 0
            int count = 0;

            count = (from item in _array where item == 0 select item).Count();
            // запрос к массиву - Вычисление количества элементов массива, равных 0
            // используем синтаксис LINQ - Language INtegrated Queries
            Console.Write("\nВ синтаксисе LINQ:\n");
            Console.WriteLine($"{count}");
            count = 0;

            // тот же запрос, но с использованием синтаксиса методов расширения
            count = (_array
                .Where(x => x == 0)
                .Select(x => x)).Count();
            Console.Write("\nВ синтаксисе расширяющих методов:\n");
            Console.WriteLine($"{count}");
        } // Task2

        // Задание 3. Вычисление суммы элементов массива, расположенных после первого максимального элемента
        public void Task3(){
            Init();
            double max = _array.Max();
            int indexMax = 0;

            bool flag = true; // для того, чтобы показать только 1 раз максимальный элемент

            Console.WriteLine($"Исходный массив: ");
            ConsoleColor fColor = Console.ForegroundColor;
            Array.ForEach(_array, x =>
            {
                if (x == max && flag)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    flag = false;
                } // если x = max, то меняем цвет, если нет, то меняем цвет на основной
            
                else Console.ForegroundColor = fColor;
                Console.Write($"{Math.Round(x, 2)} ");
            });
            Console.ForegroundColor = fColor;

            int sum = 0; // для вычисления суммы

           // var query1 = from item in _array where 


        } // Task3

    } // Task1Controller
}