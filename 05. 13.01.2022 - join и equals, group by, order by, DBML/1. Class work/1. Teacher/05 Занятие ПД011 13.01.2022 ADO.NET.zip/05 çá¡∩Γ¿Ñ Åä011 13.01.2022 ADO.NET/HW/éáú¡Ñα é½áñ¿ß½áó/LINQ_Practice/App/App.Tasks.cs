﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LINQ_Practice.Utilities;
using LINQ_Practice.Model;


/*
 * 
 * Задача 1. Для класса, представляющего товар (наименование, цена, количество, год выпуска) разработать расширяющий метод, 
 *           возвращающий процент скидки в зависимости от возраста товара – до 3х лет скидка не представляется, от 3х до 10 лет скидка 3%, свыше 10 лет – скидка 7%. Продемонстрировать работу метода на коллекции из 12 товаров.
 * 
 * Задача 2. С использованием LINQ (создавайте 2 варианта запросов – в синтаксисе LINQ и в синтаксисе расширяющих методов) 
             выполнить обработки для одномерного массива из n вещественных элементов:

        Вычисление количества элементов массива, со значениями в диапазоне от A до B
        Вычисление количества элементов массива, равных 0
        Вычисление суммы элементов массива, расположенных после первого максимального элемента
        Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом 

   Задача 3. Для коллекции товаров из задачи 1 выполнить следующие LINQ-запросы 
            (создавайте 2 варианта запросов – в синтаксисе LINQ и в синтаксисе расширяющих методов):

        товары с заданным диапазоном цен
        сумма товаров с заданным годом выпуска
        сумма товаров с заданным наименованием (суммируем произведение цены на количество, наименование товара может быть задано частично, но без маски типа %, _)
        наименование и год выпуска товаров с максимальным количеством
        все товары, для которых произведение цены на количество находится в заданном диапазоне

 * */

namespace LINQ_Practice.App
{
    public partial class Application
    {

        //Задача 1
        void Task1()
        {
            Utils.ShowBarMessage("Задача_1: работа с классом представляющим товар. Формирование скидок.");
            //Utils.ShowFrameMessage("Задача 1 в разработке! Скоро будет)","INFO",1,2);

            color.EstablishColor();
            //Console.WriteLine(goods.ToString());

            Console.WriteLine($"Скидка: {goods.Discount()}%");
        }


        //Задача 2
        void Task2()
        {
            Utils.ShowBarMessage("Задача_2: обработка одномерного массива с использованием LINQ");
            //Utils.ShowFrameMessage("Задача 2 в разработке! Скоро будет)", "INFO", 1, 2);


            Palette.MainColor.EstablishColor();

            //получение массива
            int[] Arr = Utils.GetIntArray();

            Array.ForEach(Arr, elem => Console.Write($" {elem} ")); ; ;

            Console.Write("\n\n");

            #region Подзадача 1

            //Вычисление количества элементов массива, со значениями в диапазоне от A до B
            (int A, int B) range = (5, 60);
            var query =
                from elem in Arr
                where elem > range.A && elem < range.B
                select elem;

            int count = query.
                        ToArray().
                        Count();
            //Вывод 
            Utils.ShowHighlighted($"Кол-во элементов в диапазоне от {range.A} до {range.B} (LINQ syntax):");
            Console.WriteLine($" {count}");

            //Вариант 2 
            count = Arr.
                Where(item => item > range.A && item < range.B).
                ToArray().
                Count();
            //Вывод 
            Console.Write('\n');
            Utils.ShowHighlighted($"Кол-во элементов в диапазоне от {range.A} до {range.B} (Расширяющие методы):");
            Console.WriteLine($" {count}");

            #endregion

            Console.Write('\n' + Utils.Splitter()+ "| Подзадача_2\n\n");

            #region Подзадача_2
            //Вычисление количества элементов массива, равных 0
            query =
                from elem in Arr
                where elem == 0
                select elem;

            count = query.
                ToArray().
                Count();

            //Вывод 
            Utils.ShowHighlighted($"Кол-во элементов равных 0 (LINQ syntax):");
            Console.WriteLine($" {count}");


            //Вариант 2 
            count = Arr.
                Where(item => item == 0).
                ToArray().
                Count();

            //Вывод 

            Console.Write('\n');
            Utils.ShowHighlighted($"Кол-во элементов равных 0 (Расширяющие методы):");
            Console.WriteLine($" {count}");
            #endregion


            Console.Write('\n' + Utils.Splitter() + "| Подзадача_3\n\n");

            #region Подзадача_3
            //Вычисление суммы элементов массива, расположенных после первого максимального элемента

            //Индекс максимального 
            int MaxIndex = Array.IndexOf(Arr, Arr.Max());

            //Вывод массива
            Utils.ShowHighlighted("Выделены элементы после max:", BackColor: ConsoleColor.White);
            ShowArrayDependMax(Arr,MaxIndex);

            Console.Write("\n\n");

            Utils.ShowHighlighted($"Сумма элементов массива, расположенных после первого максимального элемента (LINQ Syntax):");
            Utils.ShowHighlighted($" не нашел решения!",ConsoleColor.White,ConsoleColor.Red);


            //Создаём нужную проекцию массива для последующих действий
            //Пропускаем элементы до максимального + включительно максимальный.
            int summ = Arr.Skip(MaxIndex + 1).Sum(elem => elem);

            //Вывод 

            Console.Write("\n\n");
            Utils.ShowHighlighted($"Сумма элементов массива, расположенных после первого максимального элемента (Расширяющие методы):");
            Console.WriteLine($" {summ}");

            #endregion


            Console.Write('\n' + Utils.Splitter() + "| Подзадача_4\n\n");

            //Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом

            //Создаём проекцию 
            query =
                from elem in Arr
                select Math.Abs(elem);

            int[] ArrAbs = query.ToArray();

            //Индекс минимального по модулю 
            int MinInd = Array.LastIndexOf(ArrAbs,ArrAbs.Min());

            //Вывод массива
            Utils.ShowHighlighted("Выделены элементы до min:",BackColor: ConsoleColor.White);
            ShowArrayDependMin(ArrAbs,MinInd);

            //Подсчёт суммы 
            summ = ArrAbs
                .Take(MinInd)
                .Sum();

            //Вывод 
            Console.Write("\n\n");
            Utils.ShowHighlighted($"Сумма элементов массива, расположенных после первого максимального элемента (Расширяющие методы):");
            Console.WriteLine($" {summ}"); 
            
            //Через LINQ
            Console.Write("\n");

            Utils.ShowHighlighted($"Сумма элементов массива, расположенных после первого максимального элемента (LINQ Syntax):");
            Utils.ShowHighlighted($" не нашел решения!", ConsoleColor.White, ConsoleColor.Red);

        }


        //Вывод массива с выделением элементов после максимального 
        void ShowArrayDependMax(int[] arr, int maxInd)
        {
            for (int i = 0; i < arr.Length; i++) {

                if (i <= maxInd)
                {
                    Console.Write($" {arr[i]} ");
                    continue;
                }

                Console.Write(' ');

                Utils.ShowHighlighted(arr[i].ToString(),BackColor: ConsoleColor.Yellow);

                Console.Write(' ');
            }
        }

        //Вывод массива с выделением элементов после максимального 
        void ShowArrayDependMin(int[] arr, int minInd)
        {
            for (int i = 0; i < arr.Length; i++) {

                if (i >= minInd)
                {
                    Console.Write($" {arr[i]} ");
                    continue;
                }

                Console.Write(' ');

                Utils.ShowHighlighted(arr[i].ToString(),BackColor: ConsoleColor.Yellow);

                Console.Write(' ');
            }
        }


        //Задача 3
        void Task3()
        {
            Utils.ShowBarMessage("Задача_3: работа с коллекцией товаров через LINQ");
            Utils.ShowFrameMessage("Задача 3 в разработке! Скоро будет)", "INFO", 1, 2);
        }


        //Расширяющие методы для класса товаров


    }
}
