﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W3Ado.Models
{
    // модель для отображения издания - все поля представления
    public class Publication
    {
        public int PublicationId { get; set;}
        public string IndexPublication { get; set;}
        public string TypePublication { get; set;}
        public string TitlePublication { get; set;}
        public double PricePublication { get; set;}


        // шапка таблицы, статическое свойство
        public static string Header()
        {
            return
            $"\t┌────────┬───────────────┬───────────┬─────────────────────────┬─────────────┐\n" +
            $"\t│   ID   │  Индекс       │ Тип       │      Название           │ Цена        │\n" +
            $"\t│        │      издания  │   издания │             издания     │    издания  │\n" +
            $"\t├────────┼───────────────┼───────────┼─────────────────────────┼─────────────┤\n";
        } // Header

        // подвал таблицы, статическое свойство
        public static string Footer() =>
            $"\t└────────┴───────────────┴───────────┴─────────────────────────┴─────────────┘\n";

        // вывод в строку таблицы
        public string ToTableRow() =>
            $"\t│ {PublicationId,6} │ {IndexPublication,-13} │ {TypePublication,-9} │ {TitlePublication, -23} │ {PricePublication, 11:f2} │";


    }// class Publication
}
