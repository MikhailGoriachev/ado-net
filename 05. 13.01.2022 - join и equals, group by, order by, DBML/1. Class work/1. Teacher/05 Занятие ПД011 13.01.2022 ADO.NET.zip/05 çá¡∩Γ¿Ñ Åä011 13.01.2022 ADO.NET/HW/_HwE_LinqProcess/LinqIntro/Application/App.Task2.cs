﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqIntro.Helpers;

namespace LinqIntro.Application
{
    /*
     * Методы для решения задачи 2
     */
    public partial class App
    {
        // Заполнить массив новым набором чисел, показать массив
        public void ArrayFillAndShow() {
            Utils.ShowNavBarTask("   Заполнить массив новым набором чисел, показать массив");

            _task2Controller.Initializer(-10, 10);
            _task2Controller.ShowArray("\n\n\tНовый массив для обработки сформирован:\n", 0, 0);
        } // ArrayFillAndShow


        // Количество элементов массива, со значениями в диапазоне от A до B
        public void NumberOfItemInRangeAb() {
            Utils.ShowNavBarTask("   Количество элементов массива, со значениями в диапазоне от A до B");

            _task2Controller.ShowArray("\n\n\tМассив для обработки:\n");
            
            // Диапазон значений для подсчета количества элементов массива, попадающих
            // в этот диапазон
            double a = Utils.GetRandom(-10d, 3d);
            double b = Utils.GetRandom(3d, 10d);

            // Выводим массив с выделением цветом элементов в интервале [a, b]
            _task2Controller.ShowArray($"\n\n\tМассив с выделенными цветом элементами из диапазона " +
                                       $"[{a:n2} ... {b:n2}]:\n", a, b);
            
            // вычисление по заданию
            int amount1 = _task2Controller.Query01A(a, b);
            int amount2 = _task2Controller.Query01B(a, b);

            Console.WriteLine(
                $"\n\n\tКоличество элементов со значениями в диапазоне от [{a:n2} ... {b:n2}]:\n\n" +
                $"\t  Синтаксис языка запросов LINQ: {amount1}\n\n" +
                $"\t  Синтаксис расширяющих методов: {amount2}\n\n\n");
        } // NumberOfItemInRangeAb


        // Количество элементов массива, равных 0
        public void NumberOfItemEqZero() {
            Utils.ShowNavBarTask("   Количество элементов массива, равных 0");

            // Выводим массив с выделением цветом элементов равных 0
            // воспользуемся побочным эффектом метода ShowArray
            _task2Controller.ShowArray("\n\n\tМассив с выделенными цветом элементами, равными 0:\n", 0d, 0d);

            // вычисление по заданию
            int amount1 = _task2Controller.Query02A();
            int amount2 = _task2Controller.Query02B();

            Console.WriteLine(
                $"\n\n\tКоличество элементов массива, равных 0:\n\n" +
                $"\t  Синтаксис языка запросов LINQ: {amount1}\n\n" +
                $"\t  Синтаксис расширяющих методов: {amount2}\n\n\n");
        } // NumberOfItemEqZero


        // Сумма элементов массива, расположенных после первого максимального элемента
        public void SumAfterFirstMax() {
            Utils.ShowNavBarTask("   Сумма элементов массива, расположенных после первого максимального элемента");

            // вывод массива для обработки с цветовым выделением
            string caption = "\n\n\tМассив с выделенным первым максимальным элементом и элементами после него:\n";
            _task2Controller.ShowArrayMax(caption);

            // вычисление по заданию
            double sum1 = _task2Controller.Query03A();
            double sum2 = _task2Controller.Query03B();

            Console.WriteLine(
                $"\n\n\tСумма элементов массива, расположенных после первого максимального элемента:\n\n" +
                $"\t  Синтаксис языка запросов LINQ: {sum1:n2} - не могу реализовать\n\n" +
                $"\t  Синтаксис расширяющих методов: {sum2:n2}\n\n\n");
        } // SumAfterFirstMax


        // Сумма элементов массива, расположенных перед последним минимальным по модулю элементом 
        public void SumBeforeLastAbsMin() {
            Utils.ShowNavBarTask("   Сумма элементов массива, расположенных перед последним минимальным по модулю элементом");

            // вывод массива для обработки с цветовым выделением
            string caption = "\n\n\tМассив с выделенным последним минимальным по модулю элементом и элементами перед ним:\n";
            _task2Controller.ShowArrayMin(caption);

            // вычисление по заданию
            double sum1 = _task2Controller.Query04A();
            double sum2 = _task2Controller.Query04B();

            Console.WriteLine(
                $"\n\n\tСумма элементов массива, расположенных перед последним по модулю элементом:\n\n" +
                $"\t  Синтаксис языка запросов LINQ: {sum1:n2} - не могу реализовать\n\n" +
                $"\t  Синтаксис расширяющих методов: {sum2:n2}\n\n\n");
        } // SumBeforeLastAbsMin
    } // class App
}
