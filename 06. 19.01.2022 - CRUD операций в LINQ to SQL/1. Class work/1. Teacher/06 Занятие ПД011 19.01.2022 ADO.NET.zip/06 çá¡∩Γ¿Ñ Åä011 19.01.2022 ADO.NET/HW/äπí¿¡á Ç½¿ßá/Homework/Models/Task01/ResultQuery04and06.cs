﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Task01
{
    // для хранения результатов запросов 4 и 6 из задачи 1
    // фамилия И.О. автора и количество книг этого автора
    public class ResultQuery04and06 {
        // фамилия И.О. автора
        public string FullName { get; set; } // FullName


        // количество книг этого автора
        public int Amount { get; set; } // Amount

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {FullName,-15} │ {Amount,12} шт. │";

        // статический метод для вывода шапки таблицы
        public static string Header()
        {
            return
                $"  ┌─────────────────┬──────────────────┐\n" +
                $"  │ Автор           │ Кол-во книг      │\n" +
                $"  ├─────────────────┼──────────────────┤";
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────────────────┴──────────────────┘\n";
    } // ResultQuery04
}
