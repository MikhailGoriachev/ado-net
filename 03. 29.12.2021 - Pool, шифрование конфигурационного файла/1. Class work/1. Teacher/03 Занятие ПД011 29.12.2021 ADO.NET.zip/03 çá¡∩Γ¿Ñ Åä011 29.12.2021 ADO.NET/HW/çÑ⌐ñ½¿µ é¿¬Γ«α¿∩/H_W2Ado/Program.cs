﻿using H_W2Ado.Application;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;        // для ADO.NET
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace H_W2Ado
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 2.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Запрос 1.Выбирает 3-х кв. на улице <<Cадовая>>" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Запрос 2.Выбирает риелторов с фамилией на 'И' и вознаграждение больше 10%." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Запрос 3.Выбирает информацию о квартирах в ценовом диапазоне от 900_000 до 1_000_000." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Запрос 4.Выбирает информацию о квартирах с заданным числом комнат." },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Запрос 5.Выбирет 2-х кв. с площадью находящейся в некотором диапазоне." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Запрос 6.Вычисляет размер комиссионного вознаграждения риелтора." },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Запрос 7.Выбирает всех риелторов, количество клиентов, оформивших с ним сделку." },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Запрос 8.Для всех улиц вывести сумму сделок." },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Запрос 9.Для всех улиц вывести сумму сделок за заданный период." },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Запрос 1.Выбирает все факты проката автомобиля с заданным госномером." },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Запрос 2.Выбирает все факты проката автомобиля с заданной моделью/брендом." },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Запрос 3.Выбирает информацию об автомобиле с заданным госномером." },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Запрос 4.Выбирает информацию о клиентах по серии и номеру паспорта." },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Запрос 5.Выбирает все факты проката автомобилей в заданный интервал времени." },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Запрос 6.Вычисляет для каждого факта проката стоимость проката." },
                new MenuItem { HotKey = ConsoleKey.J, Text = "Запрос 7.Вычисляет для всех клиентов прокатной фирмы количество фактов проката." },
                new MenuItem { HotKey = ConsoleKey.K, Text = "Запрос 8.Выбирает информацию о фактах проката автомобилей по госномеру." },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();
                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(20, 5, "Запросы к базам данных : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    // строка подключения к БД - взята из свойств базы данных
                    //string connectingString =
                    //   @"Data Source=(LocalDB)\MSSQLLocalDB;
                    //   AttachDbFilename=D:\Users\User\source\repos\H_W2Ado\H_W2Ado\App_Data\RealEstateTransactions.mdf;Integrated Security=True";

                    //string connectingString2 =
                    //   @"Data Source=(LocalDB)\MSSQLLocalDB;
                    //   AttachDbFilename=D:\Users\User\source\repos\H_W2Ado\H_W2Ado\App_Data\CarRental.mdf;Integrated Security=True";   
                    
                    string connectingString2 =
                       @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Students\ПД011\06 ADO.NET\03 Занятие ПД011 29.12.2021 ADO.NET\HW\Зейдлиц Виктория\H_W2Ado\App_Data\CarRental.mdf"";Integrated Security=True";

                    string connectingString =
                       @"Data Source=(LocalDB)\MSSQLLocalDB;
                       AttachDbFilename=""D:\Students\ПД011\06 ADO.NET\03 Занятие ПД011 29.12.2021 ADO.NET\HW\Зейдлиц Виктория\H_W2Ado\App_Data\RealEstateTransactions.mdf"";Integrated Security=True";

                    switch (key)
                    {
                        // Выбирает 3-х кв. на улице <<Cадовая>>
                        case ConsoleKey.Q:
                            app.Query01(connectingString);
                            break;

                        // Выбирает риелторов с фамилией на 'И' и вознаграждение больше 10%
                        case ConsoleKey.W:
                            app.Query02(connectingString);
                            break;

                        // Выбирает информацию о квартирах в ценовом диапазоне от 900_000 до 1_000_000
                        case ConsoleKey.E:
                            app.Query03(connectingString);
                            break;

                        // Выбирает информацию о квартирах с заданным числом комнат
                        case ConsoleKey.R:
                            app.Query04(connectingString);
                            break;

                        // Выбирет 2-х кв. с площадью находящейся в некотором диапазоне
                        case ConsoleKey.T:
                            app.Query05(connectingString);
                            break;

                        // Вычисляет размер комиссионного вознаграждения риелтора
                        case ConsoleKey.Y:
                            app.Query06(connectingString);
                            break;

                        // Выбирает всех риелторов, количество клиентов, оформивших с ним сделку
                        case ConsoleKey.U:
                            app.Query07(connectingString);
                            break;

                        // Для всех улиц вывести сумму сделок
                        case ConsoleKey.I:
                            app.Query08(connectingString);
                            break;

                        // Для всех улиц вывести сумму сделок за заданный период
                        case ConsoleKey.O:
                            app.Query09(connectingString);
                            break;

                        // Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
                        case ConsoleKey.A:
                            app.Task2Query01(connectingString2);
                            break;

                        // Выбирает все факты проката автомобиля с заданной моделью/брендом
                        case ConsoleKey.S:
                            app.Task2Query02(connectingString2);
                            break;

                        // Выбирает информацию об автомобиле с заданным госномером
                        case ConsoleKey.D:
                            app.Task2Query03(connectingString2);
                            break;

                        // Выбирает информацию о клиентах по серии и номеру паспорта
                        case ConsoleKey.F:
                            app.Task2Query04(connectingString2);
                            break;

                            // Выбирает все факты проката автомобилей в некоторый заданный интервал времени
                        case ConsoleKey.G:
                            app.Task2Query05(connectingString2);
                            break;

                        // Вычисляет для каждого факта проката стоимость проката
                        case ConsoleKey.H:
                            app.Task2Query06(connectingString2);
                            break;

                        // Вычисляет для всех клиентов прокатной фирмы количество фактов проката
                        case ConsoleKey.J:
                            app.Task2Query07(connectingString2);
                            break;

                        // Выбирает информацию о фактах проката автомобилей по госномеру
                        case ConsoleKey.K:
                            app.Task2Query08(connectingString2);
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;

        }// Main
    }
}
