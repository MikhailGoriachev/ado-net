﻿namespace DemoLinqToSql.Models.Task1
{
    // класс для вывода данных книги с расшифровкой поля автор
    public class BookViewModel
    {
        // идентификатор книги
        public int Id { get; set; }

        // Фамилия и инициалы автора
        public string Author { get; set; }

        // название книги
        public string Title { get; set;}

        // год издания
        public int PubYear { get; set; }

        // цена
        public int Price { get; set; }

        #region  Вспомогательный метод и свойства вывода таблицы
        // строка таблицы
        public string ToTableRow() =>
            $"│ {Id, 5} │ {Author, -18} │ {Title, -40} │ {PubYear,8} │ {Price,10:n2} │";

        // заголовок таблицы товаров
        public static string Header =
            "\t┌───────┬────────────────────┬──────────────────────────────────────────┬──────────┬────────────┐\n" +
            "\t│   Ид. │ Автор              │ Название книги                           │ Год изд. │ Цена, руб. │\n" +
            "\t├───────┼────────────────────┼──────────────────────────────────────────┼──────────┼────────────┤";

        // подвал таблицы вывода товаров
        public static string Footer =
            "\t└───────┴────────────────────┴──────────────────────────────────────────┴──────────┴────────────┘\n";
        #endregion  
    } // class BookViewModel
}
