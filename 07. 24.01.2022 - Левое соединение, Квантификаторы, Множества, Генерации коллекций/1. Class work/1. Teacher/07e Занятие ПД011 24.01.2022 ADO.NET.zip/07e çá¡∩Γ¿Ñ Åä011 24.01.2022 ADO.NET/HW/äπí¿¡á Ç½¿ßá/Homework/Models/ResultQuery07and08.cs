﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
    // для хранения результата запросов 7 и 8
    internal class ResultQuery07and08 {
        // наименование товара/продавец
        public string Title { get; set; } // Title

        // средняя цена закупки товара/среднее значение по полю Цена продажи единицы товара
        public double Average { get; set; }

        // кол-во закупок товара/кол-во продаж продавца
        public int Amount { get; set; } // Amount
    } // ResultQuery07and08
}
