﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Controllers;

namespace Homework.Application
{
	internal partial class App
	{
		private Menu _mainMenu;

		private Task1Controller _task1Controller;
		private Task2Controller _task2Controller;

		public App() 
		{
			_task1Controller = new Task1Controller();
			_task2Controller = new Task2Controller();
			InitMenu();
		}
		

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem {Text = "Задача 1. Вывести все книги коллекции, выводить фамилии и инициалы автора", 
						Callback = Task1Item1},
					new Menu.MenuItem {Text = "Задача 1. Вывести книги авторов, год рождения которых принадлежит заданном диапазону", 
						Callback = Task1Item2},
					new Menu.MenuItem {Text = "Задача 1. Вывести книги, в названии которых содержится заданная подстрока и цена не превышает заданного значения",
						Callback = Task1Item3},
					new Menu.MenuItem {Text = "Задача 1. Список авторов и количество их книг в коллекции", 
						Callback = Task1Item4},
					new Menu.MenuItem {Text = "Задача 1. Средняя цена книг по годам издания",
						Callback = Task1Item5},
					new Menu.MenuItem {Text = "Задача 1. Список авторов по убыванию количества их книг в коллекции ",
						Callback = Task1Item6},
					new Menu.MenuItem {Text = "Задача 1. Средний возраст книг по авторам, с упорядочиванием фамилий и инициалов авторов по алфавиту",
						Callback = Task1Item7},


					new Menu.MenuItem {Text = "Задача 2. Вывод всех таблиц базы данных", 
						Callback = Task2Item1},
					new Menu.MenuItem {Text = "Задача 2. Tовары, единицей измерения которых является «шт» и цена закупки составляет меньше 200 руб.", 
						Callback = Task2Item2},
					new Menu.MenuItem {Text = "Задача 2. Товары, цена закупки которых больше 500 руб. за единицу товара", 
						Callback = Task2Item3},
					new Menu.MenuItem {Text = "Задача 2. Товары с заданным наименованием, для которых цена закупки меньше 1800 руб.", 
						Callback = Task2Item4},
					new Menu.MenuItem {Text = "Задача 2. Продавцы с заданным значением процента комиссионных.",
						Callback = Task2Item5},
					new Menu.MenuItem {Text = "Задача 2. Все зафиксированные факты продажи товаров, с ценой продажи в заданных границах. ",
						Callback = Task2Item6},
					new Menu.MenuItem {Text = "Задача 2. Прибыль от продажи за каждый проданный товар. Сортировка по полю Наименование товара", 
						Callback = Task2Item7},
					new Menu.MenuItem {Text = "Выход"}
				}, new Point(5, 5),
				"Меню приложения");
		}
		public void Run() =>_mainMenu.Run();

	}
}
