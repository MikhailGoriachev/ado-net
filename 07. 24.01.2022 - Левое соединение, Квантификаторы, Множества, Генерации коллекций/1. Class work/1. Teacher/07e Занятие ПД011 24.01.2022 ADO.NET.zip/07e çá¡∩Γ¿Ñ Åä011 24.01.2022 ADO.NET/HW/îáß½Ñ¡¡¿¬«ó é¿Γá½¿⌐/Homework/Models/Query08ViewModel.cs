﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	public class Query08ViewModel
	{
		// имя продавца
		public string SurnameNP { get; set; }

		// средняя цена продажи единицы товара
		public double AvgSalePrice { get; set; }
		
		// количество продаж
		public int SalesAmount { get; set; }
	}
}
