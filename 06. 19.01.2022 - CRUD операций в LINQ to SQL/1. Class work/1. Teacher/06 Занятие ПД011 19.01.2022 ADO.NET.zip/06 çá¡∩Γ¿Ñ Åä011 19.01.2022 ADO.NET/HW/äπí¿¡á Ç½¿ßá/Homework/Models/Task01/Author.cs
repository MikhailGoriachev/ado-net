﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Task01
{
    // Поля объекта класса Автор: идентификатор, фамилия и инициалы, год рождения. 
    public class Author {
        // идентификатор
        private int _id;
        public int Id {
            get => _id;
            set => _id = value;
        } // Id

        // фамилия и инициалы
        string _fullName;
        public string FullName {
            get => _fullName;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Author: Некорректные фамилия и инициалы автора!"); _fullName = value; }
        } // FullName

        // год рождения
        private int _year;
        public int Year {
            get => _year;
            set { if (value > DateTime.Now.Year) throw new Exception("Author: Некорректный год рождения автора!"); _year = value; }
        } // Year
    } // Author
}
