﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoLinqToSql.Controllers;
using DemoLinqToSql.Helpers;

/*
 * Задача 1.
 * Даны две связанные коллекции – описание книг и авторов книг. Объект класса
 * Книга имеет следующие поля: идентификатор, идентификатор автора, название
 * книги, год издания, цена. Поля объекта класса Автор: идентификатор, фамилия
 * и инициалы, год рождения. Требуется реализовать запросы к коллекциям,
 * использовать два варианта – синтаксис запросов и синтаксис расширяющих
 * функций.  
 *     o Вывести все книги коллекции, выводить фамилии и инициалы автора
 *     o Вывести книги авторов, год рождения которых принадлежит заданном
 *       диапазону 
 *     o Вывести книги, в названии которых содержится заданная подстрока
 *       и цена не превышает заданного значения
 *     o Список авторов и количество их книг в коллекции
 *     o Средняя цена книг по годам издания
 *     o Список авторов по убыванию количества их книг в коллекции 
 *     o Средний возраст книг по авторам, выводить список с упорядочиванием
 *       фамилий и инициалов авторов по алфавиту
 *
 * Задача 2.
 * Для базы данных учета продаж оптового магазина из задания на 24.11.2021
 * разработайте и выполните запросы LINQ to SQL. Реализуйте два варианта –
 * с использованием синтаксиса запросов и с использованием расширяющих
 * методов.
 *
 */

namespace DemoLinqToSql
{
    public class Program
    {
        static void Main(string[] args)
        {
            Utils.SetColor(ConsoleColor.Gray, ConsoleColor.DarkGray);
            Console.Clear();

            // TODO: добавить класс Application, интерфейс пользователя
            Task1Controller task1Controller = new Task1Controller();
            Task2Controller task2Controller = new Task2Controller();
            
            task1Controller.ShowAllBooks();

            task2Controller.ShowAllSells();

            task2Controller.RunAndShowQuery03Ext();
            task2Controller.RunAndShowQuery03Linq();
        } // Main
    } // class Program
}
