﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W5AdoLINQtoSQL.Application
{
    internal partial class App
    {
        public void Query01()
        {
            Utils.ShowNavBarTask("   Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых \n " +
                "является «шт» (штуки) и цена закупки составляет меньше 100 руб.");

            _wholesale.Query01Ext();
            _wholesale.Query01Linq();
        }// Query01


        public void Query02()
        {
            Utils.ShowNavBarTask("   Выбирает из таблицы ТОВАРЫ информацию о товарах,\n" +
                " цена закупки которых больше 140 руб. за единицу товара.");

            _wholesale.Query02Ext();
            _wholesale.Query02Linq();
        }// Query02


        public void Query03()
        {
            Utils.ShowNavBarTask("  Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием\n" +
                " (например, «чехол защитный»), для которых цена закупки меньше 200 руб.");

            _wholesale.Query03Ext();
            _wholesale.Query03Linq();
        }// Query03


        public void Query04()
        {
            Utils.ShowNavBarTask("  Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением процента комиссионных.");

            _wholesale.Query04Ext();
            _wholesale.Query04Linq();
        }// Query04


         
        public void Query05()
        {
            Utils.ShowNavBarTask("  Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех\n" +
                " зафиксированных фактах продажи товаров (Наименование товара, Цена закупки, Цена продажи,\n" +
                " дата продажи), для которых Цена продажи оказалась в некоторых заданных границах.");

            _wholesale.Query05Ext();
            _wholesale.Query05Linq();
        }// Query05


        public void Query06()
        {
            Utils.ShowNavBarTask("  Вычисляет прибыль от продажи за каждый проданный товар.\n" +
                " Включает поля Дата продажи, Наименование товара, Цена закупки,\n" +
                " Цена продажи, Количество проданных единиц, Прибыль." +
                "\n Сортировка по полю Наименование товара.");

            _wholesale.Query06Ext();
            _wholesale.Query06Linq();
        }// Query06

    }// class App
}
