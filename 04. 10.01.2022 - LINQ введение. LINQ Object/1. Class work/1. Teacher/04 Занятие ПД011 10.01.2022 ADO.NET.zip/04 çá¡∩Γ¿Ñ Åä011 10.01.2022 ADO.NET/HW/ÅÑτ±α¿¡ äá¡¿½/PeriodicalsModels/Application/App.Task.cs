﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PeriodicalsModels.Helpers;
using PeriodicalsModels.Models;


namespace PeriodicalsModels.Application
{
    public partial class App
    {
        //Запрос 1. Издания с заданным с опреденной стоимостью

        public void ExecQuery01()
        {
            Utils.ShowNavBarTask("      Выполнение запроса 1  ");

            List<Publication> list = _queryControllers.Query1("журнал", 250);
            
            // выводим имена столбцов 
            Console.WriteLine("\t" +
                              $" |{nameof(Publication.Id),5}| {nameof(Publication.PubIndex),16}" +
                              $"| {nameof(Publication.Title),36}" +
                              $"| {nameof(Publication.Price),5} |");
            //вывод списка
            list.ForEach(a=>Console.WriteLine(a.ToTableRow()));

            Console.ReadKey();
        }
        //Запрос 2.
        public void ExecQuery02()
        {
            Utils.ShowNavBarTask("   Выполнение запроса 2");

            List<Subscriber> list =_queryControllers.Query2("ул. Садовая", "118", "Юный техник");

            // выводим имена столбцов 
            Console.WriteLine("\t" +
                              $" | {nameof(Subscriber.Id),4}| {nameof(Subscriber.Subcriber),15}" +
                              $" | {nameof(Subscriber.Passport),15} | {nameof(Subscriber.Address),35}" +
                              $" | {nameof(Subscriber.Pubtype),11} | {nameof(Subscriber.Title),10}"); 
            //вывод список
            list.ForEach(a=>Console.WriteLine(a.ToTableRow()));

            Console.ReadKey();
        }
        //Запрос 3.
        public void ExecQuery03()
        {
            Utils.ShowNavBarTask("      Выполнение запроса 3");

            List<Publication> list =_queryControllers.Query3(100, 150);

            // выводим имена столбцов 
            Console.WriteLine("\t" +
                              $" |{nameof(Publication.Id),5}| {nameof(Publication.PubIndex),16}" +
                              $"| {nameof(Publication.Title),36}" +
                              $"| {nameof(Publication.Price),5} |");
            //вывод списка
            list.ForEach(a => Console.WriteLine(a.ToTableRow()));

            Console.ReadKey();
        }

        //Запрос 4.
        public void ExecQuery04()
        {
            Utils.ShowNavBarTask("        Выполнение запроса 4");

            List<Subscriber> list =_queryControllers.Query4("газета");


            // выводим имена столбцов 
            Console.WriteLine("\t" +
                              $" | {nameof(Subscriber.Id),4}| {nameof(Subscriber.Subcriber),15}" +
                              $" | {nameof(Subscriber.Passport),15} | {nameof(Subscriber.Address),33}" +
                              $" | {nameof(Subscriber.Pubtype),8} | {nameof(Subscriber.Title),26}|");
            //вывод список
            list.ForEach(a => Console.WriteLine(a.ToTableRow()));
            Console.ReadKey();
        }

        //Запрос 5. 
        public void ExecQuery05()
        {
            Utils.ShowNavBarTask("            Выполнение  запроса 5");

            _queryControllers.Query5(3,4);

            Console.ReadKey();
        }

        //Запрос 6.
        public void ExecQuery06()
        {
            Utils.ShowNavBarTask("      Выполнение запроса 6");
            List<SubscribersCost> list = _queryControllers.Query6();


            // выводим имена столбцов 
            Console.WriteLine("\t" +
                              $" | {nameof(SubscribersCost.Id),3}| {nameof(SubscribersCost.PubType),8}" +
                              $" | {nameof(SubscribersCost.Title),31} | {nameof(SubscribersCost.Price),8}" +
                              $" | {nameof(SubscribersCost.DateStart),17} | {nameof(SubscribersCost.Duration),10}|" +
                              $" | {nameof(SubscribersCost.SubscriberCost),10}");

            // выводим список 
            list.ForEach(a=>Console.WriteLine(a.ToTableRow()));
            Console.ReadKey();
        }

        //Запрос 7.

        public void ExecQuery07()
        {
            Utils.ShowNavBarTask("       Выполнение запроса 7");
            List<TotalMinMax> list =_queryControllers.Query7();

            Console.WriteLine("\t" +
                              $" |{nameof(TotalMinMax.PubType),9} | {nameof(TotalMinMax.TotalPubType)}" +
                              $"|{nameof(TotalMinMax.MaxPrice),9}  | {nameof(TotalMinMax.MinPrice),8} |");
            //выводим список
            list.ForEach(a=>Console.WriteLine(a.ToTableRow()));
            Console.ReadKey();
        }

        //Запрос 8 
        public void ExecQuery08()
        {
            Utils.ShowNavBarTask("       Выполнение запроса 8 ");
            List<GroupByStreet> list = _queryControllers.Query8();

            Console.WriteLine("\t" + 
                              $" | {nameof(GroupByStreet.Street),16} | {nameof(GroupByStreet),15}|");
            //выводим список
            list.ForEach(a=>Console.WriteLine(a.ToTableRow()));
            Console.ReadKey();
        }

        //Запрос 9 
        public void ExecQuery09()
        {
            Utils.ShowNavBarTask("         Выполнение запроса 9");
            List<Deliveries> list =_queryControllers.Query9();

            Console.WriteLine("\t" +
                              $" | {nameof(Deliveries.PubType),16} | {nameof(Deliveries.DeliveriesAmount),15}|");

            //выводим список
            list.ForEach(a=>Console.WriteLine(a.ToTableRow()));
            Console.ReadKey();
        }
    }
}
