﻿using System;
using AdoNetIntro.Controllers;

namespace AdoNetIntro.Application
{
    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    public partial class App
    {
        private QueriesController _queriesController;
       
        // конструктор по умолчанию
        public App(): this(new QueriesController()) { }
        public App(string connectingString): this(new QueriesController(connectingString)) { }

        public App(QueriesController queriesController) {
            _queriesController = queriesController;
        } // App

    } // class App
}