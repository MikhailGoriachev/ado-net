﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Main.Models;


namespace Main.Infrastructure
{
	public sealed class QueriesProvider
	{
		private static readonly string ConnectionString =
			@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Catalan\Desktop\Homework_06\Homework_06\Main\Data\Wholesale.mdf;Integrated Security=True";


		public IEnumerable<(string Title, ICollection Result)> Queries()
		{
			var queryMethods = GetType()
							   .GetMethods(BindingFlags.Instance | BindingFlags.NonPublic)
							   .Where(method => method.Name.Contains("Query"));

			foreach (var queryMethod in queryMethods)
			{
				var result = (ICollection)queryMethod.Invoke(this, null);
				var title = queryMethod.GetCustomAttribute<DisplayNameAttribute>()?.DisplayName
							?? queryMethod.Name;

				yield return (title, result);
			}
		}


		// Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения 
		// которых является «шт» (штуки) и цена закупки составляет меньше 200 руб.
		[DisplayName("Первый запрос")]
		private ICollection Query1() =>
			Connect().Purchases
					 .Where(purchase => purchase.Unit.Short == "шт" && purchase.Price < 200)
					 .Select(purchase => new
					 {
						 Name = purchase.Good.Item,
						 purchase.Price,
						 Unit = purchase.Unit.Short,
						 purchase.Amount
					 })
					 .ToArray();


		// Выбирает из таблицы ТОВАРЫ информацию о товарах, цена
		// закупки которых больше 500 руб.за единицу товара
		[DisplayName("Второй запрос")]
		private ICollection Query2() =>
			Connect().Purchases
					 .Where(purchase => purchase.Price > 500)
					 .Select(purchase => new
					 {
						 Name = purchase.Good.Item,
						 purchase.Price,
						 Unit = purchase.Unit.Short,
						 purchase.Amount
					 })
					 .ToArray();


		// Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием
		// (например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
		[DisplayName("Третий запрос")]
		private ICollection Query3() =>
			Connect().Purchases
					 .Where(purchase => purchase.Price > 500)
					 .Select(purchase => new
					 {
						 Name = purchase.Good.Item,
						 purchase.Price,
						 Unit = purchase.Unit.Short,
						 purchase.Amount
					 }).ToArray();


		// Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением процента комиссионных. 
		[DisplayName("Четвертый запрос")]
		private ICollection Query4() =>
			Connect().Sellers
					 .Where(seller => seller.Interest.Equals(3))
					 .Select(seller => new
					 {
						 seller.Person.Name,
						 seller.Person.Surname,
						 seller.Person.Patronymic,
						 seller.Person.Passport,
						 seller.Interest
					 })
					 .ToArray();


		// Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех зафиксированных фактах
		// продажи товаров (Наименование товара, Цена закупки, Цена продажи, дата продажи),
		// для которых Цена продажи оказалась в некоторых заданных границах. 
		[DisplayName("Пятый запрос")]
		private ICollection Query5() =>
			Connect().Sales
					 .Where(sale => sale.Price >= 15000 && sale.Price <= 150000)
					 .Select(sale => new
					 {
						 sale.Purchase.Good.Item,
						 Date = sale.SaleDate,
						 sale.Price,
						 Unit = sale.Unit.Short,
						 Seller =
							 $"{sale.Seller.Person.Surname} {sale.Seller.Person.Name} {sale.Seller.Person.Patronymic}"
					 })
					 .ToArray();


		// Вычисляет прибыль от продажи за каждый проданный товар. Включает поля Дата продажи,
		// Наименование товара, Цена закупки, Цена продажи, Количество проданных единиц,
		// Прибыль. Сортировка по полю Наименование товара
		[DisplayName("Шестой запрос")]
		private ICollection Query6() =>
			Connect().Sales
					 .Select(sale => new
					 {
						 sale.Purchase.Good.Item,
						 Date          = sale.SaleDate,
						 SalePrice     = sale.Price,
						 PurchasePrice = sale.Purchase.Price,
						 sale.Amount,
						 Unit   = sale.Unit.Short,
						 Profit = (sale.Price - sale.Purchase.Price) * sale.Amount,
						 Seller =
							 $"{sale.Seller.Person.Surname} {sale.Seller.Person.Name} {sale.Seller.Person.Patronymic}"
					 })
					 .OrderBy(arg => arg.Item)
					 .ToArray();


		// Выполняет группировку по полю Наименование товара. Для каждого наименования
		// вычисляет среднюю цену закупки товара, количество закупок
		[DisplayName("Седьмой запрос")]
		private ICollection Query7() =>
			Connect().Purchases
					 .GroupBy(purchase => new
					 {
						 purchase.Good.Item, purchase.Unit.Long
					 })
					 .Select(arg => new
					 {
						 arg.Key.Item,
						 arg.Key.Long,
						 Average = arg.Average(purchase => purchase.Price),
						 Count   = arg.Count(),
					 })
					 .ToArray();


		// Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ. Для каждого
		// продавца вычисляет среднее значение по полю Цена продажи единицы товара, количество продаж
		[DisplayName("Восьмой запрос")]
		private ICollection Query8() =>
			Connect().Sales
					 .GroupBy(sale => new
					 {
						 sale.IdSeller, sale.Seller.Person.Name,
						 sale.Seller.Person.Surname, sale.Seller.Person.Patronymic,
						 sale.Seller.Person.Passport
					 })
					 .Select(arg => new
					 {
						 arg.Key.Name,
						 arg.Key.Surname,
						 arg.Key.Patronymic,
						 arg.Key.Passport,
						 AveragePrice = arg.Average(sale => sale.Price),
						 SalesCount = arg.Count()
					 })
					 .ToArray();


		private static WholesaleDataContext Connect() => new(ConnectionString);
	}
}