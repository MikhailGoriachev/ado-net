﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PeriodicalsModels.Application;
using PeriodicalsModels.Helpers;
using System.Configuration;

namespace PeriodicalsModels
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 10.02.2022 - модели в запросах к базам данных";

            MenuItem[] menu = new[]
            {
                new MenuItem { HotKey = ConsoleKey.Q, Text ="Информация о изданиях заданного типа, стоимость 1 экземпляра для которых меньше заданной"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Информация о подписчиках, проживающих на улице и номере дома,оформившие подписку с заданным наименованием"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Информация об изданиях, с Ценой 1 экземпляра в заданном диапазоне значений"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Информация о подписчиках, подписавшихся на заданный параметром тип издания"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Информация обо всех оформленных подписках из некоторого диапазона"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Выполняет группировку по полю Вид издания.Вычисляет максимальную и минимальную цену 1 экземпляра"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Выполняет группировку по полю Улица.Вычисляет количество подписчиков на данной улице"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Для всех изданий выводит количество оформленных подписок"},
                
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" }
            }; // MenuItem

            App app = new App(ConfigurationManager.ConnectionStrings["Periodicals"].ConnectionString);

            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Models в ADO.NET");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с базой данных «Учет сделок с недвижимостью»", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            app.ExecQuery01();
                            break;

                        case ConsoleKey.W:
                            app.ExecQuery02();
                            break;

                        case ConsoleKey.E:
                            app.ExecQuery03();
                            break;
                        case ConsoleKey.R:
                            app.ExecQuery04();
                            break;
                        case ConsoleKey.T:
                            app.ExecQuery05();
                            break;
                        case ConsoleKey.A:
                            app.ExecQuery06();
                            break;
                        case ConsoleKey.S:
                            app.ExecQuery07();
                            break;
                        case ConsoleKey.D: 
                            app.ExecQuery08();
                            break;
                        case ConsoleKey.F:
                            app.ExecQuery09();
                            break;
                    }// switch

                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }
            }// while

        }
    }
}
