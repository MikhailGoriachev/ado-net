﻿using System.Data;


namespace Main
{
	public interface IMappable<T>
	{
		T Map(DataRow row);
	}
}