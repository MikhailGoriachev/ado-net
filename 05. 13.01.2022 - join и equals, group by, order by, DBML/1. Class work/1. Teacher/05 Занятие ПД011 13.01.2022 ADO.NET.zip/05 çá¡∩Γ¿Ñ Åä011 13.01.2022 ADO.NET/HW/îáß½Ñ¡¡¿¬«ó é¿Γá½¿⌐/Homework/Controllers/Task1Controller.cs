﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
	public class Task1Controller
	{
		private List<Product> _products;
		private readonly int nProducts = 12;

		public Task1Controller()
		{
			_products = new();
			for (int i = 0; i < nProducts; i++)
				_products.Add(Product.Generate());
		}

		public void ExtensionDemo()
		{
			Console.WriteLine($"\n  Список товаров:\n");
			Console.Write(Product.Header());
			_products.ForEach(x => Console.WriteLine(x.ToTableRow() + "  Скидка: " + x.Discount()));
			Console.Write(Product.Footer());
		}
	}
}
