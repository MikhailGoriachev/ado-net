﻿/*
 * База данных «Учет подписки на периодические печатные издания»
 *
 * База данных должна включать таблицы ИЗДАНИЯ, ПОДПИСЧИКИ, ДОСТАВКА, 
 * содержащие следующую информацию:
 *     • Фамилия подписчика
 *     • Имя подписчика
 *     • Отчество подписчика
 *     • Номер паспорта подписчика
 *     • Улица
 *     • Номер дома
 *     • Номер квартиры
 *     • Индекс издания по каталогу
 *     • Вид издания (газета, журнал, каталог, …)
 *     • Наименование (название) издания
 *     • Цена 1 экземпляра
 *     • Дата начала подписки
 *     • Срок подписки (количество месяцев)
 *
 */

-- при повторном запуске скрипта удаляем старые варианты таблиц, не разбирая пустые они или нет
-- таблицы удаляем в порядке, обратном порядку создания
drop table if exists Deliveries;
drop table if exists Subscribers;
drop table if exists Publications;
drop table if exists Streets;
drop table if exists PubTypes;


-- виды изданий
create table PubTypes (
	Id          int          not null primary key identity (1, 1),
	PubType     nvarchar(30) not null    -- название типа издания
);
go

-- названия улиц
create table Streets (
	Id          int          not null primary key identity (1, 1),
	Street      nvarchar(30) not null    -- название улицы
);
go

-- издания
create table Publications (
    Id          int          not null primary key identity (1, 1),
	IdPubType   int          not null,  -- вид издания
    PubIndex    nvarchar(12) not null,  -- индекс издания по каталогу
    Title       nvarchar(80) not null,  -- наименование (название) издания
    Price       int          not null,  -- цена 1 экземпляра

	-- ограничение на цену 1 экземпляра
	constraint CK_Publications_Price check (Price > 0),

	-- внешний ключ - связь M:1 к таблице PubTypes
	constraint FK_Publications_PubTypes foreign key (IdPubType) references dbo.PubTypes(Id)
);
go

-- подписчики
create table Subscribers (
	Id          int          not null primary key identity (1, 1),
	Surname     nvarchar(60) not null,    -- Фамилия подписчика
	[Name]      nvarchar(50) not null,    -- Имя подписчика
	Patronymic  nvarchar(60) not null,    -- Отчество подписчика
	Passport    nvarchar(15) not null,    -- Серия и номер подписчика
	IdStreet    int          not null,    -- улица
	Building    nvarchar(10) not null,    -- номер дома
	Flat        int          not null,    -- номер квартиры, 0 для частного сектора

	-- ограничение на номер квартиры
	constraint CK_Subscribers_Flat check (Flat >= 0),

	-- внешний ключ - связь 1:M к таблице Streets
	constraint FK_Subscribers_Streets foreign key (IdStreet) references dbo.Streets(Id)
);
go

-- доставки
create table Deliveries (
    Id            int  not null primary key identity (1, 1),  
	IdSubscriber  int  not null,   -- кто подписался
	IdPublication int  not null,   -- на какое издание
	DateStart     date not null,   -- начиная с какой даты
	Duration      int  not null,   -- длительность подписки, на какое количество месяцев

	-- ограничение на длительность подписки - от 1 до 12 месяцев
	constraint CK_Deliveries_Duration check (Duration between 1 and 12),

	-- внешний ключ - связь M:1 к таблице Subscribers
	constraint FK_Deliveries_Subscribers foreign key (IdSubscriber) references dbo.Subscribers(Id),

	-- внешний ключ - связь M:1 к таблице Publications
	constraint FK_Deliveries_Publications foreign key (IdPublication) references dbo.Publications(Id),
);
go

