﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Realestate.Controllers
{
    class Task1Controller {
        // строка подключения к базе данных
        private string _connectingString;
        public string ConnectingString {
            get => _connectingString;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Не указана строка подключения к базе данных");

                _connectingString = value;
            } // set
        } // ConnectionString

        public Task1Controller(string connectingString) {
            ConnectingString = connectingString;
        } // Task1Controller

        // 1. Хранимая процедура	
        //    Выбирает информацию о 3-комнатных квартирах,
        //    расположенных на улице «Садовая». Значения задавать параметрами запроса
        public void Query01(int roomNum = 3, string street = "ул. Садовая") {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery01");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);
                cmd.Parameters.AddWithValue("@street", street);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬────────────┬────────────┬─────────┬──────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2), -10} │ {reader.GetName(3), -10} │ {reader.GetName(4),-7} │ {reader.GetName(5),-8} │");
                    Console.WriteLine("\t├────┼─────────────────┼────────────┼────────────┼─────────┼──────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2), 10} │ " +
                            $"{reader.GetInt32(3), 10} │ {reader.GetInt32(4), 7:n2} │ {reader.GetInt32(5), 8} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴────────────┴────────────┴─────────┴──────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query01


        // 2. Хранимая процедура	
        //    Выбирает информацию о риэлторах, фамилия которых начинается
        //    с буквы «И» и процент вознаграждения больше 10%.
        //    Значения задавать параметрами запроса
        public void Query02(double percent = 10, string surname = "И") {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery02");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@percent", percent);
                cmd.Parameters.AddWithValue("@surname", surname);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬─────────────────┬─────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-15} │ {reader.GetName(3),-15} │ {reader.GetName(4),-7} │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼─────────────────┼─────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),-15} │ " +
                            $"{reader.GetString(3),-15} │ {reader.GetDouble(4),7:n2} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴─────────────────┴─────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query02


        // 3. Хранимая процедура	
        //    Выбирает информацию об 1-комнатных квартирах, цена на которых
        //    находится в диапазоне от 900 000 руб. до 1000 000 руб.
        //    Значения задавать параметрами запроса
        public void Query03(int roomNum = 1, int lo = 900_000, int hi = 1_000_000) {
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery03");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬────────────┬────────────┬───────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-10} │ {reader.GetName(3),-10} │ {reader.GetName(4),-5} │ {reader.GetName(5),-10} │ {reader.GetName(6),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼────────────┼────────────┼───────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),10} │ " +
                            $"{reader.GetInt32(3),10} │ {reader.GetInt32(4),5:n2} │ {reader.GetInt32(5),10} │ {reader.GetInt32(6),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴────────────┴────────────┴───────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query03


        // 4. Хранимая процедура
        //    Выбирает информацию о квартирах с заданным числом комнат.
        //    Значения задавать параметрами запроса
        public void Query04(int roomNum) {
            Console.WriteLine($"\nЗаданное число комнат:{roomNum}");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery04");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬────────────┬────────────┬──────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-10} │ {reader.GetName(3),-10} │ {reader.GetName(4),-8} │ {reader.GetName(5),-10} │ {reader.GetName(6),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼────────────┼────────────┼──────────┼────────────┼────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),10} │ " +
                            $"{reader.GetInt32(3),10} │ {reader.GetInt32(4),8:n2} │ {reader.GetInt32(5),10} │ {reader.GetInt32(6),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴────────────┴────────────┴──────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query04


        // 5. Хранимая процедура	
        //    Выбирает информацию обо всех 2-комнатных квартирах,
        //    площадь которых есть значение из некоторого диапазона.
        //    Значения задавать параметрами запроса
        public void Query05(int roomNum = 2, int lo = 80, int hi = 120) {
            Console.WriteLine($"\nЗаданный диапазон: от {lo:n2} до {hi:n2}");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery05");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNum);
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬────────────┬────────────┬───────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-10} │ {reader.GetName(3),-10} │ {reader.GetName(4),-5} │ {reader.GetName(5),-10} │ {reader.GetName(6),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼────────────┼────────────┼───────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),10} │ " +
                            $"{reader.GetInt32(3),10} │ {reader.GetInt32(4),5:n2} │ {reader.GetInt32(5),10} │ {reader.GetInt32(6),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴────────────┴────────────┴───────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query05


        // 6. Хранимая процедура	
        //    Вычисляет для каждой оформленной сделки размер комиссионного
        //    вознаграждения риэлтора.
        //    Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора,
        //    Дата сделки, Цена квартиры, Комиссионные.
        //    Сортировка по полю Дата сделки
        public void Query06() {

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery06");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌─────────────────┬─────────────────┬─────────────────┬────────────┬─────────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-15} │ " +
                        $"{reader.GetName(1),-15} │ {reader.GetName(2),-15} │ {reader.GetName(3),-10} │ {reader.GetName(4),-15} │ {reader.GetName(5),-10} │ {reader.GetName(6),-10} │");
                    Console.WriteLine("\t├─────────────────┼─────────────────┼─────────────────┼────────────┼─────────────────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-15} │ {reader.GetString(1),-15} │ " +
                            $"{reader.GetString(2),-15} │ {reader.GetDateTime(3),10:dd/MM/yyyy} │ " +
                            $"{reader.GetInt32(4),15:n2} │ {reader.GetDouble(5),10:n2} │ {reader.GetDouble(6),10:n2} │");
                    } // while
                    Console.WriteLine("\t└─────────────────┴─────────────────┴─────────────────┴────────────┴─────────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query06


        // 7. Хранимая процедура	
        //    Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки
        //    и сумму сделок риэлтора. Упорядочить выборку по убыванию суммы сделок.
        public void Query07() {

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery07");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬─────────────────┬──────────────┬──────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)} │ {reader.GetName(1),-15} │ " +
                        $"{reader.GetName(2),-15} │ {reader.GetName(3),-15} │ {reader.GetName(4),-12} │ {reader.GetName(5),-12} │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼─────────────────┼──────────────┼──────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2} │ " +
                            $"{reader.GetString(1),-15} │ {reader.GetString(2),-15} │ " +
                            $"{reader.GetString(3),-15} │ {reader.GetInt32(4),12} │ {reader.GetInt32(5), 12:n2} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴─────────────────┴──────────────┴──────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query07


        // 8. Хранимая процедура	
        //    Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
        public void Query08() {

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery08");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌───────────────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-17} │ {reader.GetName(1),-15} │");
                    Console.WriteLine("\t├───────────────────┼─────────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-17} │ {reader.GetInt32(1), 15:n2} │");
                    } // while
                    Console.WriteLine("\t└───────────────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query08


        // 9. Хранимая процедура	
        //    Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку
        //    по убыванию суммы сделки. Диапазон задавать параметрами запроса
        // {reader.GetDateTime(3),10:dd/MM/yyyy}
        public void Query09(DateTime from, DateTime to) {
            Console.WriteLine($"\nЗаданный диапазон: c {from,10:dd/MM/yyyy} до {to,10:dd/MM/yyyy}");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"ProcQuery09");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to", to);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌───────────────────┬────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-17} │ {reader.GetName(1),-6} │ {reader.GetName(2),-15} │");
                    Console.WriteLine("\t├───────────────────┼────────┼─────────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-17} │ {reader.GetInt32(1),6} │ {reader.GetInt32(2), 15:n2} │");
                    } // while
                    Console.WriteLine("\t└───────────────────┴────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query09
    }
}
