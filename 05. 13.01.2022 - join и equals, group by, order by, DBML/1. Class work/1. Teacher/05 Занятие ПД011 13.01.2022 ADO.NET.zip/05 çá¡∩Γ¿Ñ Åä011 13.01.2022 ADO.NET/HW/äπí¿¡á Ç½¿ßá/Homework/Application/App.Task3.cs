﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;

namespace Homework.Application
{
    /* 
    * Методы для решения задачи 3
    */
    internal partial class App {

        // Товары с заданным диапазоном цен
        public void ExecGoodsInRange() {
            Utils.ShowNavBarTask("    Товары с заданным диапазоном цен");

            // генерация диапазона
            int lo = Utils.Random.Next(2, 60);
            int hi = lo + Utils.Random.Next(60, 1000);

            _goodsController.GoodsInRange(lo *10, hi *10);
        } // ExecGoodsInRange

        // Cумма товаров с заданным годом выпуска
        public void ExecGoodsByYear() {
            Utils.ShowNavBarTask("    Cумма товаров с заданным годом выпуска");

            int index = Utils.Random.Next(0, Utils.seeds.Length - 1);

            _goodsController.GoodsByYear(DateTime.Now.Year - Utils.seeds[index].old);
        } // ExecGoodsByYear

        // Cумма товаров с заданным наименованием
        public void ExecGoodsByName() {
            Utils.ShowNavBarTask("    Cумма товаров с заданным наименованием");

            int index = Utils.Random.Next(0, Utils.seeds.Length - 1);

            _goodsController.GoodsByName(Utils.seeds[index].Name);
        } // ExecGoodsByName

        // наименование и год выпуска товаров с максимальным количеством
        public void ExecMaxNumberGoods() {
            Utils.ShowNavBarTask("    Наименование и год выпуска товаров с максимальным количеством");

            _goodsController.MaxNomberGoods();
        } // ExecMaxNumberGoods

        // Tовары, для которых произведение цены на количество находится в заданном диапазоне
        public void ExecGoodsPriceInRange() {
            Utils.ShowNavBarTask("    Tовары, для которых произведение цены на количество находится в заданном диапазоне");

            // генерация диапазона
            int lo = Utils.Random.Next(4, 60);
            int hi = lo + Utils.Random.Next(100, 1000);

            _goodsController.GoodsPriceInRange(lo * 10, hi * 10);
        } // ExecGoodsPriceInRange

    } // App
}
