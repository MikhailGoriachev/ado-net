﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W5AdoLINQtoSQL.Models.Task1
{
    // Kласс Автор:
    // *идентификатор,
    // *фамилия и инициалы,
    // *год рождения
    public class Author
    {
        // идентификатор
        private int _id;
        public int Id
        {
            get => _id;
            set
            {
                if (value < 0)
                    throw new ArgumentException($"Author: Недопустимое значение индентификатора автора: {value}");
                _id = value;
            }
        }// Id


        // фамилия и инициалы
        private string _fullNameAuthor;
        public string FullNameAuthor
        {
            get => _fullNameAuthor;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Author: Не верно задано ФИО автора или задано пустой строкой");
                _fullNameAuthor = value;
            }
        }// FullNameAuthor


        // год рождения
        private int _yearOfBirth;
        public int YearOfBirth
        {
            get => _yearOfBirth;
            set
            {
                if (value > DateTime.Now.Year)
                    throw new ArgumentException($"Author: Недопустимое значение года рождения автора: {value}");
                _yearOfBirth = value;
            }
        }// YearOfBirth


        // конструкторы
        public Author():this(0, "Лора Хилленбранд", 1967) { }
        public Author(int id, string fullname, int year)
        {
            Id             = id;
            FullNameAuthor = fullname;
            YearOfBirth    = year;
        }// Author


        // для вывода данных о авторе в строковом формате
        public override string ToString() =>
            $"{Id,5} : автор {FullNameAuthor,-20}, {YearOfBirth, 10}года рождения";

    }// class Author
}
