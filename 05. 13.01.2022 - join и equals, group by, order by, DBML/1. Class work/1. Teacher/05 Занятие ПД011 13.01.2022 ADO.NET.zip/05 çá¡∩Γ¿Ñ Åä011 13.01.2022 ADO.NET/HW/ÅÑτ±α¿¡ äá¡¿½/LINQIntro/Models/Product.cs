﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQIntro.Models
{
    public class Product
    {
        // Класс, представляющий товар 
        public string Name { get; set; } // наименование товара

        public int Price { get; set; }  // цена товара 

        public int Number { get; set; } // количество товаров 

        public int YearOfManufacture { get; set; }  //год выпуска

        public string ToTableRow() =>
            $" \t|{Name,-26} |{Price, 12} |{Number, 15} | {YearOfManufacture, 17} |";

        public static string Header =>
            "\t┌───────────────────────────┬─────────────┬────────────────┬───────────────────┐\n" +
            "\t│ Наименование Товара       │    Цена     │ Количество     │ Год выпуска       │\n" +
            "\t├───────────────────────────┼─────────────┼────────────────┼───────────────────┤";
        // Подвал таблицы
        public static string Footer =>
            "\t└───────────────────────────┴─────────────┴────────────────┴───────────────────┘";

    }
}
