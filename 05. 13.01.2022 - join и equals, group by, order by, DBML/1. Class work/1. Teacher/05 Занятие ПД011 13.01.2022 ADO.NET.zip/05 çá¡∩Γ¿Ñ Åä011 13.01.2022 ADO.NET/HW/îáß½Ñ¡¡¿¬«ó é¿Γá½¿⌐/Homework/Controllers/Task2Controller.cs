﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Controllers
{
	public class Task2Controller
	{

		public void Item1(double[] arr, double from, double to)
		{
			Console.WriteLine($"\n\n  Количество элементов массива, со значениями в диапазоне от {from:F2} до {to:F2}.\n");


			Console.WriteLine("  Расширяющие методы:  " + 
			                  $"{arr.Count(x => x >= from && x <= to)}");

			var linq =
				(from x in arr
				where x >= @from && x <= to
				select x).Count();

			Console.WriteLine($"  LINQ: {linq}");
		}

		public void Item2(double[] arr)
		{
			Console.WriteLine($"\n\n  Кол-во элеметов массива, равных нулю.\n");


			Console.WriteLine("  Расширяющие методы:  " +
			                  $"{arr.Count(x => Math.Abs(x) < 1e-6  )}");

			var linq =
				(from x in arr
					where Math.Abs(x) < 1e-6
				 select x).Count();

			Console.WriteLine($"  LINQ: {linq}");
		}

		public void Item3(double[] arr)
		{
			var max = arr.Max();

			Console.WriteLine($"\n\n  Сумма элементов массива, расположенных после первого максимального элемента ({max:F2}).\n");

			var result = 
				arr.SkipWhile(x => Math.Abs(x - max) > 1e-6 ) 
				.Skip(1)
				.Sum();

			Console.WriteLine($"  Расширяющие методы: {result:F2}");

			result =
				(from x in arr
					select x)
				.SkipWhile(x => x < max)
				.Skip(1)
				.Sum();

			Console.WriteLine($"  LINQ: {result:F2}");
		}

		public void Item4(double[] arr)
		{
			var min = arr.Min(Math.Abs);

			Console.WriteLine($"\n\n  Сумма элементов массива, расположенных перед последним минимальным по модулю элементом ({min:F2}).\n");

			
			var result = 
				arr.Reverse()
				.SkipWhile(x => (Math.Abs(x) - min) > 1e-6)
				.Skip(1)
				.Sum();
			
			Console.WriteLine($"  Расширяющие методы: {result:F2}");

			result =
				(from x in arr
					select x)
				.Reverse()
				.SkipWhile(x => (Math.Abs(x) - min) > 1e-6)
				.Skip(1)
				.Sum();

			Console.WriteLine($"  LINQ: {result:F2}");
		}

	}
}
