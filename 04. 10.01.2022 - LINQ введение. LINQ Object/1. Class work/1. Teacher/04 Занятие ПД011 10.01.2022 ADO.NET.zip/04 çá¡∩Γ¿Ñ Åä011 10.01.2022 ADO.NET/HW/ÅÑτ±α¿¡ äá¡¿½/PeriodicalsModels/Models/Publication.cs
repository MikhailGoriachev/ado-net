﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeriodicalsModels.Models
{
    public class Publication
    {
        public int Id { get; set; }
        public string PubIndex { get; set; }
        public string PubType { get; set; }
        public string Title { get; set; }
        public int Price { get; set; }

        public string ToTableRow() =>
            $"\t | {Id, 3} | {PubIndex, 15} | {Title, 35} | {Price, 5} |";
    }
}
