﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqIntro.Helpers;
using LinqIntro.Models;

namespace LinqIntro.Controllers
{
    /*
     * Решение задачи 3
     */
    public class Task3Controller
    {
        private List<Goods> _goodses;

        public Task3Controller():this(new List<Goods>()) {
            Initializer();
        } // Task3Controller

        public Task3Controller(List<Goods> goodses) {
            _goodses = goodses;
        } // Task3Controller


        // Инициализация коллекции товаров
        public void Initializer() => _goodses = Utils.ListGoods();

        // Вывод коллекции товаров в консоль
        public void ShowGoods(string caption) =>
            Console.WriteLine($"{Utils.ToTable(_goodses)}");


        #region Запросы к коллекции объектов - решение задачи 3

        // товары с заданным диапазоном цен - синтаксис LINQ
        public List<Goods> Query01A(double fromPrice, double toPrice) => (
           from
               goods in _goodses
           where
               goods.Price >= fromPrice && goods.Price <= toPrice
           select
               goods)
            .ToList();

        // товары с заданным диапазоном цен - расширяющие методы
        public List<Goods> Query01B(double fromPrice, double toPrice) => _goodses
            .Where(g => g.Price >= fromPrice && g.Price <= toPrice)
            .ToList();

        // сумма товаров с заданным годом выпуска - синтаксис LINQ
        public double Query02A(int year) {
            // отбор данных по заданию
            var query = 
                from 
                    goods in _goodses 
                where 
                    goods.Year == year
                select
                    goods;

            // суммирование по отобранным данным
            return query.Sum(g => g.Price * g.Amount);
        } // Query02A

        // сумма товаров с заданным годом выпуска - расширяющие методы
        public double Query02B(int year) => _goodses
            .Where(g => g.Year == year)
            .Sum(g => g.Price * g.Amount);

        // Выборка товаров с заданным годом выпуска, для вывода этой
        // выборки в консоль
        public List<Goods> GoodsWhereYear(int year) => _goodses
            .Where(g => g.Year == year)
            .ToList();

        // сумма товаров с заданным наименованием - синтаксис LINQ
        public double Query03A(string nameGoods) =>  (
            // отбор данных по заданию
            from
                goods in _goodses
            where
                goods.GoodsName.ToLower().Contains(nameGoods.ToLower())
            select
                goods)
            .Sum(g => g.Price * g.Amount); // суммирование по отобранным данным

        // сумма товаров с заданным наименованием - расширяющие методы
        public double Query03B(string nameGoods) => _goodses
            .Where(g => g.GoodsName.ToLower().Contains(nameGoods.ToLower()))
            .Sum(g => g.Price * g.Amount);

        // Выборка товаров с заданным наименованием, вывод этой
        // выборки в консоль
        public List<Goods> GoodsWhereName(string nameGoods) => _goodses
            .Where(g => g.GoodsName.ToLower().Contains(nameGoods.ToLower()))
            .ToList();


        // наименование и год выпуска товаров с максимальным количеством - синтаксис LINQ
        /*
         * select
         *    GoodsName
         *    , Amount
         * from
         *    Goodses
         * having
         *    Amount = Max(Goodese.Amount)
         *
         */
        public List<ResultQuery04> Query04A() => (
            from goods in _goodses
                let max = _goodses.Max(g => g.Amount)
                where goods.Amount == max
                select new ResultQuery04 {GoodsName = goods.GoodsName, Year = goods.Year})
            .ToList();


        // наименование и год выпуска товаров с максимальным количеством - расширяющие методы
        public List<ResultQuery04> Query04B() {
            int max = _goodses.Max(t => t.Amount);
            var query = _goodses
                .Where(g => g.Amount == max)
                .Select(g => new ResultQuery04 {GoodsName = g.GoodsName, Year = g.Year});
            return query.ToList();
        } // Query04B


        // все товары, для которых произведение цены на количество находится в
        // заданном диапазоне  - синтаксис LINQ
        public List<Goods> Query05A(double @from, double to) => (
            from 
                goods in _goodses
            where 
                goods.Price * goods.Amount >= @from && goods.Price * goods.Amount <= to
            select 
                goods).ToList();


        // все товары, для которых произведение цены на количество находится в
        // заданном диапазоне  - расширяющие методы
        public List<Goods> Query05B(double from, double to) => _goodses
            .Where(g => g.Price * g.Amount >= from && g.Price * g.Amount <= to)
            .ToList();
   

        // --------------------------------------------------------------------------------


        // вывод результатов запроса 4 в табличном виде
        public void ShowQuery04(List<ResultQuery04> query) {
            Console.WriteLine(
                "\n\n\tНаименование и год выпуска товаров с\n" +
                $"\tмаксимальным количеством ({_goodses.Max(g => g.Amount)} шт.)\n" +
                "\t┌───────┬──────────────────────────┬─────────────┐\n" +
                "\t│ Номер │ Наименование товара      │ Год выпуска │\n" +
                "\t├───────┼──────────────────────────┼─────────────┤");
            int i = 0;
            foreach (var item in query) {
                Console.WriteLine($"\t│ {++i,5} │ {item.GoodsName,-24} │ {item.Year,11} │");
            } // foreach

            Console.WriteLine("\t└───────┴──────────────────────────┴─────────────┘\n");
        } // ShowQuery04
        #endregion


        // получение случайного наименования товара из коллекции
        public string GetRandomName() {
            var names = _goodses
                .Select(g => g.GoodsName) // проекция на коллекцию строк с наименованием товаров
                .Distinct()                    // получить различные значения
                .ToArray();

            return names[Utils.GetRandom(0, names.Length-1)];
        } // GetRandomName

    } // class Task3Controller
}
