﻿-- База данных «Учет подписки на периодические печатные издания»

-- вывод всех таблиц с рашифровкой полей связанных таблиц
select
   *
from
    PubTypes;
go

select
    *
from
    Streets;
go

-- подписчики с расшифровкой
select
    Subscribers.Id
    , Subscribers.Surname
    , Subscribers.[Name]
    , Subscribers.Patronymic
    , Subscribers.Passport
    , Streets.Street
    , Subscribers.Building
    , Subscribers.Flat
from
    Subscribers join Streets on Subscribers.IdStreet = Streets.Id;
go

-- издания с расшифровкой
select
    Publications.Id
    , PubTypes.PubType
    , Publications.PubIndex
    , Publications.Title
    , Publications.Price
from 
    Publications join PubTypes on Publications.IdPubType = PubTypes.Id;
go

-- доставки с расшифровкой
select
    Deliveries.Id
    , PubTypes.PubType
    , Publications.PubIndex
    , Publications.Title
    , Publications.Price
    , Subscribers.Surname
    , Subscribers.[Name]
    , Subscribers.Patronymic
    , Subscribers.Passport
    , Streets.Street
    , Subscribers.Building
    , Subscribers.Flat
    , Deliveries.DateStart
    , Deliveries.Duration
from
    Deliveries join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id) 
                    on Deliveries.IdPublication = Publications.Id
               join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
                    on Deliveries.IdSubscriber = Subscribers.Id;
go


-- Выполнение запросов по заданию

-- 01 Запрос с параметром	
-- Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях 
-- заданного типа, стоимость 1 экземпляра для которых меньше заданной
declare @pubType nvarchar(30) = N'журнал', @price int = 250;

exec ProcQuery01 @pubType, @price;
select
    Publications.Id
    , Publications.PubIndex
    , PubTypes.PubType
    , Publications.Title
    , Publications.Price
from 
    Publications join PubTypes on Publications.IdPubType = PubTypes.Id
where
    PubTypes.PubType = @pubType and Publications.Price < @price
go


-- 02 Запрос с параметром	
-- Выбирает из таблиц информацию о подписчиках, проживающих на заданной 
-- параметром улице и номере дома, которые оформили подписку на издание 
-- с заданным параметром наименованием
declare @street nvarchar(30) = N'ул. Садовая', @building nvarchar(10) = N'118', 
        @title nvarchar(80) = N'Юный техник';

exec ProcQuery02 @street, @building, @title

select
    Deliveries.Id
    , Subscribers.Surname + N' ' + Substring(Subscribers.[Name], 1, 1) + N'.' + Substring(Subscribers.Patronymic, 1, 1) + N'.' as Subscriber 
    , Subscribers.Passport
    , Streets.Street + N',  д. ' + Subscribers.Building + N', кв. ' + LTrim(Str(Subscribers.Flat, 5)) as [Address] 
    , Publications.Title
from
    Deliveries join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) on Deliveries.IdSubscriber = Subscribers.Id
               join Publications on Deliveries.IdPublication = Publications.Id
where
    Streets.Street = @street and Subscribers.Building = @building and Publications.Title = @title;

select  -- с учетом вида издания
    Deliveries.Id
    , Subscribers.Surname + N' ' + Substring(Subscribers.[Name], 1, 1) + N'.' + Substring(Subscribers.Patronymic, 1, 1) + N'.' as Subscriber 
    , Subscribers.Passport
    , Streets.Street + N',  д. ' + Subscribers.Building + N', кв. ' + LTrim(Str(Subscribers.Flat, 5)) as [Address] 
    , PubTypes.PubType
    , Publications.Title
from
    Deliveries join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
                    on Deliveries.IdSubscriber = Subscribers.Id
               join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id) 
                    on Deliveries.IdPublication = Publications.Id
where
    Streets.Street = @street and Subscribers.Building = @building and Publications.Title = @title;
go


-- 03 Запрос с параметром	
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение
-- в поле Цена 1 экземпляра находится в заданном диапазоне значений
declare @loPrice int = 100, @hiPrice int = 150;
exec ProcQuery03 @loPrice, @hiPrice
select
    Publications.Id
    , PubTypes.PubType
    , Publications.PubIndex
    , Publications.Title
    , Publications.Price
from 
    Publications join PubTypes on Publications.IdPubType = PubTypes.Id
where
    Publications.Price between @loPrice and @hiPrice;
go


-- 04 Запрос с параметром	
-- Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный 
-- параметром тип издания
declare @pubType nvarchar(30) = N'газета';
exec ProcQuery04 @pubType;
select
    Deliveries.Id
    , Subscribers.Surname + N' ' + Substring(Subscribers.[Name], 1, 1) + N'.' + Substring(Subscribers.Patronymic, 1, 1) + N'.' as Subscriber 
    , Subscribers.Passport
    , Streets.Street + N',  д. ' + Subscribers.Building + N', кв. ' + LTrim(Str(Subscribers.Flat, 5)) as [Address] 
    , PubTypes.PubType
    , Publications.Title
from
    Deliveries join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
                    on Deliveries.IdSubscriber = Subscribers.Id
               join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id) 
                    on Deliveries.IdPublication = Publications.Id
where
    PubTypes.PubType = @pubType;
go


-- 05 Запрос с параметром	
-- Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКИ информацию обо всех оформленных 
-- подписках, для которых срок подписки есть значение из некоторого диапазона. 
-- Нижняя и верхняя границы диапазона задаются при выполнении запроса
declare @loDuration int = 3, @hiDuration int = 4;
exec ProcQuery05 @loDuration, @hiDuration;

select
    Deliveries.Id
    , PubTypes.PubType
    , Publications.Title
    , Deliveries.Duration
    , Deliveries.DateStart
from
    Deliveries join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id) 
                    on Deliveries.IdPublication = Publications.Id
where
    Deliveries.Duration between @loDuration and @hiDuration;

-- запрос расширяем данными о подписчике
select
    Deliveries.Id
   , Subscribers.Surname + N' ' + Substring(Subscribers.[Name], 1, 1) + N'.' + Substring(Subscribers.Patronymic, 1, 1) + N'.' as Subscriber 
    , Subscribers.Passport
    , Streets.Street + N',  д. ' + Subscribers.Building + N', кв. ' + LTrim(Str(Subscribers.Flat, 5)) as [Address] 
    , PubTypes.PubType
    , Publications.Title
    , Deliveries.Duration
    , Deliveries.DateStart
from
    Deliveries join (Subscribers join Streets on Subscribers.IdStreet = Streets.Id) 
                    on Deliveries.IdSubscriber = Subscribers.Id
               join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id) 
                    on Deliveries.IdPublication = Publications.Id
where
    Deliveries.Duration between @loDuration and @hiDuration;
go


-- 06 Запрос с вычисляемыми полями	
-- Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС 
-- Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата 
-- начала подписки, Срок подписки, Стоимость подписки без НДС. Сортировка по 
-- полю Индекс издания
exec ProcQuery06;

select
    Deliveries.Id
    , Publications.PubIndex
    , Publications.Title
    , Publications.Price
    , Deliveries.DateStart
    , Deliveries.Duration
    -- стоимость подписки с доставкой (1%) и без НДС 
    , 1.01 * (Publications.Price * Deliveries.Duration) as SubscribeCost
from
    Deliveries join (Publications join PubTypes on Publications.IdPubType = PubTypes.Id) 
                    on Deliveries.IdPublication = Publications.Id
order by
    Publications.PubIndex;
go


-- 07 Итоговый запрос	
-- Выполняет группировку по полю Вид издания. Для каждого вида вычисляет 
-- максимальную и минимальную цену 1 экземпляра
exec ProcQuery07
select
    PubTypes.PubType
    , Count(Publications.Id) as TotalPubType
    , Max(Publications.Price) as MaxPrice
    , Min(Publications.Price) as MinPrice
from
    Publications join PubTypes on Publications.IdPubType = PubTypes.Id
group by
    PubTypes.PubType;
go


-- 08 Итоговый запрос с левым соединением	
-- Выполняет группировку по полю Улица. Для всех улиц вычисляет количество 
-- подписчиков, проживающих на данной улице (итоги по полю Код получателя)
exec ProcQuery08;

select
    Streets.Street
    , Count(Deliveries.IdSubscriber) as SubscriberAmount
from
    Streets left join (Subscribers join Deliveries on Subscribers.Id = Deliveries.IdSubscriber)
        on Streets.Id = Subscribers.IdStreet
group by
    Streets.Street;
go

-- 09 Итоговый запрос с левым соединением	
-- Для всех изданий выводит количество оформленных подписок
exec ProcQuery09;

select
    PubTypes.PubType
    , Count(Deliveries.Id) as DeliveriesAmount
from
    PubTypes left join (Deliveries join Publications on Deliveries.IdPublication = Publications.Id) 
                       on PubTypes.Id = Publications.IdPubType
group by
    PubTypes.PubType;
