﻿-- создание представления для квартир
drop view if exists ViewApartments;
go

create view ViewApartments as
select
    Apartments.Id as ApartmentId
    , Streets.Id           
    , Streets.Street            
    , HouseNumbers.HouseNumber  
    , ApartmentNumber           
    , Area		   
    , NumberRooms    
    , Price
from  
    Apartments join Streets on Apartments.IdStreet = Streets.Id
               join HouseNumbers on Apartments.IdHouseNumber = HouseNumbers.Id;
go

-- создание представления для владельцев квартир
drop view if exists ViewOwners;
go
create view ViewOwners as
select
    Owners.Id as OwnerId
    , Persons.Surname     as OwnerSurname
    , Persons.[Name]      as OwnerName
    , Persons.Patronymic  as OwnerPatronymic
    , Owners.Passport
    , ViewApartments.ApartmentNumber
    , ViewApartments.Area		   
    , ViewApartments.NumberRooms    
    , ViewApartments.Price         
    , ViewApartments.Street      
    , ViewApartments.HouseNumber 

from
    Owners join Persons on Owners.IdPerson = Persons.Id
           join ViewApartments on Owners.IdApartment = ViewApartments.ApartmentId; 
go

-- создание представления для риелторов
drop view if exists ViewRealtors;
go

create view ViewRealtors as
select
    Realtors.Id as RealtorId
    , Persons.Surname     as RealtorSurname
    , Persons.[Name]      as RealtorName
    , Persons.Patronymic  as RealtorPatronymic
    , Realtors.PercentageRemuneration
from
    Realtors join Persons on Realtors.IdPerson = Persons.Id;
go


-- создание представления для сделок
drop view if exists ViewTransactions
go

create view ViewTransactions as
select 
    Id as TransactionId 
    , ViewOwners.OwnerId    
    , ViewOwners.OwnerSurname    
    , ViewOwners.OwnerName       
    , ViewOwners.OwnerPatronymic 
    , ViewOwners.Passport
    , ViewOwners.ApartmentNumber
    , ViewOwners.Area		   
    , ViewOwners.NumberRooms    
    , ViewOwners.Price         
    , ViewOwners.Street      
    , ViewOwners.HouseNumber
    
    , ViewRealtors.RealtorId
    , ViewRealtors.RealtorSurname
    , ViewRealtors.RealtorName
    , ViewRealtors.RealtorPatronymic
    , ViewRealtors.PercentageRemuneration

    , Transactions.DateExecution
from
    Transactions join ViewOwners on Transactions.IdOwner = ViewOwners.OwnerId
                 join ViewRealtors on Transactions.IdRealtor = ViewRealtors.RealtorId
go