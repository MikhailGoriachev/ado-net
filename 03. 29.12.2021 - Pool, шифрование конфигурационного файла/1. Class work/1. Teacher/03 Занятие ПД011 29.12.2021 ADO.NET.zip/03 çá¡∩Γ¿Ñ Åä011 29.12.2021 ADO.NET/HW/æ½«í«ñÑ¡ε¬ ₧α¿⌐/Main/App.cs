﻿using Main.Utilities.Menu;


namespace Main
{
	public sealed class App : MenuWrapper
	{
		private readonly EstateAgencyMenu _estateAgencyMenu = new();
		private readonly CarRentingMenu _carRentingMenu = new();


		public App() =>
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Учет сделок с недвижимостью", _estateAgencyMenu.Run)
					{ IsSimpleInvoke = true },
				new MenuItem("Прокат автомобилей", _carRentingMenu.Run)
					{ IsSimpleInvoke = true }
			});
	}
}