﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeriodicalsModels.Models
{
    public class Subscriber
    {
        public int Id { get; set; }

        public string Subcriber { get; set; }  

        public string Passport { get; set; }

        public string Address { get; set; }

        public string Pubtype { get; set; }

        public string Title { get; set; }

        public string ToTableRow() =>
            $"\t | {Id,3} | {Subcriber, 16}| {Passport, 16}| {Address,33} | {Pubtype, 8} | {Title, 26}|";
    }
}
