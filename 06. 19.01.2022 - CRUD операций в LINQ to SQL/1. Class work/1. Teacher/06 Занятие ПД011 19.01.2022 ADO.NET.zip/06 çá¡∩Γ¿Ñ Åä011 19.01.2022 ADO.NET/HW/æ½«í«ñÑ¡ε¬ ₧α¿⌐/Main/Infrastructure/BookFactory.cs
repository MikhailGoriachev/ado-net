using System.Collections.Generic;
using Bogus;
using Main.Models;
using Main.Utilities;


namespace Main.Infrastructure
{
	public static class BookFactory
	{
		public static string Locale = "ru";


		private static readonly Faker<Book> BookFaker =
			new Faker<Book>(Locale)
				.RuleFor(a => a.Identifier, f => f.Random.AlphaNumeric(f.Random.Number(3, 7)).ToUpper())
				.RuleFor(a => a.Author, MakeAuthor)
				.RuleFor(a => a.Price, f => decimal.Parse(f.Commerce.Price()))
				.RuleFor(a => a.Published, f => f.Date.Past(5).Year)
				.RuleFor(a => a.Title, f => f.Lorem.Sentence(2, 1));


		private static readonly Faker<Author> AuthorFaker =
			new Faker<Author>(Locale)
				.RuleFor(a => a.Fullname, f => f.Person.FullName)
				.RuleFor(a => a.BornYear, f => f.Person.DateOfBirth.Year);


		public static Author MakeAuthor() =>
			AuthorFaker.Generate();


		public static List<Author> MakeMultipleAuthors(int count) =>
			AuthorFaker.Generate(count);
		
		
		public static Book MakeBook() =>
			BookFaker.Generate();
		
		
		public static List<Book> MakeMultipleBooks(int count) =>
			BookFaker.Generate(count);
	}
}