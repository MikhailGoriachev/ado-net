﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrainTickets.Helpers;

namespace TrainTickets.Models
{
    [DataContract]
    public class TrainCar {
        // кол-во купе в вагоне
        public const int CountCompartment = 9;

        private Utils.TrainCarType _type;
        [DataMember]
        public Utils.TrainCarType Type {
            get => _type;
            set => _type = value; 
        } // Type


        private int _number;
        [DataMember]
        public int Number { 
            get => _number;
            set {
                if (value <= 0)
                    throw new Exception("TrainCar: Некорректный номер вагона!");
                _number = value;
            } // set 
        } // Number

        // индексатор для доступа к массиву купе
        public Compartment this[int index] {
            get => _compartments[index];
            set => _compartments[index] = value;
        } // Compartment

        // номер последнего места
        public int LastNum { get; private set; }

        private Compartment[] _compartments;
        [DataMember]
        public Compartment[] Compartments {
            get => _compartments;
            set => _compartments = value;
        } // Compartments

        public TrainCar(Utils.TrainCarType type, int number, int lastPlaceNum) {
            _type = type;
            _number = number;
            Initialize(lastPlaceNum);
        } // Compartment

        public void Initialize(int lastPlaceNum) {
            _compartments = new Compartment[CountCompartment];
            for (int i = 0; i < _compartments.Length; i++) {
                _compartments[i] = new Compartment(_type, lastPlaceNum);
                lastPlaceNum = _compartments[i].Seats[(int)_type - 1].Number + 1;
            } // for i
            LastNum = _compartments[_compartments.Length - 1].LastNum;
        } // Initialize

        // кол-во проданных билетов
        public int CountSales() {
            int count = 0;
            for (int i = 0; i < _compartments.Length; i++)
                count += _compartments[i].CountSales();
            return count;
        } // CountSales

        // кол-во билетов
        public int Count() {
            int count = 0;
            for (int i = 0; i < _compartments.Length; i++)
                count += _compartments[i].Count();
            return count;
        } // Count

        // кол-во проданных билетов по типу
        public int CountSales(Utils.TrainCarType type) {
            if (_type != type) return 0;
            int count = 0;
            for (int i = 0; i < _compartments.Length; i++)
                count += _compartments[i].CountSales(type);
            return count;
        } // CountSales

        // кол-во билетов по типу
        public int Count(Utils.TrainCarType type) {
            if (_type != type) return 0;
            int count = 0;
            for (int i = 0; i < _compartments.Length; i++)
                count += _compartments[i].Count(type);
            return count;
        } // Count

    } // TrainCar
}
