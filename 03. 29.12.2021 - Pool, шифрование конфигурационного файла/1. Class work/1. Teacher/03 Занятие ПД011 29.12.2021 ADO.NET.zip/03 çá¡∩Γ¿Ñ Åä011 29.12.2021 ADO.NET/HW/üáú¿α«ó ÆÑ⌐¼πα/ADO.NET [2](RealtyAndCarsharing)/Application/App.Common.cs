﻿using System;
using ADO.NET__2__RealtyAndCarsharing_.Controllers;

namespace ADO.NET__2__RealtyAndCarsharing_.Application
{
    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    public partial class App
    {
        private Task1Controller _task1Controller1;
        private Task2Controller _task2Controller2;
       
        // конструктор по умолчанию
        public App(): this(new Task1Controller(), new Task2Controller()) { }
        public App(string connectingString): 
               this(new Task1Controller(connectingString), new Task2Controller(connectingString)) { }

        public App(Task1Controller task1Controller1, Task2Controller task2Controller2) {
            _task1Controller1 = task1Controller1;
            _task2Controller2 = task2Controller2;
        } // App

    } // class App
}