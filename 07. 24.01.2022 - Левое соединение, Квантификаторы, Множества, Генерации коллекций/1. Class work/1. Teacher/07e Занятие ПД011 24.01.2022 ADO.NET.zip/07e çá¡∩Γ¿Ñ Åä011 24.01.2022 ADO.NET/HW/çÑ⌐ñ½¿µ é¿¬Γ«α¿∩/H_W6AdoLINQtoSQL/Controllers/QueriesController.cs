﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W6AdoLINQtoSQL.Models;

namespace H_W6AdoLINQtoSQL.Controllers
{
    public class QueriesController
    {
        // связь с базой данных
        private WholesaleStoreDataContext _db;

        public QueriesController() : this(new WholesaleStoreDataContext()) { } 

        public QueriesController(WholesaleStoreDataContext db)
        {
            _db = db;
        } // QueriesController


        // Выбирает из таблицы ТОВАРЫ информацию о товарах,
        // единицей измерения которых является «шт» (штуки) и
        // цена закупки составляет меньше 100 руб. 
        public List<GoodsViewModel> Query01()=>
        _db.Purchases
            .Where(purchase => purchase.PricePurchase< 100 && purchase.Units.Short == "шт.")
            .Select(p => new GoodsViewModel
            {
                Name = p.Goods.Name,
                Amount = p.Amount,
                Short = p.Units.Short,
                PricePurchase = p.PricePurchase,
                DatePurchase = p.DatePurchase
            })
            .ToList();


        // Выбирает из таблицы ТОВАРЫ информацию о товарах,
        // цена закупки которых больше 140 руб. за единицу товара
        public List<GoodsViewModel> Query02() =>
          _db.Purchases
              .Where(purchase => purchase.PricePurchase > 140)
              .Select(p => new GoodsViewModel
              {
                 Name = p.Goods.Name,
                 Amount = p.Amount,
                 Short = p.Units.Short,
                 PricePurchase = p.PricePurchase,
                 DatePurchase = p.DatePurchase
              })
              .ToList();


        // Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием
        // (например, «чехол защитный»), для которых цена закупки меньше 200 руб.
        public List<GoodsViewModel> Query03() =>
            _db.Purchases
            .Where(purchase => purchase.Goods.Name == "Кофе NESCAFE Классик растворимый" && purchase.PricePurchase < 200)
            .Select(p => new GoodsViewModel
            {
                 Name = p.Goods.Name,
                 Amount = p.Amount,
                 Short = p.Units.Short,
                 PricePurchase = p.PricePurchase,
                 DatePurchase = p.DatePurchase
            })
            .ToList();


        // Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах
        // с заданным значением процента комиссионных. 
        public List<SellerViewModel> Query04() =>
            _db.Sellers
            .Where(seller => seller.Interest == 4)
            .Select(p => new SellerViewModel
            {
                Surname = p.Surname,
                NameSeller = p.NameSeller,
                Patronymic = p.Patronymic,
                Interest = p.Interest

            })
            .ToList();


        // Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех
        // зафиксированных фактах продажи товаров (Наименование товара, Цена закупки,
        // Цена продажи, дата продажи),
        // для которых Цена продажи оказалась в некоторых заданных границах.         
        public List<AllSalesViewModel> Query05() =>
            _db.Sales
            .Where(sale => sale.PriceSale >= 150 && sale.PriceSale <= 300)
            .Select(s => new AllSalesViewModel
            {
                Name = s.Purchases.Goods.Name,
                PricePurchase = s.Purchases.PricePurchase,
                PriceSale = s.PriceSale,
                DateSale = s.DateSale
            })
            .ToList();


        // Вычисляет прибыль от продажи за каждый проданный товар.
        // Включает поля Дата продажи, Наименование товара,
        // Цена закупки, Цена продажи, Количество проданных единиц,
        // Прибыль. Сортировка по полю Наименование товара
        public List<SaleViewModel> Query06() =>
            _db.Sales
            .Select(s => new SaleViewModel
            {
                DateSale = s.DateSale,
                Name = s.Purchases.Goods.Name,
                PricePurchase = s.Purchases.PricePurchase,
                PriceSale = s.PriceSale,
                AmountSale = s.AmountSale,
                Profit = (s.AmountSale - s.PriceSale) * -s.AmountSale
            })
            .OrderBy(good => good.Name)
            .ToList();


        // Выполняет группировку по полю Наименование товара.
        // Для каждого наименования вычисляет среднюю цену закупки товара,
        // количество закупок        
        public List<CalculationViewModel> Query07() =>
            _db.Purchases
            .GroupBy(p => p.Goods.Name, (key, group) => new CalculationViewModel
            {
                Name = key,
                AvgPricepurchase = (int)group.Average(p => p.PricePurchase),
                AmountPurchase = group.Count()               
            })
            .Select(p => new CalculationViewModel
            {
                Name = p.Name,
                AvgPricepurchase = p.AvgPricepurchase,
                AmountPurchase = p.AmountPurchase
            })
            .OrderBy(good => good.Name)
            .ToList();


        // Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ.
        // Для каждого продавца вычисляет среднее значение по полю Цена
        // продажи единицы товара, количество продаж      
        public List<CalculateSellesViewModel> Query08() =>
            _db.Sales
            .GroupBy(s => s.Sellers.Id, (key, group) => new CalculateSellesViewModel
            {
                IdSeller = key,
                SalesAmount = group.Count(),
                AvgPrice = (int)group.Average(s => s.PriceSale),
                //Surname = group.Select(s => s.Sellers.Surname)
            })
            .Select(s => new CalculateSellesViewModel
            {
                IdSeller = s.IdSeller,
                Surname = s.Surname,
                NameSeller = s.NameSeller,
                Patronymic = s.Patronymic,
                Interest = s.Interest,
                SalesAmount = s.SalesAmount,
                AvgPrice = s.AvgPrice
            })
            .ToList();
        

    }// class QueriesController
}
