﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigSecurityModels.Models
{
    // данные оформленной подписки, в т.ч. данные о подписчике
    public class Delivery
    {
        public int DeliveryId { get; set; }

        // Индекс по каталогу подписных изданий 
        public string PubIndex { get; set; }

        // Тип издания
        public string PubType { get; set; }

        // Название издания
        public string Title { get; set; }

        // Стоимость 1 экземпляра
        public int Price { get; set; }

        // фамилия подписчика
        public string Surname { get; set; }
        
        // имя подписчика
        public string Name { get; set; }
        
        // отчество подписчика
        public string Patronymic { get; set; }
        
        // серия и номер паспорта 
        public string Passport { get; set; }
        
        // улица
        public string Street { get; set; }
        
        // номер дома
        public string Building { get; set; }
        
        // номер квартиры
        public int Flat { get; set; }

        // дата начала подписки
        public DateTime DateStart { get; set; }

        // длительность подписки
        public int Duration { get; set; }


        // Для вывода данных о подписчике в табличном формате
        public static string HeaderSubscriber =>
            "\t┌───────┬────────┬────────────────┬────────────────┬────────────────┬──────────────┬────────────────┬──────┬──────────┬─────────────┬──────────────────────────────────┐\n" +
            "\t│ # п/п │ Идент. │ Фамилия        │ Имя            │ Отчество       │ Паспорт      │ Улица          │ Дом  │ Квартира │ Тип издания │ Название издания                 │\n" +
            "\t├───────┼────────┼────────────────┼────────────────┼────────────────┼──────────────┼────────────────┼──────┼──────────┼─────────────┼──────────────────────────────────┤";
        
        public string ToTableRowSubscriber(int row) =>
            $"\t│ {row,5} │ {DeliveryId,6} │ {Surname,-14} │ {Name, -14} │ {Patronymic, -14} " +
            $"│ {Passport, -14} │ {Street, -20} │ {Building, -12} │ {Flat, 12} │ {PubType,-11} " +
            $"│ {Title,-32} │";

        public static string FooterSubscriber =>
            "\t└───────┴────────┴────────────────┴────────────────┴────────────────┴──────────────┴────────────────┴──────┴──────────┴─────────────┴──────────────────────────────────┘";


        // Для вывода данных об оформленной подписке в табличном формате
        public static string HeaderDelivery =>
            "\t┌───────┬────────┬────────────────┬─────────────┬──────────────────────────────────┬───────────────────┐\n" +
            "\t│ # п/п │ Идент. │ Индекс издания │ Тип издания │ Название издания                 │ 1 экз., руб./мес. │\n" +
            "\t├───────┼────────┼────────────────┼─────────────┼──────────────────────────────────┼───────────────────┤";
        public string ToTableRowDelivery(int row) =>
            $"\t│ {row,5} │ {DeliveryId,6} │ {PubIndex,-14} │ {PubType,-11} │ {Title,-32} │ {Price,17:n2} │";
        public static string FooterDelivery =>
            "\t└───────┴────────┴────────────────┴─────────────┴──────────────────────────────────┴───────────────────┘";
    } // class Delivery
}
