﻿using Homework.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
    class GoodsController
    {
        // коллекция товаров
        private List<Good> _goods;

        public GoodsController() : this(new List<Good>()) { }
        public GoodsController(List<Good> goods) {
            _goods = goods;
            Initialize();
        } // GoodsController

        // формирование массивa
        public void Initialize(int n = 12) {
            _goods.Clear();
            // заполнить коллекцию товаров новым набором данных
            for (int i = 0; i < n; i++) {
                int k = Utils.Random.Next(0, Utils.seeds.Length - 1);
                _goods.Add(new Good {
                    Name = Utils.seeds[k].Name,
                    Price = Utils.seeds[k].Price,
                    Number = Utils.Random.Next(1, 5),
                    Year = DateTime.Now.Year - Utils.seeds[k].old
                });
            } // for i
        } // Initialize



        // вывод коллекции
        public void Show(string title, List<Good> goods) {
            Console.WriteLine($"    {title}");

            Console.WriteLine(Good.Header());

            int i = 1;
            goods.ForEach(item => Console.WriteLine(item.ToTableRow(i++)));

            Console.WriteLine(Good.Footer());
        } // Show
        public void Show(string title) => Show(title, _goods);

        // Демонстрация работы расширяющего метода
        public void ShowPercent(string title) {
            Console.WriteLine($"    {title}");

            Console.WriteLine($"{Good.Header()}    Процент скидки");

            int i = 1;
            _goods.ForEach(item => Console.WriteLine($"{item.ToTableRow(i++)}  ->       {item.Percent()} %"));

            Console.WriteLine(Good.Footer());
        } // Show



        // товары с заданным диапазоном цен
        public void GoodsInRange(int lo, int hi) {
            Console.WriteLine($"\n    Диапазон: от {lo:f2} до {hi:f2}");

            List<Good> selected;

            #region в синтаксисе LINQ
            /*
            var query =
                from x in _goods
                where lo <= x.Price && x.Price <= hi
                select x;

            selected = query.ToList();
            */
            #endregion

            // в синтаксисе расширяющих методов
            selected = _goods.Where(x => lo <= x.Price && x.Price <= hi).ToList();

            Show("Выбранные товары:", selected);
        } // GoodsInRange

        // сумма товаров с заданным годом выпуска
        public void GoodsByYear(int year) {
            Console.WriteLine($"\n    Заданный год: {year}");

            List<Good> selected;
            int sum;

            #region в синтаксисе LINQ
            /*
            var query =
                from x in _goods
                where x.Year == year
                select x;

            selected = query.ToList();
            */
            #endregion

            // в синтаксисе расширяющих методов
            selected = _goods.Where(x => x.Year == year).ToList();

            sum = selected.Sum(x => x.Price * x.Number);

            Show("Выбранные товары:", selected);
            Console.WriteLine($"    Cумма товаров: {sum}");
        } // GoodsInRange

        // сумма товаров с заданным наименованием
        public void GoodsByName(string name) {
            Console.WriteLine($"\n    Заданное наименование: {name}");

            List<Good> selected;
            int sum;

            #region в синтаксисе LINQ
            /*
            var query =
                from x in _goods
                where x.Name.Contains(name)
                select x;

            selected = query.ToList();
            */
            #endregion

            // в синтаксисе расширяющих методов
            selected = _goods.Where(x => x.Name.Contains(name)).ToList();

            sum = selected.Sum(x => x.Price * x.Number);

            Show("Выбранные товары:", selected);
            Console.WriteLine($"    Cумма товаров: {sum}");
        } // GoodsInRange

        // наименование и год выпуска товаров с максимальным количеством
        public void MaxNomberGoods() {
            List<Good> selected;
            int num = _goods.Max(x => x.Number);

            #region в синтаксисе LINQ
            /*
            var query =
                from x in _goods
                where x.Number == num
                select x;

            selected = query.ToList();
            */
            #endregion

            // в синтаксисе расширяющих методов
            selected = _goods.Where(x => x.Number == num).ToList();

            Show("Выбранные товары:", selected);
        } // GoodsInRange


        // все товары, для которых произведение цены на количество находится в заданном диапазоне
        internal void GoodsPriceInRange(int lo, int hi) {
            Console.WriteLine($"\n    Диапазон: от {lo:f2} до {hi:f2}");

            List<Good> selected;

            #region в синтаксисе LINQ
            /*
            var query =
                from x in _goods
                where lo <= x.Price * x.Number && x.Price * x.Number <= hi
                select x;

            selected = query.ToList();
            */
            #endregion

            // в синтаксисе расширяющих методов
            selected = _goods.Where(x => lo <= x.Price * x.Number && x.Price * x.Number <= hi).ToList();

            Show("Выбранные товары:", selected);
        } // GoodsPriceInRange
    }
}
