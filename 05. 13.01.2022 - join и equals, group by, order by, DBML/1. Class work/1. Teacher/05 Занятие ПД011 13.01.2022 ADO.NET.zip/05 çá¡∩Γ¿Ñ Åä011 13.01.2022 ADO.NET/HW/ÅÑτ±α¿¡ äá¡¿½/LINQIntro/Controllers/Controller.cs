﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using LINQIntro.Models;
using LINQIntro.App_Data;
using LINQIntro.Helpers;

namespace LINQIntro.Controllers
{
    public class Controller
    {
        // вывод коллекции товаров 
        public static void ShowCollection()
        {
            Console.WriteLine(Product.Header);
            foreach (var item in App.List)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Product.Footer);
            
        }

        public static string NumberOfElements()
        {
            // массив для исследований
            int[] data = { 2, 4, 5, 1, -1, -11, 6, 12, 1, -11, 12, -11 };

            //данные для диапазона 
            int lo = -6;
            int hi = 2;

            Console.WriteLine("Исходный массив:");
            foreach (var item in data)
            {
                Console.Write($"{item,5}");
            }
            Console.WriteLine("\n");

            var number = from item in data
                where item > lo && item < hi
                select item;

            return $"Количество элементов в диапазоне от {lo} до {hi}  равно {number.Count()}";

        }

        public static string NumberOfElementsExtension()
        {
            // массив для исследований
            int[] data = { 2, 4, 5, 1, -1, -11, 6, 12, 1, -11, 12, -11 };

            //данные для диапазона 
            int lo = -6;
            int hi = 2;

            Console.WriteLine("\nИсходный массив:");
            foreach (var item in data)
            {
                Console.Write($"{item,5}");
            }
            Console.WriteLine("\n");

            var number = data
                .Where(a => a > lo && a < hi)
                .Count();

            return $"Количество элементов в диапазоне от {lo} до {hi}  равно {number}";
        }

        public static string NumberOfNulls()
        {
            // массив для исследований
            int[] data = { 2, 4, 5, 0, -1, -11, 6, 12, 0, -11, 12, -11 };

            Console.WriteLine("\nИсходный массив:");
            foreach (var item in data)
            {
                Console.Write($"{item,5}");
            }
            Console.WriteLine("\n");

            var number = from item in data
                where item == 0
                select item; 

            return $"Количество нулей в коллекции равно {number.Count()}";
        }

        public static string NumberOfNullsExtension()
        {
            // массив для исследований
            int[] data = { 2, 4, 5, 0, -1, -11, 6, 12, 0, -11, 12, -11 };

            Console.WriteLine("\nИсходный массив:");
            foreach (var item in data)
            {
                Console.Write($"{item,5}");
            }
            Console.WriteLine("\n");

            var number = data
                .Where(a => a == 0)
                .Count();

            return $"Количество нулей в коллекции равно {number}";
        }

        public static void DiapasonePriceGoods()
        {
            // коллекция для исследования
            var goods = App.List
                .Where(a => a.Price > 20 && a.Price < 40);

            Console.WriteLine(Product.Header);
            foreach (var item in goods)
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Product.Footer);
        }

        public static void SumOfGoods()
        {
            var number = App.List
                .Where(a => a.YearOfManufacture == 2021)
                .Count();
            Console.WriteLine($"Количество товаров 2021 года равно {number}");
        }

        //сумма товаров с заданным наименованием (суммируем произведение цены на количество,
        //наименование товара может быть задано частично, но без маски типа %, _)
        public static void NameOfGoods()
        {
            var nameofgoods = App.List
                .Where(a => a.Name.Contains("для"))
                .Sum(a => a.Price * a.Number);
            Console.WriteLine($"Произведение количества товаров, содержащих слово \"для\" равно {nameofgoods}");

        }

        //наименование и год выпуска товаров с максимальным количеством
        public static void NameAndYear()
        {
            var maxnumber = App.List
                .Max(a => a.Number);
            var nameandyear = App.List
                .Where(a => a.Number == maxnumber)
                .Select(a => (a.Name, a.YearOfManufacture));
            Console.WriteLine($"Максимальное количество товара - {maxnumber}, наименование и год - ");
            foreach (var item in nameandyear)
            {
                Console.WriteLine(item);
            }
        }

        //все товары, для которых произведение цены на количество находится в заданном диапазоне

        public static void MultiplyPriceAndNumber()
        {
            var allgoods = App.List
                .Where(a =>
                {
                    int temp = a.Price * a.Number;

                    return temp > 10000 && temp < 50000;
                });

            Console.WriteLine(Product.Header);
            foreach (var item in allgoods )
            {
                Console.WriteLine(item.ToTableRow());
            }
            Console.WriteLine(Product.Footer);
        }
    }
}
