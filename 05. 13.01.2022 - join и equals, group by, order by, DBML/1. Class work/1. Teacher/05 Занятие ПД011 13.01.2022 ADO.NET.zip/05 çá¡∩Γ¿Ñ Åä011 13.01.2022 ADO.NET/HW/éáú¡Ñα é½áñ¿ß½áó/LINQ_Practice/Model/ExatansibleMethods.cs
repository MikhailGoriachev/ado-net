﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Practice.Model
{
    public static class ExatansibleMethods
    {
        //Расширяющие методы 
        public static int Discount(this Goods goods)
        {
            int age = DateTime.Now.Year - goods.Manufactured;
            //до 3х лет скидка не представляется, от 3х до 10 лет скидка 3 %, свыше 10 лет – скидка 7 %
            return age < 3 ? 0 : age <= 10 ? 3 : 7;
        }
    }
}
