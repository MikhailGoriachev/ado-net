﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task02_WpfIntro.Models
{
    // Класс для обработки по заданию, для обработки:
    //     • вычисление среднего арифметического
    //     • среднего геометрического трех чисел
    //     • вычисление корня квадратного уравнения
    public class Task2
    {
        // число 1 для обработки по заданию
        private double _a;
        public double A {
            get => _a;
            set => _a = value;
        } // A

        // число 2 для обработки по заданию
        private double _b;
        public double B {
            get => _b;
            set => _b = value;
        } // B

        // число 3 для обработки по заданию
        private double _c;
        public double C {
            get => _c;
            set => _c = value;
        } // C


        #region Ансамбль конструкторов
        public Task2():this(0, 0, 0) { } // Task2
        public Task2(double a, double b, double c) {
            _a = a;
            _b = b;
            _c = c;
        } // Task2
        #endregion

        #region Методы обработки по заданию

        // Вычисление среднего арифметического
        public double Average() => (_a + _b + _c) / 3; 

        // Вычисление среднего геометрического
        public double Geometric() {
            
            // при отрицательном произведении _a, _b, _c вычисление
            // среднего геометрического невозможно
            double temp = _a * _b * _c;
            if (temp < 0)
                throw new Exception($"Task2: Невозможно вычислить среднее арифметическое\n" +
                                    $"для чисел {_a:n3}, {_b:n3} и {_c:n3}");

            // вычислить и вернуть среднее геометрическое
            return Math.Sqrt(_a * _b * _c);
        } // Geometric

        // Вычисление корня квадратного уравнения
        public (double X1, double X2) SquareRoots() {
            // Проверим, есть ли решение как таковое
            if (_a == 0)
                throw new Exception("Task2: Квадрантное уравнение\n" +
                                    "с коэффициентом A = 0\n" +
                                    "не имеет решения");

            // дискриминант
            double d = _b * _b - 4 * _a * _c;

            if (d < 0)
                throw new Exception("Task2: Квадратное уравнение\n" +
                                    $"с коэффициентами A = {_a:n3} B = {_b:n3} C = {_c:n3}\n" +
                                    $"не имеет действительных корней");

            double z = -2 * _a;
            (double X1, double X2) roots;
            roots.X1 = (-_b + Math.Sqrt(d)) / z;
            roots.X2 = (-_b - Math.Sqrt(d)) / z;

            return roots;
        } // SquareRoots
        #endregion
    } // class Task2
}
