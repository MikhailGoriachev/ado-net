﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW.Application
{
    public partial class App
    {
        // Задача 2. Вычисление количества элементов массива, со значениями в диапазоне от A до B
        public void Task2_1() =>
            _task2Controller.Task1();

        // Задача 2. Вычисление количества элементов массива, равных 0
        public void Task2_2() =>
            _task2Controller.Task2();

        // Задача 2. Вычисление суммы элементов массива, расположенных после первого максимального элемента
        public void Task2_3() =>
            _task2Controller.Task3();

    }
}