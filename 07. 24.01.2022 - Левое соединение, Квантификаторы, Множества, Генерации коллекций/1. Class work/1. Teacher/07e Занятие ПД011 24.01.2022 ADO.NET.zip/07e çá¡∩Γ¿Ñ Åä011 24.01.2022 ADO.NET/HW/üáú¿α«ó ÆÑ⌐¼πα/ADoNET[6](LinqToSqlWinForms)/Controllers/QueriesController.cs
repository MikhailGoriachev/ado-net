﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 

using ADoNET_6__LinqToSqlWinForms_.Models;

namespace ADoNET_6__LinqToSqlWinForms_.Controllers
{
    public class QueriesController {
        // контекст данных - подключение к базе данных
        private WholesaleDataContext _db;
        
        public QueriesController() {
            _db = new WholesaleDataContext();
        } // QueriesController


    // Информация о товарах, единица измерения которых «шт» (штуки) и цена закупки меньше 200 руб
    // синтаксис расширяющих методов
        public IEnumerable Query01(string unit = "шт", int price = 200) => _db.Purchases
                .Where(purchase => purchase.Units.Short == unit && purchase.Price<price)
                .Select(purchase => new Purchase
                {
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                });
 
        // Информация о товарах, цена закупки которых больше 500 руб
        // синтаксис расширяющих методов
        public IEnumerable Query02(int price = 500) =>_db.Purchases
                .Where(purchase => purchase.Price > price)
                .Select(purchase => new Purchase
                {
                    Id = purchase.Id, 
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                });
 

        // Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1800 руб
        // синтаксис расширяющих методов
        public IEnumerable Query03(string good = "чехол защитный", int price = 1800) => _db.Purchases
                .Where(purchase => purchase.Price > price && purchase.Goods.Item == good)
                .Select(purchase => new Purchase
                {                      
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                });  

         
        // Информация о продавцах с заданным значением процента комиссионных.
        // синтаксис расширяющих методов
        public IEnumerable Query04(double interest = 10d) => _db.Sellers
                .Where(seller => seller.Interest == interest)
                .Select(seller => new Seller
                {
                    Id = seller.Id,
                    Interest = seller.Interest,
                    Name = seller.Persons.Name,
                    Surname = seller.Persons.Surname,
                    Patronymic = seller.Persons.Patronymic,
                });
 

        // Информация о фактах продажи, для которых цена продажи в заданном диапазоне
        // синтаксис расширяющих методов
        public IEnumerable Query05(int lo = 800, int hi = 2000) =>  _db.Sales
                .Where(sale => sale.Price >= lo && sale.Price <= hi)
                .Select(sale => new Sale
                {
                    Id = sale.Id,
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    Unit = sale.Units.Short,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                    Seller = sale.Sellers.Persons.Surname + " " +
                    sale.Sellers.Persons.Name.Substring(0, 1) + ". " +
                    sale.Sellers.Persons.Patronymic.Substring(0, 1) + "."
                });
  

        // Вычислить прибыль от продажи за каждый проданный товар
        // синтаксис расширяющих методов
        public IEnumerable Query06() =>  _db.Sales
                .Select(sale => new ResultQuery06
                {
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                });
 




    }

}
