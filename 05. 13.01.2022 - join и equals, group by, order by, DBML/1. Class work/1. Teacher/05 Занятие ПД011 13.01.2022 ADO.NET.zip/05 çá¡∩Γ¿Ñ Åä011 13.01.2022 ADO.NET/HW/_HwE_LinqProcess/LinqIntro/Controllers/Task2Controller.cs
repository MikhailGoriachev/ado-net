﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqIntro.Helpers;

namespace LinqIntro.Controllers
{
    /*
     * Решение задачи 2
     */
    public class Task2Controller
    {
        // данные для обработки
        public double[] Data;

        // Основной цвет для вывода в консоль
        private static readonly (ConsoleColor f, ConsoleColor b) MainColor = (ConsoleColor.Gray, ConsoleColor.DarkGray);
        
        // Цвет вывода выделенных элементов массива
        private static readonly (ConsoleColor f, ConsoleColor b) MarkedColor = (ConsoleColor.Gray, ConsoleColor.DarkBlue);

        // Цвет вывода особых значений (минимумов, максимумов и т.д.
        private static readonly (ConsoleColor f, ConsoleColor b) AccentColor = (ConsoleColor.Cyan, ConsoleColor.DarkBlue);

        public Task2Controller(): this(new double[15]) { } // Task2Controller

        public Task2Controller(double[] data) {
            Data = data;
            Initializer(-10, 10);
        } // Task2Controller 

        // заполнение массива случайными числами
        public void Initializer(double from, double to) {
            Data = Enumerable
                .Repeat(0, Data.Length)               // создание массива из Data.Length нулей
                .Select(item => Utils.GetRandom(from, to)) // в массив записать случайные числа 
                .ToArray(); // собственно формирование массива
        } // Initializer



        #region Запросы к массиву по заданию
        // Вычисление количества элементов массива, со значениями в диапазоне от A до B
        // синтаксис LINQ
        public int Query01A(double a, double b) => (
            from item in Data
                where item >= a && item <= b
                select item).Count();

        // Вычисление количества элементов массива, со значениями в диапазоне от A до B
        // синтаксис расширяющих методов
        public int Query01B(double a, double b) => Data
            .Count(item => item >= a && item <= b);


        // Вычисление количества элементов массива, равных 0
        // синтаксис LINQ
        public int Query02A() => (
            from item in Data
                where item.Equals(0) // Math.Abs(item) <= 1e-5
                select item).Count();

        // Вычисление количества элементов массива, равных 0
        // синтаксис расширяющих методов
        public int Query02B() => Data
            .Count(item => item == 0);

        // Вычисление суммы элементов массива, расположенных после первого максимального
        // элемента - синтаксис LINQ, не реализуем в рамках изученного материала
        public double Query03A() => (
            from item in Data.Skip(Array.IndexOf(Data, Data.Max()) + 1).ToArray()
            select item)
            .Sum();


        // Вычисление суммы элементов массива, расположенных после первого максимального
        // элемента - синтаксис расширяющих методов
        public double Query03B() => Data
            .Skip(Array.IndexOf(Data, Data.Max()) + 1)
            .Sum();

        // Вычисление суммы элементов массива, расположенных перед последним минимальным
        // по модулю элементом - синтаксис LINQ, не реализуем в рамках изученного материала
        public double Query04A() {
            return 0;
        } // Query04A

        // Вычисление суммы элементов массива, расположенных перед последним минимальным
        // по модулю элементом - синтаксис расширяющих методов
        public double Query04B() {
            double[] dataAbs = Data  // проекция: вспомогательный массив 
                .Select(Math.Abs)    // из абсолютных значений исходного массива
                .ToArray();

            // индекс последнего минимального по модулю элемента
            int indexMin = Array.LastIndexOf(dataAbs, dataAbs.Min()); 
            
            // сумма элементов массива до последнего минимального по модулю
            return Data
                .Take(indexMin)
                .Sum();
        } // Query04B
        #endregion


        #region Варианты вывода массива с выделением элементов цветом
        // Вывод массива в консоль, выделяем цветом элементы, попадающие в интервал [a, b]
        // чтобы ни одни элемент не попадал в интервал по умолчанию, т.е. если интервал
        // не задан, задаем соответствующие значения по умолчанию
        public void ShowArray(string caption, double a = double.MaxValue, double b = double.MinValue) {
            Console.Write($"{caption}\n\t");

            int index = 0;
            Array.ForEach(Data, item => {
                if (item >= a && item <= b)
                    Utils.SetColor(MarkedColor.f, MarkedColor.b);

                Console.Write($"{item, 7:n2}   ");
                Utils.SetColor(MainColor.f, MainColor.b);
                Console.Write(" ");  // вывести один разделительный пробел базовым цветом
                if (++index % 8 == 0) Console.Write("\n\t");
                
            });
            Console.WriteLine();
        } // ShowArray


        // Выводим массив в консоль с цветовым оформлением: выделяем первый
        // максимальный элемент и все элементы после него, до конца массива
        public void ShowArrayMax(string caption) {
            Console.Write($"{caption}\n\t");

            // индекс первого максимального элемента
            int imax = Array.IndexOf(Data, Data.Max());

            // индекс текущего элемента массива 
            int index = 0;
            Array.ForEach(Data, item => {
                (ConsoleColor f, ConsoleColor b) color;
                if (index == imax)
                    color = AccentColor;
                else if (index > imax)
                    color = MarkedColor;
                else
                    color = MainColor;
                Utils.SetColor(color.f, color.b);

                Console.Write($"{item,7:n2}   ");
                Utils.SetColor(MainColor.f, MainColor.b);
                Console.Write(" ");  // вывести один разделительный поробел базовым цветом
                if (++index % 8 == 0) Console.Write("\n\t");
            });
            Console.WriteLine();
        } // ShowArrayMax


        // Выводим массив в консоль с цветовым оформлением: выделяем первый
        // максимальный элемент и все элементы после него, до конца массива
        public void ShowArrayMin(string caption) {
            Console.Write($"{caption}\n\t");

            // индекс последнего минимального по модулю элемента
            double[] dataAbs = Data.Select(Math.Abs).ToArray();
            int imin = Array.LastIndexOf(dataAbs, dataAbs.Min());

            // индекс текущего элемента массива 
            int index = 0;
            Array.ForEach(Data, item => {
                (ConsoleColor f, ConsoleColor b) color;
                if (index == imin)
                    color = AccentColor;
                else if (index < imin)
                    color = MarkedColor;
                else
                    color = MainColor;
                Utils.SetColor(color.f, color.b);

                Console.Write($"{item,7:n2}   ");
                Utils.SetColor(MainColor.f, MainColor.b);
                Console.Write(" ");  // вывести один разделительный поробел базовым цветом
                if (++index % 8 == 0) Console.Write("\n\t");
            });
            Console.WriteLine();
        } // ShowArrayMin
        #endregion
    } // class Task2Controller
}
