﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeWork.Application;
using HomeWork.Models;
using Microsoft.VisualBasic;

namespace HomeWork
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.Title = "Домашние задание на 10.01.22";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Запрос 1. Хранимая процедура"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Запрос 2. Хранимая процедура"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Запрос 3. Хранимая процедура"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Запрос 4. Хранимая процедура"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Запрос 5. Хранимая процедура"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Запрос 6. Хранимая процедура"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Запрос 7. Итоговый запрос. Хранимая процедура"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Запрос 8. Итоговый запрос с левым соединением. Хранимая процедура"},
                new MenuItem {HotKey = ConsoleKey.X, Text = "Запрос 9. Итоговый запрос с левым соединением. Хранимая процедура"}, 
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.C, Text = "Шифрования конфигурационного файла"},
                new MenuItem {HotKey = ConsoleKey.V, Text = "Расшифровывания конфигурационного файла"},
              


                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App app = new App();


            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("Учет подписки на периодические печатные издания");
                    Utils.ShowMenu(12, 5, "Меню ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key)
                    {
                        // Задача 1
                        case ConsoleKey.Q:
                            app.Query01();
                            break;

                        case ConsoleKey.W:
                            app.Query02();
                            break;

                        case ConsoleKey.E:
                            app.Query03();
                            break;

                        case ConsoleKey.R:
                            app.Query04();
                            break;

                        case ConsoleKey.T:
                            app.Query05();
                            break;

                        case ConsoleKey.A:
                            app.Query06();
                            break;

                        case ConsoleKey.S:
                            app.Query07();
                            break;

                        case ConsoleKey.D:
                            app.Query08();
                            break;

                        case ConsoleKey.X:
                            app.Query09();
                            break;
                                         
                        case ConsoleKey.C:
                            app.SecurityConfigON();
                            break;

                        case ConsoleKey.V:
                            app.SecurityConfigOFF();
                            break;

                        
                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while


        }
    }
}
