﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	public class ProfitModelView
	{
		// Дата продажи
		public DateTime SellDate { get; set; }

		// Наименование товара
		public string Title { get; set; }
		
		// Цена закупки
		public int PurchasePrice { get; set; }

		// Цена продажи
		public int SellPrice { get; set; }

		// Количество проданных единиц
		public int Amount { get; set; }

		// Прибыль
		public int Profit { get; set; }
	}
}
