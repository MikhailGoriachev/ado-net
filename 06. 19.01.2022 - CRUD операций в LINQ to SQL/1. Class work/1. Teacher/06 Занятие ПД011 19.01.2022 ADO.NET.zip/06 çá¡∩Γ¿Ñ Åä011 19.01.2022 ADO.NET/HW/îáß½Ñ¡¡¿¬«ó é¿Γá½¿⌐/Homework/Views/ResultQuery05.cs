﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Views
{
    public class ResultQuery05
	{
		public int Year { get; set; }

		public int Amount { get; set; }

		public double AvgPrice { get; set; }

		public override string ToString() =>
			$"  {Year}г. - {AvgPrice:F1}р. ({Amount}шт.)";
	}
}
