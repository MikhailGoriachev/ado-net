﻿using H_W5AdoLINQtoSQL.Application;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;        // для ADO.NET
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Configuration;


namespace H_W5AdoLINQtoSQL
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 5.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1.Вывести список книг и авторов в коллекцию." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1.Вывести книги авторов, год рождения которых принадлежит заданном диапазону." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1.Вывести книги, в которых содержится подстрока и цена не превышает заданного значения." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 1.Список авторов и количество их книг в коллекции." },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 1.Средняя цена книг по годам издания." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Задача 1.Список авторов по убыванию количества их книг в коллекции ." },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Задача 1.Средний возраст книг по авторам, выводить список с упорядочиванием по ФИО." },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2.Товары цена закупки составляет меньше 100 руб. за единицу товара." },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2.Товары цена закупки составляет больше 140 руб. за единицу товара." },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2.Товары с заданным наименованием, для которых цена закупки меньше 200 руб." },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2.Продавцы с заданным значением процента комиссионных." },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Задача 2.Товары цена продажи которых оказалась в некоторых заданных границах." },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Задача 2.Вычисляет прибыль от продажи за каждый проданный товар." },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(20, 5, "Меню приложения для решения задач с помощью LINQ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Вывести список книг в коллекцию
                        case ConsoleKey.Q:
                           app.ShowBooks();
                            break;

                        // Вывести книги авторов, год рождения которых принадлежит заданном диапазону 
                        case ConsoleKey.W:
                           app.AuthorBirthDiapazone();
                            break;

                        // Вывести книги, в которых содержится подстрока и цена не превышает заданного значения
                        case ConsoleKey.E:
                            app.BooksPrice();
                            break;

                        // Список авторов и количество их книг в коллекции
                        case ConsoleKey.R:
                            app.AutorsAndBook();
                            break;

                        // Средняя цена книг по годам издания
                        case ConsoleKey.T:
                            app.AvgBooksInYear();
                            break;

                        // Список авторов по убыванию количества их книг в коллекции 
                        case ConsoleKey.Y:
                            app.AutorsAndBookSort();
                            break;

                        // Средний возраст книг по авторам, выводить список с упорядочиванием по ФИО
                        case ConsoleKey.U:
                            app.AvgYearBookOrderAuthor();
                            break;

                        // Товары цена закупки составляет меньше 100 руб. за единицу товара
                        case ConsoleKey.A:
                            app.Query01();
                            break;

                        // Товары цена закупки составляет меньше 100 руб. за единицу товара
                        case ConsoleKey.S:
                            app.Query02();
                            break;

                        // Товары с заданным наименованием, для которых цена закупки меньше 200 руб.
                        case ConsoleKey.D:
                            app.Query03();
                            break;

                        // Продавцы с заданным значением процента комиссионных
                        case ConsoleKey.F:
                           app.Query04();
                            break;

                        // Товары цена продажи которых оказалась в некоторых заданных границах
                        case ConsoleKey.G:
                            app.Query05();
                            break;

                        // Вычисляет прибыль от продажи за каждый проданный товар
                        case ConsoleKey.H:
                             app.Query06();
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;

        }// Main
    }
}
