﻿namespace LinqWinForms.Models
{
    public partial class Person
    {
        public override string ToString()
        {
            return $" {Name}, {Surname}";
        }
    }
}