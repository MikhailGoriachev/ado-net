﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Main.Models;
using Main.Utilities;
using Main.Utilities.Menu;
using Newtonsoft.Json;


namespace Main.Controllers
{
	public sealed class Task2Controller : MenuWrapper
	{
		private static readonly string ConnectionString =
			@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Catalan\Desktop\Homework_5\Main\Main\Data\Wholesale.mdf;Integrated Security=True";


		public Task2Controller() => Menu = new Menu("Главное меню приложения", new[]
		{
			new MenuItem("Первый запрос", Query1),
			new MenuItem("Второй запрос", Query2),
			new MenuItem("Третий запрос", Query3),
			new MenuItem("Четвертый запрос", Query4),
			new MenuItem("Пятый запрос", Query5),
			new MenuItem("Шестой запрос", Query6),
		});


		// Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения 
		// которых является «шт» (штуки) и цена закупки составляет меньше 200 руб.
		private void Query1()
		{
			var context = Connect();

			var result = context.Purchases
								.Where(purchase => purchase.Unit.Short == "шт" && purchase.Price < 200)
								.Select(purchase => new
								{
									Name   = purchase.Good.Item,
									Price  = purchase.Price,
									Unit   = purchase.Unit.Short,
									Amount = purchase.Amount
								});

			ShowResult(result.ToArray());
		}


		// Выбирает из таблицы ТОВАРЫ информацию о товарах, цена
		// закупки которых больше 500 руб.за единицу товара
		private void Query2()
		{
			var context = Connect();

			var result = context.Purchases
								.Where(purchase => purchase.Price > 500)
								.Select(purchase => new
								{
									Name   = purchase.Good.Item,
									Price  = purchase.Price,
									Unit   = purchase.Unit.Short,
									Amount = purchase.Amount
								});

			ShowResult(result.ToArray());
		}


		// Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием
		// (например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
		private void Query3()
		{
			var context = Connect();

			var result = context.Purchases
								.Where(purchase => purchase.Price > 500)
								.Select(purchase => new
								{
									Name   = purchase.Good.Item,
									Price  = purchase.Price,
									Unit   = purchase.Unit.Short,
									Amount = purchase.Amount
								});

			ShowResult(result.ToArray());
		}


		// Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением процента комиссионных. 
		private void Query4()
		{
			var context = Connect();

			var result = context.Sellers
								.Where(seller => seller.Interest.Equals(3))
								.Select(seller => new
								{
									seller.Person.Name,
									seller.Person.Surname,
									seller.Person.Patronymic,
									seller.Person.Passport,
									seller.Interest
								});

			ShowResult(result.ToArray());
		}


		// Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех зафиксированных фактах
		// продажи товаров (Наименование товара, Цена закупки, Цена продажи, дата продажи),
		// для которых Цена продажи оказалась в некоторых заданных границах. 
		private void Query5()
		{
			var context = Connect();

			var result = context.Sales
								.Where(sale => sale.Price >= 15000 && sale.Price <= 150000)
								.Select(sale => new
								{
									Item  = sale.Purchase.Good.Item,
									Date  = sale.SaleDate,
									Price = sale.Price,
									Unit  = sale.Unit.Short,
									Seller =
										$"{sale.Seller.Person.Surname} {sale.Seller.Person.Name} {sale.Seller.Person.Patronymic}",
								});

			ShowResult(result.ToArray());
		}


		// Вычисляет прибыль от продажи за каждый проданный товар. Включает поля Дата продажи,
		// Наименование товара, Цена закупки, Цена продажи, Количество проданных единиц,
		// Прибыль. Сортировка по полю Наименование товара
		private void Query6()
		{
			var context = Connect();

			var result = context.Sales
								.Select(sale => new
								{
									Item  = sale.Purchase.Good.Item,
									Date  = sale.SaleDate,
									SalePrice = sale.Price,
									PurchasePrice = sale.Purchase.Price,
									Amount = sale.Amount,
									Unit  = sale.Unit.Short,
									Profit = (sale.Price - sale.Purchase.Price) * sale.Amount,
									Seller = $"{sale.Seller.Person.Surname} {sale.Seller.Person.Name} {sale.Seller.Person.Patronymic}",
								})
								.OrderBy(arg => arg.Item);

			ShowResult(result.ToArray());
		}

		/*
select
    Sales.Id
    , Goods.Item
    , Units.Short
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Sales.SaleDate
    , Sales.Amount
    , Purchases.Price   as PurchasePrice
    , Sales.Price       as SalePrice
    , (Sales.Price - Purchases.Price) * Sales.Amount as Profit 
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id) on Sales.IdSeller = Sellers.IdPerson
          join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id
order by
    Goods.Item;
		*/



		private static void ShowResult<T>(IEnumerable<T> values) =>
			Console.WriteLine(JsonConvert.SerializeObject(values, Formatting.Indented));


		private static WholesaleDataContext Connect() => new(ConnectionString);
	}
}