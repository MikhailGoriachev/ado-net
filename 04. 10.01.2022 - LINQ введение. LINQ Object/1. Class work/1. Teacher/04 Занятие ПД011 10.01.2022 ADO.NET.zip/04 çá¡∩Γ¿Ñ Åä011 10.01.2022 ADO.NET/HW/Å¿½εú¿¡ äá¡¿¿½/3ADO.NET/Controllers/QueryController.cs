﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _3ADO.NET.Models;

namespace _3ADO.NET.Controllers
{
    class QueryController
    {
        string connectionString; //строка подклбчения к базе данных

        //конструктор по умолчанию
        public QueryController()
        {
            connectionString = ConfigurationManager.ConnectionStrings["SubsConnectionString"].ConnectionString;
        }
        public List<Publication> Query1(string type, int cost)
        {
            //вызываемая процедура
            string procedure = "ShowPubByTypeAndCost";
            //коллекция подписчиков из базы данных
            List<Publication> pubs = new List<Publication>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(procedure, connection);
                cmd.Parameters.AddWithValue("@type", type);
                cmd.Parameters.AddWithValue("@cost", cost);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                    while (reader.Read())
                        pubs.Add(new Publication()
                        {
                            id = reader.GetInt32(0),
                            EditName = reader.GetString(1),
                            EditType = reader.GetString(2),
                            Cost = reader.GetInt32(3)
                        });
            }
            return pubs;
        }
        public List<Subscriber> Query2(string street, string numHouse, string pub)
        {
            string procedure = "ShowSubByStreetAndPub";
            List<Subscriber> subs = new List<Subscriber>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(procedure, connection);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@street", street);
                cmd.Parameters.AddWithValue("@numHouse", numHouse);
                cmd.Parameters.AddWithValue("@pub", pub);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                    while (reader.Read())
                        subs.Add( new Subscriber()
                        {
                            id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Surname = reader.GetString(2),
                            Patronymic = reader.GetString(3),
                            Passport = reader.GetInt32(4),
                            Street = reader.GetString(5),
                            NumHouse = reader.GetString(6),
                            NumApartment = reader.GetString(7),
                        });
            }

            return subs;
        }
        public List<Publication> Query3(int lo, int hi)
        {
            List<Publication> pubs = new List<Publication>();
            string proc = "ShowPubByCost";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(proc, connection) 
                    { CommandType = System.Data.CommandType.StoredProcedure};

                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                    while (reader.Read())
                        pubs.Add(new Publication()
                        {
                            id = reader.GetInt32(0),
                            EditName = reader.GetString(1),
                            EditType = reader.GetString(2),
                            Cost = reader.GetInt32(3)
                        });
            }

            return pubs;
        }
        public List<Subscriber> Query4(string editName)
        {
            List<Subscriber> subs = new List<Subscriber>();
            string proc = "ShowSubByPubName";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(proc, connection)
                { CommandType = System.Data.CommandType.StoredProcedure };

                cmd.Parameters.AddWithValue("@editName", editName);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                    while (reader.Read())
                        subs.Add(new Subscriber()
                        {
                            id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Surname = reader.GetString(2),
                            Patronymic = reader.GetString(3),
                            Passport = reader.GetInt32(4),
                            Street = reader.GetString(5),
                            NumHouse = reader.GetString(6),
                            NumApartment = reader.GetString(7),
                        });
            }
            return subs;
        }
        public void Query5(DateTime lo, DateTime hi)
        {
            string proc = "ShowDelivsByDate";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(proc, connection)
                { CommandType = System.Data.CommandType.StoredProcedure };

                cmd.Parameters.AddWithValue("@lo", lo.Date);
                cmd.Parameters.AddWithValue("@hi", hi.Date);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    Console.WriteLine(" __________________________________________________________________________________________\n"
                        + "| id |                ФИО                |   Название издания   |     Тип     |  Подписка  |\n" +
                        "|____|___________________________________|______________________|_____________|____________|");
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string fio = reader.GetString(1) + " " + reader.GetString(2) + " " + reader.GetString(3);
                        Console.WriteLine($"| {id,-2} | {fio,-33} | {reader.GetString(4),-20} |" +
                            $" {reader.GetString(5),-11} | {reader.GetDateTime(6).ToShortDateString()} |");
                    }
                    Console.WriteLine("|____|___________________________________|______________________|_____________|____________|");
                }
            }
        }
        public void Query6()
        {
            string proc = "ShowCostOfDelivs";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(proc, connection)
                { CommandType = System.Data.CommandType.StoredProcedure };

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    Console.WriteLine(" _____________________________________________________________________________________\n" +
                        $"| id | {reader.GetName(1)}|  Цена  |  Подписка  |" +
                        $" Срок | {reader.GetName(5)}  |\n" +
                        "|____|_____________________|________|____________|______|_____________________________|");
                    while (reader.Read())
                    {
                        Console.WriteLine($"| {reader.GetInt32(0),-2} | {reader.GetString(1),-19} | {reader.GetInt32(2),-6} |" +
                            $" {reader.GetDateTime(3).ToShortDateString(),-10} |   {reader.GetInt32(4), -3}|          {reader.GetValue(5), -18} |");
                    }
                    Console.WriteLine("|____|_____________________|________|____________|______|_____________________________|");
                }
            }
        }
        public void Query7()
        {
            string proc = "ShowPubMaxMinCost";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(proc, connection)
                { CommandType = System.Data.CommandType.StoredProcedure };

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    Console.WriteLine("\t\t __________________________________________\n" +
                        $"\t\t|    {reader.GetName(0)}   |    {reader.GetName(1)}    |    {reader.GetName(2)}    |\n" +
                        "\t\t|__________________|___________|___________|");
                    while (reader.Read())
                    {
                        Console.WriteLine($"\t\t|      {reader.GetString(0),-11} |    {reader.GetValue(1),-6} |    {reader.GetValue(2),-6} |");
                    }
                    Console.WriteLine("\t\t|__________________|___________|___________|");
                }
            }
        }
        public void Query8()
        {
            string proc = "ShowSubsStatByStreet";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(proc, connection)
                { CommandType = System.Data.CommandType.StoredProcedure };

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    Console.WriteLine("\t\t __________________________________________\n" +
                        $"\t\t|     Улица   |    {reader.GetName(1)}  |\n" +
                        "\t\t|_____________|____________________________|");
                    while (reader.Read())
                    {
                        Console.WriteLine($"\t\t| {reader.GetString(0),-11} |              {reader.GetValue(1),-13} |");
                    }
                    Console.WriteLine("\t\t|_____________|____________________________|");
                }
            }
        }    
        public void Query9()
        {
            string proc = "ShowPubStat";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(proc, connection)
                { CommandType = System.Data.CommandType.StoredProcedure };

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    Console.WriteLine("\t\t ________________________________________________\n" +
                        $"\t\t|  Название издательства  | Оформленные подписки |\n" +
                        "\t\t|_________________________|______________________|");
                    while (reader.Read())
                    {
                        Console.WriteLine($"\t\t| {reader.GetString(0),-23} |           {reader.GetValue(1),-10} |");
                    }
                    Console.WriteLine("\t\t|_________________________|______________________|");
                }
            }
        }
    }
}
