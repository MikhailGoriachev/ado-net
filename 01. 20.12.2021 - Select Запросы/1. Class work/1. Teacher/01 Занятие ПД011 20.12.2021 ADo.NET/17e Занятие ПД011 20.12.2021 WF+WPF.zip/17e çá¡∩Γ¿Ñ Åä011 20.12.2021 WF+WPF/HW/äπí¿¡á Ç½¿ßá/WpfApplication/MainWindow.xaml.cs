﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication.Models;

namespace WpfApplication
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Numbers _numbers;
        public MainWindow(): this(new Numbers()){ }
        public MainWindow(Numbers numbers) {
            InitializeComponent();
            _numbers = numbers;
        } // MainWindow

        // вычисление среднего арифметического
        private void BtnAMean_Click(object sender, RoutedEventArgs e) {
            double a, b, c;
            if(!double.TryParse(FirstNum.Text, out a)  || !double.TryParse(SecondNum.Text, out b) || !double.TryParse(ThirdNum.Text, out c))
            {
                TxbResult.Text = $"Ошибка!";
                return;
            } // if

            _numbers.A = a;
            _numbers.B = b;
            _numbers.C = c;

            TxbResult.Text = $"Среднее арифметическое: {_numbers.CountAMean():f2}";
        } // BtnAMean_Click

        // вычисление среднего геометрического 
        private void BtnGMean_Click(object sender, RoutedEventArgs e) {
            double a, b, c;
            if(!double.TryParse(FirstNum.Text, out a)  || !double.TryParse(SecondNum.Text, out b) || !double.TryParse(ThirdNum.Text, out c))
            {
                TxbResult.Text = $"Ошибка!";
                return;
            } // if

            _numbers.A = a;
            _numbers.B = b;
            _numbers.C = c;

            TxbResult.Text = $"Среднее геометрическое: {_numbers.CountGMean():f2}";
        } // BtnAMean_Click


        // вычисление корней квадратного уравнения
        private void BtnQuadraticRoots_Click(object sender, RoutedEventArgs e) {
            double a, b, c;
            if (!double.TryParse(FirstNum.Text, out a) || !double.TryParse(SecondNum.Text, out b) || !double.TryParse(ThirdNum.Text, out c) || a == 0)
            {
                TxbResult.Text = $"Ошибка!";
                return;
            } // if

            _numbers.A = a;
            _numbers.B = b;
            _numbers.C = c;
            (double? r1, double? r2) = _numbers.CountQuadraticRoots();

            if(r1 == null && r2 == null)
                TxbResult.Text = $"Корней нет!";
            else if (r1 != null && r2 == null)
                TxbResult.Text = $"Результат: {r1:f2}";
            else
                TxbResult.Text = $"Корень 1: {r1:f2}\nКорень 2: {r2:f2}";
        } // BtnQuadraticRoots_Click


        // Очистка результата при вводе новых значений 
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e) =>
            TxbResult.Text = "";
    }
}
