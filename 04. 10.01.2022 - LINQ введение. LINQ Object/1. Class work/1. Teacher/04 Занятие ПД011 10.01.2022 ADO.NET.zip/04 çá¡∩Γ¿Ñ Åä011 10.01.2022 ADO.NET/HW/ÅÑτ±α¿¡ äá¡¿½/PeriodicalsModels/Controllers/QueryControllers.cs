﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using PeriodicalsModels.Models;
using System.Data;

namespace PeriodicalsModels.Controllers
{
    public class QueryControllers
    {
        // строка подключения к базе данных
        private static string _connectingString;

        public string ConnectingString
        {
            get => _connectingString;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Не указана строка подлючения к базе данных");

                _connectingString = value;
            }// set
        }// ConnectingString

        public QueryControllers(string connectingString)
        {
            ConnectingString = connectingString;
        }

        // 01 Запрос с параметром	
        //Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях 
        //заданного типа, стоимость 1 экземпляра для которых меньше заданной

        public List<Publication> Query1(string pubtype, int price)
        {
            List<Publication> publist = new List<Publication>();
            Console.WriteLine("\n\n\nЗапрос 01.\n\n" + 
                              $"\tИздания, стоимостью меньше 250\n");

                // подключения к БД
                using (SqlConnection connection = new SqlConnection(_connectingString))
                {
                    // подключение к серверу 
                    connection.Open();

                    //создание команды (запрос SQL) 
                    SqlCommand cmd = new SqlCommand(@"InformationAboutPublications");

                    //задать соединение с БД
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.StoredProcedure;

                    //задать параметры запроса
                    cmd.Parameters.AddWithValue("@pubType", pubtype);
                    cmd.Parameters.AddWithValue("@price", price);

                    // выполнение запроса, ссылка на  выбранные данные - reader
                    SqlDataReader reader = cmd.ExecuteReader();

                    //Если данные получены (есть строки в полученном ответе сервера)
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            publist.Add(new Publication
                            {
                                Id = reader.GetInt32(0),
                                PubIndex = reader.GetString(1),
                                PubType = reader.GetString(2),
                                Title = reader.GetString(3),
                                Price = reader.GetInt32(4)
                            });
                        }//while
                    } //if


                    
                    
                }

                return publist;
        }

        // 02 Запрос с параметром	
        // Выбирает из таблиц информацию о подписчиках, проживающих на заданной
        //  параметром улице и номере дома, которые оформили подписку на издание 
        // с заданным параметром наименованием

        public List<Subscriber> Query2(string street, string building, string journal)
        {
            List<Subscriber> sublist = new List<Subscriber>();
            Console.WriteLine("\n\nЗапрос 02 \n\n" + 
                              $"\tПодписчики оформившие подписку заданного издания\n");

            //подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                // подключение к серверу 
                connection.Open();

                //создание команды (запрос SQL)
                SqlCommand cmd = new SqlCommand(@"InformationAboutSubscribers");

                //задать соединение с БД 
                cmd.Connection = connection;
                cmd.CommandType = CommandType.StoredProcedure;


                //задать параметры запроса
                cmd.Parameters.AddWithValue("@street", street);
                cmd.Parameters.AddWithValue("@building", building);
                cmd.Parameters.AddWithValue("@title", journal);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                //Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while(reader.Read())
                    {
                        sublist.Add(new Subscriber
                        {
                            Id = reader.GetInt32(0),
                            Subcriber = reader.GetString(1),
                            Passport = reader.GetString(2),
                            Address = reader.GetString(3),
                            Pubtype = reader.GetString(4),
                            Title = reader.GetString(5)
                        });

                    }//while
                }//if

                
                

            }

            return sublist;
        }

        //03 Запрос с параметром	
        // Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение
        // в поле Цена 1 экземпляра находится в заданном диапазоне значений

        public List<Publication> Query3(int lowPrice, int hiPrice)
        {
            List<Publication> publist = new List<Publication>();
            Console.WriteLine("\n\nЗапрос 03 \n\n" +
                              $"\tИздания в заданном ценовом диапазоне\n");

                // подключение к БД
                using (SqlConnection connection = new SqlConnection(_connectingString))
                {
                    //подключение к серверу
                    connection.Open();

                    //создание команды (запрос Sql)
                    SqlCommand cmd = new SqlCommand(@"PricePerIssue");

                    //задать соединение с БД
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.StoredProcedure;


                    //задать параметры запроса
                    cmd.Parameters.AddWithValue("@loPrice", lowPrice);
                    cmd.Parameters.AddWithValue("@hiPrice", hiPrice);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                    //Если данные получены (есть строки в полученном ответе сервера)
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            publist.Add(new Publication
                            {
                                Id = reader.GetInt32(0),
                                PubIndex = reader.GetString(1),
                                PubType = reader.GetString(2),
                                Title = reader.GetString(3),
                                Price = reader.GetInt32(4)
                            });
                        }//while
                    } //if


                    
                    

                }
                return publist;
        }

        //04 Запрос с параметром	
        // Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный 
        // параметром тип издания
        public List<Subscriber> Query4(string pubType)
        {
            List<Subscriber> sublist = new List<Subscriber>();
            Console.WriteLine("\n\nЗапрос 04 \n\n" +
                              $"\tИнформация о подписчиках на определенный тип издания\n");


            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                //подключение к серверу
                connection.Open();

                //создание команда (запрос Sql)
                SqlCommand cmd = new SqlCommand(@"SubscribersAndType");

                //задать соединение с БД
                cmd.Connection = connection;
                cmd.CommandType = CommandType.StoredProcedure;

                //задать параметры запроса 
                cmd.Parameters.AddWithValue("pubType", pubType);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                //Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        sublist.Add(new Subscriber
                        {
                            Id = reader.GetInt32(0),
                            Subcriber = reader.GetString(1),
                            Passport = reader.GetString(2),
                            Address = reader.GetString(3),
                            Pubtype = reader.GetString(4),
                            Title = reader.GetString(5)
                        });

                    }//while
                }//if

                
                


            }

            return sublist;
        }
        //05 Запрос с параметром	
        // Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКИ информацию обо всех оформленных 
        // подписках, для которых срок подписки есть значение из некоторого диапазона.
        // Нижняя и верхняя границы диапазона задаются при выполнении запроса
        public void Query5(int loDuration, int hiDuration)
        {
            Console.WriteLine("\n\nЗапрос 05 \n\n" +
                              $"\tИнформация обо всех оформленных подписках из временного диапазона\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {

                //подключение к серверу
                connection.Open();

                //создание команды запроса 
                SqlCommand cmd = new SqlCommand(@"FilledSubscriptions");

                //задать соединение с БД
                cmd.Connection = connection;

               

                //задать параметры запроса
                cmd.Parameters.AddWithValue("@loDuration", loDuration);
                cmd.Parameters.AddWithValue("@hiDuration", hiDuration);

                
            }

        }

        // 06 Запрос с вычисляемыми полями	
        // Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС 
        // Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата 
        // начала подписки, Срок подписки, Стоимость подписки без НДС.Сортировка по
        // полю Индекс издания

        public List <SubscribersCost> Query6()
        {
            List<SubscribersCost> subcost = new List<SubscribersCost>();
             Console.WriteLine("\n\nЗапрос 06 \n\n" +
                              $"\tВычисляемые запросы с заданными полями\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {

                //подключение к серверу
                connection.Open();

                //создание команды запроса 
                SqlCommand cmd = new SqlCommand(@"CalculateAndSort");

                //задать соединение с БД
                cmd.Connection = connection;
                cmd.CommandType = CommandType.StoredProcedure;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        subcost.Add(new SubscribersCost
                        {
                            Id = reader.GetInt32(0),
                            PubType = reader.GetString(1),
                            Title = reader.GetString(2),
                            Price = reader.GetInt32(3),
                            DateStart = reader.GetDateTime(4),
                            Duration = reader.GetInt32(5),
                            SubscriberCost = reader.GetDecimal(6)
                        });
                    }
                }

                
                
            }

            return subcost;
        }

        //07 Итоговый запрос	
        // Выполняет группировку по полю Вид издания.Для каждого вида вычисляет
        // максимальную и минимальную цену 1 экземпляра
        public List<TotalMinMax> Query7()
        {
            List<TotalMinMax> minmax = new List<TotalMinMax>();
            Console.WriteLine("\n\nЗапрос 07 \n\n" +
                              $"\tИтоговый запрос с группировкой\n");

                //подключение к БД
                using (SqlConnection connection = new SqlConnection(_connectingString))
                {
                    // подключение к серверу 
                    connection.Open();

                    //создание команды запроса 
                    SqlCommand cmd = new SqlCommand(@"SummarisedQuery");

                    //задать соединение с БД
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.StoredProcedure;

                    // выполнение запроса, ссылка на  выбранные данные - reader
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            minmax.Add( new TotalMinMax
                            {
                                PubType = reader.GetString(0),
                                TotalPubType = reader.GetInt32(1),
                                MaxPrice = reader.GetInt32(2),
                                MinPrice = reader.GetInt32(3)
                            });
                        }
                    }

                }

            return minmax;
        }

        //08 Итоговый запрос с левым соединением	
        //Выполняет группировку по полю Улица.Для всех улиц вычисляет количество 
        //подписчиков, проживающих на данной улице(итоги по полю Код получателя)

        public List<GroupByStreet> Query8()
        {
            List<GroupByStreet> streetlist = new List<GroupByStreet>();
            Console.WriteLine("\n\nЗапрос 08 \n\n" +
                              $"\tИтоговый запрос с левым соединением\n");

                // подключение к БД
                using (SqlConnection connection = new SqlConnection(_connectingString))
                {
                       //подключение к серверу
                       connection.Open();

                       //создание команды запроса
                       SqlCommand cmd = new SqlCommand(@"GroupByStreet");

                       //задать соединение
                       cmd.Connection = connection;
                       cmd.CommandType = CommandType.StoredProcedure;

                       //выполнение запроса 
                       SqlDataReader reader = cmd.ExecuteReader();

                       if (reader.HasRows)
                       {
                           while (reader.Read())
                           {
                               streetlist.Add(new GroupByStreet
                               {
                                   Street = reader.GetString(0),
                                   SubscriberAmount = reader.GetInt32(1)
                               });
                           }
                       }
                       
                       
                }

                return streetlist;
        }

        //09 Итоговый запрос с левым соединением	
        // Для всех изданий выводит количество оформленных подписок
        public List<Deliveries> Query9()
        {
            List<Deliveries> delv = new List<Deliveries>();
            Console.WriteLine("\n\nЗапрос 09 \n\n" +
                              $"\tИтоговый запрос с левым соединением, выводящий общее количество подписок\n");

                // подключение к БД
                using (SqlConnection connection = new SqlConnection(_connectingString))
                {
                    //подключение к серверу 
                    connection.Open();

                    //создание команды запроса 
                    SqlCommand cmd = new SqlCommand(@"AllSubscription");

                    //задать соединение 
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.StoredProcedure;

                    //выполнение запроса
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            delv.Add(new Deliveries
                            {
                                PubType = reader.GetString(0),
                                DeliveriesAmount = reader.GetInt32(1)
                            });
                        }
                    }
                    
                    
                }

                return delv;
        }

       

       

        

       

        

        
    }
}
