﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Railway.Helpers;
using Railway.Models;

namespace Railway.Controllers
{
	// контроллер для класса Train
	public class TrainController
	{
		// объект модели данных
		private Train _train;
		public Train Train
		{
			get => _train;
			set
			{
				_train = value;
			}
		}

		// коллекция для представления в таблице
		private List<CarTableModel> _trainTable;

		public List<CarTableModel> TrainTable
		{
			get => _trainTable;
			set
			{
				_trainTable = value;
			}
		}

		// вернуть коллекцию вагонов поезда
		public List<Car> Cars => _train.Cars;


		// директория и имя файля для сохранения
		public string FileName { get; set; }

		// директория и имя файля для сохранения по-умолчанию
		public static readonly string FileNameDefault = Environment.CurrentDirectory + @"\App_Data\train.json";

		// конструкторы
		public TrainController() : this(FileNameDefault, new Train())
		{
			string dir = Path.GetDirectoryName(FileNameDefault);
			if (!Directory.Exists(dir))
				Directory.CreateDirectory(dir);
			
			if (File.Exists(FileNameDefault))
				ReadJsonFromFile(FileNameDefault);
			else
			{
				Initialize();
				SaveJsonToFile(FileNameDefault);
			}
		}

		public TrainController(string fileName, Train train)
		{
			_train = Train;
			_trainTable = new List<CarTableModel>();
			FileName = fileName;
		}

		public void Initialize() => Train = Train.Generate();



		public List<CarTableModel> GetTableModel(Car car)
		{
			List<CarTableModel> carTable = new List<CarTableModel>();

			foreach (var cmp in car.Compartments)
				foreach (var place in cmp.Places)
					carTable.Add(new CarTableModel()
					{
						CarNumber = car.Number,
						CarType = car.Type,
						CompartmentNumber = cmp.Number,
						PlaceNumber = place.Number,
						PlaceState = place.StateToString,
					});

			return carTable;
		}

		// сортировка вагонов по убыванию количества проданных мест 
		public void OrderBySoldDesc() => _train.OrderBy((c1, c2) =>
			c2.SoldPlacesCount.CompareTo(c1.SoldPlacesCount));
		
		//сортировка поезда по возрастанию номеров вагонов
		public void OrderByCarNumbersAsc() => 
			_train.OrderBy((c1, c2) => c1.Number.CompareTo(c2.Number));

		//сортировка поезда по убыванию номеров вагонов 
		public void OrderByCarNumbersDesc() =>
			_train.OrderBy((c1, c2) => c2.Number.CompareTo(c1.Number));


		// всего вагонов св
		public int CarsSvCount() => _train.CountCarsWhere(car => car.Type == "св");
		// всего вагонов купе 
		public int CarsCoupeCount() => _train.CountCarsWhere(car => car.Type == "купе");
		// всего вагонов плацкарт
		public int CarsEconomyCount() => _train.CountCarsWhere(car => car.Type == "плацкарт");

		// всего мест в поезде
		public int TotalPlaces() => _train.CountPlacesWhere(car => true, place => true);
		
		// всего мест вагонов св
		public int TotalSvPlaces() => _train.CountPlacesWhere(car => car.Type == "св", place => true);

		// всего мест вагонов купе 
		public int TotalCoupePlaces() => _train.CountPlacesWhere(car => car.Type == "купе", place => true);

		// всего мест вагонов плацкарт
		public int TotalEconomyPlaces() => _train.CountPlacesWhere(car => car.Type == "плацкарт", place => true);

		// всего мест продано в поезде
		public int TotalPlacesSold() => _train.CountPlacesWhere(car => true, place => !place.State);


		// всего мест продано вагонов св
		public int TotalSvPlacesSold() => _train.CountPlacesWhere(car => car.Type == "св", place => !place.State);

		// всего мест продано вагонов купе 
		public int TotalCoupePlacesSold() => _train.CountPlacesWhere(car => car.Type == "купе", place => !place.State);

		// всего мест продано вагонов плацкарт
		public int TotalEconomyPlacesSold() => _train.CountPlacesWhere(car => car.Type == "плацкарт", place => !place.State);


		public void AddCar(string type) => _train.AddCar(type);

		public void RemoveCar(Car car) => _train.RemoveCar(car);

		#region Сериализация
		// Сохранение в файл JSON форматом
		public void SaveJsonToFile(string fileName)
		{
			using (StreamWriter file = File.CreateText(fileName))
			{
				new JsonSerializer { Formatting = Formatting.Indented }.Serialize(file, _train);
			}
		}

		// Чтение из файла JSON форматом
		public void ReadJsonFromFile(string fileName)
		{

			using (StreamReader file = File.OpenText(fileName))
			{
				JsonSerializer serializer = new JsonSerializer();
				_train = (Train)serializer.Deserialize(file, typeof(Train));
				FileName = fileName;
			}
		}
		#endregion

	}
}
