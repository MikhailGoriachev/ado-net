﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3ADO.NET.Models
{
    //модель подписчика
    class Subscriber
    {
        public int id { get; set; }                 //айди
        public string Name { get; set; }            //имя
        public string Surname { get; set; }         //фамилия
        public string Patronymic { get; set; }      //отчество
        public int Passport { get; set; }           //номер пасспорта
        public string Street { get; set; }          //улица проживания
        public string NumHouse { get; set; }        //нмоер дома
        public string NumApartment { get; set; }    //номер квартиры

        public static string HeaderOfTable()
            => " ____________________________________________________________________________________\n" +
            "| id | \t\t\tФИО\t\t\t| Номер паспорта | Адресс проживания |\n" +
            "|____|__________________________________________|________________|___________________|";
        public static string BottomOfTable()
            => "|____|__________________________________________|________________|___________________|";
        public override string ToString()
            => $"{id}\t{Name}\t{Surname}\t{Patronymic}\t{Passport}\t{Street}\t{NumHouse}\t{NumApartment}";

        public string ToTableRow()
        {

            string address = Street + " " + NumHouse + " " + NumApartment;
            string fio = Surname + " " + Name + " " + Patronymic;
            return $"| {id,2} | {fio,-40} |     {Passport,5}     | {address,-17} |";
        }
    }
}
