﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
	public class Task1Controller
	{
		// строка подключения к базе данных
		private string _connectingString;
		public string ConnectingString
		{
			get => _connectingString;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new Exception("Не указана строка подключения к базе данных");

				_connectingString = value;
			}
		}

		public Task1Controller(string connectingString) =>
			ConnectingString = connectingString;


		// 1. Хранимая процедура	
		//Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа, 
		//стоимость 1 экземпляра для которых меньше заданной.
		public void Query01(string pubType, int price)
        {
	        List<PublicationsModel> publications = new List<PublicationsModel>();

	        // подключение к БД
	        using (SqlConnection connection = new SqlConnection(_connectingString))
	        {
		        connection.Open(); // подключение к серверу, блокирующий вызов

		        SqlCommand cmd = new SqlCommand("ProcQuery01", connection)
		        {
			        CommandType = CommandType.StoredProcedure
		        };

		        cmd.Parameters.AddWithValue("@pubType", pubType);
		        cmd.Parameters.AddWithValue("@price", price);


		        // выполнение запроса, ссылка на  выбранные данные - reader
		        SqlDataReader reader = cmd.ExecuteReader();

		        if (reader.HasRows)
			        while (reader.Read())
			        {
						publications.Add(new PublicationsModel()
						{
							Id = reader.GetInt32(0),
							PubType = reader.GetString(1),
							PubIndex = reader.GetString(2),
							Title = reader.GetString(3),
							Price = reader.GetInt32(4)
						});
			        }

		        Console.WriteLine();
	        }

			Console.Write(PublicationsModel.Header());
			publications.ForEach(x => Console.WriteLine(x.ToTableRow()));
			Console.Write(PublicationsModel.Footer());
		}

		// 2. Хранимая процедура	
		//Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома, 
		//которые оформили подписку на издание с заданным параметром наименованием
		public void Query02(string street, string building, string title)
        {
	        List<SubscribersModel> subscribers = new List<SubscribersModel>();

	        // подключение к БД
	        using (SqlConnection connection = new SqlConnection(_connectingString))
	        {
		        connection.Open(); // подключение к серверу, блокирующий вызов

		        SqlCommand cmd = new SqlCommand("ProcQuery02", connection)
		        {
			        CommandType = CommandType.StoredProcedure
		        };

		        cmd.Parameters.AddWithValue("@street", street);
		        cmd.Parameters.AddWithValue("@building", building);
		        cmd.Parameters.AddWithValue("@title", title);


		        // выполнение запроса, ссылка на  выбранные данные - reader
		        SqlDataReader reader = cmd.ExecuteReader();

		        if (reader.HasRows)
			        while (reader.Read())
			        {
						subscribers.Add(new SubscribersModel()
						{
							Id = reader.GetInt32(0),
							Surname = reader.GetString(1),
							Name = reader.GetString(2),
							Patronymic = reader.GetString(3),
							Passport = reader.GetString(4),
							Street = reader.GetString(5),
							Building = reader.GetString(6),
							Flat = reader.GetInt32(7)
						});
					}

		        Console.WriteLine();
	        }

			Console.Write(SubscribersModel.Header());
	        subscribers.ForEach(x => Console.WriteLine(x.ToTableRow()));
	        Console.Write(SubscribersModel.Footer());
		}

		// 3. Хранимая процедура	
		//Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле Цена 1 экземпляра
		//находится в заданном диапазоне значений
		public void Query03(int loPrice, int hiPrice)
		{

			List<PublicationsModel> publications = new List<PublicationsModel>();

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(_connectingString))
			{
				connection.Open(); // подключение к серверу, блокирующий вызов

				SqlCommand cmd = new SqlCommand("ProcQuery03", connection)
				{
					CommandType = CommandType.StoredProcedure
				};

				cmd.Parameters.AddWithValue("@loPrice", loPrice);
				cmd.Parameters.AddWithValue("@hiPrice", hiPrice);


				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.HasRows)
					while (reader.Read())
					{
						publications.Add(new PublicationsModel()
						{
							Id = reader.GetInt32(0),
							PubType = reader.GetString(1),
							PubIndex = reader.GetString(2),
							Title = reader.GetString(3),
							Price = reader.GetInt32(4)
						});
					}

				Console.WriteLine();
			}
			Console.Write(PublicationsModel.Header());
			publications.ForEach(x => Console.WriteLine(x.ToTableRow()));
			Console.Write(PublicationsModel.Footer());
		}


		// 4. Хранимая процедура
		//Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания
		public void Query04(string pubType)
		{
			List<SubscribersModel> subscribers = new List<SubscribersModel>();

			// подключение к БД
			using (SqlConnection connection = new SqlConnection(_connectingString))
			{
				connection.Open(); // подключение к серверу, блокирующий вызов

				SqlCommand cmd = new SqlCommand("ProcQuery04", connection)
				{
					CommandType = CommandType.StoredProcedure
				};

				cmd.Parameters.AddWithValue("@pubType", pubType);

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.HasRows)
					while (reader.Read())
					{
						subscribers.Add(new SubscribersModel()
						{
							Id = reader.GetInt32(0),
							Surname = reader.GetString(1),
							Name = reader.GetString(2),
							Patronymic = reader.GetString(3),
							Passport = reader.GetString(4),
							Street = reader.GetString(5),
							Building = reader.GetString(6),
							Flat = reader.GetInt32(7)
						});
					}

				Console.WriteLine();
			}
			Console.Write(SubscribersModel.Header());
			subscribers.ForEach(x => Console.WriteLine(x.ToTableRow()));
			Console.Write(SubscribersModel.Footer());
		}


		// 5. Хранимая процедура	
		//Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках, 
		//для которых срок подписки есть значение из некоторого диапазона
		public void Query05(int loDuration, int @hiDuration) =>
	        Utilities.ExecuteDbProcedure(_connectingString, @"ProcQuery05", new List<SqlParameter>
	        {
		        new ("@loDuration", loDuration),
		        new ("@hiDuration", hiDuration)
	        });


		// 6. Хранимая процедура	
		//Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. Включает поля 
		//Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки, Срок подписки, 
		//Стоимость подписки без НДС. Сортировка по полю Индекс издания
		public void Query06() => 
	        Utilities.ExecuteDbProcedure(_connectingString, @"ProcQuery06");


		// 7. Хранимая процедура	
		//Выполняет группировку по полю Вид издания. Для каждого вида вычисляет максимальную и
		//минимальную цену 1 экземпляра
		public void Query07() =>
	        Utilities.ExecuteDbProcedure(_connectingString, @"ProcQuery07");


		// 8. Хранимая процедура	
		//Выполняет группировку по полю Улица. Для всех улиц вычисляет количество подписчиков, проживающих на
		//данной улице (итоги по полю Код получателя)
		public void Query08() =>
	        Utilities.ExecuteDbProcedure(_connectingString, @"ProcQuery08");


		// 9. Хранимая процедура	
		//Для всех изданий выводит количество оформленных подписок
		public void Query09() =>
	        Utilities.ExecuteDbProcedure(_connectingString, @"ProcQuery09");
	}
}


