﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainTickets.ViewModels
{
    // модель для отображения данных вагона в DataGridView
    //     • номер вагона
    //     • тип вагона
    //     • номер купе
    //     • номер места
    //     • признак продано/свободно
    public class CarriageView
    {
        public int    Number { get; set; }                   // номер вагона
        public string CarriageType { get; set; }             // тип вагона
        public int    CompartmentNumber { get; set; }        // номер купе
        public int    SeatNumber { get; set; }               // номер места
        public string Sold { get; set; }                     // продано / свободно

    } // class CarriageView
}
