﻿using HomeWork.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Controllers
{
    public class Task1Controller
    {
        // список товаров
        private List<Goods> _listGoods;
        public List<Goods> ListGoods
        {
            get { return _listGoods; }
            set { _listGoods = value; }
        }


        // конструктор по умолчанию
        public Task1Controller() {

            _listGoods = new List<Goods>();
            InitListGoods(12);
        }

        
        // заполнение массива товаров
        public void InitListGoods(int count) {
            _listGoods.Clear();

            for (int i = 0; i < count; i++)
            {
                _listGoods.Add(Goods.CreateGoods());
            }
        }

        /*
        *Задача 1. Для класса, представляющего товар (наименование, цена, количество, год выпуска) 
        *          разработать расширяющий метод, возвращающий процент скидки в зависимости от возраста товара
        *              – до 3х лет скидка не представляется, 
        *              от 3х до 10 лет скидка 3%, 
        *              свыше 10 лет – скидка 7%. 
        *          Продемонстрировать работу метода на коллекции из 12 товаров.
        */
        // демострация работы расширящего метода
        public void Demo() {

            InitListGoods(12);

            StringBuilder sb = new StringBuilder();
            sb.Append("Задача 1. Для класса, представляющего товар (наименование, цена, количество, год выпуска)\n");
            sb.Append("\t  разработать расширяющий метод, возвращающий процент скидки в зависимости от возраста товара\n");
            sb.Append("\t\t– до 3х лет скидка не представляется, \n");
            sb.Append("\t\tот 3х до 10 лет скидка 3%,\n");
            sb.Append("\t\tсвыше 10 лет – скидка 7%. \n");
            sb.Append("\t  Продемонстрировать работу метода на коллекции из 12 товаров.\n");
            Console.WriteLine(sb.ToString());
          
            Console.WriteLine(Goods.HeaderDiscount());
            foreach (var item in _listGoods)
            {
                Console.WriteLine(item.ToTableRowDiscount(item.Discount())); 
            }
            Console.WriteLine(Goods.FooterDiscount());

        }// demo

    }// Task1Controller


    // класс для метода/методов расширения
    static class MyExtendedMethods
    {
        // расширяющий метод, возвращающий процент скидки в зависимости от возраста товара – до 3х лет скидка не представляется,
        // от 3х до 10 лет скидка 3%, свыше 10 лет – скидка 7%. 
        // формат заголовка метода (метод - статический!!!)
        // public static тип ИмяМетода(this ИмяРасширяемогоКласса объектРасширяемогоКласса, тип1 пар1, ...) {}
        public static int Discount(this Goods x)
        {
            int goodsAge = DateTime.Now.Year - x.Year;
            int result = 0;
            switch (goodsAge)
            {
                case 0:
                case 1:
                case 2:
                    break;

                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                    result = 3;
                    break;

                default:
                    result = 7;
                    break;
            }

            return result;

        } // SqrLength


    } // class ForMyExtendedMethods
}
