﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Task01
{
    // для хранения результата запросов 1 и 2 из задачи 1
    // данные книги, фамилия И.О. автора и год рождения автора
    public class ResultQuery01and02 {
        // фамилия И.О. автора
        public string FullName { get; set; } // FullName

        // год рождения автора
        public int YearOfBirth { get; set; } // YearOfBirth

        // идентификатор
        public int Id { get; set; } // Id

        // название книги
        public string Title  { get; set; }

        // год издания
        public int Year { get; set; } // Year

        // цена
        public int Price { get; set; } // Price

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {Id,3} │ {(Title.Length > 31 ? $"{Title.Substring(0,28)}..." : $"{Title, -31}")} │ {Year,11} │ {Price,15:f2}  │ {FullName,-15} │ {YearOfBirth,12} │";

        // статический метод для вывода шапки таблицы
        public static string Header() {
            return
                $"  ┌─────┬─────────────────────────────────┬─────────────┬──────────────────┬─────────────────┬──────────────┐\n" +
                $"  │ ID  │ Название книги                  │ Год издания │ Cтоимость 1 ед.  │ Автор           │ Год рождения │\n" +
                $"  ├─────┼─────────────────────────────────┼─────────────┼──────────────────┼─────────────────┼──────────────┤";
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────┴─────────────────────────────────┴─────────────┴──────────────────┴─────────────────┴──────────────┘\n";
    } // ResultQuery01
}
