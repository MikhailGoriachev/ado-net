﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ConfigSecurityModels.Application;
using ConfigSecurityModels.Helpers;

namespace ConfigSecurityModels
{
   class Program
    {
       static void Main(string[] args) {
            Console.Title = "Задание на 10.01.2022 - выполнение запросов в подключенном режиме, шифрование конфигурационного файла";

            // простейшее меню приложения
            List<MenuItem> menu = new List<MenuItem>(new[]{
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Запрос 1. Издания со стоимостью экземпляра ниже заданной" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Запрос 2. Подписчики заданного издания, проживающие по заданному адресу" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Запрос 3. Издания с ценой в заданом диапазоне" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Запрос 4. Подписчики, подписавшиеся на заданный тип издания" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Запрос 5. Подписки, оформленные на срок из заданного диапазона" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Запрос 6. Стоимость оформленных подписок с доставкой, без НДС" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Запрос 7. Минимальная и максимальная цена одного экземпляра по видам изданий" },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Запрос 8. Количество подписчиков по улицам" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Запрос 9. Количество оформленных подписок по видам изданий" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Separator" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Шифровать конфигурационный файл" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Расшифровать конфигурационный файл" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Separator" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            });
            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 10.01.2022 - шифрование конфигурационного файла, модели в запросах");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        #region Выполнение запросов по задаче 1
                        // Запрос 1. Издания со стоимостью экземпляра ниже заданной
                        case ConsoleKey.Q:
                            app.ExecQuery01();
                            break;

                        // Запрос 2. Подписчики заданного издания, проживающие по заданному адресу
                        case ConsoleKey.W:
                            app.ExecQuery02();
                            break;

                        // Запрос 3. Издания с ценой в заданом диапазоне
                        case ConsoleKey.E:
                            app.ExecQuery03();
                            break;

                        // Запрос 4. Подписчики, подписавшиеся на заданный тип издания
                        case ConsoleKey.R:
                            app.ExecQuery04();
                            break;

                        // Запрос 5. Подписки, оформленные на срок из заданного диапазона
                        case ConsoleKey.T:
                            app.ExecQuery05();
                            break;

                        // Запрос 6. Стоимость оформленных подписок с доставкой, без НДС 
                        case ConsoleKey.Y:
                            app.ExecQuery06();
                            break;

                        // Запрос 7. Минимальная и максимальная цена одного экземпляра по видам изданий
                        case ConsoleKey.U:
                            app.ExecQuery07();
                            break;

                        // Запрос 8. Количество подписчиков по улицам
                        case ConsoleKey.I:
                            app.ExecQuery08();
                            break;

                        // Запрос 9. Количество оформленных подписок по видам изданий
                        case ConsoleKey.O:
                            app.ExecQuery09();
                            break;
                        #endregion

                        #region Шифрование, расшифровка конфигурационного файла
                        // Шифрование конфигурационного файла
                        case ConsoleKey.A:
                            app.EncodeConfigFile();
                            break;

                        // Расшифровка когфигурационного файла
                        case ConsoleKey.S:
                            app.decodeConfigFile();
                            break;
                        #endregion

                        // выход из приложения назначен на клавишу F10 или кавишу Z или на клавишу Esc
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                } catch (Exception ex) {
                    // получить первые 79 символов сообщения об ошибке
                    string str = ex.Message.Length > 79?ex.Message.Substring(0, 79):ex.Message;

                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20,  9, $"                                                                                        ", ConsoleColor.White);
                    Utils.WriteXY(20, 10, $"  ┌──────────────────────────────────────────────────────────────────────────────────┐  ", ConsoleColor.White);
                    Utils.WriteXY(20, 11, $"  │                                   Исключение.                                    │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  │ {str, -79}  │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 13, $"  │                                                                                  │  ", ConsoleColor.White);
                    Utils.WriteXY(20, 14, $"  └──────────────────────────────────────────────────────────────────────────────────┘  ", ConsoleColor.White);
                    Utils.WriteXY(20, 15, $"                                                                                        ", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                } finally {
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                } // try-catch
            } // while
       } // Main
    } // class Program
}
