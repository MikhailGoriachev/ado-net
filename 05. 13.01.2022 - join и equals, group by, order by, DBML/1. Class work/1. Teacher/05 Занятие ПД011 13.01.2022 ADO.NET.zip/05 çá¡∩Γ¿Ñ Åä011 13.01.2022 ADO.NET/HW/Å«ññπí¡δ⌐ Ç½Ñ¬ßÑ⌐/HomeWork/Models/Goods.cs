﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Models
{
    // класс, описующий товар
    public class Goods
    {
        // наименование
        private string _name;
        public string Name
        {
            get { return _name; }
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Goods: ошибка имени товара");
                    _name = value; }
        }

        // цена
        private double _price;
        public double Price
        {
            get { return _price; }
            set { if (value <= 0)
                    throw new Exception("Goods: ошибка цены товара");
                    _price = value; }
        }


        // количество
        private int _amount;
        public int Amount
        {
            get { return _amount; }
            set { if (value < 0)
                    throw new Exception("Goods: ошибка количества товара");
                    _amount = value; }
        }

        // год выпуска
        private int _year;
        public int Year
        {
            get { return _year; }
            set { if (value < 0)
                    throw new Exception("Goods: ошибка года выпуска товара");
                    _year = value; }
        }



        // конструктор
        public Goods(string name, double price, int amount, int year) {

            Name = name;
            Price = price;
            Amount = amount;
            Year = year;       
        
        }




        public static string Header()
        {

            return
            $"┌────────────────────────────┬────────────────┬────────────┬────────────────┐\n" +
            $"│        Наименование        │      Цена      │ Количество │   Год выпуска  │\n" +
            $"├────────────────────────────┼────────────────┼────────────┼────────────────┤";

        }

        public string ToTableRow() =>
            $"│ {Name,-26} │ {Price,14} │ {Amount,10} │ {Year,14} │";


        public static string Footer() =>
            $"└────────────────────────────┴────────────────┴────────────┴────────────────┘\n";


        public static string HeaderDiscount()
        {

            return
            $"┌────────────────────────────┬────────────────┬────────────┬────────────────┬────────────────┐\n" +
            $"│        Наименование        │      Цена, р   │ Количество │   Год выпуска  │     Скидка, %  │\n" +
            $"├────────────────────────────┼────────────────┼────────────┼────────────────┼────────────────┤";

        }

        public string ToTableRowDiscount(int discount) =>
            $"│ {Name,-26} │ {Price,14} │ {Amount,10} │ {Year,14} │ {discount, 14} │";


        public static string FooterDiscount() =>
            $"└────────────────────────────┴────────────────┴────────────┴────────────────┴────────────────┘\n";



        public static string HeaderCoast()
        {

            return
            $"┌────────────────────────────┬────────────────┬────────────┬────────────────┬──────────────────────┐\n" +
            $"│        Наименование        │      Цена, р   │ Количество │   Год выпуска  │        Сумма         │\n" +
            $"├────────────────────────────┼────────────────┼────────────┼────────────────┼──────────────────────┤";

        }

       


        public static string FooterCoast() =>
            $"└────────────────────────────┴────────────────┴────────────┴────────────────┴──────────────────────┘\n";


        #region ФОРМИРОВАНИЕ ТОВАРА


        // тип товара
        static string[] GoodsNames =  {
                ("Зимняя шина"),
                ("Летняя шина"),
                ("Диски"),
                ("Колпаки")

         };

        // бренд
        static string[] Brands =  {
                ("Toyo"      ),
                ("Michelin"  ),
                ("GoodYear"  ),
                ("Komo"      ),
                ("EZ"        ),
                ("Pirelli"   ),
                ("YOKOHAMA"  ),
                ("Hankook"   )

         };

        // фабрика создания товара
        public static Goods CreateGoods()
        {

            return new Goods(
                GoodsNames[Utils.GetRandom(0, GoodsNames.Length )] + " "+
                Brands[Utils.GetRandom(0, Brands.Length - 1)],
                Utils.GetRandom(10, 150) * 100,
                Utils.GetRandom(5, 30),
                Utils.GetRandom(2008, DateTime.Now.Year)
                );           
        }



        #endregion




    }




}
