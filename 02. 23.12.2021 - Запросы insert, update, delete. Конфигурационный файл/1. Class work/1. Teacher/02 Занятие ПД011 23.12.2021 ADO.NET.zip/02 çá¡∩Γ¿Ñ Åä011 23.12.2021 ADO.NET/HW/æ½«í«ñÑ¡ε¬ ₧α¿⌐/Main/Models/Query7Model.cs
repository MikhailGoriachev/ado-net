﻿using System;
using System.Data;
using Main.Utilities.TableFormatter;


namespace Main.Models
{
	/*
	a.AgentsId			as AgentId,
	Count(ClientsId)	as DealsCount,
	Sum(d.Price)		as DealsTotal
	 */
	public sealed class Query7Model : IMappable<Query7Model>
	{
		[TableData("Агент", "{0, -14:N0}")]
		public int AgentId { get; set; }

		[TableData("Кол-во сделок", "{0, -18:N0}")]
		public int DealsCount { get; set; }

		[TableData("Сумма сделок", "{0, -18:N0}")]
		public decimal DealsTotal { get; set; }

		public Query7Model Map(DataRow row) =>
			new()
			{
				AgentId    = (int)row["AgentId"],
				DealsCount = (int)(Convert.IsDBNull(row["DealsCount"]) ? 0 : row["DealsCount"]),
				DealsTotal = (decimal)(Convert.IsDBNull(row["DealsTotal"]) ? 0m : row["DealsTotal"])
			};
	}
}