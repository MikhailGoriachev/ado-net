﻿
namespace Railway.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			this.TsbMain = new System.Windows.Forms.ToolStrip();
			this.TsbNew = new System.Windows.Forms.ToolStripButton();
			this.TsbOpen = new System.Windows.Forms.ToolStripButton();
			this.TsbSave = new System.Windows.Forms.ToolStripButton();
			this.TsbSaveAs = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbAdd = new System.Windows.Forms.ToolStripDropDownButton();
			this.TbsAddSv = new System.Windows.Forms.ToolStripMenuItem();
			this.TbsAddCoupe = new System.Windows.Forms.ToolStripMenuItem();
			this.TbsAddEconomy = new System.Windows.Forms.ToolStripMenuItem();
			this.TsbRemove = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbBuy = new System.Windows.Forms.ToolStripButton();
			this.TsbRefund = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbOrderSoldDesc = new System.Windows.Forms.ToolStripButton();
			this.TsbOrderCarsAsc = new System.Windows.Forms.ToolStripButton();
			this.TsbOrderCarsDesc = new System.Windows.Forms.ToolStripButton();
			this.StlMain = new System.Windows.Forms.StatusStrip();
			this.TsStl = new System.Windows.Forms.ToolStripStatusLabel();
			this.SpcMain = new System.Windows.Forms.SplitContainer();
			this.TrvMain = new System.Windows.Forms.TreeView();
			this.ImlTree = new System.Windows.Forms.ImageList(this.components);
			this.DgvMain = new System.Windows.Forms.DataGridView();
			this.MniMain = new System.Windows.Forms.MenuStrip();
			this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
			this.создатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.сохранитьКакToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.MniEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.MniEditAdd = new System.Windows.Forms.ToolStripMenuItem();
			this.MniEditAddSv = new System.Windows.Forms.ToolStripMenuItem();
			this.MniEditAddCoupe = new System.Windows.Forms.ToolStripMenuItem();
			this.MniEditAddEconomy = new System.Windows.Forms.ToolStripMenuItem();
			this.MniEditRemove = new System.Windows.Forms.ToolStripMenuItem();
			this.MniTickets = new System.Windows.Forms.ToolStripMenuItem();
			this.MniTicketsBuy = new System.Windows.Forms.ToolStripMenuItem();
			this.MniTicketsRefund = new System.Windows.Forms.ToolStripMenuItem();
			this.MniOrder = new System.Windows.Forms.ToolStripMenuItem();
			this.MniOrderCarNumbersAsc = new System.Windows.Forms.ToolStripMenuItem();
			this.MniOrderCarNumbersDesc = new System.Windows.Forms.ToolStripMenuItem();
			this.MniOrderSoldDesc = new System.Windows.Forms.ToolStripMenuItem();
			this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvTrain = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrvAdd = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvAddSv = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvAddCoupe = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvAddEconomy = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvCar = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrvRemove = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvPlace = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrvBuy = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvRefund = new System.Windows.Forms.ToolStripMenuItem();
			this.BnsTrain = new System.Windows.Forms.BindingSource(this.components);
			this.SfdMain = new System.Windows.Forms.SaveFileDialog();
			this.OfdMain = new System.Windows.Forms.OpenFileDialog();
			this.TpMain = new System.Windows.Forms.ToolTip(this.components);
			this.ClnNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ClnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ClnCmpNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ClnPlaceNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ClnState = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TsbMain.SuspendLayout();
			this.StlMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.SpcMain)).BeginInit();
			this.SpcMain.Panel1.SuspendLayout();
			this.SpcMain.Panel2.SuspendLayout();
			this.SpcMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvMain)).BeginInit();
			this.MniMain.SuspendLayout();
			this.CmnTrvTrain.SuspendLayout();
			this.CmnTrvCar.SuspendLayout();
			this.CmnTrvPlace.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.BnsTrain)).BeginInit();
			this.SuspendLayout();
			// 
			// TsbMain
			// 
			this.TsbMain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.TsbMain.ImageScalingSize = new System.Drawing.Size(30, 30);
			this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNew,
            this.TsbOpen,
            this.TsbSave,
            this.TsbSaveAs,
            this.toolStripSeparator1,
            this.TsbAdd,
            this.TsbRemove,
            this.toolStripSeparator2,
            this.TsbBuy,
            this.TsbRefund,
            this.toolStripSeparator5,
            this.TsbOrderSoldDesc,
            this.TsbOrderCarsAsc,
            this.TsbOrderCarsDesc});
			this.TsbMain.Location = new System.Drawing.Point(0, 27);
			this.TsbMain.Name = "TsbMain";
			this.TsbMain.Padding = new System.Windows.Forms.Padding(6, 1, 17, 1);
			this.TsbMain.Size = new System.Drawing.Size(954, 39);
			this.TsbMain.TabIndex = 0;
			this.TsbMain.Text = "toolStrip1";
			// 
			// TsbNew
			// 
			this.TsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbNew.Image = global::Railway.Properties.Resources.file_new;
			this.TsbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbNew.Name = "TsbNew";
			this.TsbNew.Size = new System.Drawing.Size(34, 34);
			this.TsbNew.Text = "Создать";
			this.TsbNew.Click += new System.EventHandler(this.FileNew_Command);
			// 
			// TsbOpen
			// 
			this.TsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOpen.Image = global::Railway.Properties.Resources.file_open;
			this.TsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOpen.Name = "TsbOpen";
			this.TsbOpen.Size = new System.Drawing.Size(34, 34);
			this.TsbOpen.Text = "Открыть";
			this.TsbOpen.Click += new System.EventHandler(this.FileOpen_Command);
			// 
			// TsbSave
			// 
			this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbSave.Image = global::Railway.Properties.Resources.file_save;
			this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbSave.Name = "TsbSave";
			this.TsbSave.Size = new System.Drawing.Size(34, 34);
			this.TsbSave.Text = "Сохранить";
			this.TsbSave.Click += new System.EventHandler(this.Save_Command);
			// 
			// TsbSaveAs
			// 
			this.TsbSaveAs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbSaveAs.Image = global::Railway.Properties.Resources.file_saveas;
			this.TsbSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbSaveAs.Name = "TsbSaveAs";
			this.TsbSaveAs.Size = new System.Drawing.Size(34, 34);
			this.TsbSaveAs.Text = "Сохранить как...";
			this.TsbSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbAdd
			// 
			this.TsbAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbAdd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TbsAddSv,
            this.TbsAddCoupe,
            this.TbsAddEconomy});
			this.TsbAdd.Image = global::Railway.Properties.Resources.add;
			this.TsbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbAdd.Name = "TsbAdd";
			this.TsbAdd.Size = new System.Drawing.Size(43, 34);
			this.TsbAdd.Text = "Добавить вагон";
			// 
			// TbsAddSv
			// 
			this.TbsAddSv.Name = "TbsAddSv";
			this.TbsAddSv.Size = new System.Drawing.Size(176, 24);
			this.TbsAddSv.Text = "Вагон СВ";
			this.TbsAddSv.Click += new System.EventHandler(this.AddSvCar_Command);
			// 
			// TbsAddCoupe
			// 
			this.TbsAddCoupe.Name = "TbsAddCoupe";
			this.TbsAddCoupe.Size = new System.Drawing.Size(176, 24);
			this.TbsAddCoupe.Text = "Вагон купе";
			this.TbsAddCoupe.Click += new System.EventHandler(this.AddCoupeCar_Command);
			// 
			// TbsAddEconomy
			// 
			this.TbsAddEconomy.Name = "TbsAddEconomy";
			this.TbsAddEconomy.Size = new System.Drawing.Size(176, 24);
			this.TbsAddEconomy.Text = "Вагон плацкарт";
			this.TbsAddEconomy.Click += new System.EventHandler(this.AddEconomyCar_Command);
			// 
			// TsbRemove
			// 
			this.TsbRemove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRemove.Image = global::Railway.Properties.Resources.seat_sold;
			this.TsbRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRemove.Name = "TsbRemove";
			this.TsbRemove.Size = new System.Drawing.Size(34, 34);
			this.TsbRemove.Text = "Удалить вагон";
			this.TsbRemove.Click += new System.EventHandler(this.RemoveCar_Command);
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbBuy
			// 
			this.TsbBuy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbBuy.Image = global::Railway.Properties.Resources.buy_ticket;
			this.TsbBuy.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbBuy.Name = "TsbBuy";
			this.TsbBuy.Size = new System.Drawing.Size(34, 34);
			this.TsbBuy.Text = "Купить билет";
			this.TsbBuy.Click += new System.EventHandler(this.BuyTicket_Command);
			// 
			// TsbRefund
			// 
			this.TsbRefund.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRefund.Image = global::Railway.Properties.Resources.refund_ticket;
			this.TsbRefund.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRefund.Name = "TsbRefund";
			this.TsbRefund.Size = new System.Drawing.Size(34, 34);
			this.TsbRefund.Text = "Вернуть билет";
			this.TsbRefund.Click += new System.EventHandler(this.RefundTicketCommand);
			// 
			// toolStripSeparator5
			// 
			this.toolStripSeparator5.Name = "toolStripSeparator5";
			this.toolStripSeparator5.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbOrderSoldDesc
			// 
			this.TsbOrderSoldDesc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderSoldDesc.Image = global::Railway.Properties.Resources.order_places_desc;
			this.TsbOrderSoldDesc.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderSoldDesc.Name = "TsbOrderSoldDesc";
			this.TsbOrderSoldDesc.Size = new System.Drawing.Size(34, 34);
			this.TsbOrderSoldDesc.Text = "Cортировка вагонов по убыванию количества проданных мест";
			this.TsbOrderSoldDesc.Click += new System.EventHandler(this.OrderSoldDesc_Command);
			// 
			// TsbOrderCarsAsc
			// 
			this.TsbOrderCarsAsc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderCarsAsc.Image = global::Railway.Properties.Resources.order_numbers_asc;
			this.TsbOrderCarsAsc.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderCarsAsc.Name = "TsbOrderCarsAsc";
			this.TsbOrderCarsAsc.Size = new System.Drawing.Size(34, 34);
			this.TsbOrderCarsAsc.Text = "Cортировка поезда по возрастанию номеров вагонов";
			this.TsbOrderCarsAsc.Click += new System.EventHandler(this.OrderNumbersAsc_Command);
			// 
			// TsbOrderCarsDesc
			// 
			this.TsbOrderCarsDesc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderCarsDesc.Image = global::Railway.Properties.Resources.order_numbers_desc;
			this.TsbOrderCarsDesc.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderCarsDesc.Name = "TsbOrderCarsDesc";
			this.TsbOrderCarsDesc.Size = new System.Drawing.Size(34, 34);
			this.TsbOrderCarsDesc.Text = "Cортировка поезда по убыванию номеров вагонов";
			this.TsbOrderCarsDesc.Click += new System.EventHandler(this.OrderNumbersDesc_Command);
			// 
			// StlMain
			// 
			this.StlMain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.StlMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsStl});
			this.StlMain.Location = new System.Drawing.Point(0, 398);
			this.StlMain.Name = "StlMain";
			this.StlMain.Size = new System.Drawing.Size(954, 24);
			this.StlMain.TabIndex = 1;
			// 
			// TsStl
			// 
			this.TsStl.Name = "TsStl";
			this.TsStl.Size = new System.Drawing.Size(139, 19);
			this.TsStl.Text = "toolStripStatusLabel1";
			// 
			// SpcMain
			// 
			this.SpcMain.BackColor = System.Drawing.Color.Transparent;
			this.SpcMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.SpcMain.Location = new System.Drawing.Point(0, 66);
			this.SpcMain.Name = "SpcMain";
			// 
			// SpcMain.Panel1
			// 
			this.SpcMain.Panel1.Controls.Add(this.TrvMain);
			// 
			// SpcMain.Panel2
			// 
			this.SpcMain.Panel2.Controls.Add(this.DgvMain);
			this.SpcMain.Size = new System.Drawing.Size(954, 332);
			this.SpcMain.SplitterDistance = 287;
			this.SpcMain.TabIndex = 2;
			// 
			// TrvMain
			// 
			this.TrvMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.TrvMain.ImageIndex = 0;
			this.TrvMain.ImageList = this.ImlTree;
			this.TrvMain.Location = new System.Drawing.Point(0, 0);
			this.TrvMain.Name = "TrvMain";
			this.TrvMain.SelectedImageIndex = 0;
			this.TrvMain.ShowNodeToolTips = true;
			this.TrvMain.Size = new System.Drawing.Size(287, 332);
			this.TrvMain.TabIndex = 0;
			this.TrvMain.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.TrvMain_NodeMouseClick);
			this.TrvMain.DragDrop += new System.Windows.Forms.DragEventHandler(this.Command_DragDrop);
			this.TrvMain.DragEnter += new System.Windows.Forms.DragEventHandler(this.Command_DragEnter);
			// 
			// ImlTree
			// 
			this.ImlTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlTree.ImageStream")));
			this.ImlTree.TransparentColor = System.Drawing.Color.Transparent;
			this.ImlTree.Images.SetKeyName(0, "seat_available.png");
			this.ImlTree.Images.SetKeyName(1, "seat_sold.png");
			this.ImlTree.Images.SetKeyName(2, "train.png");
			this.ImlTree.Images.SetKeyName(3, "car.png");
			this.ImlTree.Images.SetKeyName(4, "cmp.png");
			// 
			// DgvMain
			// 
			this.DgvMain.AllowDrop = true;
			this.DgvMain.AllowUserToAddRows = false;
			this.DgvMain.AllowUserToDeleteRows = false;
			this.DgvMain.AllowUserToResizeColumns = false;
			this.DgvMain.AllowUserToResizeRows = false;
			this.DgvMain.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvMain.BackgroundColor = System.Drawing.SystemColors.Control;
			this.DgvMain.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.DgvMain.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
			this.DgvMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.DgvMain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClnNum,
            this.ClnType,
            this.ClnCmpNumber,
            this.ClnPlaceNum,
            this.ClnState});
			this.DgvMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.DgvMain.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			this.DgvMain.Location = new System.Drawing.Point(0, 0);
			this.DgvMain.MultiSelect = false;
			this.DgvMain.Name = "DgvMain";
			this.DgvMain.ReadOnly = true;
			this.DgvMain.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
			this.DgvMain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvMain.Size = new System.Drawing.Size(663, 332);
			this.DgvMain.TabIndex = 0;
			this.DgvMain.DragDrop += new System.Windows.Forms.DragEventHandler(this.Command_DragDrop);
			this.DgvMain.DragEnter += new System.Windows.Forms.DragEventHandler(this.Command_DragEnter);
			// 
			// MniMain
			// 
			this.MniMain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.MniMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniEdit,
            this.MniTickets,
            this.MniOrder,
            this.MniHelp});
			this.MniMain.Location = new System.Drawing.Point(0, 0);
			this.MniMain.Name = "MniMain";
			this.MniMain.Size = new System.Drawing.Size(954, 27);
			this.MniMain.TabIndex = 3;
			this.MniMain.Text = "menuStrip1";
			// 
			// MniFile
			// 
			this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьToolStripMenuItem,
            this.открытьToolStripMenuItem,
            this.сохранитьToolStripMenuItem,
            this.сохранитьКакToolStripMenuItem,
            this.toolStripSeparator3,
            this.MniFileExit});
			this.MniFile.Name = "MniFile";
			this.MniFile.Size = new System.Drawing.Size(53, 23);
			this.MniFile.Text = "Файл";
			// 
			// создатьToolStripMenuItem
			// 
			this.создатьToolStripMenuItem.Name = "создатьToolStripMenuItem";
			this.создатьToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
			this.создатьToolStripMenuItem.Text = "Создать";
			this.создатьToolStripMenuItem.Click += new System.EventHandler(this.FileNew_Command);
			// 
			// открытьToolStripMenuItem
			// 
			this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
			this.открытьToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
			this.открытьToolStripMenuItem.Text = "Открыть...";
			this.открытьToolStripMenuItem.Click += new System.EventHandler(this.FileOpen_Command);
			// 
			// сохранитьToolStripMenuItem
			// 
			this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
			this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
			this.сохранитьToolStripMenuItem.Text = "Сохранить";
			this.сохранитьToolStripMenuItem.Click += new System.EventHandler(this.Save_Command);
			// 
			// сохранитьКакToolStripMenuItem
			// 
			this.сохранитьКакToolStripMenuItem.Name = "сохранитьКакToolStripMenuItem";
			this.сохранитьКакToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
			this.сохранитьКакToolStripMenuItem.Text = "Сохранить как...";
			this.сохранитьКакToolStripMenuItem.Click += new System.EventHandler(this.SaveAs_Command);
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(176, 6);
			// 
			// MniFileExit
			// 
			this.MniFileExit.Name = "MniFileExit";
			this.MniFileExit.Size = new System.Drawing.Size(179, 24);
			this.MniFileExit.Text = "Выход";
			this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// MniEdit
			// 
			this.MniEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniEditAdd,
            this.MniEditRemove});
			this.MniEdit.Name = "MniEdit";
			this.MniEdit.Size = new System.Drawing.Size(60, 23);
			this.MniEdit.Text = "Поезд";
			// 
			// MniEditAdd
			// 
			this.MniEditAdd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniEditAddSv,
            this.MniEditAddCoupe,
            this.MniEditAddEconomy});
			this.MniEditAdd.Name = "MniEditAdd";
			this.MniEditAdd.Size = new System.Drawing.Size(178, 24);
			this.MniEditAdd.Text = "Добавить вагон";
			// 
			// MniEditAddSv
			// 
			this.MniEditAddSv.Name = "MniEditAddSv";
			this.MniEditAddSv.Size = new System.Drawing.Size(138, 24);
			this.MniEditAddSv.Text = "СВ";
			this.MniEditAddSv.Click += new System.EventHandler(this.AddSvCar_Command);
			// 
			// MniEditAddCoupe
			// 
			this.MniEditAddCoupe.Name = "MniEditAddCoupe";
			this.MniEditAddCoupe.Size = new System.Drawing.Size(138, 24);
			this.MniEditAddCoupe.Text = "Купе";
			this.MniEditAddCoupe.Click += new System.EventHandler(this.AddCoupeCar_Command);
			// 
			// MniEditAddEconomy
			// 
			this.MniEditAddEconomy.Name = "MniEditAddEconomy";
			this.MniEditAddEconomy.Size = new System.Drawing.Size(138, 24);
			this.MniEditAddEconomy.Text = "Плацкарт";
			this.MniEditAddEconomy.Click += new System.EventHandler(this.AddEconomyCar_Command);
			// 
			// MniEditRemove
			// 
			this.MniEditRemove.Name = "MniEditRemove";
			this.MniEditRemove.Size = new System.Drawing.Size(178, 24);
			this.MniEditRemove.Text = "Удалить вагон";
			this.MniEditRemove.Click += new System.EventHandler(this.RemoveCar_Command);
			// 
			// MniTickets
			// 
			this.MniTickets.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTicketsBuy,
            this.MniTicketsRefund});
			this.MniTickets.Name = "MniTickets";
			this.MniTickets.Size = new System.Drawing.Size(67, 23);
			this.MniTickets.Text = "Билеты";
			// 
			// MniTicketsBuy
			// 
			this.MniTicketsBuy.Name = "MniTicketsBuy";
			this.MniTicketsBuy.Size = new System.Drawing.Size(179, 24);
			this.MniTicketsBuy.Text = "Покупка билета";
			this.MniTicketsBuy.Click += new System.EventHandler(this.BuyTicket_Command);
			// 
			// MniTicketsRefund
			// 
			this.MniTicketsRefund.Name = "MniTicketsRefund";
			this.MniTicketsRefund.Size = new System.Drawing.Size(179, 24);
			this.MniTicketsRefund.Text = "Возврат билета";
			this.MniTicketsRefund.Click += new System.EventHandler(this.RefundTicketCommand);
			// 
			// MniOrder
			// 
			this.MniOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniOrderCarNumbersAsc,
            this.MniOrderCarNumbersDesc,
            this.MniOrderSoldDesc});
			this.MniOrder.Name = "MniOrder";
			this.MniOrder.Size = new System.Drawing.Size(97, 23);
			this.MniOrder.Text = "Сортировка";
			// 
			// MniOrderCarNumbersAsc
			// 
			this.MniOrderCarNumbersAsc.Name = "MniOrderCarNumbersAsc";
			this.MniOrderCarNumbersAsc.Size = new System.Drawing.Size(410, 24);
			this.MniOrderCarNumbersAsc.Text = "по возрастанию номеров вагонов";
			this.MniOrderCarNumbersAsc.Click += new System.EventHandler(this.OrderNumbersAsc_Command);
			// 
			// MniOrderCarNumbersDesc
			// 
			this.MniOrderCarNumbersDesc.Name = "MniOrderCarNumbersDesc";
			this.MniOrderCarNumbersDesc.Size = new System.Drawing.Size(410, 24);
			this.MniOrderCarNumbersDesc.Text = "по убыванию номеров вагонов";
			this.MniOrderCarNumbersDesc.Click += new System.EventHandler(this.OrderNumbersDesc_Command);
			// 
			// MniOrderSoldDesc
			// 
			this.MniOrderSoldDesc.Name = "MniOrderSoldDesc";
			this.MniOrderSoldDesc.Size = new System.Drawing.Size(410, 24);
			this.MniOrderSoldDesc.Text = "по убыванию количества проданных в вагонах мест";
			this.MniOrderSoldDesc.Click += new System.EventHandler(this.OrderSoldDesc_Command);
			// 
			// MniHelp
			// 
			this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
			this.MniHelp.Name = "MniHelp";
			this.MniHelp.Size = new System.Drawing.Size(74, 23);
			this.MniHelp.Text = "Справка";
			// 
			// MniHelpAbout
			// 
			this.MniHelpAbout.Name = "MniHelpAbout";
			this.MniHelpAbout.Size = new System.Drawing.Size(164, 24);
			this.MniHelpAbout.Text = "О программе";
			this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// CmnTrvTrain
			// 
			this.CmnTrvTrain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.CmnTrvTrain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrvAdd});
			this.CmnTrvTrain.Name = "CmnTrvTrain";
			this.CmnTrvTrain.Size = new System.Drawing.Size(179, 28);
			// 
			// CmnTrvAdd
			// 
			this.CmnTrvAdd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrvAddSv,
            this.CmnTrvAddCoupe,
            this.CmnTrvAddEconomy});
			this.CmnTrvAdd.Name = "CmnTrvAdd";
			this.CmnTrvAdd.Size = new System.Drawing.Size(178, 24);
			this.CmnTrvAdd.Text = "Добавить вагон";
			// 
			// CmnTrvAddSv
			// 
			this.CmnTrvAddSv.Name = "CmnTrvAddSv";
			this.CmnTrvAddSv.Size = new System.Drawing.Size(138, 24);
			this.CmnTrvAddSv.Text = "СВ";
			this.CmnTrvAddSv.Click += new System.EventHandler(this.AddSvCar_Command);
			// 
			// CmnTrvAddCoupe
			// 
			this.CmnTrvAddCoupe.Name = "CmnTrvAddCoupe";
			this.CmnTrvAddCoupe.Size = new System.Drawing.Size(138, 24);
			this.CmnTrvAddCoupe.Text = "Купе";
			this.CmnTrvAddCoupe.Click += new System.EventHandler(this.AddCoupeCar_Command);
			// 
			// CmnTrvAddEconomy
			// 
			this.CmnTrvAddEconomy.Name = "CmnTrvAddEconomy";
			this.CmnTrvAddEconomy.Size = new System.Drawing.Size(138, 24);
			this.CmnTrvAddEconomy.Text = "Плацкарт";
			this.CmnTrvAddEconomy.Click += new System.EventHandler(this.AddEconomyCar_Command);
			// 
			// CmnTrvCar
			// 
			this.CmnTrvCar.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.CmnTrvCar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrvRemove});
			this.CmnTrvCar.Name = "CmnTrvCar";
			this.CmnTrvCar.Size = new System.Drawing.Size(169, 28);
			// 
			// CmnTrvRemove
			// 
			this.CmnTrvRemove.Name = "CmnTrvRemove";
			this.CmnTrvRemove.Size = new System.Drawing.Size(168, 24);
			this.CmnTrvRemove.Text = "Удалить вагон";
			this.CmnTrvRemove.Click += new System.EventHandler(this.RemoveCar_Command);
			// 
			// CmnTrvPlace
			// 
			this.CmnTrvPlace.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.CmnTrvPlace.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrvBuy,
            this.CmnTrvRefund});
			this.CmnTrvPlace.Name = "CmnTrvPlace";
			this.CmnTrvPlace.Size = new System.Drawing.Size(180, 52);
			// 
			// CmnTrvBuy
			// 
			this.CmnTrvBuy.Name = "CmnTrvBuy";
			this.CmnTrvBuy.Size = new System.Drawing.Size(179, 24);
			this.CmnTrvBuy.Text = "Покупка билета";
			this.CmnTrvBuy.Click += new System.EventHandler(this.BuyTicket_Command);
			// 
			// CmnTrvRefund
			// 
			this.CmnTrvRefund.Name = "CmnTrvRefund";
			this.CmnTrvRefund.Size = new System.Drawing.Size(179, 24);
			this.CmnTrvRefund.Text = "Возврат билета";
			this.CmnTrvRefund.Click += new System.EventHandler(this.RefundTicketCommand);
			// 
			// SfdMain
			// 
			this.SfdMain.FileName = "train.json";
			this.SfdMain.Filter = "Файлы JSON(*.json)|*.json";
			this.SfdMain.SupportMultiDottedExtensions = true;
			this.SfdMain.Title = "Сохранить данные в файл";
			// 
			// OfdMain
			// 
			this.OfdMain.FileName = "train.json";
			this.OfdMain.Filter = "Файлы JSON(*.json)|*.json";
			this.OfdMain.Title = "Загрузить данные из файла";
			// 
			// ClnNum
			// 
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.ClnNum.DefaultCellStyle = dataGridViewCellStyle1;
			this.ClnNum.HeaderText = "Номер вагона";
			this.ClnNum.Name = "ClnNum";
			this.ClnNum.ReadOnly = true;
			this.ClnNum.Width = 140;
			// 
			// ClnType
			// 
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			this.ClnType.DefaultCellStyle = dataGridViewCellStyle2;
			this.ClnType.HeaderText = "Тип вагона";
			this.ClnType.Name = "ClnType";
			this.ClnType.ReadOnly = true;
			this.ClnType.Width = 117;
			// 
			// ClnCmpNumber
			// 
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.ClnCmpNumber.DefaultCellStyle = dataGridViewCellStyle3;
			this.ClnCmpNumber.HeaderText = "Номер купе";
			this.ClnCmpNumber.Name = "ClnCmpNumber";
			this.ClnCmpNumber.ReadOnly = true;
			this.ClnCmpNumber.Width = 121;
			// 
			// ClnPlaceNum
			// 
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.ClnPlaceNum.DefaultCellStyle = dataGridViewCellStyle4;
			this.ClnPlaceNum.HeaderText = "Номер места";
			this.ClnPlaceNum.Name = "ClnPlaceNum";
			this.ClnPlaceNum.ReadOnly = true;
			this.ClnPlaceNum.Width = 134;
			// 
			// ClnState
			// 
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			this.ClnState.DefaultCellStyle = dataGridViewCellStyle5;
			this.ClnState.HeaderText = "Статус";
			this.ClnState.Name = "ClnState";
			this.ClnState.ReadOnly = true;
			this.ClnState.Width = 87;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(954, 422);
			this.Controls.Add(this.SpcMain);
			this.Controls.Add(this.StlMain);
			this.Controls.Add(this.TsbMain);
			this.Controls.Add(this.MniMain);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MainMenuStrip = this.MniMain;
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "RailWay";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.TsbMain.ResumeLayout(false);
			this.TsbMain.PerformLayout();
			this.StlMain.ResumeLayout(false);
			this.StlMain.PerformLayout();
			this.SpcMain.Panel1.ResumeLayout(false);
			this.SpcMain.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.SpcMain)).EndInit();
			this.SpcMain.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.DgvMain)).EndInit();
			this.MniMain.ResumeLayout(false);
			this.MniMain.PerformLayout();
			this.CmnTrvTrain.ResumeLayout(false);
			this.CmnTrvCar.ResumeLayout(false);
			this.CmnTrvPlace.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.BnsTrain)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ToolStrip TsbMain;
		private System.Windows.Forms.StatusStrip StlMain;
		private System.Windows.Forms.SplitContainer SpcMain;
		private System.Windows.Forms.TreeView TrvMain;
		private System.Windows.Forms.DataGridView DgvMain;
		private System.Windows.Forms.MenuStrip MniMain;
		private System.Windows.Forms.ToolStripMenuItem MniFile;
		private System.Windows.Forms.BindingSource BnsTrain;
		private System.Windows.Forms.ImageList ImlTree;
		private System.Windows.Forms.ContextMenuStrip CmnTrvTrain;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvAdd;
		private System.Windows.Forms.ContextMenuStrip CmnTrvCar;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvRemove;
		private System.Windows.Forms.ContextMenuStrip CmnTrvPlace;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvBuy;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvRefund;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvAddSv;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvAddCoupe;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvAddEconomy;
		private System.Windows.Forms.ToolStripMenuItem MniFileExit;
		private System.Windows.Forms.ToolStripButton TsbRemove;
		private System.Windows.Forms.ToolStripButton TsbBuy;
		private System.Windows.Forms.ToolStripButton TsbRefund;
		private System.Windows.Forms.ToolStripMenuItem MniEdit;
		private System.Windows.Forms.ToolStripMenuItem MniTickets;
		private System.Windows.Forms.ToolStripMenuItem MniHelp;
		private System.Windows.Forms.ToolStripButton TsbNew;
		private System.Windows.Forms.ToolStripButton TsbOpen;
		private System.Windows.Forms.ToolStripButton TsbSave;
		private System.Windows.Forms.ToolStripButton TsbSaveAs;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripMenuItem создатьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem сохранитьКакToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripMenuItem MniEditAdd;
		private System.Windows.Forms.ToolStripMenuItem MniEditRemove;
		private System.Windows.Forms.ToolStripMenuItem MniTicketsBuy;
		private System.Windows.Forms.ToolStripMenuItem MniTicketsRefund;
		private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
		private System.Windows.Forms.ToolStripButton TsbOrderSoldDesc;
		private System.Windows.Forms.ToolStripButton TsbOrderCarsAsc;
		private System.Windows.Forms.ToolStripButton TsbOrderCarsDesc;
		private System.Windows.Forms.ToolStripMenuItem MniOrder;
		private System.Windows.Forms.ToolStripMenuItem MniOrderCarNumbersAsc;
		private System.Windows.Forms.ToolStripMenuItem MniOrderCarNumbersDesc;
		private System.Windows.Forms.ToolStripMenuItem MniOrderSoldDesc;
		private System.Windows.Forms.SaveFileDialog SfdMain;
		private System.Windows.Forms.OpenFileDialog OfdMain;
		private System.Windows.Forms.ToolStripStatusLabel TsStl;
		private System.Windows.Forms.ToolStripMenuItem MniEditAddSv;
		private System.Windows.Forms.ToolStripMenuItem MniEditAddCoupe;
		private System.Windows.Forms.ToolStripMenuItem MniEditAddEconomy;
		private System.Windows.Forms.ToolStripDropDownButton TsbAdd;
		private System.Windows.Forms.ToolStripMenuItem TbsAddSv;
		private System.Windows.Forms.ToolStripMenuItem TbsAddCoupe;
		private System.Windows.Forms.ToolStripMenuItem TbsAddEconomy;
		private System.Windows.Forms.ToolTip TpMain;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnNum;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnType;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnCmpNumber;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnPlaceNum;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnState;
	}
}

