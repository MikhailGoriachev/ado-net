﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using LINQ_LeftJoin_Shop_DB.Models;
using LINQ_LeftJoin_Shop_DB.Utilities;
using LINQ_LeftJoin_Shop_DB.Views;

namespace LINQ_LeftJoin_Shop_DB.Controller
{
    public class QueriesController
    {
        //Доступ к базе данных
        Shop_DBDataContext _dataContext;

        public QueriesController():this(new Shop_DBDataContext())
        {}

        public QueriesController(Shop_DBDataContext dc)
        {
            _dataContext = dc;
        } //ctor 

        #region Запросы LinqToSQL

        /*Запрос_1: Выбирает всех продавцов(выводить Код продавца, фамилию и инициалы продавца), 
        количество и суммы их продаж за заданный период, упорядочивать по фамилиям и инициалам*/
        public IEnumerable Query_1(DateTime start, DateTime end)
        => (from seller in _dataContext.Sellers
                //Присоединяем коллекцию продаж к продавцам и пишем в коллекцию обеденения
            join sale in _dataContext.Sales on seller.Id equals sale.IdSeller into JoinedCollection
            from joinedSale in JoinedCollection.DefaultIfEmpty()
                //where joinedSale.DateSale>= start && joinedSale.DateSale <= end
            select new
            {
                SellerId = seller.Id,
                SellerSNP = seller.Surname + "." + seller.Name_s.Substring(0, 1) + "." + seller.Patronymic.Substring(0, 1)+ "." /*$"{seller.Surname}.{seller.Name_s.Substring(0, 1)}.{seller.Patronymic.Substring(0, 1)}"*/,
                Price = joinedSale == null ? 0:joinedSale.Price,
            })
            .GroupBy(seller => new { seller.SellerSNP, seller.SellerId }, (seller, group) =>
             new
             {
                 SellerId = seller.SellerId,
                 SellerSNP = seller.SellerSNP,
                 SalesSumm = group.Sum(s => s.Price),
                 SalesAmount = group.Count(s => s.Price > 0), //Подсчёт кол-ва проведенных продаж
             })
            .OrderBy(s => s.SellerSNP)
            .ToList();

        /*Запрос_2: Выбирает все товары, количество и сумму продаж по этим товарам. 
         * Упорядочивать по убыванию суммы продаж*/
        public IEnumerable Query_2()
        => (from goods in _dataContext.Goods
                //Присоединяем коллекцию продаж к продавцам и пишем в коллекцию обеденения
            join sale in _dataContext.Sales on goods.Id equals sale.Purchase.IdGood into JoinedCollection
            from joinedSale in JoinedCollection.DefaultIfEmpty()
            select new
            {
                Id = goods.Id,
                GoodsName = goods.Good_name,
                //Для избежания exception
                Price = joinedSale == null ? 0:joinedSale.Price,
            })
            .GroupBy(goods => new { goods.GoodsName, goods.Id }, (goods, group) =>
             new
             {
                 Id = goods.Id,
                 Good_Name = goods.GoodsName,
                 SalesSumm = group.Sum(s => s.Price),
                 SalesAmount = group.Count(s => s.Price > 0), //Подсчёт кол-ва  продаж
             })
            .OrderByDescending(g => g.SalesSumm)
            .ToList();

        #endregion

        #region Вывод таблиц
        public IEnumerable showSalesTable()
            => _dataContext.Sales
            .Select(sale => new
            {
                SellerSNP = $"{sale.Seller.Surname}.{sale.Seller.Name_s.Substring(0, 1)}.{sale.Seller.Patronymic.Substring(0, 1)}",
                Goods = sale.Purchase.Good.Good_name,
                Unit = sale.Unit.Short,
                Amount = sale.Amount,
                Price = sale.Price,
            })
            .ToList();

        #endregion
    }
}
