﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Task02
{
    internal class Sale {
        // идентификатор
        public int Id { get; set; } // Id

        // наименование товара
        public string Good { get; set; } // Good

        // краткое наименование единицы измерения
        public string Unit { get; set; } // Unit

        // Фамилия И.О. продавца
        public string Seller { get; set; } // Seller

        // дата продажи
        public DateTime SaleDate { get; set; } // SaleDate

        // цена продажи единицы товара
        public int SalePrice { get; set; } // SalePrice

        // цена закупки единицы товара
        public int PurchasePrice { get; set; } // PurchasePrice

        // количество продаваемого товара
        public int Amount { get; set; } // Amount

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {Id,3} │ {Good,-19} │ {Unit,-11} │  {SaleDate,10:dd.MM.yyyy}  │ {PurchasePrice,12:f2} │ {SalePrice,12:f2} │ {Seller,-16}│ {Amount,6} │";

        // статический метод для вывода шапки таблицы
        public static string Header()=>
                $"  ┌─────┬─────────────────────┬─────────────┬──────────────┬──────────────┬──────────────┬─────────────────┬────────┐\n" +
                $"  │ ID  │ Наименование товара │ Единица изм.│ Дата продажи │ Цена закупки │ Цена продажи │ Продавец        │ Кол-во │\n" +
                $"  ├─────┼─────────────────────┼─────────────┼──────────────┼──────────────┼──────────────┼─────────────────┼────────┤";

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────┴─────────────────────┴─────────────┴──────────────┴──────────────┴──────────────┴─────────────────┴────────┘\n";
    } // Sale
}
