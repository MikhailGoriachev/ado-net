﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Railway.Helpers;

namespace Railway.Models
{
	// класс, описывающий вагон
	public class Car
	{
		// тип вагона
		private string _type;
		public string Type
		{
			get => _type; 
			set { 
				_type = value; 
			}
		}

		// номер вагона
		private int _number;

		public int Number
		{
			get => _number; 
			set { 
				_number = value; 
			}
		}

		// количество купе в вагоне
		private readonly int _compartmentsCount = 9;
		public int CompartmentsCount => _compartmentsCount;

		public int CompartmentsCapacity { get; set; }


		// коллекция купе вагона
		private List<Compartment> _compartments;
		
		public List<Compartment> Compartments
		{
			get => _compartments; 
			set {
				_compartments = value; 
			}
		}

		// конструкторы
		public Car() { }


		public Car(string type, int number, List<Compartment> compartments)
		{
			Type = type;
			Number = number;
			Compartments = compartments;


			CompartmentsCapacity = Type switch
			{
				"св" => 2,
				"купе" => 4,
				"плацкарт" => 6,
				_ => throw new ArgumentOutOfRangeException()
			};
		}

		// индексатор
		public Compartment this[int index]
		{
			get => _compartments[index];
			set => _compartments[index] = value;
		}

		// количество проданых мест
		public int SoldPlacesCount => _compartments.Sum(cmp => cmp.Places.Sum(p => p.State? 0 : 1));


		// генерация вагона
		public static Car Generate(string type, int number)
		{
			Car car = new Car(type, number, new List<Compartment>());
			int nPlaceStart = 1;
			
			for (int i = 0; i < car.CompartmentsCount; i++)
				car.Compartments.Add(Compartment.Generate(type, i + 1, ref nPlaceStart));

			return car;
		}

	}
}
