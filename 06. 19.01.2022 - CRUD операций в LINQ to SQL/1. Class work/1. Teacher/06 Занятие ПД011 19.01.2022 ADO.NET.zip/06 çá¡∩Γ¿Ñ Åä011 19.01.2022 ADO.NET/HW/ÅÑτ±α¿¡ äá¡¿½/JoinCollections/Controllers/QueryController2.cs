﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace JoinCollections.Controllers
{
    class QueryController2
    {
        private WholeSalesDataContext ws = new WholeSalesDataContext(
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\данил\source\repos\ADO\JoinCollections\JoinCollections\App_Data\Wholesale.mdf;Integrated Security=True");
        //Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых
        //является «шт» (штуки) и цена закупки составляет меньше 200 руб.

        public void Query1()
        {
            var query =
                from Product in ws.Purchases
                where Product.Unit.Short == "шт" && Product.Price < 200
                select Product;

            foreach (var item in query)
            {
                //Console.WriteLine($"{}");
            }
            
        }

        public void Query1Extension()
        {
            var query = ws.Purchases
                .Where((product) => product.Unit.Short == "шт" && product.Price < 200)
                .ToList();
           

        }

        

    }
}
