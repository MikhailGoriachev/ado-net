﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Views
{
	public class BookView
	{
		// идентификатор
		public int Id { get; set; }

		// фамилия и инициалы автора
		public string Author { get; set; }

		// название книги
		public string Title { get; set; }

		// год издания
		public int Year { get; set; }

		// цена
		public int Price { get; set; }

		public override string ToString() =>
			$"  Id:{Id}. {Title}, {Author}, {Year}г., {Price}р.";

	}
}
