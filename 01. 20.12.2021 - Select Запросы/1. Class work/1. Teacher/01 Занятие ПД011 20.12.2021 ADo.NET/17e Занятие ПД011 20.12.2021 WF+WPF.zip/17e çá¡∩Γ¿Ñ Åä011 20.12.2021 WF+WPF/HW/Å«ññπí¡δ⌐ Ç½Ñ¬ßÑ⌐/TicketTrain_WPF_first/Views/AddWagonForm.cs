﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TicketTrain_WPF_first.Models;

namespace TicketTrain_WPF_first.Views
{
    public partial class AddWagonForm : Form
    {
        public AddWagonForm()
        {
            InitializeComponent();
        }

        public string GetNewWagonType => comboBox1.Text;


    }
}
