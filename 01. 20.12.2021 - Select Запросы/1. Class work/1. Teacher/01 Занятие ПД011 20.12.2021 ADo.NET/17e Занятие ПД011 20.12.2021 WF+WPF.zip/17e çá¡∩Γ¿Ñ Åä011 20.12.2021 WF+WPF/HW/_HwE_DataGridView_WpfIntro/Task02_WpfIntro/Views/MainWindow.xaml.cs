﻿using System;
using System.Windows;
using System.Windows.Controls;
using Task02_WpfIntro.Models;

namespace Task02_WpfIntro.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Task2 _task2;

        // конструктор для окна
        public MainWindow():this(new Task2()) { } // MainWindow

        // конструктор с внедрением зависимости
        public MainWindow(Task2 task2) {
            InitializeComponent();

            _task2 = task2;

            // заполнить поля ввода начальными значениями
            TxbNumberA.Text = $"{_task2.A}";
            TxbNumberB.Text = $"{_task2.B}";
            TxbNumberC.Text = $"{_task2.C}";

            // очистка поля вывода результата
            TblResult.Text = "";

            // фокус на первом поле ввода
            TxbNumberA.Focus();
        } // MainWindow


        // Вычисление среднего арифметического
        private void Average_Command(object sender, RoutedEventArgs e) {
            try {
                _task2.A = double.Parse(TxbNumberA.Text);
                _task2.B = double.Parse(TxbNumberB.Text);
                _task2.C = double.Parse(TxbNumberC.Text);

                double avg = _task2.Average();

                TblResult.Text = $"\n\n\tДля чисел\n\n" +
                                 $"\tA = {_task2.A:n3};\n\tB = {_task2.B:n3}\n\tC = {_task2.C:n3}\n\n" +
                                 $"\tСреднее арифметическое {avg:n3}";
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Average_Command


        // Вычисление среднего геометрического
        private void Geometric_Command(object sender, RoutedEventArgs e) {
            try {
                _task2.A = double.Parse(TxbNumberA.Text);
                _task2.B = double.Parse(TxbNumberB.Text);
                _task2.C = double.Parse(TxbNumberC.Text);

                double geom = _task2.Geometric();

                TblResult.Text = $"\n\n\tДля чисел\n\n" +
                                 $"\tA = {_task2.A:n3};\n\tB = {_task2.B:n3}\n\tC = {_task2.C:n3}\n\n" +
                                 $"\tСреднее геометрическое {geom:n3}";
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Geometric_Command
        
        
        // Вычисление корней квадратного уравнения 
        private void SquareRoot_Command(object sender, RoutedEventArgs e) {
            try {
                _task2.A = double.Parse(TxbNumberA.Text);
                _task2.B = double.Parse(TxbNumberB.Text);
                _task2.C = double.Parse(TxbNumberC.Text);

                double x1, x2;
                (x1, x2) = _task2.SquareRoots();

                TblResult.Text = $"\n\n\tДля квадратного уравнения\n\n" +
                                 $"\tA = {_task2.A:n3};\n\tB = {_task2.B:n3}\n\tC = {_task2.C:n3}\n\n" +
                                 $"\tкорни: x1 = {x1:n3} и x2 = {x2:n3}";
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Geometric_Command


        // Очистка поля вывода результата при изменении значений в полях ввода
        private void TextChanged_Handler(object sender, TextChangedEventArgs e) {
            TblResult.Text = "";
        } // TextChanged_Handler
    } // class MainWindow
}
