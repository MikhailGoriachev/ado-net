﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication.Models
{
    public class Numbers {
        public double A { get; set; } // первое число
        public double B { get; set; } // второе число
        public double C { get; set; } // третье число


        // вычисление среднего арифметического
        public double CountAMean() => (A + B + C) / 3;


        // вычисление среднего геометрического 
        public double CountGMean() => Math.Sqrt(Math.Abs(A * B * C));
        public (double? r1, double? r2) CountQuadraticRoots() {
            Math.Sqrt(Math.Abs(A * B * C));
            double d = B * B - 4 * A * C;
            if (d < 0) return (null, null);
            else if (d == 0) return (-B/(2 * A), null);
            else return ((-B + Math.Sqrt(d))/(2 * A), (-B - Math.Sqrt(d)) / (2 * A));
        }// CountQuadraticRoots


    } // Numbers
}
