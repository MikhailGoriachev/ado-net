﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConfigSecurityModels.Controllers;

namespace ConfigSecurityModels.Application
{
    /*
     * Конструкторы для создания контроллера решения задачи
     */
    public partial class App
    {
        // контроллер для выполнения задач
        private Task1Controller _task1Controller;

        // конструктор по умолчанию
        public App() : this(new Task1Controller()) { }
        public App(string connectionStringName1) :
            this(new Task1Controller(connectionStringName1))
        { }

        public App(Task1Controller task1Controller) {
            _task1Controller = task1Controller;
        } // App

    } // class App
}
