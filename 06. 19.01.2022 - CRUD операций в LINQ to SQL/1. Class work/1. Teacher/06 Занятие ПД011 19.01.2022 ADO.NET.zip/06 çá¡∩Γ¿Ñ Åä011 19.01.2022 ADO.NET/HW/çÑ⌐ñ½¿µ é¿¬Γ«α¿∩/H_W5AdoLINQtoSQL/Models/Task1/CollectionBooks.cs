﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W5AdoLINQtoSQL.Models.Task1
{
    public class CollectionBooks
    {
        
        // коллекция книг
        private List<Book> _books;
        private List<Author> _authors;

        public List<Book> GetBooks => _books;
        public List<Author> GetAuthors => _authors;
        public CollectionBooks()
        {
            InitializeBook();
            InitializeAuthor();
        }

        public CollectionBooks(List<Book> books, List<Author> authors)
        {
            _books   = books;
            _authors = authors;
        }

        public void InitializeBook()
        {
            _books = new List<Book>
            {
                new Book{Id = 1, IdAuthor = 3, NameBook = "Ничто не вечно",    YearPublishing = 1994, Price = 857.3},
                new Book{Id = 2, IdAuthor = 2, NameBook = "Доктор Сон",        YearPublishing = 2013, Price = 738.5},
                new Book{Id = 3, IdAuthor = 1, NameBook = "Пятая гора",        YearPublishing = 1996, Price = 1244.2},
                new Book{Id = 4, IdAuthor = 2, NameBook = "Зелёная миля",      YearPublishing = 1996, Price = 1483.3},
                new Book{Id = 5, IdAuthor = 5, NameBook = "Калина красная",    YearPublishing = 1973, Price = 689d},
                new Book{Id = 6, IdAuthor = 4, NameBook = "Океанский патруль", YearPublishing = 1961, Price = 1183.7},
                new Book{Id = 7, IdAuthor = 1, NameBook = "Алхимик",           YearPublishing = 1988, Price = 937.9},
                new Book{Id = 9, IdAuthor = 3, NameBook = "Сорвать маску",     YearPublishing = 1970, Price = 1285.3},
                new Book{Id = 9, IdAuthor = 2, NameBook = "Лангольеры",        YearPublishing = 1990, Price = 1683.4},
                new Book{Id = 10,IdAuthor = 4, NameBook = "Богатство",         YearPublishing = 1977, Price = 1228d},

            };
        }

        public void InitializeAuthor()
        {
            _authors = new List<Author> {
                new Author{Id = 1, FullNameAuthor = "Пауло Коэльо",    YearOfBirth = 1947},
                new Author{Id = 2, FullNameAuthor = "Стивен Кинг",     YearOfBirth = 1947},
                new Author{Id = 3, FullNameAuthor = "Сидни Шелдон",    YearOfBirth = 1917},
                new Author{Id = 4, FullNameAuthor = "Валентин Пикуль", YearOfBirth = 1928},
                new Author{Id = 5, FullNameAuthor = "Василий Шукшин",  YearOfBirth = 1929},
            };
        }

        // Вывести все книги коллекции, выводить фамилии и инициалы автора
        public void Query01Ext()
        {
            var request =
                 from book in _books
                 join author in GetAuthors on book.IdAuthor equals author.Id 
                 select new {
                    AuthorName = author.FullNameAuthor,
                    book.NameBook,
                    book.YearPublishing,
                    book.Price
                };

            var result = request.ToList();
            ShowList(result, "\n Список книг и их авторов, синтаксис запроса:\n\n");
        }// Query01Ext

        // Вывести все книги коллекции, выводить фамилии и инициалы автора
        public void Query01Linq()
        {
            var result = _books
                 .Join(
                     _authors,
                     book => book.IdAuthor,
                     author => author.Id,
                    (book, author) => new { AuthorName = author.FullNameAuthor, book.NameBook, book.YearPublishing, book.Price })
                 .ToList();
            ShowList(result, $"\n Список книги их авторов, синтаксис методов расширения:\n\n");
        }// Query01Linq


        // Вывести книги авторов, год рождения которых принадлежит заданном диапазону 
        public void Query02Ext(int loyear, int hiyear)
        {
            var request =
                 from book in _books
                 join author in _authors on book.IdAuthor equals author.Id
                 where author.YearOfBirth >= loyear && author.YearOfBirth <= hiyear
                 select new {
                     AuthorName = author.FullNameAuthor,
                     book.NameBook,
                     book.YearPublishing,
                     book.Price
                 };

            var result = request.ToList();
            ShowList(result, "\n Книги авторов, год рождения которых принадлежит диапазону, синтаксис запроса :\n\n");
        }// Query02Ext

        // Вывести книги авторов, год рождения которых принадлежит заданном диапазону 
        public void Query02Linq(int loyear, int hiyear)
        {
            var result = _books
                .Join(
                    _authors.Where(author => author.YearOfBirth >= loyear && author.YearOfBirth <= hiyear),
                    book => book.IdAuthor,
                    author => author.Id,
                    (book, author) => new { AuthorName = author.FullNameAuthor, book.NameBook, book.YearPublishing, book.Price })
                .ToList();
            ShowList(result, "\n Книги авторов, год рождения которых принадлежит диапазону, синтаксис методов расширения:\n\n");
        }// Query02Linq


        // Список авторов и количество их книг в коллекции
        public void Query04Ext()
        {
            var request =
                  from book in _books
                  join author in _authors on book.IdAuthor equals author.Id
                  group author by author.FullNameAuthor into grAuthor
                  select new {
                     AuthorName = grAuthor.Key,
                     AuthorBookCount = grAuthor.Count()
                  };

            var result = request.ToList();
            ShowList(result, "\n Список авторов и количество их книг в коллекции, синтаксис запроса :\n\n");
        }// Query04Ext


        // Список авторов и количество их книг в коллекции
        public void Query04Linq()
        {
            var result = _books
                .Join(_authors, book => book.IdAuthor, author => author.Id,
                (b, a) => new
                { b.Id, b.NameBook, b.YearPublishing, AuthorName = a.FullNameAuthor })
                .GroupBy(item => item.AuthorName,
                (key, group) => new
                {
                    AuthorName = key,
                    AuthorBookCount = group.Count()
                })
                .ToList();
            ShowList(result, "\n Список авторов и количество их книг в коллекции, синтаксис методов расширения:\n\n");
        }// Query04Linq



        // Средняя цена книг по годам издания
        public void Query05Ext()
        {
            var request =
                  from book in _books
                  join author in _authors on book.IdAuthor equals author.Id
                  group book by book.YearPublishing into grBook
                  select new
                  {
                      BookYear = grBook.Key,
                      AvgBookPrice = grBook.Average(a => a.Price)
                  };

            var result = request.ToList();
            ShowList(result, "\n Средняя цена книг по годам издания, синтаксис запроса :\n\n");
        }// Query05Ext

        // Средняя цена книг по годам издания
        public void Query05Linq()
        {
            var result = _books
                .Join(_authors, book => book.IdAuthor, author => author.Id,
                (b, a) => new
                {b.NameBook, b.Price, BookYear = b.YearPublishing })
                .GroupBy(item => item.BookYear,
                (key, group) => new
                {
                    BookYear = key,
                    AvgBookPrice = group.Average(y => y.Price)
                })
                .ToList();
            ShowList(result, "\n Средняя цена книг по годам издания, синтаксис методов расширения:\n\n");
        }// Query05Linq


        // Список авторов по убыванию количества их книг в коллекции 
        public void Query06Ext()
        {
            var request =
                 from book in _books
                 join author in _authors on book.IdAuthor equals author.Id
                 group author by author.FullNameAuthor into grAuthor
                 orderby grAuthor.Count() descending
                 select new
                 {
                    AuthorName = grAuthor.Key,
                    AuthorBookCount = grAuthor.Count()
                 };

            var result = request.ToList();
            ShowList(result, "\n Список авторов по убыванию количества их книг в коллекции, синтаксис запроса :\n\n");
        }// Query06Ext


        // Список авторов по убыванию количества их книг в коллекции 
        public void Query06Linq()
        {
            var result = _books
                .Join(_authors, book => book.IdAuthor, author => author.Id,
                (b, a) => new
                { b.Id, b.NameBook, b.YearPublishing, AuthorName = a.FullNameAuthor })
                .GroupBy(item => item.AuthorName,
                (key, group) => new
                {
                    AuthorName = key,
                    AuthorBookCount = group.Count()
                })
                .OrderByDescending(author => author.AuthorBookCount)
                .ToList();
            ShowList(result, "\n Список авторов по убыванию количества их книг в коллекции , синтаксис методов расширения:\n\n");
        }// Query06Linq


        // Средний возраст книг по авторам,
        // выводить список с упорядочиванием фамилий и инициалов авторов по алфавиту
        public void Query07Ext()
        {
            var request =
                 from book in _books
                 join author in _authors on book.IdAuthor equals author.Id
                 orderby author.FullNameAuthor
                 group book by author.FullNameAuthor into grBook                 
                 select new
                 {
                     AuthorName = grBook.Key,
                     AvgBookYear = grBook.Average(y => y.YearPublishing)
                 };

            var result = request.ToList();
            ShowList(result, "\n Средний возраст книг по авторам, выводить список с упорядочиванием по ФИО, синтаксис запроса :\n\n");
        }// Query07Ext

        // Средний возраст книг по авторам,
        // выводить список с упорядочиванием фамилий и инициалов авторов по алфавиту
        public void Query07Linq()
        {
            var result = _books
                .Join(_authors, book => book.IdAuthor, author => author.Id,
                (b, a) => new
                { b.Id, b.NameBook, b.YearPublishing, AuthorName = a.FullNameAuthor })
                .GroupBy(item => item.AuthorName,
                (key, group) => new
                {
                    AuthorName = key,
                    AvgBookYear = group.Average(y => y.YearPublishing)
                })
                .OrderBy(author => author.AuthorName)
                .ToList();
            ShowList(result, "\n Средний возраст книг по авторам, выводить список с упорядочиванием по ФИО, синтаксис методов расширения:\n\n");
        }// Query07Linq

        // Вывод результата
        private static void ShowList<T>(List<T> list, string title)
        {
            Console.Write(title);
            foreach (var item in list)
            {
                Console.WriteLine($"{item}");
            } // foreach
        } // ShowList

    }// class CollectionBooks
}
