﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;

namespace Homework.Application
{
    /* 
    * Методы для решения задачи 3
    */
    internal partial class App {

        // Вывод коллекции книг
        public void ShowBooks() {
            Utils.ShowNavBarTask("    Вывод коллекции книг.");

            _task1Controller.Query01A();
            _task1Controller.Query01B();
        } // ShowBooks

        // Вывод книг авторов, год рождения которых принадлежит заданном диапазону
        public void BooksInRange() {
            Utils.ShowNavBarTask("    Вывод книг авторов, год рождения которых принадлежит заданном диапазону.");

            int lo = Utils.Random.Next(1900, 1970), hi = Utils.Random.Next(lo + 10, 2000);

            Console.WriteLine($"\n\tДиапазон: от {lo} до {hi}");

            _task1Controller.Query02A(lo, hi);
            _task1Controller.Query02B(lo, hi);
        } // BooksInRange

        // Вывод книг, в названии которых содержится подстрока и цена меньше заданного значения.
        public void BooksWhereTitleAndPrice() {
            Utils.ShowNavBarTask("    Вывод книг, в названии которых содержится подстрока и цена меньше заданного значения.");

            int price = 600;
            string str = "программировать";

            Console.WriteLine($"\n\tПодстрока        : \"{str}\"" +
                              $"\n\tЗаданное значение: {price}");

            _task1Controller.Query03A(str, price);
            _task1Controller.Query03B(str, price);
        } // BooksWhereTitleAndPrice

        // Список авторов и количество их книг в коллекции.
        public void AuthorsBookAmount() {
            Utils.ShowNavBarTask("    Список авторов и количество их книг в коллекции.");

            _task1Controller.Query04A();
            _task1Controller.Query04B();
        } // AuthorsBookAmount

        // Средняя цена книг по годам издания
        public void BookAvgPriceByYear() {
            Utils.ShowNavBarTask("    Средняя цена книг по годам издания.");

            _task1Controller.Query05A();
            _task1Controller.Query05B();
        } // AuthorsBookAmountDesc

        // Список авторов по убыванию количества их книг в коллекции.
        public void AuthorsBookAmountDesc() {
            Utils.ShowNavBarTask("    Список авторов по убыванию количества их книг в коллекции.");

            _task1Controller.Query06A();
            _task1Controller.Query06B();
        } // AuthorsBookAmountDesc

        // Средний возраст книг по авторам, выводить список с упорядочиванием фамилий и инициалов авторов.
        public void AuthorsAvgAge() {
            Utils.ShowNavBarTask("    Средний возраст книг по авторам, выводить список с упорядочиванием фамилий и инициалов авторов.");

            _task1Controller.Query07A();
            _task1Controller.Query07B();
        } // AuthorsAvgAge

    } // App
}
