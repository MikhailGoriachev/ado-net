﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfBegin
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		// Обработка кнопки вычисления среднего арифметического
		private void BtnAMean_Click(object sender, RoutedEventArgs e)
		{
			double number1 = 0, number2 = 0, number3 = 0;
			if (!ParseInput(ref number1, ref number2, ref number3)){
				TxbResult.Text = "Введены неверные данные";
				return;
			}

			double aMean = (number1 + number2 + number3) / 3d;
			TxbResult.Text = $"{aMean:f1}";
		}

		// Обработка кнопки вычисления среднего геометрического
		private void BtnGMean_Click(object sender, RoutedEventArgs e)
		{
			double number1 = 0, number2 = 0, number3 = 0;
			if (!ParseInput(ref number1, ref number2, ref number3))
			{
				TxbResult.Text = "Введены неверные данные";
				return;
			}

			double gMean = Math.Pow(number3 * number2 * number1, 1 / 3);
			TxbResult.Text = $"{gMean:f1}";
		}

		// Обработка кнопки вычисления корней квадратного уравнения
		private void BtnRoots_Click(object sender, RoutedEventArgs e)
		{
			double number1 = 0, number2 = 0, number3 = 0;
			if (!ParseInput(ref number1, ref number2, ref number3))
			{
				TxbResult.Text = "Введены неверные данные";
				return;
			}

			double d = number2 * number2 - 4 * number1 * number3;

			if (number1 == 0 || d < 0)
			{
				TxbResult.Text = "Нет корней";
				return;
			}

			double x1 = (-number2 + Math.Sqrt(d)) / 2 * number1;
			double x2 = (-number2 - Math.Sqrt(d)) / 2 * number1;

			TxbResult.Text = $"x1 = {x1:f2}, x2 = {x2:f2} ";
		}

		// Парсинг текста из текстбоксов
		private bool ParseInput(ref double num1, ref double num2, ref double num3) =>
			double.TryParse(Number1.Text, out num1) &&
			double.TryParse(Number2.Text, out num2) &&
			double.TryParse(Number3.Text, out num3);

	}
}
