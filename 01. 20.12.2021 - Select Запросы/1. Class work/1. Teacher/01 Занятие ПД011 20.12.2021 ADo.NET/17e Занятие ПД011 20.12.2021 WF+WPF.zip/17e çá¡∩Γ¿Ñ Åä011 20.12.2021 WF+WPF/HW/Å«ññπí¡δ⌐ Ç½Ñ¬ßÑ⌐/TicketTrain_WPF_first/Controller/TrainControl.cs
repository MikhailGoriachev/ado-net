﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using TicketTrain_WPF_first.Models;
using TicketTrain_WPF_first.Utils;
using TicketTrain_WPF_first.ViewModels;

namespace TicketTrain_WPF_first.Controller
{
    // управление поездом
    class TrainControl
    {
        // имя файла для сохранение по умолчанию
        public string _serialiseDefaultName = "train.json";
        // дериктория файла для сохранение по умолчанию
        public string _serialiseDefaultPath = "App_Data\\";


        // поезд
        private Train _train;
        public Train Train
        {
            get { return _train; }
            set { _train = value; }
        }

        // конструктор по умолчанию
        public TrainControl()
        {
            _train = new Train(_trainNumbers[Utils.Utils.GetRandom(0, _trainNumbers.Length - 1)], Utils.Utils.GetRandom(10, 15));
        }

        // массив для номеров поездов
        string[] _trainNumbers = {
            "К-Л144",
            "К-М215",
            "Д-Д301",
            "Д-К154",
            "У-З254",
            "У-С205",
            "Р-Д315",
            "П-К159",
            "Ж-Д147",
        };






        //	добавление вагона(тип вагона задаем в меню или соответствующей кнопкой)
        public void AddWagon(string type)
        {
            _train.Wagons.Add(new TrainCar(Utils.Utils.types[type], _train.Wagons.Count() + 1));
        }


        //	удаление вагона
        public void DeleteWagon(int numberWagon)
        {

            _train.Wagons.RemoveAt(numberWagon - 1);

            // измененние нумерации вагонов поезда
            for (int i = numberWagon - 1; i < _train.Wagons.Count(); i++)
            {
                _train.Wagons[i].NumbTrainCar--;
            }



        }

        //	удаление вагона
        public void DeleteWagon(TrainCar trainCar)
        {
            int numberWagon = trainCar.NumbTrainCar;

            _train.Wagons.Remove(trainCar);

            // измененние нумерации вагонов поезда
            for (int i = numberWagon, j = numberWagon + 1; i < _train.Wagons.Count(); i++, j++)
            {
                _train.Wagons[j].NumbTrainCar = i;
            }



        }

        // получить коллекцию вагонов
        public List<TrainCar> GetAll() => _train.Wagons;


        //	покупка билета
        public void GetTicket(int numberWagon, int NumberSeat)
        {
            _train.Wagons[numberWagon].StateSeat(NumberSeat, true);
        }

        //	возврат билета
        public void ReturnTicket(int numberWagon, int NumberSeat)
        {
            _train.Wagons[numberWagon].GetSeat(NumberSeat).State = false;
        }

        //	сохранение данных поезда в файл(JSON)
        public void SerializeData(string fileName)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Train));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, _train);
            }
        }

        public void Clear()
        {
            _train.Clear();
        }


        //	чтение данных поезда из файла(JSON)
        public void DeserializeData(string fileName)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Train));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                _train = (Train)jsonFormatter.ReadObject(fs);
            }
        }



        // Drag'n'Drop
        // 1.	Всего вагонов в поезде
        public int AllWagonsCount => _train.Wagons.Count();

        // 2.	Всего мест в поезде/продано билетов
        public int AllSeatCount()
        {
            int count = 0;
            foreach (var item in _train.Wagons)
            {
                count += item.GetSeatCount();
            }
            return count;
        }

        public string GetFileName()
        {
            return _serialiseDefaultPath + _serialiseDefaultName;
        }

        // Всего продано билетов
        public int AllSaleSeatCount()
        {
            int count = 0;
            foreach (var item in _train.Wagons)
            {
                count += item.GetSaleSeatCount();
            }
            return count;
        }


        // 3.	СВ/Купе/Плайкарт: вагонов/мест/продано билетов
        public int WagonSeatCount(string type)
        {
            int count = 0;
            foreach (var item in _train.Wagons)
            {
                if (item.TypeTrainCar == type)
                    count += item.GetSeatCount();
            }
            return count;
        }

        public int WagonSaleSeatCount(string type)
        {
            int count = 0;
            foreach (var item in _train.Wagons)
            {
                if (item.TypeTrainCar == type)
                    count += item.GetSaleSeatCount();
            }
            return count;
        }

        // Запрос на выборку в коллекцию информации о вагоне для отображения в DataGridView
        public List<TrainTicket> SelectWhereNumber(int carriageNumber) =>
            _train.MapToCarriageView(carriageNumber);


        // сортировка вагонов по убыванию количества проданных мест и перестройка дерева
        public void OrederBySaleSeatsDecs() {

            _train.Wagons.Sort((a, b) => b.GetSaleSeatCount().CompareTo(a.GetSaleSeatCount()));        
        
        }

        // сортировка поезда по возрастанию номеров вагонов и перестройка дерева
        public void OrederByNumbWagon()
        {

            _train.Wagons.Sort((a, b) => a.NumbTrainCar.CompareTo(b.NumbTrainCar));

        }

        // сортировка поезда по убыванию номеров вагонов и перестройка дерева
        public void OrederByNumbWagonDecs()
        {

            _train.Wagons.Sort((a, b) => b.NumbTrainCar.CompareTo(a.NumbTrainCar));

        }




    }
}
