﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Realestate.Controllers
{
    class Task2Controller {
        // строка подключения к базе данных
        private string _connectingString;
        public string ConnectingString {
            get => _connectingString;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Не указана строка подключения к базе данных");

                _connectingString = value;
            } // set
        } // ConnectionString

        public Task2Controller(string connectingString) {
            ConnectingString = connectingString;
        } // Task2Controller

        // 1. Хранимая процедура
        //    Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
        public void Query01(string plate = "О169РК") {
            Console.WriteLine($"\n\tЗаданный госномер: {plate}");
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Query01");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // задать параметры запроса
                cmd.Parameters.AddWithValue("@plate", plate);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)}" +
                        $" │ {reader.GetName(1),-15}" +
                        $" │ {reader.GetName(2), -15}" +
                        $" │ {reader.GetName(3), -10}" +
                        $" │ {reader.GetName(4),-10}" +
                        $" │ {reader.GetName(5),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼────────────┼────────────┼────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2}" +
                            $" │ {reader.GetString(1),-15}" +
                            $" │ {reader.GetString(2), 15}" +
                            $" │ {reader.GetString(3), 10}" +
                            $" │ {reader.GetDateTime(4),10:dd/MM/yyyy}" +
                            $" │ {reader.GetInt32(5),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query01


        // 2. Хранимая процедура
        //    Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
        public void Query02(string brandModel = "Skoda Fabia New") {

            Console.WriteLine($"\n\tЗаданная модель/брен: {brandModel}");
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Query02");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // задать параметры запроса
                cmd.Parameters.AddWithValue("@brandModel", brandModel);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)}" +
                        $" │ {reader.GetName(1),-15}" +
                        $" │ {reader.GetName(2), -15}" +
                        $" │ {reader.GetName(3), -10}" +
                        $" │ {reader.GetName(4),-10}" +
                        $" │ {reader.GetName(5),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼────────────┼────────────┼────────────┤");

                    while (reader.Read()) {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2}" +
                            $" │ {reader.GetString(1),-15}" +
                            $" │ {reader.GetString(2), 15}" +
                            $" │ {reader.GetString(3), 10}" +
                            $" │ {reader.GetDateTime(4),10:dd/MM/yyyy}" +
                            $" │ {reader.GetInt32(5),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query02


        // 3. Хранимая процедура
        //    Выбирает информацию об автомобиле с заданным госномером
        public void Query03(string plate = "Т306РК") {

            Console.WriteLine($"\n\tЗаданный госномер: {plate}");
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))  {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Query03");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // задать параметры запроса
                cmd.Parameters.AddWithValue("@plate", plate);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬────────────┬────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)}" +
                        $" │ {reader.GetName(1),-15}" +
                        $" │ {reader.GetName(2),-15}" +
                        $" │ {reader.GetName(3),-10}" +
                        $" │ {reader.GetName(4),-10}" +
                        $" │ {reader.GetName(5),-10}" +
                        $" │ {reader.GetName(6),-10}" +
                        $" │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼────────────┼────────────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2}" +
                            $" │ {reader.GetString(1),-15}" +
                            $" │ {reader.GetString(2),15}" +
                            $" │ {reader.GetString(3),10}" +
                            $" │ {reader.GetInt32(4),10}" +
                            $" │ {reader.GetInt32(5),10}" +
                            $" │ {reader.GetInt32(6),10}" +
                            $" │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴────────────┴────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query03


        // 4. Хранимая процедура
        //    Выбирает информацию о клиентах по серии и номеру паспорта
        public void Query04(string passport = "12 21 187651") {

            Console.WriteLine($"\n\tСерия и номер паспорта: {passport}");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))  {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Query04");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // задать параметры запроса
                cmd.Parameters.AddWithValue("@passport", passport);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

               
                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬─────────────────┬─────────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)}" +
                        $" │ {reader.GetName(1),-15}" +
                        $" │ {reader.GetName(2),-15}" +
                        $" │ {reader.GetName(3),-15}" +
                        $" │ {reader.GetName(4),-15}" +
                        $" │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼─────────────────┼─────────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2}" +
                            $" │ {reader.GetString(1),-15}" +
                            $" │ {reader.GetString(2),15}" +
                            $" │ {reader.GetString(3),15}" +
                            $" │ {reader.GetString(4),15}" +
                            $" │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴─────────────────┴─────────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query04


        // 5. Хранимая процедура
        //    Выбирает информацию обо всех зафиксированных фактах проката автомобилей 
        //    в некоторый заданный интервал времени.м
        public void Query05(DateTime from, DateTime to) {

            Console.WriteLine($"\nЗаданный диапазон: c {from,10:dd/MM/yyyy} до {to,10:dd/MM/yyyy}");
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Query05");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // задать параметры запроса
                cmd.Parameters.AddWithValue("@from", from);
                cmd.Parameters.AddWithValue("@to", to);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬─────────────────┬─────────────────┬────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)}" +
                        $" │ {reader.GetName(1),-15}" +
                        $" │ {reader.GetName(2),-15}" +
                        $" │ {reader.GetName(3),-10}" +
                        $" │ {reader.GetName(4),-10}" +
                        $" │ {reader.GetName(5),-10} │");
                    Console.WriteLine("\t├────┼─────────────────┼─────────────────┼────────────┼────────────┼────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2}" +
                            $" │ {reader.GetString(1),-15}" +
                            $" │ {reader.GetString(2),15}" +
                            $" │ {reader.GetString(3),10}" +
                            $" │ {reader.GetDateTime(4),10:dd/MM/yyyy}" +
                            $" │ {reader.GetInt32(5),10} │");
                    } // while
                    Console.WriteLine("\t└────┴─────────────────┴─────────────────┴────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query05


        // 6. Хранимая процедура
        //    Вычисляет для каждого факта проката стоимость проката.
        //    Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
        //    Сортировка по полю Дата проката
        public void Query06() {
            Console.WriteLine();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))  {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Query06");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

               
                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬────────────┬─────────────────┬─────────────────┬──────────────┬────────────┬────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)}" +
                        $" │ {reader.GetName(1),-10}" +
                        $" │ {reader.GetName(2),-15}" +
                        $" │ {reader.GetName(3),-15}" +
                        $" │ {reader.GetName(4),-12}" +
                        $" │ {reader.GetName(5),-10}" +
                        $" │ {reader.GetName(6),-10}" +
                        $" │");
                    Console.WriteLine("\t├────┼────────────┼─────────────────┼─────────────────┼──────────────┼────────────┼────────────┤");

                    while (reader.Read())  {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2}" +
                            $" │ {reader.GetDateTime(1),10:dd/MM/yyyy}" +
                            $" │ {reader.GetString(2),15}" +
                            $" │ {reader.GetString(3),15}" +
                            $" │ {reader.GetInt32(4),12:n2}" +
                            $" │ {reader.GetInt32(5),10}" +
                            $" │ {reader.GetInt32(6),10:n2}" +
                            $" │");
                    } // while
                    Console.WriteLine("\t└────┴────────────┴─────────────────┴─────────────────┴──────────────┴────────────┴────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query06


        // 7. Хранимая процедура
        //    Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
        //    суммарное количество дней проката, упорядочивание по убыванию суммарного количества дней проката
        public void Query07() {
            Console.WriteLine();

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))  {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Query07");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows) {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌────┬──────────────────┬────────────┬───────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0)}" +
                        $" │ {reader.GetName(1),-16}" +
                        $" │ {reader.GetName(2),-10}" +
                        $" │ {reader.GetName(3),-13}" +
                        $" │");
                    Console.WriteLine("\t├────┼──────────────────┼────────────┼───────────────┤");

                    while (reader.Read())  {
                        Console.WriteLine(
                            $"\t│ {reader.GetInt32(0),2}" +
                            $" │ {reader.GetString(1),16}" +
                            $" │ {reader.GetInt32(2),10}" +
                            $" │ {reader.GetInt32(3),13}" +
                            $" │");
                    } // while
                    Console.WriteLine("\t└────┴──────────────────┴────────────┴───────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query07

        // 8. Хранимая процедура
        //    Выбирает информацию о фактах проката автомобилей по госномеру: 
        //    количество фактов проката, сумма за прокаты, суммарная длительность прокатов
        public void Query08(string plate = "Т306РК") {

            Console.WriteLine($"\n\tЗаданный госномер: {plate}");
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))  {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Query08");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@plate", plate);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine("\t┌─────────────────┬────────────┬─────────────┬───────────────┐");
                    Console.WriteLine(
                        $"\t│ {reader.GetName(0),-15}" +
                        $" │ {reader.GetName(1),-10}" +
                        $" │ {reader.GetName(2),-11}" +
                        $" │ {reader.GetName(3),-13}" +
                        $" │");
                    Console.WriteLine("\t├─────────────────┼────────────┼─────────────┼───────────────┤");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"\t│ {reader.GetString(0),-15}" +
                            $" │ {reader.GetInt32(1),-10}" +
                            $" │ {reader.GetInt32(2),11}" +
                            $" │ {reader.GetInt32(3),13}" +
                            $" │");
                    } // while
                    Console.WriteLine("\t└─────────────────┴────────────┴─────────────┴───────────────┘");
                } // if
            } // using
            Console.WriteLine();
        } // Query08
    } // Task2Controller
}
