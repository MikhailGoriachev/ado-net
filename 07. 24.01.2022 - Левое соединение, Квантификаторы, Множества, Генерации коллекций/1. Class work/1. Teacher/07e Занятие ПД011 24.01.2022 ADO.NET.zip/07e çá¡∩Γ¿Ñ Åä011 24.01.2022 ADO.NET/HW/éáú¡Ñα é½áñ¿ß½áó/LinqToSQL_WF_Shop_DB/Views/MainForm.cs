﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LinqToSQL_WF_Shop_DB.Controller;
using LinqToSQL_WF_Shop_DB.Utilities;

namespace LinqToSQL_WF_Shop_DB.Views
{
    public partial class MainForm : Form
    {
        //Конроллер 
        QueriesController _controller;

        public MainForm()
        {
            _controller = new QueriesController();
            InitializeComponent();

            Cbx_Query_3.DataSource = _controller.GoodsNames.ToList();
            Cbx_Query_4.DataSource = _controller.GetInterests.ToList();
            Nud_Price.Value = (decimal)20000;

        }

        //Изменение строки статуса
        private void ChangeStatusStr(int QueryNum, int ObjAmount)
        {
            Lbl_Status_Qantity.Text = $"Выбрано обектов: {ObjAmount}";
            Lbl_Query_Num.Text = $"Запрос N_{QueryNum}";
        }

        //Связывание 
        void BindDgv(DataGridView dgv, IEnumerable<object> collection)
        {
            dgv.DataSource = null;
            dgv.DataSource = collection;
        }


        private void Tab_Query_1_Enter(object sender, EventArgs e)
        {
            if (Tbc_Main.SelectedTab != Tab_Query_1 || Utils.Query_1_Executed)
                return;

            BindDgv(Dgv_Query_1, _controller.Query_1());

            Utils.Query_1_Executed = true;

            //Строка состояния
            ChangeStatusStr(1, Dgv_Query_1.Rows.Count);
        }

        private void Tab_Query_2_Enter(object sender, EventArgs e)
        {
            //Если текущая вкладка - не вкладка запроса или запрос по умолчанию исполнялся
            if (Tbc_Main.SelectedTab != Tab_Query_2 || Utils.Query_2_Executed)
                return;

            BindDgv(Dgv_Query_2, _controller.Query_2());

            Utils.Query_2_Executed = true;

            ChangeStatusStr(2, Dgv_Query_2.Rows.Count);
        }

        private void Exit_Command(object sender, EventArgs e)
         => Application.Exit();

        private void Tab_Query_3_Enter(object sender, EventArgs e)
        {
            //Если текущая вкладка - не вкладка запроса или запрос по умолчанию исполнялся
            if (Tbc_Main.SelectedTab != Tab_Query_3 || Utils.Query_3_Executed)
                return;
            
            //В аргументы запроса передаём наименование и стоимость
            BindDgv(Dgv_Query_3, _controller.Query_3(Cbx_Query_3.SelectedItem.ToString(),(int)Nud_Price.Value));

            Utils.Query_3_Executed = true;

            ChangeStatusStr(3, Dgv_Query_3.Rows.Count);
        }

        //В 3-й вкладке cbx
        private void Cbx_Query3_SelectedChanged(object sender, EventArgs e)
        {
            if (Tbc_Main.SelectedTab != Tab_Query_3)
                return;

            int NudValue = (int)Nud_Price.Value;

            Lbl_Query3.Text = "Выбирает из таблицы ТОВАРЫ информацию о товарах " +
                 "\n с заданным наименованием ," +
                $"\n для которых цена закупки меньше {NudValue} руб.";

            BindDgv(Dgv_Query_3, _controller.Query_3(Cbx_Query_3.SelectedItem.ToString(), NudValue));

            Utils.Query_3_Executed = true;

            ChangeStatusStr(3, Dgv_Query_3.Rows.Count);
        }

        private void Nud_Query3_Changed(object sender, EventArgs e)
        {

            if (Tbc_Main.SelectedTab != Tab_Query_3)
                return;

            int NudValue = (int)Nud_Price.Value;

            Lbl_Query3.Text = "Выбирает из таблицы ТОВАРЫ информацию о товарах " +
                "\n с заданным наименованием ," +
                $"\n для которых цена закупки меньше {NudValue} руб.";

            BindDgv(Dgv_Query_3, _controller.Query_3(Cbx_Query_3.SelectedItem.ToString(), NudValue));

            Utils.Query_3_Executed = true;

            ChangeStatusStr(3, Dgv_Query_3.Rows.Count);
        }

        private void Tab_Query_4_Enter(object sender, EventArgs e)
        {

            //Если текущая вкладка - не вкладка запроса или запрос по умолчанию исполнялся
            if (Tbc_Main.SelectedTab != Tab_Query_4 || Utils.Query_4_Executed)
                return;

            Lbl_Query4.Text = "Выбирает из таблицы ПРОДАВЦЫ информацию" +
                $"\n о продавцах с {(double)Cbx_Query_4.SelectedItem * 100}% комиссионных";

            //В аргументы запроса передаём наименование и стоимость
            BindDgv(Dgv_Query_4, _controller.Query_4((double)Cbx_Query_4.SelectedItem));

            Utils.Query_4_Executed = true;

            ChangeStatusStr(4, Dgv_Query_4.Rows.Count);
        }

        private void Cbx_Query4_Changed(object sender, EventArgs e)
        {
            //Если текущая вкладка - не вкладка запроса или запрос по умолчанию исполнялся
            if (Tbc_Main.SelectedTab != Tab_Query_4 )
                return;

            Lbl_Query4.Text = "Выбирает из таблицы ПРОДАВЦЫ информацию" +
                $"\n о продавцах с {(double)Cbx_Query_4.SelectedItem * 100}% комиссионных";

            //В аргументы запроса передаём наименование и стоимость
            BindDgv(Dgv_Query_4, _controller.Query_4((double)Cbx_Query_4.SelectedItem));

            Utils.Query_4_Executed = true;

            ChangeStatusStr(4, Dgv_Query_4.Rows.Count);
        }
    }
}
