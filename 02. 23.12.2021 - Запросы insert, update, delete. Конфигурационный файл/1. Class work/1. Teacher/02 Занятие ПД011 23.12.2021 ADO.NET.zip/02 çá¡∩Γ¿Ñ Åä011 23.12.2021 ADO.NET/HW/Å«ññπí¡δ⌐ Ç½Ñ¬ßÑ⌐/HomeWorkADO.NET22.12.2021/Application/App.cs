﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkADO.NET22._12._2021.Application
{
    // класс для обработки
    class App
    {
        // строка подключения к бд
        public string ConnectingString { get; set; }

        // 1	Запрос с параметрами	
        //      Выбирает информацию о 3-комнатных квартирах, расположенных на улице «Садовая». 
        //      Значения задавать параметрами запроса
        public void Query01(int countRooms, string StreetName)
        {
            Console.WriteLine("\nЗапрос 1");
            Console.WriteLine("Запрос с параметрами");
            Console.WriteLine($"Выбирает информацию о {countRooms}-комнатных квартирах, расположенных на улице «{StreetName}».");
            Console.WriteLine("Значения задавать параметрами запроса");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select	                        
                        ViewApartment.Id
                        , StreetType
                        , StreetName
                        , HouseNumber
                        , ApartmentNumber
                        , Area
                        , CountRooms
                        , Price
	              from
	                  ViewApartment
                  where
	                  CountRooms = @countRooms and StreetName = @streetName"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@countRooms", countRooms);
                cmd.Parameters.AddWithValue("@streetName", StreetName);
                

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                    //      Id
                    //      , StreetType
                    //      , StreetName
                    //      , HouseNumber
                    //      , ApartmentNumber
                    //      , Area
                    //      , CountRooms
                    //      , Price


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌────┬───────────────┬──────────────────────┬────────────┬────────────────┬─────────┬─────────────┬──────────────────┐");
                    Console.WriteLine($"| ID |   Тип улицы   |    Название улицы    | Номер дома | Номер квартиры | Площадь | Кол. комнат |       Цена       |");
                    Console.WriteLine($"├────┼───────────────┼──────────────────────┼────────────┼────────────────┼─────────┼─────────────┼──────────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetInt32(0),2} | " +                //  ID
                             $"{reader.GetString(1),-13} | " +              //  Тип улицы
                             $"{reader.GetString(2),-20} | " +              //  Название улицы
                             $"{reader.GetString(3),10} | " +              //  Номер дома
                             $"{reader.GetString(4),14} | " +              //  Номер квартиры
                             $"{reader.GetInt32(5),7} | " +                //  Площадь
                             $"{reader.GetInt32(6),11} | " +               //  Кол. комнат
                             $"{reader.GetDouble(7),16:n3} | ");            //  Цена   

                    } // while

                    Console.WriteLine($"└────┴───────────────┴──────────────────────┴────────────┴────────────────┴─────────┴─────────────┴──────────────────┘");

                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }


        //  2	Запрос с параметрами 
        //      Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%. 
        //      Значения задавать параметрами запроса
        public void Query02(int percent, string startSurnameLater)
        {
            Console.WriteLine("\nЗапрос 2");
            Console.WriteLine("Запрос с параметрами");
            Console.WriteLine($"Выбирает информацию о риэлторах, фамилия которых начинается с буквы «{startSurnameLater}» и процент вознаграждения больше {percent}%.");
            Console.WriteLine("Значения задавать параметрами запроса");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select	                        
                        ViewRealtor.Id
                        , RealtorSurname
                        , RealtorName
                        , RealtorPatronymic
                        , [Percent]                    
	              from
	                  ViewRealtor
                  where
	                  [Percent] > @percent and RealtorSurname like @startSurnameLater+N'%'"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@percent", percent);
                cmd.Parameters.AddWithValue("@startSurnameLater", startSurnameLater);


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                    //    ViewRealtor.Id
                    //    , RealtorSurname
                    //    , RealtorName
                    //    , RealtorPatronymic
                    //    , [Percent]


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌────┬───────────────┬────────────────┬────────────────┬─────────────┐");
                    Console.WriteLine($"| ID |    Фамилия    |       Имя      |     Отчество   |   Процент   |");
                    Console.WriteLine($"├────┼───────────────┼────────────────┼────────────────┼─────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetInt32(0),2} | " +               //  ID
                             $"{reader.GetString(1),-13} | " +              //  Фамилия
                             $"{reader.GetString(2),-14} | " +              //  Имя
                             $"{reader.GetString(3),-14} | " +              //  Отчество                             
                             $"{reader.GetInt32(4),11} | " );                //  Процент   

                    } // while

                    Console.WriteLine($"└────┴───────────────┴────────────────┴────────────────┴─────────────┘");


                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }


        //  3	Запрос с параметрами 
        //      Выбирает информацию об 1-комнатных квартирах, цена на которые находится в диапазоне от 900 000 руб.до 1000 000 руб.
        //      Значения задавать параметрами запроса
        public void Query03(int countRooms, int lo, int hi)
        {
            Console.WriteLine("\nЗапрос 3");
            Console.WriteLine("Запрос с параметрами");
            Console.WriteLine($"Выбирает информацию об {countRooms} -комнатных квартирах, цена на которые находится в диапазоне от {lo} руб.до {hi} руб.");
            Console.WriteLine("Значения задавать параметрами запроса");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select	                        
                        ViewApartment.Id
                        , StreetType
                        , StreetName
                        , HouseNumber     
                        , ApartmentNumber
                        , Area
                        , CountRooms
                        , Price                  
	              from
	                  ViewApartment
                  where
	                  (Price between @lo and @hi) and CountRooms = @countRooms"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@countRooms", countRooms);
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                        // ViewApartment.Id
                        // , StreetType
                        // , StreetName
                        // , HouseNumber
                        // , ApartmentNumber
                        // , Area
                        // , CountRooms
                        // , Price


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌────┬───────────────┬──────────────────────┬────────────┬────────────────┬─────────┬─────────────┬──────────────────┐");
                    Console.WriteLine($"| ID |   Тип улицы   |    Название улицы    | Номер дома | Номер квартиры | Площадь | Кол. комнат |       Цена       |");
                    Console.WriteLine($"├────┼───────────────┼──────────────────────┼────────────┼────────────────┼─────────┼─────────────┼──────────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetInt32(0),2} | " +                //  ID
                             $"{reader.GetString(1),-13} | " +              //  Тип улицы
                             $"{reader.GetString(2),-20} | " +              //  Название улицы
                             $"{reader.GetString(3),10} | " +              //  Номер дома
                             $"{reader.GetString(4),14} | " +              //  Номер квартиры
                             $"{reader.GetInt32(5),7} | " +                //  Площадь
                             $"{reader.GetInt32(6),11} | " +               //  Кол. комнат
                             $"{reader.GetDouble(7),16:n3} | ");            //  Цена   

                    } // while

                    Console.WriteLine($"└────┴───────────────┴──────────────────────┴────────────┴────────────────┴─────────┴─────────────┴──────────────────┘");


                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }


        //  4	Запрос с параметрами 
        //      Выбирает информацию о квартирах с заданным числом комнат.
        //      Значения задавать параметрами запроса
        public void Query04()
        {
            Console.WriteLine("\nЗапрос 4");
            Console.WriteLine("Запрос с параметрами");
            Console.WriteLine($"Выбирает информацию о квартирах с заданным числом комнат.");
            Console.WriteLine("Значения задавать параметрами запроса");
            Console.Write("\nВведите количество комнат : ");
            int countRooms = Convert.ToInt32(Console.ReadLine());

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select	                        
                        ViewApartment.Id
                        , StreetType
                        , StreetName
                        , HouseNumber     
                        , ApartmentNumber
                        , Area
                        , CountRooms
                        , Price                  
	              from
	                  ViewApartment
                  where
	                  CountRooms = @countRooms"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@countRooms", countRooms);
              


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                // ViewApartment.Id
                // , StreetType
                // , StreetName
                // , HouseNumber
                // , ApartmentNumber
                // , Area
                // , CountRooms
                // , Price


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌────┬───────────────┬──────────────────────┬────────────┬────────────────┬─────────┬─────────────┬──────────────────┐");
                    Console.WriteLine($"| ID |   Тип улицы   |    Название улицы    | Номер дома | Номер квартиры | Площадь | Кол. комнат |       Цена       |");
                    Console.WriteLine($"├────┼───────────────┼──────────────────────┼────────────┼────────────────┼─────────┼─────────────┼──────────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetInt32(0),2} | " +                //  ID
                             $"{reader.GetString(1),-13} | " +              //  Тип улицы
                             $"{reader.GetString(2),-20} | " +              //  Название улицы
                             $"{reader.GetString(3),10} | " +              //  Номер дома
                             $"{reader.GetString(4),14} | " +              //  Номер квартиры
                             $"{reader.GetInt32(5),7} | " +                //  Площадь
                             $"{reader.GetInt32(6),11} | " +               //  Кол. комнат
                             $"{reader.GetDouble(7),16:n3} | ");            //  Цена   

                    } // while

                    Console.WriteLine($"└────┴───────────────┴──────────────────────┴────────────┴────────────────┴─────────┴─────────────┴──────────────────┘");


                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }


        //  5	Запрос с параметрами 
        //      Выбирает информацию обо всех 2-комнатных квартирах, площадь которых есть значение из некоторого диапазона.
        //      Значения задавать параметрами запроса
        public void Query05(int countRooms)
        {
            Console.WriteLine("\nЗапрос 5");
            Console.WriteLine("Запрос с параметрами");
            Console.WriteLine($"Выбирает информацию обо всех {countRooms}-комнатных квартирах, площадь которых есть значение из некоторого диапазона.");
            Console.WriteLine("Значения задавать параметрами запроса");
            Console.Write("\nВведите минимальную площадь : ");
            int loArea = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите максимальную площадь : ");
            int hiArea = Convert.ToInt32(Console.ReadLine());

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select	                        
                        ViewApartment.Id
                        , StreetType
                        , StreetName
                        , HouseNumber     
                        , ApartmentNumber
                        , Area
                        , CountRooms
                        , Price                  
	              from
	                  ViewApartment
                  where
	                  CountRooms = @countRooms and (Area between @lo and @hi)  " 
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@countRooms", countRooms);
                cmd.Parameters.AddWithValue("@lo", loArea);
                cmd.Parameters.AddWithValue("@hi", hiArea);



                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                // ViewApartment.Id
                // , StreetType
                // , StreetName
                // , HouseNumber
                // , ApartmentNumber
                // , Area
                // , CountRooms
                // , Price


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌────┬───────────────┬──────────────────────┬────────────┬────────────────┬─────────┬─────────────┬──────────────────┐");
                    Console.WriteLine($"| ID |   Тип улицы   |    Название улицы    | Номер дома | Номер квартиры | Площадь | Кол. комнат |       Цена       |");
                    Console.WriteLine($"├────┼───────────────┼──────────────────────┼────────────┼────────────────┼─────────┼─────────────┼──────────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetInt32(0),2} | " +                //  ID
                             $"{reader.GetString(1),-13} | " +              //  Тип улицы
                             $"{reader.GetString(2),-20} | " +              //  Название улицы
                             $"{reader.GetString(3),10} | " +              //  Номер дома
                             $"{reader.GetString(4),14} | " +              //  Номер квартиры
                             $"{reader.GetInt32(5),7} | " +                //  Площадь
                             $"{reader.GetInt32(6),11} | " +               //  Кол. комнат
                             $"{reader.GetDouble(7),16:n3} | ");            //  Цена   

                    } // while

                    Console.WriteLine($"└────┴───────────────┴──────────────────────┴────────────┴────────────────┴─────────┴─────────────┴──────────────────┘");


                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }


        //  6   Запрос с вычисляемыми полями    
        //      Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.
        //      Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные. 
        //      Сортировка по полю Дата сделки
        public void Query06()
        {
            Console.WriteLine("\nЗапрос 6");
            Console.WriteLine("Запрос с вычисляемыми полями");
            Console.WriteLine($"Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.");
            Console.WriteLine($"Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные.");
            Console.WriteLine("Сортировка по полю Дата сделки");
      

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select	                        
                        ViewDeals.Id
                        , RealtorSurname
                        , RealtorName
                        , RealtorPatronymic     
                        , [Date]
                        , Price
                        , Price * [Percent] / 100
                                        
	              from
	                  ViewDeals
                  order by
                      [Date]"
                );

                // задать соединение с БД
                cmd.Connection = connection;         

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();


                        // ViewDeals.Id
                        // , RealtorSurname
                        // , RealtorName
                        // , RealtorPatronymic
                        // , [Date]
                        // , Price
                        // , Price * [Percent] 


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌────┬────────────────────┬────────────────────┬─────────────────────┬──────────────┬──────────────────┬──────────────┐");
                    Console.WriteLine($"| ID |  Фамилия риелтора  |    Имя риелтора    |  Отчество риелтора  |     Дата     |       Цена       | Комиссионные |");
                    Console.WriteLine($"├────┼────────────────────┼────────────────────┼─────────────────────┼──────────────┼──────────────────┼──────────────┤");


                    while (reader.Read())
                    {                        

                        Console.WriteLine(
                             $"| {reader.GetInt32(0),2} | " +                                       //  ID
                             $"{reader.GetString(1),-18} | " +                                      //  Фамилия риелтора
                             $"{reader.GetString(2),-18} | " +                                      //  Имя риелтора
                             $"{reader.GetString(3),-19} | " +                                      //  Отчество риелтора
                             $"{reader.GetDateTime(4).ToString().Substring(0, 10),12} | " +         //  Дата
                             $"{reader.GetDouble(5),16} | " +                                       //  Цена
                             $"{reader.GetDouble(6),12:f3} | ");                                    //  Комиссионные   

                    } // while

                    Console.WriteLine($"└────┴────────────────────┴────────────────────┴─────────────────────┴──────────────┴──────────────────┴──────────────┘");


                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }


        //  7	Запрос на левое соединение  
        //      Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора.
        //      Упорядочить выборку по убыванию суммы сделок.
        public void Query07()
        {
            Console.WriteLine("\nЗапрос 7");
            Console.WriteLine("Запрос на левое соединение");
            Console.WriteLine($"Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора.");
            Console.WriteLine($"Упорядочить выборку по убыванию суммы сделок.");
    


            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                        Person.Surname  as RealtorSurname
                        , Person.[Name]  as RealtorName
                        , Person.Patronymic  as RealtorPatronymic
                        , COUNT (Deals.Id) as AmountClients                     
                        , IsNull(SUM (Apartment.Price),0) as TransactionAmount            
                  
                  from
                  
                     Realtor left join (Deals join ( Seller join Apartment on Seller.IdApartment = Apartment.Id)
                                              on Deals.IdSeller=Seller.Id  )
                                  on Deals.IdRealtor = Realtor.Id
                             left join Person on Realtor.IdPerson = Person.Id
                  
                  group by
                      Person.Surname, Person.[Name], Person.Patronymic
                  order by  
                      SUM (Apartment.Price) desc "
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                        // Person.Surname as RealtorSurname
                        // , Person.Name as RealtorName
                        // , Person.Patronimc as RealtorPatronymic
                        // , COUNT(Deals.Id) as AmountClients
                        // , SUM(Apartment.Price) as TransactionAmount


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌────────────────────┬────────────────────┬─────────────────────┬───────────────┬────────────────────────┐");
                    Console.WriteLine($"|  Фамилия риелтора  |    Имя риелтора    |  Отчество риелтора  | Кол. клиентов |      Сумма сделок      |");
                    Console.WriteLine($"├────────────────────┼────────────────────┼─────────────────────┼───────────────┼────────────────────────┤");


                    while (reader.Read())
                    {
                        
                        Console.WriteLine(
                             $"| {reader.GetString(0),-18} | " +                                    //  Фамилия риелтора
                             $"{reader.GetString(1),-18} | " +                                      //  Имя риелтора
                             $"{reader.GetString(2),-19} | " +                                      //  Отчество риелтора
                             $"{reader.GetInt32(3),13} | " +                                        //  Кол. клиентов
                             $"{reader.GetDouble(4),22} | ");                                       //  Сумма сделок                            

                    } // while

                    Console.WriteLine($"└────────────────────┴────────────────────┴─────────────────────┴───────────────┴────────────────────────┘");


                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }


        //  8	Запрос на левое соединение  
        //      Для всех улиц вывести сумму сделок, 
        //      упорядочить выборку по убыванию суммы сделки
        public void Query08()
        {
            Console.WriteLine("\nЗапрос 8");
            Console.WriteLine("Запрос на левое соединение");
            Console.WriteLine($"Для всех улиц вывести сумму сделок,");
            Console.WriteLine($"упорядочить выборку по убыванию суммы сделки");



            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      IsNull(StreetType.TypeOfStreet, N'')
                      , StreetName.NameOfStreet         
                      , IsNull(SUM (Apartment.Price),0) as TransactionAmount
                      
                  from

                    StreetName left join (((([Address] join  StreetType on [Address].IdStreetType = StreetType.id) join Apartment on Apartment.IdAddress = [Address].Id) join Seller on Seller.IdApartment = Apartment.Id) join Deals on Deals.IdSeller=Seller.Id)  on [Address].IdStreetName = StreetName.id

                  group by
                     StreetType.TypeOfStreet, StreetName.NameOfStreet
                  order by  
                      SUM (Apartment.Price) desc "
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Person.Surname as RealtorSurname
                // , Person.Name as RealtorName
                // , Person.Patronimc as RealtorPatronymic
                // , COUNT(Deals.Id) as AmountClients
                // , SUM(Apartment.Price) as TransactionAmount


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌───────────────────┬──────────────────────────┬───────────────────────┐");
                    Console.WriteLine($"|     Тип улицы     |      Название улицы      |      Сумма сделок     |");
                    Console.WriteLine($"├───────────────────┼──────────────────────────┼───────────────────────┤");


                    while (reader.Read())
                    {
                        //Console.WriteLine($"| {reader.GetString(0),-17} | ");
                        Console.WriteLine(
                             $"| {reader.GetString(0),-17} | " +                                    //  Фамилия риелтора
                             $"{reader.GetString(1),-24} | " +                                      //  Имя риелтора
                             $"{reader.GetDouble(2),21} | ");                                       //  Сумма сделок                            

                    } // while

                    Console.WriteLine($"└───────────────────┴──────────────────────────┴───────────────────────┘");


                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }


        //   9	Запрос на левое соединение 
        //      Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки.
        //      Диапазон задавать параметрами запроса
        public void Query09()
        {
            Console.WriteLine("\nЗапрос 9");
            Console.WriteLine("Запрос на левое соединение");
            Console.WriteLine($"Для всех улиц вывести сумму сделок за заданный период,");
            Console.WriteLine($"упорядочить выборку по убыванию суммы сделки");



            // подключение к БД
            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine("\nСоединение с серевером баз данных произошло успешно\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(
                @"select
                      IsNull(PeriodDeals.TypeOfStreet, N'')
                      , StreetName.NameOfStreet     
                      , IsNull(SUM (PeriodDeals.Price),0) as TransactionAmount
                      
                  from

                    StreetName left join 
                    (select StreetType.TypeOfStreet,  Deals.[Date], Apartment.Price, [Address].IdStreetName
                    from (((([Address] join  StreetType on [Address].IdStreetType = StreetType.id) join Apartment on Apartment.IdAddress = [Address].Id) join Seller on Seller.IdApartment = Apartment.Id) join Deals on Deals.IdSeller=Seller.Id)  
                    where Deals.[Date] between @lo and @hi) PeriodDeals
                    on PeriodDeals.IdStreetName = StreetName.id
                  
                  group by
                     PeriodDeals.TypeOfStreet, StreetName.NameOfStreet
                  order by  
                      SUM (PeriodDeals.Price) desc "
                );

                // задать соединение с БД
                cmd.Connection = connection;

                DateTime lo = new DateTime(2021,08,01);
                DateTime hi = new DateTime(2021,08,21);

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@lo", lo );
                cmd.Parameters.AddWithValue("@hi", hi );

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Person.Surname as RealtorSurname
                // , Person.Name as RealtorName
                // , Person.Patronimc as RealtorPatronymic
                // , COUNT(Deals.Id) as AmountClients
                // , SUM(Apartment.Price) as TransactionAmount


                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌───────────────────┬──────────────────────────┬───────────────────────┬──────────────┬──────────────┐");
                    Console.WriteLine($"|     Тип улицы     |      Название улицы      |      Сумма сделок     | Дата начала  |  Дата конца  |");
                    Console.WriteLine($"├───────────────────┼──────────────────────────┼───────────────────────┼──────────────┼──────────────┤");


                    while (reader.Read())
                    {
                        //Console.WriteLine($"| {reader.GetString(0),-17} | ");
                        Console.WriteLine(
                             $"| {reader.GetString(0),-17} | " +                                    //  Фамилия риелтора
                             $"{reader.GetString(1),-24} | " +                                      //  Имя риелтора
                             $"{reader.GetDouble(2),21} | " +                                      //  Сумма сделок            
                             $"{lo.ToString().Substring(0, 10),12} | " +                                                        //  Дата начала
                             $"{hi.ToString().Substring(0, 10),12} | ");                                                        //  Дата конца




                    } // while

                    Console.WriteLine($"└───────────────────┴──────────────────────────┴───────────────────────┴──────────────┴──────────────┘");


                } // if
            } // using
            Console.WriteLine("Соединение с серевером баз данных завершенно");
            Console.WriteLine();
        }
    }
}
