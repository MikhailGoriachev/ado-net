﻿-- База данных «Прокат автомобилей»


-- Создание хранимых процедур


-- 1. Хранимая процедура.
-- Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
drop proc if exists ProcQuery01;
go

create proc ProcQuery01 @numCar nvarchar(10)
as begin
      select
         *
      from
         ViewAllRentals
      where
         CarNumber = @numCar;
end;
go

exec ProcQuery01 N'X739OC';
go


-- 2. Хранимая процедура.
-- Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
drop proc if exists ProcQuery02;
go

create proc ProcQuery02 @modelCar nvarchar(15)
as begin
      select
         *
      from
         ViewAllRentals
      where
        Model = @modelCar;
end;
go

exec ProcQuery02 'Lexus';
go


-- 3. Хранимая процедура.
-- Выбирает информацию об автомобиле с заданным госномером
drop proc if exists ProcQuery03;
go

create proc ProcQuery03 @numCar nvarchar(10)
as begin
      select
         *
      from
         ViewCars
      where
         CarNumber = @numCar;
end;
go

exec ProcQuery03 N'H730CA';
go


-- 4. Хранимая процедура.
-- Выбирает информацию о клиентах по серии и номеру паспорта
drop proc if exists ProcQuery04;
go

create proc ProcQuery04 @passportNum nvarchar(10)
as begin
      select
         *
      from
         Clients
      where
         PassportNum = @passportNum;
end;
go

exec ProcQuery04 N'OH830853';
go


-- 5. Хранимая процедура.
-- Выбирает информацию обо всех зафиксированных фактах проката автомобилей в
-- некоторый заданный интервал времени.
drop proc if exists ProcQuery05;
go

create proc ProcQuery05 @fromDate date, @toDate date
as begin
      select
         *
      from
         ViewAllRentals
      where
         RentalStartDate between @fromDate and @toDate;
end;
go

exec ProcQuery05 '05-01-2021', '10-01-2021';
go


-- 6. Хранимая процедура.
-- Вычисляет для каждого факта проката стоимость проката.
-- Включает поля Дата проката, Госномер автомобиля,
-- Модель автомобиля, Стоимость проката.
-- Сортировка по полю Дата проката
drop proc if exists ProcQuery06;
go

create proc ProcQuery06 
as begin
      select
         RentalStartDate
         , CarNumber
         , Model
       -- Стоимость проката автомобиля определяется как 
       -- Стоимость одного дня проката * Количество дней проката. 
         , (PayRentalDay * Duration) as CostRental 
      from
         ViewAllRentals
      order by
         RentalStartDate;
end;
go

exec ProcQuery06;
go


-- 7. Хранимая процедура.
-- Для всех клиентов прокатной фирмы вычисляет количество фактов проката,
-- суммарное количество дней проката,
-- упорядочивание по убыванию суммарного количества дней проката
drop proc if exists ProcQuery07;
go

create proc ProcQuery07 
as begin
      select
         Clients.Surname + N' ' + Substring(Clients.[Name], 1, 1) + N'.' + 
                         Substring(Clients.Patronymic, 1, 1) + N'.' as Client
         , Count(Rentals.Id) as AmountRental
         , IsNull(Sum(Rentals.Duration), 0) as SumRentalDays
      from
         Clients left join Rentals on Clients.Id = Rentals.IdClient
      group by
         Clients.Surname, Clients.[Name], Clients.Patronymic
      order by
         SumRentalDays desc;
end;
go

exec ProcQuery07;
go


-- 8. Хранимая процедура.
-- Выбирает информацию о фактах проката автомобилей по госномеру:
-- количество фактов проката, сумма за прокаты, суммарная длительность прокатов
drop proc if exists ProcQuery08;
go

create proc ProcQuery08 
as begin
      select
         Cars.CarNumber
        , Count(Cars.CarNumber) as AmountRental
        , Sum(Cars.PayRentalDay * Rentals.Duration) as SumRental
        , Sum(Rentals.Duration) as SumRentalDays
      from 
        Rentals join(Cars join Models on Cars.IdModel = Models.Id)
                on Rentals.IdCar = Cars.Id
      group by
        Cars.CarNumber;
end;
go

exec ProcQuery08;
go