﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_LeftJoin_Shop_DB.Models
{
    public class Query2_ViewModel
    {
    }
}
