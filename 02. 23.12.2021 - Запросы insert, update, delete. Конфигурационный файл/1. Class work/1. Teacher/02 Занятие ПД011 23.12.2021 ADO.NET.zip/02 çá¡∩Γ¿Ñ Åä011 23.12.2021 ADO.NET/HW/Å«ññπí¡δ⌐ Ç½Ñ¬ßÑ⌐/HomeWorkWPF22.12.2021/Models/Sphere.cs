﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkWPF22._12._2021.Models
{
    public class Sphere
    {
        // радиус 
        private double _r;
        public double R
        {
            get { return _r; }
            set
            {
                if (value <= 0)
                    throw new Exception("Sphere: ошибка радиуса");
                _r = value;
            }
        }

        // плотность
        private double _p;
        public double P
        {
            get { return _p; }
            set
            {
                if (value <= 0)
                    throw new Exception("Sphere: ошибка плотности");
                _p = value;
            }
        }

        // конструкторы
        public Sphere() : this(1d, 1d) { }
        public Sphere(double r, double p)
        {
            R = r;           
            P = p;            
        }

        // вычисление полной площади поверхности
        public double GetS()
        {
            return 4d * Math.PI * _r * _r;
        }

        // вычисление объема  
        public double GetV()
        {
            return (4d * Math.PI * _r * _r * _r) / 3d;
        }

        // вычисление массы
        public double GetMass()
        {
            return GetV() * _p;
        }

    }
}
