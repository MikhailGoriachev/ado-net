﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Models
{
    // класс для отображения публикаций
    public class PublicationModel
    {
        // Id
        public int Id { get; set; }

        // Индекс публикации
        public string Index { get; set; }

        // Тип печатного издания
        public string TypeOfPrintEdition { get; set; }

        // название публикации
        public string NameOfPublication { get; set; }

        // цена 
        public int Price { get; set; }

        public PublicationModel(int id, string index, string typeOfPrintEdition, string nameOfPublication, int price)
        {
            Id = id;
            Index = index;
            TypeOfPrintEdition = typeOfPrintEdition;
            NameOfPublication = nameOfPublication;
            Price = price;        
        }

        public static string Header() {

            return 
            $"┌──────┬──────────────┬─────────────────────────────┬──────────────────────────────────────────┬──────────┐\n" +
            $"│  Id  │    Индекс    │         Тип издания         │             Название издания             │   Цена   │\n" +
            $"├──────┼──────────────┼─────────────────────────────┼──────────────────────────────────────────┼──────────┤";

        }

        public string ToTableRow() =>
            $"│ {Id,4} │ {Index,-12} │ {TypeOfPrintEdition,-27} │ {NameOfPublication,-40} │ {Price,8} │";


        public static string Footer() =>
            $"└──────┴──────────────┴─────────────────────────────┴──────────────────────────────────────────┴──────────┘\n";
        


    }
}
