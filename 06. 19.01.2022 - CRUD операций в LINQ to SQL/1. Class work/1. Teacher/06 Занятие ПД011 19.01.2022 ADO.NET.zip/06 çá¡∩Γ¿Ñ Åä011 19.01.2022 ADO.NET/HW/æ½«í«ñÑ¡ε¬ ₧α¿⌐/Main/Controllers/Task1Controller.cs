using System;
using System.Collections.Generic;
using System.Linq;
using Main.Infrastructure;
using Main.Models;
using Main.Utilities;
using Main.Utilities.Menu;
using Newtonsoft.Json;


namespace Main.Controllers
{
	public sealed class Task1Controller : MenuWrapper
	{
		private IList<Book> _books;


		public Task1Controller() => Menu = new("Первая задача", new[]
		{
			new MenuItem("Сгенерировать данные", Generate),
			new MenuItem("Вывести все книги коллекции, выводить фамилии и инициалы автора", SelectAuthors),
			new MenuItem("Вывести книги авторов, год рождения которых принадлежит заданном диапазону", SelectAuthorsWhereBornYearRange),
			new MenuItem("Книги в названии которых содержится заданная подстрока и цена не превышает заданного значения",
				SelectWhereSubstringAndPrice),
			new MenuItem("Список авторов и количество их книг в коллекции", SelectAuthorsWithBooksCount),
			new MenuItem("Средняя цена книг по годам издания", AveragePriceForYears),
			new MenuItem("Список авторов по убыванию количества их книг в коллекции", SelectAuthorsWithBooksCountDescending),
			new MenuItem("Средний возраст книг по авторам, выводить список с упорядочиванием фамилий и инициалов авторов",
				SelectAuthorsWithBooksAverageLifetime),
		});


		private void Generate()
		{
			_books = BookFactory.MakeMultipleBooks(General.Rand.Next(20, 32));

			ShowResult(_books);
		}


		// Вывести все книги коллекции, выводить фамилии и инициалы автора
		private void SelectAuthors()
		{
			var authors = _books.Select(book => book.Author.Fullname);

			ShowResult(authors);
		}


		// Вывести книги авторов, год рождения которых принадлежит заданном диапазону
		private void SelectAuthorsWhereBornYearRange()
		{
			var range = Range<int>.CreateWithRandom(() => General.Rand.Next(1950, 2022));

			Console.WriteLine($"Диапазон: {range}");

			var authors = _books.Where(book => range.IsInRangeInclusive(book.Author.BornYear));

			ShowResult(authors);
		}


		// Вывести книги, в названии которых содержится заданная подстрока и цена не превышает заданного значения
		private void SelectWhereSubstringAndPrice()
		{
			var substring = "а";
			var maxPrice = BookFactory.MakeBook().Price;

			Console.WriteLine($"Максимальная цена: {maxPrice}. Подстрока: {substring}");

			var result = _books.Where(book => book.Price < maxPrice && book.Title.Contains(substring));

			ShowResult(result);
		}


		// Список авторов и количество их книг в коллекции
		private void SelectAuthorsWithBooksCount()
		{
			var result = _books.GroupBy(book => book.Author)
							   .Select(books => new
							   {
								   Author     = books.Key,
								   BooksCount = books.Count()
							   });

			ShowResult(result);
		}


		// Средняя цена книг по годам издания
		private void AveragePriceForYears()
		{
			var result = _books.GroupBy(book => book.Published)
							   .Select(books => new
							   {
								   Published    = books.Key,
								   AveragePrice = books.Average(book => book.Price)
							   });

			ShowResult(result);
		}


		// Список авторов по убыванию количества их книг в коллекции
		private void SelectAuthorsWithBooksCountDescending()
		{
			var result = _books.GroupBy(book => book.Author)
							   .Select(books => new
							   {
								   Author     = books.Key,
								   BooksCount = books.Count()
							   })
							   .OrderByDescending(arg => arg.BooksCount)
							   .Select(arg => arg.Author);

			ShowResult(result);
		}


		// Средний возраст книг по авторам, выводить список с упорядочиванием фамилий и инициалов авторов
		private void SelectAuthorsWithBooksAverageLifetime()
		{
			var currentYear = DateTime.UtcNow.Year;
			
			var result = _books.GroupBy(book => book.Author)
							   .Select(books => new
							   {
								   Author     = books.Key,
								   AverageBooksLifetime = books.Average(book => currentYear - book.Published)
							   })
							   .OrderBy(arg => arg.Author.Fullname);

			ShowResult(result);
		}


		private static void ShowResult<T>(IEnumerable<T> values) =>
			Console.WriteLine(JsonConvert.SerializeObject(values, Formatting.Indented));
	}
}