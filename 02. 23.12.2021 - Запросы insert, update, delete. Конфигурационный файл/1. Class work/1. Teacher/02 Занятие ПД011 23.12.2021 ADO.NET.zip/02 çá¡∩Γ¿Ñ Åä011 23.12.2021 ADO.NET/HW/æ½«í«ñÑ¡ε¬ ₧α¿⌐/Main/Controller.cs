﻿using System;
using System.Linq;
using Main.Models;
using Main.Utilities.TableFormatter;


namespace Main
{
	public sealed class Controller
	{
		private readonly ClearAdoDataAccess _dataAccess;


		public Controller(string connectionString) =>
			_dataAccess = new(connectionString);


		public void Query1(string street, int rooms)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select * from ApartmentsView
					where Rooms = @rooms and Street = @street";
				command.Parameters.AddWithValue("@rooms", rooms);
				command.Parameters.AddWithValue("@street", street);
			});

			var items = _dataAccess.MapTo<ApartmentModel>(result);

			new TableFormatter<ApartmentModel>().Show(items);
		}


		public void Query2(string surnamePattern, double dealPercent)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select * from AgentsView
					where 
						AgentSurname like @surname and
						DealPercent > @percent";
				command.Parameters.AddWithValue("@surname", surnamePattern);
				command.Parameters.AddWithValue("@percent", dealPercent);
			});

			var items = _dataAccess.MapTo<AgentModel>(result);

			new TableFormatter<AgentModel>().Show(items);
		}


		public void Query3(int min, int max)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select * from ApartmentsView
					where Price between @min and @max";
				command.Parameters.AddWithValue("@min", min);
				command.Parameters.AddWithValue("@max", max);
			});

			var items = _dataAccess.MapTo<ApartmentModel>(result);

			new TableFormatter<ApartmentModel>().Show(items);
		}


		public void Query4(int rooms)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select * from ApartmentsView
					where Rooms = @rooms";
				command.Parameters.AddWithValue("@rooms", rooms);
			});

			var items = _dataAccess.MapTo<ApartmentModel>(result);

			new TableFormatter<ApartmentModel>().Show(items);
		}


		public void Query5(int rooms, (double min, double max) area)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select * from Apartments
					where 
						Rooms = @rooms and
						Area between @areaMin and @areaMax";
				command.Parameters.AddWithValue("@rooms", rooms);
				command.Parameters.AddWithValue("@areaMin", area.min);
				command.Parameters.AddWithValue("@areaMax", area.max);
			});

			var items = _dataAccess.MapTo<ApartmentModel>(result);

			new TableFormatter<ApartmentModel>().Show(items);
		}


		public void Query6()
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select 
						AgentSurname,
						AgentFirstname,
						AgentPatronymic,
						RegistrationDate,
						Price,
						DealPercent,
						dbo.CalculateAgentAward(Price, DealPercent) as AgentAward
					from DealsView
					order by RegistrationDate";
			});

			var items = _dataAccess.MapTo<Query6Model>(result);

			new TableFormatter<Query6Model>().Show(items);
		}


		public void Query7()
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select 
						a.AgentsId as AgentId,
						Count(ClientsId) as DealsCount,
						Sum(d.Price) as DealsTotal
					from AgentsView a
					left join DealsView d on a.AgentsId = d.AgentsId
					group by a.AgentsId";
			});

			var items = _dataAccess.MapTo<Query7Model>(result);

			new TableFormatter<Query7Model>().Show(items);
		}


		public void Query8()
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select
						a.Street,
						Sum(a.Price) as Total
					from Apartments a
					left join Deals d on d.ApartmentId = a.ApartmentsId
					group by a.Street
					order by Total desc";
			});

			var items = _dataAccess.MapTo<Query8Model>(result);

			new TableFormatter<Query8Model>().Show(items);
		}


		public void Query9((DateTime min, DateTime max) dates)
		{
			var result = _dataAccess.ExecuteQuery(command =>
			{
				command.CommandText = @"
					select
						a.Street,
						Sum(a.Price) as Total
					from Apartments a
					left join Deals d on a.ApartmentsId = d.ApartmentId
					where d.RegistrationDate between @firstDate and @secondDate
					group by a.Street
					order by Total desc";
				command.Parameters.AddWithValue("firstDate", dates.min);
				command.Parameters.AddWithValue("secondDate", dates.max);
			});

			var items = _dataAccess.MapTo<Query8Model>(result);

			new TableFormatter<Query8Model>().Show(items);
		}
	}
}