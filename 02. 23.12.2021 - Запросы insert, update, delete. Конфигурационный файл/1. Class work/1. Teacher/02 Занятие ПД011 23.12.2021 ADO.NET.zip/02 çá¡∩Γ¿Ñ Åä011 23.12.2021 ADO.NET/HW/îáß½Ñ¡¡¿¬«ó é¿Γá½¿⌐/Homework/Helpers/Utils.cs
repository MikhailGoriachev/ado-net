﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
	public static class Utils
	{
		public static void Init()
		{
			Console.Title = "Домашняя работа - введение в ADO.NET";
			Console.WindowWidth = 140;
			Console.WindowHeight = 32;
			Console.BufferHeight = 1000;
			Console.ForegroundColor = ConsoleColor.Black;
			Console.BackgroundColor = ConsoleColor.White;
			Console.CursorVisible = false;
			Console.Clear();
		}

		public static void ReadyGo()
		{
			Console.WriteLine("\n  Нажмите клавишу для продолжения...");
			Console.ReadKey();
			Console.Clear();
		}
	}
}
