﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Homework.Application
{
	internal partial class App
	{

		public void Task2Item1()
		{
			Utilities.ShowNavBar("  Вывод всех таблиц");
			
			_task2Controller.ShowAllTables();
		}
		private void Task2Item2()
		{
			Utilities.ShowNavBar("  Tовары, единицей измерения которых является «шт» и цена закупки составляет меньше 200 руб.");
			
			Console.WriteLine("\n\n  Запрос с помощью синтаксиса LINQ:\n");
			_task2Controller.Query01A();
			Console.WriteLine("\n\n  Запрос с помощью расширяющего метода:\n");
			_task2Controller.Query01B();
		}

		private void Task2Item3()
		{
			Utilities.ShowNavBar("  Товары, цена закупки которых больше 500 руб. за единицу товара.");

			Console.Write("\n\n  Массив вещественных чисел:\n  ");

			Console.WriteLine("\n\n  Запрос с помощью синтаксиса LINQ:\n");
			_task2Controller.Query02A();
			Console.WriteLine("\n\n  Запрос с помощью расширяющего метода:\n");
			_task2Controller.Query02B();
		}

		private void Task2Item4()
		{
			Utilities.ShowNavBar("  Товары с заданным наименованием, для которых цена закупки меньше 1800 руб.");

			Console.WriteLine("\n\n  Запрос с помощью синтаксиса LINQ:\n");
			_task2Controller.Query03A();
			Console.WriteLine("\n\n  Запрос с помощью расширяющего метода:\n");
			_task2Controller.Query03B();
		}

		private void Task2Item5()
		{
			Utilities.ShowNavBar("  Продавцы с заданным значением процента комиссионных.");

			Console.Write("\n\n  Массив вещественных чисел:\n  ");

			Console.WriteLine("\n\n  Запрос с помощью синтаксиса LINQ:\n");
			_task2Controller.Query04A();
			Console.WriteLine("\n\n  Запрос с помощью расширяющего метода:\n");
			_task2Controller.Query04B();
		}

		private void Task2Item6()
		{
			Utilities.ShowNavBar("  Все зафиксированные факты продажи товаров, с ценой продажи в заданных границах.");

			Console.Write("\n\n  Массив вещественных чисел:\n  ");

			Console.WriteLine("\n\n  Запрос с помощью синтаксиса LINQ:\n");
			_task2Controller.Query05A();
			Console.WriteLine("\n\n  Запрос с помощью расширяющего метода:\n");
			_task2Controller.Query05B();
		}

		private void Task2Item7()
		{
			Utilities.ShowNavBar("  Прибыль от продажи за каждый проданный товар. Сортировка по полю Наименование товара.");

			Console.Write("\n\n  Массив вещественных чисел:\n  ");

			Console.WriteLine("\n\n  Запрос с помощью синтаксиса LINQ:\n");
			_task2Controller.Query06A();
			Console.WriteLine("\n\n  Запрос с помощью расширяющего метода:\n");
			_task2Controller.Query06B();
		}

	}
}