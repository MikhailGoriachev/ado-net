﻿/* База данных «Оптовый магазин. Учет продаж»  */

-- справочник единиц измерения
select
   *
from
    Units;
go

-- справочник номенклатуры товаров
select
    *
from
    Goods;
go


-- персональные данные
select
    *
from
    Persons;
go

-- продавцы
select
   Sellers.Id
   , Persons.Surname
   , Persons.[Name]
   , Persons.Patronymic
   , Sellers.Interest
from
    Sellers join Persons on Sellers.IdPerson = Persons.Id;
go

-- закупки товаров 
select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id;
go

-- факты продаж
select
    Sales.Id
    , Goods.Item
    , Units.Short
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Sales.SaleDate
    , Purchases.Price   as PurchasePrice
    , Sales.Price       as SalePrice
    , Sales.Amount
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id) on Sales.IdSeller = Sellers.IdPerson
          join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id;
go

-- запросы по заданию

-- Запрос  1. Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых 
-- является «шт» (штуки) и цена закупки составляет меньше 200 руб.
declare @unit nvarchar(6) = N'шт', @price int = 200;

select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id
where
    Units.Short = @unit and Purchases.Price < @price;
go

-- Запрос  2. Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах, цена закупки которых больше 
-- 500 руб. за единицу товара
declare @price int = 500;

select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id
where
    Purchases.Price > @price;
go

-- Запрос  3. Запрос с параметрами	
-- Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием 
-- (например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
declare @item nvarchar(60) = N'чехол защитный', @price int = 1800;

select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id
where
    Goods.Item = @item and Purchases.Price < @price;
go


-- Запрос  4. Запрос с параметрами	
-- Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением
-- процента комиссионных.
declare @interest float = 8;

select
   Sellers.Id
   , Persons.Surname
   , Persons.[Name]
   , Persons.Patronymic
   , Sellers.Interest
from
    Sellers join Persons on Sellers.IdPerson = Persons.Id
where 
    Sellers.Interest = @interest;
go

-- Запрос  5. Запрос с параметрами	
-- Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех 
-- зафиксированных фактах продажи товаров (Наименование товара, Цена закупки, 
-- Цена продажи, дата продажи), для которых Цена продажи оказалась в некоторых 
-- заданных границах. 
declare @fromPrice int = 15000, @toPrice int = 150000;

select
    Sales.Id
    , Goods.Item
    , Units.Short
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Sales.SaleDate
    , Purchases.Price   as PurchasePrice
    , Sales.Price       as SalePrice
    , Sales.Amount
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id) on Sales.IdSeller = Sellers.IdPerson
          join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id
where
   Sales.Price between @fromPrice and @toPrice;
go

-- Запрос  6. Запрос с вычисляемыми полями	
-- Вычисляет прибыль от продажи за каждый проданный товар. Включает поля 
-- Дата продажи, Наименование товара, Цена закупки, Цена продажи, Количество 
-- проданных единиц, Прибыль. Сортировка по полю Наименование товара
select
    Sales.Id
    , Goods.Item
    , Units.Short
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Sales.SaleDate
    , Sales.Amount
    , Purchases.Price   as PurchasePrice
    , Sales.Price       as SalePrice
    , (Sales.Price - Purchases.Price) * Sales.Amount as Profit 
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id) on Sales.IdSeller = Sellers.IdPerson
          join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id
order by
    Goods.Item;
go


-- Запрос  7. Запрос на левое соединение	
-- Выбирает всех продавцов (выводить Код продавца, фамилию и инициалы 
-- продавца), количество и суммы их продаж за заданный период, упорядочивать 
-- по фамилиям и инициалам
declare @from date = '11-01-2021', @to date = '11-30-2021';
select
   Sellers.Id
   , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
   , Sellers.Interest
   , count(PeriodSales.IdSeller)                               as SalesAmount
   , isnull(sum(PeriodSales.Price*PeriodSales.Amount), 0)      as SalesTotal
from
    (Sellers join Persons on Sellers.IdPerson = Persons.Id)
    left join
    -- продажи за заданный период
    (select IdSeller, IdPurchase, Price, Amount from Sales where SaleDate between @from and @to) PeriodSales
    on Sellers.Id = PeriodSales.IdSeller 
group by
    Sellers.Id, Persons.Surname, Persons.[Name], Persons.Patronymic, Sellers.Interest
order by
    Seller;
go


-- Запрос  8. Запрос на левое соединение	
-- Выбирает все товары, количество и сумму продаж по этим товарам. 
-- Упорядочивать по убыванию суммы продаж
select
    Goods.Id
    , Goods.Item
    , count(Sales.IdUnit)                         as SalesAmount
    , isNull(sum(Sales.Price*Sales.Amount), 0)    as SalesTotal
from
    Goods left join (Sales join Purchases on Sales.IdPurchase = Purchases.Id) 
        on Goods.Id = Purchases.IdUnit
group by
    Goods.Id, Goods.Item
order by
    SalesTotal desc;
go


-- Запрос  9. Итоговый запрос	
-- Выполняет группировку по полю Наименование товара. Для каждого наименования
-- вычисляет среднюю цену закупки товара, количество закупок
select
    Goods.Item
    , Units.Long
    , count(Purchases.IdItem) as PurchasesAmount
    , avg(Purchases.Price)    as PurchasesTotal
from
    Goods join (Purchases join Units on Purchases.IdUnit = Units.Id) on Goods.Id = Purchases.IdItem
group by
    Goods.Item, Units.Long;

go


-- Запрос 10. Итоговый запрос	
-- Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ. Для каждого 
-- продавца вычисляет среднее значение по полю Цена продажи единицы товара, 
-- количество продаж
select
    Sales.IdSeller
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Persons.Passport
    , count(Sales.IdSeller) as SalesAmount
    , avg(Sales.Price)      as AvgPrice
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id)
          on Sales.IdSeller = Sellers.Id
group by
    Sales.IdSeller, Persons.Surname, Persons.[Name], Persons.Patronymic, Persons.Passport
order by
    AvgPrice desc;
go


-- Запрос 11. Итоговый запрос с объединением	
-- Тремя запросами к таблице ТОВАРЫ с объединением определить минимальную цену
-- закупки единицы товара, среднюю цену закупки единицы товара, максимальную 
-- цену закупки единицы товара. Выводить текстовые названия значений
select
    N'минимальная цена закупки единицы товара' as Parameter
    , min(Price)                               as [Value]
from
    Purchases

union all

select
    N'средняя цена закупки единицы товара'
    , avg(Price)
from
    Purchases

union all

select
    N'максимальная цена закупки единицы товара'
    , max(Price)
from
    Purchases;
go

    
-- Запрос 12. Итоговый запрос с объединением	
-- Двумя запросами с объединением к таблицам ТОВАРЫ, ПРОДАВЦЫ, ПРОДАЖИ выводить
-- наименование товара и его количество, фамилии и инициалы продавцов и 
-- количество продаж
select
    Goods.Item          as ItemOrSeller
    , Units.Short       as UnitOrPassport
    , sum(Sales.Amount) as Amount
from
    Sales join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id
group by
    Goods.Item, Units.Short

union all

select
    Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Persons.Passport
    , count(Sales.IdSeller) as SalesAmount
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id)
          on Sales.IdSeller = Sellers.Id
group by
    Persons.Surname, Persons.[Name], Persons.Patronymic, Persons.Passport
go


-- Запрос 13. Запрос на создание базовой таблицы	
-- Создает таблицу ТОВАРЫ_ШТ, содержащую информацию о товарах, единицей 
-- измерения которых является «шт» (штуки)
drop table if exists Unit_Goods;
select
    *
    into Unit_Goods
from
    Goods
where
    Id in (select IdItem from Purchases join Units on Purchases.IdUnit = Units.Id where Units.Short = N'шт');
select * from Unit_Goods;
go

-- Запрос 14. Запрос на создание базовой таблицы	
-- Создает копию таблицы ТОВАРЫ с именем КОПИЯ_ТОВАРЫ
select
    *
    into Copy_Purchases
from
    Purchases;
select * from Copy_Purchases;
go


-- Запрос 15. Запрос на удаление	
-- Удаляет из таблицы КОПИЯ_ТОВАРЫ записи, в которых значение в поле Цена 
-- закупки единицы товара больше 500 руб.
declare @price int = 500;
delete from
    Copy_Purchases
where
    Price > @price;
select * from Copy_Purchases;
go

-- Запрос 16. Запрос на обновление	
-- Устанавливает значение в поле Процент комиссионных таблицы ПРОДАВЦЫ 
-- равным 10% для тех продавцов, процент комиссионных которых составляет 8%
declare @boundInterest float = 8, @newInterest float = 10;

update
    Sellers
set
    Interest = @newInterest
where
    Interest = @boundInterest;
go

