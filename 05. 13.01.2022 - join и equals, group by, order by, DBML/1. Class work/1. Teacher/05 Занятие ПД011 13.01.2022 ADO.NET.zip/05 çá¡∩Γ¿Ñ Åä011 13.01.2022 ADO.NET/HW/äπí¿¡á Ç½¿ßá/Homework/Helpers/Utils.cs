﻿using Homework.Models;
using System;

namespace Homework.Helpers
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();
        
        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line) {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask
        
        
        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color) {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu, ConsoleColor foregroundColor = ConsoleColor.Cyan, ConsoleColor backgroundColor = ConsoleColor.Gray) {
            WriteXY(x, y, title, backgroundColor);
            int offsetY = 2;

            foreach (var menuItem in menu) {
                WriteXY(x, y + offsetY, menuItem.HotKey.ToString(), foregroundColor);
                WriteXY(x + 2, y + offsetY++, menuItem.Text, backgroundColor);
            } // foreach menuItem
        } // ShowMenu

        // Установить текущий цвет символов и фона с сохранением
        // текущего цвета символов и фона
        private static (ConsoleColor Fore, ConsoleColor Back) _storeColor;
        public static void SetColor(ConsoleColor fore, ConsoleColor back) {
            _storeColor = (Console.ForegroundColor, Console.BackgroundColor);
            Console.ForegroundColor = fore;
            Console.BackgroundColor = back;
        } // SetColor

        // Сохранить цвет
        public static void SaveColor() =>
            _storeColor = (Console.ForegroundColor, Console.BackgroundColor);

        // Восстановить сохраненный цвет
        public static void RestoreColor() =>
            (Console.ForegroundColor, Console.BackgroundColor) = _storeColor;

        // для заполнения коллекции товаров начальными значениямм
        public static (string Name, int Price, int old)[] seeds = {
                ("ручка гелевая",           35, 2),
                ("галоши резиновые",       230, 5),
                ("пиджак импортный",      1210, 6),
                ("кинокамера",            2800, 15),
                ("маркер спиртовый",        50, 2),
                ("зонтик автоматический",  950, 4),
                ("телевизор",           10_950, 12),
            };

        // расширяющий метод для класса Good, возвращающий процент скидки
        // в зависимости от возраста товара – до 3х лет скидка не представляется,
        // от 3х до 10 лет скидка 3%, свыше 10 лет – скидка 7%. 
        public static int Percent(this Good x) {
            int old = DateTime.Now.Year - x.Year;

            if (old < 3) return 0;
            else if (old < 10) return 3;
            else return 7;
        } // Percent
    } // class Utils
}