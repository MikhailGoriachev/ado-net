﻿using Main.Infrastructure;
using Main.Pages.Query;
using Stylet;


namespace Main.Pages.Shell
{
	public sealed class ShellViewModel : Conductor<Screen>.Collection.OneActive, IShell
	{
		public ShellViewModel() => AddQueries();


		private void AddQueries()
		{
			var provider = new QueriesProvider();

			foreach (var (title, result) in provider.Queries())
			{
				var queryViewModel = new QueryViewModel(title, result);

				Items.Add(queryViewModel);
			}
		}
	}
}