﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Application
{
    public partial class App
    {
        // Демонстрация вычисления количества элементов массива, со значениями в диапазоне от A до B
        public void DemoTask2Query1() {

            double lo = Utils.GetRandom(-100d, 50d);
            double hi = lo + Utils.GetRandom(0d, 50d);


            _task2Controller.Task1(lo, hi);       
        
        
        }

        // Вычисление количества элементов массива, равных 0
        public void DemoTask2Query2()
        {
            _task2Controller.Task2();
        }

        // Вычисление суммы элементов массива, расположенных после первого максимального элемента
        public void DemoTask2Query3()
        {
            _task2Controller.Task3();
        }


        // Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом
        public void DemoTask2Query4()
        {
            _task2Controller.Task4();
        }

    }
}
