﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3ADO.NET.Models
{
    //модель класса изданий
    class Publication
    {
        public int id { get; set; }             //айди
        public string EditName { get; set; }    //название издания
        public string EditType { get; set; }    //типо издаваемого материала
        public int Cost { get; set; }           //стоимость экземпляра

        //шапка таблицы
        public static string HeaderOfTable()
            => " ______________________________________________________________\n" +
            "| id |  Название издания    |     Тип издания      | Стоимость |\n"+
            "|____|______________________|______________________|___________|";
        //дно таблицы
        public static string BottomOfTable()
            => "|____|______________________|______________________|___________|";
        public override string ToString()
            => $"{id}\t{EditName}\t{EditType}\t{Cost}";

        //представление в виде строки таблицы
        public string ToTableRow()
            => $"| {id,2} | {EditName,-20} | {EditType,-20} |   {Cost,5}   |";
    }
}
