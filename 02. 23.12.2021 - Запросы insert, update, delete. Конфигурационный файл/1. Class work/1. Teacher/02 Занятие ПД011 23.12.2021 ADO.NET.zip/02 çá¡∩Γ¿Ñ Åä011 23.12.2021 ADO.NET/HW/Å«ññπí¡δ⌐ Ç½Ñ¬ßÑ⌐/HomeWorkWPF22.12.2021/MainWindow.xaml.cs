﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HomeWorkWPF22._12._2021.Views;

namespace HomeWorkWPF22._12._2021
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SelectConoid_Command(object sender, RoutedEventArgs e)
        {
            ConoidWindow ConoidWindow = new ConoidWindow();
            ConoidWindow.ShowDialog();
        }

        private void SelectCylinder_Command(object sender, RoutedEventArgs e)
        {
            CylinderWindow CylinderWindow = new CylinderWindow();
            CylinderWindow.ShowDialog();
        }

        private void SelectRectangular_Command(object sender, RoutedEventArgs e)
        {
            RectangularWindow RectangularWindow = new RectangularWindow();
            RectangularWindow.ShowDialog();
        }

        private void SelectSphere_Command(object sender, RoutedEventArgs e)
        {
            SphereWindow SphereWindow = new SphereWindow();
            SphereWindow.ShowDialog();
        }

        private void About_Command(object sender, RoutedEventArgs e)
        {
            AboutWindow AboutWindow = new AboutWindow();
            AboutWindow.ShowDialog();
        }

        private void Exit_Command(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
