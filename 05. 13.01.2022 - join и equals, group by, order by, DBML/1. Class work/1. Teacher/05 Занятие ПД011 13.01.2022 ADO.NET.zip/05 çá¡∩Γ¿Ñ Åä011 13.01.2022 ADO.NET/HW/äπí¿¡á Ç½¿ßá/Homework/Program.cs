﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Configuration;
using Homework.Helpers;
using Homework.Application;

namespace Homework
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создание экземпляра класса приложения
            App app = new App();


            Console.Title = "Задание на 13.01.2022";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Демонстрация работы расширяющего метода."},
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 2. Вычислить количество элементов массива, со значениями в диапазоне."},
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 2. Вычислить количество элементов массива, равных 0"},
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 2. Сумма элементов, расположенных после первого максимального элемента."},
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 2. Сумма элементов, расположенных перед последним минимальным по модулю элементом."},
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 3. Товары с заданным диапазоном цен"},
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 3. Cумма товаров с заданным годом выпуска"},
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 3. Cумма товаров с заданным наименованием"},
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 3. Hаименование и год выпуска товаров с максимальным количеством"},
                new MenuItem { HotKey = ConsoleKey.G, Text = "Задача 3. Tовары, для которых произведение цены на количество находится в заданном диапазоне"},
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };


            // главный цикл приложения
            while (true)
            {
                try
                {

                    // настройка цветового оформления
                    Utils.SetColor(ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Utils.SaveColor();
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 13.01.2022");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        //  Демонстрация работы расширяющего метода
                        case ConsoleKey.Q:
                            app.ExecShowPercent();
                            break;

                        //  Вычислить количество элементов массива, со значениями в диапазоне
                        case ConsoleKey.W:
                            app.ExecCountInRange();
                            break;

                        // Вычислить количество элементов массива, равных 0
                        case ConsoleKey.E:
                            app.ExecCountZeros();
                            break;

                        // Сумма элементов, расположенных после первого максимального элемента
                        case ConsoleKey.R:
                            app.ExecSumAfterMax();
                            break;

                        // Сумма элементов, расположенных перед последним минимальным по модулю элементом
                        case ConsoleKey.T:
                            app.ExecSumBeforeMin();
                            break;

                        // Товары с заданным диапазоном цен
                        case ConsoleKey.A:
                            app.ExecGoodsInRange();
                            break;

                        // Cумма товаров с заданным годом выпуска
                        case ConsoleKey.S:
                            app.ExecGoodsByYear();
                            break;

                        // Cумма товаров с заданным наименованием
                        case ConsoleKey.D:
                            app.ExecGoodsByName();
                            break;

                        // Наименование и год выпуска товаров с максимальным количеством
                        case ConsoleKey.F:
                            app.ExecMaxNumberGoods();
                            break;

                        // Tовары, для которых произведение цены на количество находится в заданном диапазоне
                        case ConsoleKey.G:
                            app.ExecGoodsPriceInRange();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex)
                {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message,-79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally
                {
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
