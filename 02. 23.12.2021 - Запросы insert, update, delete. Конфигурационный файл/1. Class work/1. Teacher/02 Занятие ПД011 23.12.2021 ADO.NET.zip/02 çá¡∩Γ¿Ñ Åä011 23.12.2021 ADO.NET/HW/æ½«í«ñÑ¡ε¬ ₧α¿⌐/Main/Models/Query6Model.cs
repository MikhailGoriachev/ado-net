﻿using System;
using System.Data;
using Main.Utilities.TableFormatter;


namespace Main.Models
{
	public sealed class Query6Model : IMappable<Query6Model>
	{
		[TableData("Имя", "{0, -15}")]
		public string? AgentFirstname { get; set; }

		[TableData("Фамилия", "{0, -15}")]
		public string? AgentSurname { get; set; }

		[TableData("Отчество", "{0, -10}")]
		public string? AgentPatronymic { get; set; }

		[TableData("Процент", "{0, -10:F1}")]
		public double DealPercent { get; set; }

		[TableData("Дата", "{0, -10:d}")]
		public DateTime RegistrationDate { get; set; }

		[TableData("Цена", "{0, -12:N0}")]
		public decimal Price { get; set; }

		[TableData("Комиссионные", "{0, -14:N0}")]
		public decimal AgentAward { get; set; }


		public Query6Model Map(DataRow row) =>
			new()
			{
				AgentFirstname   = (string)row["AgentFirstname"],
				AgentSurname     = (string)row["AgentSurname"],
				AgentPatronymic  = (string)row["AgentPatronymic"],
				Price            = (decimal)row["Price"],
				DealPercent      = (double)row["DealPercent"],
				AgentAward       = (decimal)row["AgentAward"],
				RegistrationDate = (DateTime)row["RegistrationDate"],
			};
	}
}