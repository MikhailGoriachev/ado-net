﻿using System;
using Main.Utilities.TableFormatter;


namespace Main.Models.CarRenting
{
	public sealed class RentTotalForAllOrders
	{
		[TableData("Номер", "{0, -15}")]
		public string? LicenseNumber { get; set; }

		[TableData("Модель", "{0, -25}")]
		public string? Model { get; set; }

		[TableData("Дата начала", "{0, -17:d}")]
		public DateTime StartDate { get; set; }

		[TableData("Стоимость", "{0, -17:N0}")]
		public decimal Total { get; set; }
	}
}