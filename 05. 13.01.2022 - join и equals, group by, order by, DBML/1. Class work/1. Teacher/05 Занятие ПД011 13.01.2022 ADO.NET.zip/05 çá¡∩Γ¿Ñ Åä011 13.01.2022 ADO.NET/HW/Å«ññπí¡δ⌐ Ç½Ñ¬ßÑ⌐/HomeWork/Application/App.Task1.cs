﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Application
{
    public partial class App
    {
        // демонстрация задачи 1
        public void DemoTask1() {

             _task1Controller.Demo();
        
        }
            
    }
}
