﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
	public static class Utilities
	{
		private static Random _rand = new Random();

		// Метод, выполняющий запрос процедуры БД и выводяющий в табличном виде в консоль
		public static void ExecuteDbProcedure(string connectionString, string command, List<SqlParameter> parameters = null)
		{
			// подключение к БД
			using (SqlConnection connection = new SqlConnection(connectionString))
			{
				connection.Open();   // подключение к серверу, блокирующий вызов

				SqlCommand cmd = new SqlCommand(command, connection){
					CommandType = CommandType.StoredProcedure
				};
				
				// задать параметры запроса, если есть
				parameters?.ForEach(x => cmd.Parameters.Add(x));

				// выполнение запроса, ссылка на  выбранные данные - reader
				SqlDataReader reader = cmd.ExecuteReader();

				// Отображение результата в таблице
				if (reader.HasRows)
					Console.WriteLine(Utilities.SqlQueryToTable(reader));
			}
			Console.WriteLine();
		}
		
		// формирование таблицы SqlDataReader в строковом представлении
		public static string SqlQueryToTable(SqlDataReader reader, int indent = 4)
		{
			// количество колонок
			int nColumns = reader.FieldCount;

			// список самой длинной строки в каждой из колонок
			List<int> maxes = new();

			// список названий колонок
			var columns = new List<string>();
			
			// заполнение списка названий колонок
			for (int i = 0; i < nColumns; i++)
			{
				columns.Add(reader.GetName(i));
				// начальные значения максимальных длин в столбцах - по заголовкам
				maxes.Add(reader.GetName(i).Length);
			}

			// сохранение данных из SqlDataReader в коллекцию строк

			List<List<string>> data = new();
			

			while (reader.Read())
			{
				data.Add(new List<string>());
				for (int i = 0; i < nColumns; i++)
				{
					var cell = reader[columns[i]];

					// нужное форматирование в случае даты
					if (cell is DateTime){
						data[data.Count() - 1].Add($"{cell:dd/MM/yyyy}");
						continue;
					}

					data[data.Count() - 1].Add($"{cell}");
				}
			}

			// определение максимальных длин в каждом столбце
			for (int i = 0; i < data[0].Count; i++)
				foreach (var t in data)
					maxes[i] = Math.Max(t[i].Length, maxes[i]);

			//--------------------------------------

			// StringBuilder для формирования таблицы
			StringBuilder table = new();
			
			// формирование верхней границы
			table.Append(' ', indent);
			table.Append("┌");
			for (int i = 0; i < nColumns; i++)
			{
				table.Append('─', maxes[i] + 2);
				table.Append(i != nColumns - 1 ? "┬" : "┐");
			}

			// формирование заголовока
			table.Append("\n");
			table.Append(' ', indent);
			table.Append("│");
			int n = 0;
			columns.ForEach(x => table.AppendFormat($" {x.PadRight(maxes[n++])} │"));
			
			// формирование промежуточной границы
			table.Append("\n");
			table.Append(' ', indent);
			table.Append("├");
			for (int i = 0; i < nColumns; i++)
			{
				table.Append('─', maxes[i] + 2);
				table.Append(i != nColumns - 1 ? "┼" : "┤");
			}

			// формирование строк с данными
			foreach (var row in data)
			{
				int r = 0;
				
				table.Append("\n");
				table.Append(' ', indent);
				table.Append("│");

				foreach (var col in row)
					// форматирование отступов слева/справа в зависимости от возможности приведения к числу
					table.AppendFormat(double.TryParse(col, out var tmp)
						? $" {col.PadLeft(maxes[r++])} │"
						: $" {col.PadRight(maxes[r++])} │");
			}

			// формирование заверщающей границы
			table.Append("\n");
			table.Append(' ', indent);
			table.Append("└");
			for (int i = 0; i < nColumns; i++)
			{
				table.Append('─', maxes[i] + 2);
				table.Append(i != nColumns - 1 ? "┴" : "┘");
			}
			
			return table.ToString();
		}


		public static void ShowNavBar(string promt)
		{
			// сохранить цвет фона
			ConsoleColor oldBkColor = Console.BackgroundColor;

			string header = new string(' ', Console.WindowWidth);

			Console.BackgroundColor = ConsoleColor.Gray;
			Console.SetCursorPosition(0, 0);
			Console.Write(header);

			// Выводим текст в верхнюю строку
			WriteXY(2, 0, promt, ConsoleColor.Black);

			// восстановить цвет фона
			Console.BackgroundColor = oldBkColor;
		}

		// Вспомогательный метод для вывода в заданных координатах окна консоли текста
		// заданным цветом
		public static void WriteXY(int x, int y, string s, ConsoleColor color)
		{
			// сохранить текущий цвет консоли и установить заданный
			ConsoleColor oldColor = Console.ForegroundColor;
			Console.ForegroundColor = color;

			Console.SetCursorPosition(x, y);
			Console.WriteLine(s);

			// восстановить цвет консоли
			Console.ForegroundColor = oldColor;
		}

		public static void WriteColored(string str, ColorSet colors)
		{
			ColorSet curColors = new ColorSet(true);
			colors.SetToConsole();
			Console.Write(str);
			curColors.SetToConsole();
		}


		public static double GenerateDouble(double from, double to) => from + _rand.NextDouble() * (to - from);
		public static int GenerateInt(int from, int to) => _rand.Next(from, to);


		public class ColorSet
		{
			public ConsoleColor Foreground { get; set; }
			public ConsoleColor Background { get; set; }

			public ColorSet(bool currentConsole = false)
			{
				if (currentConsole)
				{
					Foreground = Console.ForegroundColor;
					Background = Console.BackgroundColor;
				}
			}

			public void SetToConsole()
			{
				Console.ForegroundColor = Foreground;
				Console.BackgroundColor = Background;
			}

			public static void SetToConsole(ColorSet colors)
			{
				Console.ForegroundColor = colors.Foreground;
				Console.BackgroundColor = colors.Background;
			}

		}

		public static class Palette
		{
			public static ColorSet Ordinary = new ColorSet()
				{Foreground = ConsoleColor.Green, Background = ConsoleColor.Black};

			public static ColorSet Notice = new ColorSet()
				{ Foreground = ConsoleColor.DarkCyan, Background = ConsoleColor.Black };

			public static ColorSet Context = new ColorSet()
				{ Foreground = ConsoleColor.Yellow, Background = ConsoleColor.Black };

			public static ColorSet TableRow = new ColorSet()
				{ Foreground = ConsoleColor.Black, Background = ConsoleColor.Green };
		}
	}
}
