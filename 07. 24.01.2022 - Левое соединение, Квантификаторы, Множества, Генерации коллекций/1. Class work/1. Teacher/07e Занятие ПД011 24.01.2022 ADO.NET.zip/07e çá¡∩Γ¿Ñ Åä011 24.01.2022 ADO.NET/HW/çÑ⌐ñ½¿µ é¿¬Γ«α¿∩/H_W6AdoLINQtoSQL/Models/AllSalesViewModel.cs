﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6AdoLINQtoSQL.Models
{
    // Класс для Представления для всех зафиксированных продажах
    public class AllSalesViewModel
    {
        public string Name { get; set; }
        public int PricePurchase { get; set; }
        public int PriceSale { get; set; }
        public DateTime DateSale { get; set; }

    }// class AllSalesViewModel
}
