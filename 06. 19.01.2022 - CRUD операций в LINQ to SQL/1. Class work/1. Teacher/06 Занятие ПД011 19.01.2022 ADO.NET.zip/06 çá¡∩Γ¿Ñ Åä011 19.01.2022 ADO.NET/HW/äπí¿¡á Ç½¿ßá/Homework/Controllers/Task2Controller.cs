﻿using Homework.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models.Task02;

namespace Homework.Controllers
{
    class Task2Controller
    {
        // контекст данных - подключение к базе данных
        private WholesaleDataContext _db;
        public Task2Controller() { 
            _db = new WholesaleDataContext();
        } // Task2Controller


        // Информация о товарах, единица измерения которых «шт» (штуки) и цена закупки меньше 200 руб
        // синтаксис LINQ
        public void Query01A(string unit = "шт", int price = 200) {
            var query =
                from purchase in _db.Purchases
                where purchase.Units.Short == unit && purchase.Price < price
                select new Purchase {
                    Id = purchase.Id,  
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(Purchase.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Purchase.Footer());
        } // Query01A

        // Информация о товарах, единица измерения которых «шт» (штуки) и цена закупки меньше 200 руб
        // синтаксис расширяющих методов
        public void Query01B(string unit = "шт", int price = 200) {
            var query = _db.Purchases
                .Where(purchase => purchase.Units.Short == unit && purchase.Price < price)
                .Select(purchase => new Purchase {
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                });

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(Purchase.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Purchase.Footer());
        } // Query01B


        // Информация о товарах, цена закупки которых больше 500 руб
        // синтаксис LINQ
        public void Query02A(int price = 500) {
            var query =
                from purchase in _db.Purchases
                where purchase.Price > price
                select new Purchase {
                    Id = purchase.Id,  
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(Purchase.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Purchase.Footer());
        } // Query02A

        // Информация о товарах, цена закупки которых больше 500 руб
        // синтаксис расширяющих методов
        public void Query02B(int price = 500) {
            var query = _db.Purchases
                .Where(purchase => purchase.Price > price)
                .Select(purchase => new Purchase {
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                });

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(Purchase.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Purchase.Footer());
        } // Query02B


        // Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1800 руб
        // синтаксис LINQ
        public void Query03A(string good, int price = 1800) {
            var query =
                from purchase in _db.Purchases
                where purchase.Price > price && purchase.Goods.Item == good
                select new Purchase {
                    Id = purchase.Id,  
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(Purchase.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Purchase.Footer());
        } // Query03A

        // Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1800 руб
        // синтаксис расширяющих методов
        public void Query03B(string good, int price = 1800) {
            var query = _db.Purchases
                .Where(purchase => purchase.Price > price && purchase.Goods.Item == good)
                .Select(purchase => new Purchase {
                    Id = purchase.Id,
                    Price = purchase.Price,
                    Amount = purchase.Amount,
                    Good = purchase.Goods.Item,
                    PurchaseDate = purchase.PurchaseDate,
                    Unit = purchase.Units.Short
                });

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(Purchase.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Purchase.Footer());
        } // Query03B


        // Информация о продавцах с заданным значением процента комиссионных.
        // синтаксис LINQ
        public void Query04A(double interest) {
            var query =
                from seller in _db.Sellers
                where seller.Interest == interest
                select new Seller {
                    Id = seller.Id,
                    Interest = seller.Interest,
                    Name = seller.Persons.Name,
                    Surname = seller.Persons.Surname,
                    Patronymic = seller.Persons.Patronymic,
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(Seller.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Seller.Footer());
        } // Query04A

        // Информация о продавцах с заданным значением процента комиссионных.
        // синтаксис расширяющих методов
        public void Query04B(double interest) {
            var query = _db.Sellers
                .Where(seller => seller.Interest == interest)
                .Select(seller => new Seller {
                    Id = seller.Id,
                    Interest = seller.Interest,
                    Name = seller.Persons.Name,
                    Surname = seller.Persons.Surname,
                    Patronymic = seller.Persons.Patronymic,
                });

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(Seller.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Seller.Footer());
        } // Query04B

        // Информация о фактах продажи, для которых цена продажи в заданном диапазоне
        // синтаксис LINQ
        public void Query05A(int lo, int hi) {
            var query =
                from sale in _db.Sales
                where sale.Price >= lo && sale.Price <= hi
                select new Sale {
                    Id = sale.Id,
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    Unit = sale.Units.Short,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                    Seller = sale.Sellers.Persons.Surname + " " +
                    sale.Sellers.Persons.Name.Substring(0, 1) + ". " +
                    sale.Sellers.Persons.Patronymic.Substring(0, 1) + "."
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(Sale.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Sale.Footer());
        } // Query05A

        // Информация о фактах продажи, для которых цена продажи в заданном диапазоне
        // синтаксис расширяющих методов
        public void Query05B(int lo, int hi) {
            var query = _db.Sales
                .Where(sale => sale.Price >= lo && sale.Price <= hi)
                .Select(sale => new Sale {
                    Id = sale.Id,
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    Unit = sale.Units.Short,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                    Seller = sale.Sellers.Persons.Surname + " " +
                    sale.Sellers.Persons.Name.Substring(0, 1) + ". " +
                    sale.Sellers.Persons.Patronymic.Substring(0, 1) + "."
                });

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(Sale.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Sale.Footer());
        } // Query05B

        // Вычислить прибыль от продажи за каждый проданный товар
        // синтаксис LINQ
        public void Query06A() {
            var query =
                from sale in _db.Sales
                select new ResultQuery06 {
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(ResultQuery06.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery06.Footer());
        } // Query06A

        // Вычислить прибыль от продажи за каждый проданный товар
        // синтаксис расширяющих методов
        public void Query06B() {
            var query = _db.Sales
                .Select(sale => new ResultQuery06 {
                    Good = sale.Purchases.Goods.Item,
                    Amount = sale.Amount,
                    SaleDate = sale.SaleDate,
                    PurchasePrice = sale.Purchases.Price,
                    SalePrice = sale.Price,
                });

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(ResultQuery06.Header());
            query.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery06.Footer());
        } // Query06B

    } // Task2Controller
}
