﻿--    Удаление существующий таблиц, созданных в ходе выполнения запросов
drop table if exists Subscribers_Journal;
drop table if exists Subscribers_COPY;

--			-> Запрос №1 [ Запрос с параметром ] <-
-- Выбирает из таблицы ИЗДАНИЯ информацию 
-- о доступных для подписки изданиях заданного типа, 
-- стоимость 1 экземпляра для которых меньше заданной.
 
 --						   	  [ Вывод без условия ] 
 select 
	Editions.Id
	,Editions.IndexEditions
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
from
	Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
					on Editions.IdGoodsEditions = GoodsEditions.id 
order by
	TypeEditions.TypeEdition;
go

  --						   [ Вывод с условием ]
 declare @type nvarchar(20) = N'Газета';
 declare @hiPrice float = 200;
 select 
	Editions.Id
	,Editions.IndexEditions
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
from
	Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
					on Editions.IdGoodsEditions = GoodsEditions.id
where
	TypeEditions.TypeEdition = @type and GoodsEditions.Price < @hiPrice;
go


--			-> Запрос №2 [ Запрос с параметром ] <-
-- Выбирает из таблиц информацию о подписчиках,
-- проживающих на заданной параметром улице и номере дома, 
-- которые оформили подписку на издание с заданным параметром наименованием

 --						   	  [ Вывод без условия ] 
select
	Delivery.Id
	,Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic
	,Subscribers.Passport
	,Streets.Street
	,HouseNumbers.HouseNumber
	,Subscribers.ApartmentNumber
	,Delivery.SubscriptionDate
	,Delivery.SubDuration
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
from
	Delivery join (Subscribers join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id
							   join Streets	     on Subscribers.IdStreet      = Streets.Id) 
				  on Delivery.IdSubscriber = Subscribers.Id
			 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
				  on Editions.IdGoodsEditions = GoodsEditions.id)
				  on Delivery.IdEdition = Editions.Id;
go

--							  [ Вывод с условием ]
declare @street    nvarchar(20) = N'ул. Судовая';
declare @houseNum  nvarchar(20) = N'д. 2'	;
declare @name      nvarchar(35) = N'1000 и 1 ночь с Абрамяном';
select
	Delivery.Id
	,Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic
	,Subscribers.Passport
	,Streets.Street
	,HouseNumbers.HouseNumber
	,Subscribers.ApartmentNumber
	,Delivery.SubscriptionDate
	,Delivery.SubDuration
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
from
	Delivery join (Subscribers join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id
							   join Streets	     on Subscribers.IdStreet      = Streets.Id) 
				  on Delivery.IdSubscriber = Subscribers.Id
			 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
				  on Editions.IdGoodsEditions = GoodsEditions.id)
				  on Delivery.IdEdition = Editions.Id
where
	Streets.Street = @street and HouseNumbers.HouseNumber = @houseNum 
	and GoodsEditions.[Name] = @name;
go


--			-> Запрос №3 [ Запрос с параметром ] <-
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, 
-- для которых значение в поле Цена 1 экземпляра 
-- находится в заданном диапазоне значений

--						   	  [ Вывод без условия ]
select 
	Editions.id
	,Editions.IndexEditions
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
from	
	Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.Id)
				  on Editions.IdGoodsEditions = GoodsEditions.id
order by
	Price;
go
 --							  [ Вывод с условием ]
 declare @loPrice float = 200;
 declare @hiPrice float = 300;
 select 
	Editions.id
	,Editions.IndexEditions
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
from	
	Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.Id)
				  on Editions.IdGoodsEditions = GoodsEditions.id
where
	GoodsEditions.Price between @loPrice and @hiPrice
order by
	Price
go


--			-> Запрос №4 [ Запрос с параметром ] <-
-- Выбирает из таблиц информацию о подписчиках, 
-- подписавшихся на заданный параметром тип издания

--						   	  [ Вывод без условия ]
select
	Delivery.id
	,Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic
	,Subscribers.Passport
	,Streets.Street
	,HouseNumbers.HouseNumber
	,Subscribers.ApartmentNumber
	,Delivery.SubscriptionDate
	,Delivery.SubDuration
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
from
	Delivery join (Subscribers join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id
							   join Streets	     on Subscribers.IdStreet      = Streets.Id) 
				  on Delivery.IdSubscriber = Subscribers.Id
			 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
				  on Editions.IdGoodsEditions = GoodsEditions.id)
				  on Delivery.IdEdition = Editions.Id
order by
	TypeEditions.TypeEdition;
go

--							  [ Вывод с условием ]
declare @type    nvarchar(20) = N'Энциклопедия';
 
select
	Delivery.id
	,Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic
	,Subscribers.Passport
	,Streets.Street
	,HouseNumbers.HouseNumber
	,Subscribers.ApartmentNumber
	,Delivery.SubscriptionDate
	,Delivery.SubDuration
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
from
	Delivery join (Subscribers join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id
							   join Streets	     on Subscribers.IdStreet      = Streets.Id) 
				  on Delivery.IdSubscriber = Subscribers.Id
			 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
							on Editions.IdGoodsEditions = GoodsEditions.id)
				  on Delivery.IdEdition = Editions.Id
where
	TypeEditions.TypeEdition = @type;
go


--			-> Запрос №5 [ Запрос с параметром ] <-
-- Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА 
-- информацию обо всех оформленных подписках,
-- для которых срок подписки есть значение из некоторого диапазона. 
-- Нижняя и верхняя границы диапазона задаются при выполнении запроса

--						   	  [ Вывод без условия ]
select
	 Delivery.id
	,Subscribers.Surname		--  |
	,Subscribers.[Name]			--  | => Не по запросу, но так лучше
	,Subscribers.Patronymic		--  |
	,Editions.IndexEditions
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
	,Delivery.SubscriptionDate
	,Delivery.SubDuration 
from
	Delivery join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
							 on Editions.IdGoodsEditions = GoodsEditions.id)
				   on Delivery.IdEdition = Editions.Id
			 join  Subscribers on Delivery.IdSubscriber = Subscribers.Id;
go

--							  [ Вывод с условием ]
--		Формула "псевдо" генерации случайного числа взята отсюда: https://oracleplsql.ru/function-sql-server-rand.html
declare @hiSubDuration int = FLOOR(RAND()*(12-7)+7);
declare @loSubDuration int = FLOOR(RAND()*(6-1)+1);
-- вывод случайно сгенерированных чисел
select
	 @loSubDuration  as MinSubDuration
	,@hiSubDuration as HighSubDuration

select
	 Delivery.id
	,Subscribers.Surname		--  |
	,Subscribers.[Name]			--  | => Не по запросу, но так лучше
	,Subscribers.Patronymic		--  |
	,Editions.IndexEditions
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
	,Delivery.SubscriptionDate
	,Delivery.SubDuration 
from
	Delivery join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
							on Editions.IdGoodsEditions = GoodsEditions.id)
				   on Delivery.IdEdition = Editions.Id
			 join  Subscribers on Delivery.IdSubscriber = Subscribers.Id
where
	Delivery.SubDuration between @loSubDuration and @hiSubDuration
order by 
	Delivery.SubDuration;
go


--			-> Запрос №6 [ Запрос с вычисляемыми полями ] <-
-- Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
-- Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, 
-- Дата начала подписки, Срок подписки, Стоимость подписки без НДС. 
-- Сортировка по полю Индекс издания
select
	Delivery.id
	,Editions.IndexEditions
	,GoodsEditions.[Name]
	,GoodsEditions.Price
	,Delivery.SubscriptionDate
	,Delivery.SubDuration
	,(GoodsEditions.Price * Delivery.SubDuration) * 1.01 as PriceSubscription
from
	Delivery join (Editions join GoodsEditions on Editions.IdGoodsEditions = GoodsEditions.id)
				   on Delivery.IdEdition = Editions.Id
order by
	Editions.IndexEditions;
go

--			-> Запрос №7 [ Итоговый запрос ] <-
-- Выполняет группировку по полю Вид издания. 
-- Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
select
	TypeEditions.TypeEdition
	,MIN(GoodsEditions.Price) as MinPrice
	,AVG(GoodsEditions.Price) as AvgPrice  -- неразделимая троица :D
	,MAX(GoodsEditions.Price) as MaxPrice
from
	GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.Id
group by
	TypeEditions.TypeEdition;
go


--			-> Запрос №8 [ Итоговый запрос с левым соединением ] <-
-- Выполняет группировку по полю Улица. 
-- Для всех улиц вычисляет количество подписчиков, 
-- проживающих на данной улице (итоги по полю Код получателя)
select
	Streets.Street
	,COUNT(Subscribers.IdStreet)
from 
	Streets left join  Subscribers  on Subscribers.IdStreet = Streets.id
group by
	Streets.Street;
go


--			-> Запрос №9 [ Итоговый запрос с левым соединением ] <-
-- Для всех изданий выводит количество оформленных подписок
select
	Editions.Id
	,Editions.IndexEditions
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
	,COUNT(Delivery.IdEdition) as AmountSubscription
from 
	(Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
							on Editions.IdGoodsEditions = GoodsEditions.id) left join Delivery
			   on Delivery.IdEdition = Editions.Id
group by
	Editions.Id, Editions.IndexEditions, TypeEditions.TypeEdition,
	GoodsEditions.[Name], GoodsEditions.Price;
go
 

--			-> Запрос №10 [ Запрос на создание базовой таблицы ] <-
-- Создает таблицу ПОДПИСЧИКИ_ЖУРНАЛЫ, 
-- содержащую информацию о подписчиках изданий, 
-- имеющих вид «журнал»
			
--				[ Вывод данных, которые будут скопированы в таблицу
-- 				     "ПОДПИСЧИКИ_ЖУРНАЛЫ" (Subscribers_Journal) ]
declare @type    nvarchar(20) = N'Журнал';
select
	 Subscribers.Id
	,Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic
	,Subscribers.Passport		
	,Streets.Street
	,HouseNumbers.HouseNumber
	,Subscribers.ApartmentNumber
from
	Delivery join (Subscribers join Streets      on Subscribers.IdStreet      = Streets.Id
							   join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id)
				   on Delivery.IdSubscriber = Subscribers.Id
			 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
							on Editions.IdGoodsEditions = GoodsEditions.id)
					on Delivery.IdEdition = Editions.Id
where
	TypeEditions.TypeEdition = @type
				
	-- Удаляет таблицу если она уже создана
drop table if exists Subscribers_Journal;

-- т.к. по заданию сказано передать информация подписчика,
-- то я передаю информацию только из таблицы Subscribers

select
	 Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic
	,Subscribers.Passport		
	,Streets.Street
	,HouseNumbers.HouseNumber
	,Subscribers.ApartmentNumber
	into Subscribers_Journal
from
	Delivery join (Subscribers join Streets      on Subscribers.IdStreet      = Streets.Id
							   join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id)
				   on Delivery.IdSubscriber = Subscribers.Id
			 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
							on Editions.IdGoodsEditions = GoodsEditions.id)
					on Delivery.IdEdition = Editions.Id
where
	TypeEditions.TypeEdition = @type;
go


--			-> Запрос №11 [ Запрос на создание базовой таблицы ] <-
-- Создает копию таблицы ПОДПИСЧИКИ с именем КОПИЯ_ПОДПИСЧИКИ
	-- Удаляет таблицу если она уже создана
drop table if exists Subscribers_COPY;

select
	 Subscribers.id
	,Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic
	,Subscribers.Passport		
	,Streets.Street
	,HouseNumbers.HouseNumber
	,Subscribers.ApartmentNumber
	into Subscribers_COPY
from
	Subscribers join Streets      on Subscribers.IdStreet      = Streets.Id
			    join HouseNumbers on Subscribers.IdHouseNumber = HouseNumbers.id;
go


--			-> Запрос №12 [ Запрос на удаление ] <-
-- Удаляет из таблицы КОПИЯ_ПОДПИСЧИКИ записи, 
-- в которых значение в поле Улица равно «Садовая»

--				Вывод таблицы КОПИЯ_ПОДПИСЧИКИ(Subscribers_COPY) до удаления
select 
	*
from
	Subscribers_COPY;
go

--				Само удаление таблицы КОПИЯ_ПОДПИСЧИКИ(Subscribers_COPY)
declare @street    nvarchar(20) = N'ул. Садовая';
delete from
	Subscribers_COPY
where
	Subscribers_COPY.Street = @street;
go

--				Вывод таблицы КОПИЯ_ПОДПИСЧИКИ(Subscribers_COPY) после удаления
select 
	*
from
	Subscribers_COPY;
go


--			-> Запрос №13 [ Запрос на обновление ] <-
-- Увеличивает значение в поле Цена 1 экземпляра таблицы ИЗДАНИЯ
-- на заданное параметром количество процентов для изданий, 
-- заданного параметром вида

				-- Вывод таблицы до изменения
select
	GoodsEditions.Id
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
from 
	GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id
order by
	TypeEditions.TypeEdition;
go

			-- Само изменение таблицы
declare @percentageIncrease int =  FLOOR(RAND()*(20-5)+5);  -- генерация процента прибавки к стоимости
declare @type nvarchar(20) = N'Энциклопедия';
update 
	GoodsEditions 
set
	 Price += Price * @percentageIncrease / 100
from 
	GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id
where
	TypeEditions.TypeEdition = @type;
 

				-- Вывод таблицы после изменения
select
	GoodsEditions.Id
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,GoodsEditions.Price
	,@percentageIncrease as PercentageIncrease  -- выводит процент прибавки к стоимости
from 
	GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id
order by
	TypeEditions.TypeEdition;
go


--			-> Запрос №14 [ Запрос на обновление ] <-
-- В таблице ДОСТАВКА увеличить срок подписки на заданное параметром количество месяцев
					
					-- Вывод таблицы до изменения
select
	Delivery.id
	,Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic
	,Delivery.SubscriptionDate
	,Delivery.SubDuration
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
from
	Delivery join Subscribers on Delivery.IdSubscriber = Subscribers.Id
			 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
				  on Editions.IdGoodsEditions = GoodsEditions.id)
				  on Delivery.IdEdition = Editions.Id;
go

				 -- Само изменение таблицы
declare @addDuration int =  FLOOR(RAND()*(1-4)+6);  -- генерация прибавки к подписке
update 
	Delivery 
set
	 SubDuration += @addDuration
where
	(SubDuration + @addDuration) <= 12;

					-- Вывод таблицы после изменения
select
	Delivery.Id
	,Subscribers.Surname
	,Subscribers.[Name]
	,Subscribers.Patronymic 
	,TypeEditions.TypeEdition
	,GoodsEditions.[Name]
	,Delivery.SubDuration
	,@addDuration as AddDuration
from
	Delivery join Subscribers on Delivery.IdSubscriber = Subscribers.Id
			 join (Editions join (GoodsEditions join TypeEditions on GoodsEditions.IdTypeEdition = TypeEditions.id)
				  on Editions.IdGoodsEditions = GoodsEditions.id)
				  on Delivery.IdEdition = Editions.Id;
go
