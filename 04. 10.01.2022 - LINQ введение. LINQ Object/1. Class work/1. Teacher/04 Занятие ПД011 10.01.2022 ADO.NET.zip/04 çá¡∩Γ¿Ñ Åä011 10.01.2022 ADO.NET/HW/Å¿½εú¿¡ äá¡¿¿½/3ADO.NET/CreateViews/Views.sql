﻿--создание представлений
drop view if exists PublicationsView
go
--представление таблицы изданий
create view PublicationsView
as
select 
	Pubs.Id
	,EditionName
	,EditionType
	,Pubs.Cost
from Pubs join EditionNames on Pubs.idEditionName = EditionNames.Id
		  join EditionTypes on Pubs.idEditionType = EditionTypes.Id
go

drop view if exists SubscribersView
go

--представление таблицы подписчиков
create view SubscribersView
as
select
	PNames.PName as [Name]
	,PSurnames.PSurname as Surname
	,PPatronymics.PPatronymic as Patronymic
	,Subs.NumberOfPassport
	,Streets.Street
	,Subs.NumHouse
	,Subs.NumApartment
from Subs join PNames on Subs.idName = PNames.Id
			join PSurnames on Subs.idSurname = PSurnames.Id
			join PPatronymics on Subs.idPatronymic = PPatronymics.Id
			join Streets on Subs.idStreet = Streets.Id
go
--представление подписки доставок
drop view if exists DelivsView
go
create view DelivsView
as
select
	Delivs.id as [idDelivs]
	,Subs.Id as [idSub]
	,PNames.PName as [Name]
	,PSurnames.PSurname as Surname
	,PPatronymics.PPatronymic as Patronymic
	,Subs.NumberOfPassport
	,Streets.Street
	,Subs.NumHouse
	,Subs.NumApartment
	,Pubs.Id as [idPub]
	,EditionName
	,EditionType
	,Pubs.Cost
	,Delivs.DateOfSub
	,Delivs.Term
from Delivs join (Subs join PNames on Subs.idName = PNames.Id
				join PSurnames on Subs.idSurname = PSurnames.Id
				join PPatronymics on Subs.idPatronymic = PPatronymics.Id
				join Streets on Subs.idStreet = Streets.Id)
			on Delivs.idSub = Subs.Id
			join (Pubs join EditionNames on Pubs.idEditionName = EditionNames.Id
				join EditionTypes on Pubs.idEditionType = EditionTypes.Id)
			on Delivs.idPub = Pubs.Id
go