﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	public static class ProductExtensions
	{
		/*
		 Расширяющий метод, возвращающий процент скидки в зависимости от возраста товара –
		 до 3х лет скидка не представляется, от 3х до 10 лет скидка 3%, свыше 10 лет – скидка 7%.
		 */
		public static int Discount(this Product product) => (DateTime.Now.Year - product.YearMade) switch
		{
			> 10 => 7,
			>= 3 => 3,
			_ => 0
		};

	}
}
