﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqWinForms.Models
{
    public partial class Unit
    {
        public override string ToString() => $"{Short}";


    }
}
