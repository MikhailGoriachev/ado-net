﻿using System;
using System.Collections.Generic;
using System.Configuration;

using ADoNET_3__PrintedEdition_.Controllers;
using ADoNET_3__PrintedEdition_.Models;
using ADoNET_3__PrintedEdition_.Helpers;

namespace ADoNET_3__PrintedEdition_.Application
{
    // Класс приложения - обработка по заданию
    // Данные для обработки и конструкторы
    public class App
    {
        private QueriesController _queriesController;
        
        private List<Edition>    _editions = new List<Edition>();        // Список изданий
        private List<Subscriber> _subscribers = new List<Subscriber>(); //  Список подписчиков


        // конструктор по умолчанию
        public App(): this(new QueriesController()) { }
        
        // Конструкторы с парамметрами
        public App(string connectingString): 
               this(new QueriesController(connectingString)) { }

        public App(QueriesController queriesController) =>
            _queriesController = queriesController;
      
        #region Вывод списков
        // Отображение данных об изданиях в табличном виде
        public void ShowEdition(string title = "") {

            Console.Write($"\t {title}\n \t Выбранные данные из таблицы издания:\n");

            Console.Write($"{Edition.Header()}");

            foreach (var item in _editions){
                Console.WriteLine($"{item.ToTableRow()}");
            }
             
            // вывод подвала таблицы
            Console.WriteLine(Edition.Footer());
        } // ShowEdition

        // Отображение данных об подписчиках в табличном виде
        public void ShowSubscriber(string title = ""){
            Console.Write($"\t {title}\n \t Выбранные данные из таблицы подписчики:\n");

            Console.Write($"{Subscriber.Header()}");

            foreach (var item in _subscribers) {
                Console.WriteLine($"{item.ToTableRow()}");
            }

            // вывод подвала таблицы
            Console.WriteLine(Subscriber.Footer());
        } // ShowEdition
        #endregion

        // Запрос 1.
        // Выбирает из таблицы ИЗДАНИЯ информацию 
        // о доступных для подписки изданиях заданного типа, 
        // стоимость 1 экземпляра для которых меньше заданной.
        public void ExecQuery1() {
            Utils.ShowNavBarTask("   Выполнение запроса 1");

            _editions = _queriesController.Query1("Газета", 200);
            ShowEdition();

        } // ExecQuery1

        // Запрос 2.
        // Выбирает из таблиц информацию о подписчиках,
        // проживающих на заданной параметром улице и номере дома,
        // которые оформили подписку на издание с заданным параметром наименованием
        public void ExecQuery2() {
            Utils.ShowNavBarTask("   Выполнение запроса 2");

            _subscribers = _queriesController.Query2("ул. Судовая", "д. 2", "1000 и 1 ночь с Абрамяном");
            ShowSubscriber();
        } // ExecQuery2

        // Запрос 3.
        // Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, 
        // для которых значение в поле Цена 1 экземпляра 
        // находится в заданном диапазоне значений

        public void ExecQuery3() {
            Utils.ShowNavBarTask("   Выполнение запроса 3");

            _editions = _queriesController.Query3(200, 300);
            ShowEdition();
        } // ExecQuery3

        // Запрос 4.
        // Выбирает из таблиц информацию о подписчиках, 
        // подписавшихся на заданный параметром тип издания
        public void ExecQuery4() {
            Utils.ShowNavBarTask("   Выполнение запроса 4");

            _subscribers = _queriesController.Query4("Энциклопедия");
            ShowSubscriber();
        } // ExecQuery4

        // Запрос 5.
        // Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА 
        // информацию обо всех оформленных подписках,
        // для которых срок подписки есть значение из некоторого диапазона.
        // Нижняя и верхняя границы диапазона задаются при выполнении запроса
        public void ExecQuery5()
        {
            Utils.ShowNavBarTask("   Выполнение запроса 5");

            _queriesController.Query5(4,7);
        } // ExecQuery5

        // Запрос 6.
        // Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
        // Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, 
        // Дата начала подписки, Срок подписки, Стоимость подписки без НДС.
        // Сортировка по полю Индекс издания
        public void ExecQuery6()
        {
            Utils.ShowNavBarTask("   Выполнение запроса 6");

            _queriesController.Query6();
        } // ExecQuery6

        // Запрос 7.
        // Выполняет группировку по полю Вид издания.
        // Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
        public void ExecQuery7()
        {
            Utils.ShowNavBarTask("   Выполнение запроса 7");

            _queriesController.Query7();
        } // ExecQuery7

        // Запрос 8.
        // Выполняет группировку по полю Улица.
        // Для всех улиц вычисляет количество подписчиков,
        // проживающих на данной улице(итоги по полю Код получателя)
        public void ExecQuery8()
        {
            Utils.ShowNavBarTask("   Выполнение запроса 8");

            _queriesController.Query8();
        } // ExecQuery8

        // Запрос 9. 
        // Для всех изданий выводит количество оформленных подписок
        public void ExecQuery9()
        {
            Utils.ShowNavBarTask("   Выполнение запроса 9");

            DateTime loDate = new DateTime(1978, 03, 22);
            DateTime hiDate = new DateTime(2004, 10, 01);
            _queriesController.Query9(loDate, hiDate);
        } // ExecQuery9

        #region Шифровка/расшифровка конфигурационного файла

        // Шифрование конфигурационного файла
        public void ConfigurationEncryption(){
            // получение доступа к конфигурационному файлу
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (!section.SectionInformation.IsProtected)
            {
                // Зашифровать секцию.
                section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                // Сохранить файл конфигурации.
                config.Save();
            } // if

            // пример расшифровки секцию
            // section.SectionInformation.UnprotectSection();
            // config.Save();

            // Проверка шифрования
            Console.WriteLine($"Protected={section.SectionInformation.IsProtected}\n" +
                              $"{ConfigurationManager.ConnectionStrings["PeriodicalsConnectionSQLServer"].ConnectionString}");
            
            Utils.WriteXY(55, 13, "Конфигурационный файл зашифрован", ConsoleColor.Cyan);
        } // ConfigurationEncryption

        // Расшифровывание конфигурационного файла
        public void ConfigurationDecryption(){
            // получение доступа к конфигурационному файлу
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (!section.SectionInformation.IsProtected) {
                Utils.WriteXY(55, 13, "Конфигурационный файл не нуждается в расшифровки", ConsoleColor.Cyan);
                return;
            } 

            // расшифровка секцию
               section.SectionInformation.UnprotectSection();
               config.Save();

            // Проверка расшифрования
            Console.WriteLine($"Protected={section.SectionInformation.IsProtected}\n" +
                              $"{ConfigurationManager.ConnectionStrings["PeriodicalsConnectionSQLServer"].ConnectionString}");
            
            Utils.WriteXY(55, 13, "Конфигурационный файл расшифрован", ConsoleColor.Cyan);
        } // ConfigurationDecryption

        #endregion

    } // class App
}