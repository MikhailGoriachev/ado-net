﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Homework.Application
{
	internal partial class App
	{
		private readonly double from = -20, to = 20;

		public void Task2Item1()
		{
			Utilities.ShowNavBar("  Кол-во элеметов со значениями в диапазоне от A до B.");
			
			Console.Write("\n\n  Массив вещественных чисел:\n  ");


			double[] arr = Utilities.GetDoubleArray(Utilities.GenerateInt(10, 20), from, to);

			arr.ToList().ForEach(x => Console.Write($"{x, 9:F2}"));

			double lo = Utilities.GenerateDouble(from,(to - from)/2);
			double hi = Utilities.GenerateDouble((to - from) / 2, to);

			_task2Controller.Item1(arr, lo, hi);

		}
		private void Task2Item2()
		{
			Utilities.ShowNavBar("  Кол-во элеметов массива, равных нулю.");

			Console.Write("\n\n  Массив вещественных чисел:\n  ");

			double[] arr = Utilities.GetDoubleArray(Utilities.GenerateInt(10, 20), from, to);

			arr.ToList().ForEach(x => Console.Write($"{x,9:F2}"));

			_task2Controller.Item2(arr);
		}

		private void Task2Item3()
		{
			Utilities.ShowNavBar("  Сумма элементов массива, расположенных после первого максимального элемента.");

			Console.Write("\n\n  Массив вещественных чисел:\n  ");

			double[] arr = Utilities.GetDoubleArray(Utilities.GenerateInt(10, 20), from, to);

			arr.ToList().ForEach(x => Console.Write($"{x,9:F2}"));

			_task2Controller.Item3(arr);
		}

		private void Task2Item4()
		{
			Utilities.ShowNavBar("  Сумма элементов массива, расположенных перед последним минимальным по модулю элементом.");

			Console.Write("\n\n  Массив вещественных чисел:\n  ");

			double[] arr = Utilities.GetDoubleArray(Utilities.GenerateInt(10, 20), from, to);

			arr.ToList().ForEach(x => Console.Write($"{x,9:F2}"));

			_task2Controller.Item4(arr);
		}

	}
}