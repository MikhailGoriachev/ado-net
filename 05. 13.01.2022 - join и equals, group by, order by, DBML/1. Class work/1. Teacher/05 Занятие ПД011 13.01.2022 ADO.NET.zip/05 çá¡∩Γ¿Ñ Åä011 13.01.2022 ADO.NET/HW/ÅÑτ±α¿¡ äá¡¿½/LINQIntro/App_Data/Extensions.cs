﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LINQIntro.Models;

namespace LINQIntro.App_Data
{
    //класс для хранения расширяющих методов
    public static class Extensions
    {
        public static int Discount(this Product x)
        {
            if (DateTime.Now.Year - x.YearOfManufacture > 10) return 7;
            if (DateTime.Now.Year - x.YearOfManufacture > 3) return 3;

            return 0;
        }
    }
}
