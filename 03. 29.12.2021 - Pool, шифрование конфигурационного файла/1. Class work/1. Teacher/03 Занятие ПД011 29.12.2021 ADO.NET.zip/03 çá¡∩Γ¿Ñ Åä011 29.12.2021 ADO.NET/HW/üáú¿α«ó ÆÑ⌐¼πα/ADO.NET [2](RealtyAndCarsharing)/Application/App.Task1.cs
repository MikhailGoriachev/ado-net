﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ADO.NET__2__RealtyAndCarsharing_.Helpers;

namespace ADO.NET__2__RealtyAndCarsharing_.Application
{
    /* 
    * Методы для решения выполнения запросов по заданию
    */
    public partial class App {
        // Запрос 1. Квартиры с заданным количеством комнат на заданной улице
        public void ExecQuery1_1() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)1");

            _task1Controller1.Query1(3, "ул. Садовая");
        } // ExecQuery1_1

        // Запрос 2. Риелторы с заданной фамилией и процентом вознаграждения
        public void ExecQuery1_2() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)2");

            _task1Controller1.Query2('И', 10);
        } // ExecQuery1_2

        // Запрос 3. Однокомнатные квартиры со стоимостью в заданном диапазоне
        public void ExecQuery1_3() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)3");

            _task1Controller1.Query3(1, 900_000, 1_000_000);
        } // ExecQuery1_3

        // Запрос 4. Квартиры с заданным количеством комнат
        public void ExecQuery1_4() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)4");

            _task1Controller1.Query4(2);
        } // ExecQuery1_4

        // Запрос 5. 2-хкомнатные квартиры с площадью из заданного диапазона
        public void ExecQuery1_5() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)5");

            _task1Controller1.Query5(2, 60, 80);
        } // ExecQuery1_5

        // Запрос 6. Комиссия по всем оформленным сделкам риэлторов
        public void ExecQuery1_6() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)6");

            _task1Controller1.Query6();
        } // ExecQuery1_6

        // Запрос 7. Все риэлторы, их клиенты и сделки, по убыванию суммы сделки
        public void ExecQuery1_7() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)7");
            
            _task1Controller1.Query7();
        } // ExecQuery1_7

        // Запрос 8. По всем улицам вывести сумму сделок, по убыванию суммы
        public void ExecQuery1_8() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)8");

            _task1Controller1.Query8();
        } // ExecQuery1_8

        // Запрос 9. По всем улицам вывести сумму сделок за заданный период, по убыванию суммы
        public void ExecQuery1_9() {
            Utils.ShowNavBarTask("   Выполнение запроса (1)9");
             
            DateTime loDate = new DateTime(1978, 03, 22);
            DateTime hiDate = new DateTime(2004, 10, 01);
            _task1Controller1.Query9(loDate, hiDate);
        } // ExecQuery1_9
    } // App
}
