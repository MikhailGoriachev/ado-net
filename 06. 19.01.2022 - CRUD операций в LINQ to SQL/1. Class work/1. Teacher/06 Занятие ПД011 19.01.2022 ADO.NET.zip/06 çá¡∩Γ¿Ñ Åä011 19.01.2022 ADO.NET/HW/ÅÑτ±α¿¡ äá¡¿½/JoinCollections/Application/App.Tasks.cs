﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using JoinCollections.Controllers;
using JoinCollections.Helpers;
using JoinCollections.Models;

namespace JoinCollections.Application
{
    public partial class App
    {
        
        
            public void Task1()
        {
            Utils.ShowNavBarTask("\nВывести все книги коллекции, выводить фамилии и инициалы автора");

            _queryController.Exec1(_queryController.books, _queryController.authors);
            Console.WriteLine("\n");
            _queryController.Exec1Join(_queryController.books, _queryController.authors);
            _queryController.Exec1JoinExtended(_queryController.books, _queryController.authors);

            Console.ReadKey();
        }

            public void Task2()
            {
                Utils.ShowNavBarTask("\nВывести книги авторов, год рождения которых принадлежит заданном диапазону");
                 
                _queryController.Exce2(_queryController.books, _queryController.authors);
                Console.WriteLine("\n");

            Console.ReadKey();
        }

            public void Task3()
            {
                Utils.ShowNavBarTask("\no	Вывести книги, в названии которых содержится заданная подстрока и цена не превышает 1300 рублей");

                _queryController.Exec3(_queryController.books, _queryController.authors);

                Console.ReadKey();
            }

            public void Task4()
            {
                Utils.ShowNavBarTask("\no	Список авторов и количество их книг в коллекции");

                _queryController.Exec4(_queryController.books, _queryController.authors);

                Console.ReadKey();
            }

            public void Task5()
            {
                Utils.ShowNavBarTask("\n Средняя ценя по годам издания");

                _queryController.Exec5(_queryController.books, _queryController.authors);

                Console.ReadKey();
            }

            public void Task6()
            {
                Utils.ShowNavBarTask("\n Список авторов по убыванию книг");

                _queryController.Exec6(_queryController.books, _queryController.authors);

                Console.ReadKey();
            }

            public void Task7()
            {
                Utils.ShowNavBarTask("\n Средний возраст книг по авторам");

                _queryController.Exec7(_queryController.books, _queryController.authors);

                Console.ReadKey();
            }
    }
}
