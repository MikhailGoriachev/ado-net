﻿using System.Data;


namespace Main.Infrastructure
{
	public interface IMappable<out T>
	{
		T Map(DataRow row);
	}
}