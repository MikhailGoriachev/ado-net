﻿using System;
using System.Collections.Generic;


using System.Data;
using System.Data.SqlClient;

// в раздел проекта Ссылки добавить сборку System.Configuration.dll
// для работы с конфигурационным файлом
using System.Configuration;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConfigSecurityModels.Models;

namespace ConfigSecurityModels.Controllers
{
    /*
     * Выполнение запросов по заданию
     */
    public class Task1Controller
    {
        // строка подключения к базе данных
        private string _connectionString;
        public string ConnectionString { // value - имя строки подключения в конфигурационном файле
            get => _connectionString;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Не указано имя строки подключения к БД в конфигурационном файле");

                // чтение строки соединения из конфигурационного файла выполняем только
                // в одной точке кода
                _connectionString = ConfigurationManager.ConnectionStrings[value].ConnectionString;
            } // set
        } // ConnectionString
        

        #region Ансамбль конструкторов
        public Task1Controller():this("PublicationsConnection") 
        { } // Task1Controller


        public Task1Controller(string connectionStringName) {
            ConnectionString = connectionStringName;
        } // Task1Controller
        #endregion

        #region Выполнение запросов по заданию
        // Запрос 1. Хранимая процедура	
        // Выбирает информацию о доступных для подписки изданиях заданного типа, 
        // стоимость 1 экземпляра для которых меньше заданной.
        public void Query01(string pubType, int price) {
            Console.WriteLine("\n\n\n\n\tЗапрос 01.\n" +
                              $"\tИздания с типом \"{pubType}\" и стоимостью экземпляра ниже заданной: {price} руб.");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectionString)) {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand("Query01");

                // задать соединение с БД
                cmd.Connection = connection;

                // задать тип выполняемого запроса - хранимая процедура
                cmd.CommandType = CommandType.StoredProcedure;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@pubType", pubType);
                cmd.Parameters.AddWithValue("@price", price);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToPublications(cmd);
            } // using
        } // Query01


        // Запрос 2. Хранимая процедура	
        // Выбирает информацию о подписчиках, проживающих на заданной параметром улице
        // и номере дома, которые оформили подписку на издание с заданным параметром 
        // наименованием
        public void Query02(string street, string building, string title) {
            Console.WriteLine(
                "\n\n\n\n\tЗапрос 02.\n" +
                $"\tПодписчики, проживающие по {street} в доме {building}, подписавшиеся на \"{title}\"");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectionString)) {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand("Query02");

                // задать соединение с БД
                cmd.Connection = connection;

                // задать тип выполняемого запроса - хранимая процедура
                cmd.CommandType = CommandType.StoredProcedure;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@street", street);
                cmd.Parameters.AddWithValue("@building", building);
                cmd.Parameters.AddWithValue("@title", title);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToPublications(cmd);
            } // using
        } // Query02


        // Запрос 3. Хранимая процедура	 
        // Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение
        // в поле Цена 1 экземпляра находится в заданном диапазоне значений
        public void Query03(int loPrice, int hiPrice) {
            Console.WriteLine("\n\n\n\n\tЗапрос 03.\n" +
                              $"\tИздания со стоимостью экземпляра в диапазоне: [{loPrice}, ..., {hiPrice}] руб.");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectionString)) {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand("Query03");

                // задать соединение с БД
                cmd.Connection = connection;

                // задать тип выполняемого запроса - хранимая процедура
                cmd.CommandType = CommandType.StoredProcedure;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@loPrice", loPrice);
                cmd.Parameters.AddWithValue("@hiPrice", hiPrice);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToPublications(cmd);
            } // using
        } // Query03
        #endregion

        // Выполнение запросов к изданиям
        private void QueryToPublications(SqlCommand cmd) {
            // коллекция для сохранения данных, выбранных из таблицы сервера
            List<Publication> list = new List<Publication>();

            // выполнение запроса, ссылка на  выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // Если данные получены (есть строки в полученном ответе сервера)
            if (reader.HasRows) {
                while (reader.Read()) {
                    list.Add(new Publication {
                        PublicationId = reader.GetInt32 (0),
                        PubIndex      = reader.GetString(1),
                        PubType       = reader.GetString(2),
                        Title         = reader.GetString(3),
                        Price         = reader.GetInt32 (4)
                    });
                } // while
            } // if

            // Вывод данных из коллекции
            Console.WriteLine(Publication.Header);
            if (list.Count > 0) {
                int row = 0;
                list.ForEach(p => Console.WriteLine(p.ToTableRow(++row)));
            } else {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($"\t|  {"Нет данных", -80} │");
                Console.ForegroundColor = ConsoleColor.Gray;
            } // if

            Console.WriteLine(Publication.Footer);
        } // QueryToPublications


        // Выполнение запросов к оформленным подпискам, получение данных
        // о подписчиках
        private void QueryToSubscribersDeliveries(SqlCommand cmd) {
            // коллекция для сохранения данных, выбранных из таблицы сервера
            List<Delivery> list = new List<Delivery>();

            // выполнение запроса, ссылка на  выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // Если данные получены (есть строки в полученном ответе сервера)
            if (reader.HasRows) {
                while (reader.Read()) {
                    list.Add(new Delivery {
                        DeliveryId = reader.GetInt32 (0),
                        Surname    = reader.GetString(1),
                        Name       = reader.GetString(2),
                        Patronymic = reader.GetString(3),
                        Passport   = reader.GetString(4),
                        Street     = reader.GetString(5),
                        Building   = reader.GetString(6),
                        Flat       = reader.GetInt32 (7),
                        PubType    = reader.GetString(8),
                        Title      = reader.GetString(9)
                    });
                } // while
            } // if

            // Вывод данных из коллекции
            Console.WriteLine(Delivery.HeaderSubscriber);
            if (list.Count > 0) {
                int row = 0;
                list.ForEach(p => Console.WriteLine(p.ToTableRowSubscriber(++row)));
            } else {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($"\t|  {"Нет данных", -80} │");
                Console.ForegroundColor = ConsoleColor.Gray;
            } // if

            Console.WriteLine(Delivery.FooterSubscriber);
        } // QueryToSubscribersDeliveries


        // Шифрование конфигурационного файла
        public void EncodeConfigFile() {
            string connectionString =
                ConfigurationManager.ConnectionStrings["PublicationsConnection"].ConnectionString;

            // получение доступа к конфигурационному файлу
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (!section.SectionInformation.IsProtected) {
                // Зашифровать секцию.
                section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                // Сохранить файл конфигурации.
                config.Save();
            } // if
        } // EncodeConfigFile


        // Расшифровка конфигурационного файла
        public void DecodeConfigFile() {
            string connectionString =
                ConfigurationManager.ConnectionStrings["PublicationsConnection"].ConnectionString;

            // получение доступа к конфигурационному файлу
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (section.SectionInformation.IsProtected) {
                // Расшифровать секцию.
                section.SectionInformation.UnprotectSection();
                // Сохранить файл конфигурации.
                config.Save();
            } // if
        } // DecodeConfigFile
    } // class Task1Controller
}
