﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AVGnGVG
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow() => InitializeComponent();

        //команда выхода из приложения
        private void CloseApp_Command(object sender, RoutedEventArgs e) => Close();
        //команда расчета среднего арифметического
        private void GetAvg_Command(object sender, RoutedEventArgs e)
        {
            int x1, x2, x3;
            bool b1 = int.TryParse(TBvalue1.Text, out x1);
            bool b2 = int.TryParse(TBvalue2.Text, out x2);
            bool b3 = int.TryParse(TBvalue3.Text, out x3);

            //если получилось спарсить числа
            if (b1 && b2 && b3)
            {
                //считаем арифметическое 
                float res = (float)(x1 + x2 + x3) / 3;
                TBresult.Text = $"Среднее арифметическое чисел ({x1}, {x2}, {x3}) = {res:f1}";
            }
            else TBresult.Text = $"Некорректные данные!";
        }
        //команда расчета среднего геометрического
        private void GetGVG_Command(object sender, RoutedEventArgs e)
        {
            int x1, x2, x3;
            bool b1 = int.TryParse(TBvalue1.Text, out x1);
            bool b2 = int.TryParse(TBvalue2.Text, out x2);
            bool b3 = int.TryParse(TBvalue3.Text, out x3);

            //если получилось спарсить числа
            if (b1 && b2 && b3)
            {
                //считаем геометрическое 
                double p = x1 * x2 * x3;
                double res = Math.Pow(p, 1.0/3.0);
                TBresult.Text = $"Среднее геометрическое чисел ({x1}, {x2}, {x3}) = {res:f1}";
            }
            else TBresult.Text = $"Некорректные данные!";
        }
        //команда расчета квадратного уравнения
        private void GetRoot_Command(object sender, RoutedEventArgs e)
        {
            int a, b, c;
            bool b1 = int.TryParse(TBvalue1.Text, out a);
            bool b2 = int.TryParse(TBvalue2.Text, out b);
            bool b3 = int.TryParse(TBvalue3.Text, out c);

            //если получилось спарсить числа
            if (b1 && b2 && b3)
            {
                string res;
                //считаем дискриминант
                double d = b * b - 4 * a * c;

                //если дискриминант меньше нуля - нет корней
                if (d < 0)
                    res = "Корней нет!";
                //если дискриминант равен нулю - один корень
                else if (d == 0)
                {
                    double x = -b / (2 * a);
                    res = $"Корень ({a}x² + {b}x + {c} = 0) = {x}";
                }
                //если дискриминант больше нуля - два корня
                else
                {
                    //расчет корней
                    double x1 = (-b - Math.Sqrt(d)) / (2 * a);
                    double x2 = (-b + Math.Sqrt(d)) / (2 * a);
                    res = $"Корни ({a}x² + {b}x + {c} = 0) = {x1:f2}; {x2:f2}";
                }

                TBresult.Text = res;
            }
            else TBresult.Text = $"Некорректные данные!";
        }

        //команда для очистки текст бокс результата, если данные текст бокс значений меняется
        private void ClearResault_Command(object sender, TextChangedEventArgs e) => TBresult.Text = "";
    }


}
