﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Homework.Controllers;
using Railway.Views;

namespace Homework.Views
{
	public partial class MainForm : Form
	{
		private StoreQueriesController _storeQueriesController;

		public MainForm() : this(new StoreQueriesController())
		{}

		public MainForm(StoreQueriesController storeQueriesController)
		{
			InitializeComponent();
			_storeQueriesController = storeQueriesController;
		}


		private void MainForm_Load(object sender, EventArgs e)
		{
			DgvGoods.DataSource = _storeQueriesController.GetGoodsAll();
			DgvSales.DataSource = _storeQueriesController.GetSalesAll();
			DgvSellers.DataSource = _storeQueriesController.GetSellersAll();
			DgvPurchases.DataSource = _storeQueriesController.GetPurchasesAll();

			DgvQuery01.DataSource = _storeQueriesController.Query01();
			DgvQuery01.Columns[0].HeaderText = "Идентификатор";
			DgvQuery01.Columns[1].HeaderText = "Наименование";
			DgvQuery01.Columns[2].HeaderText = "Цена";
			DgvQuery01.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;

			DgvQuery02.DataSource = _storeQueriesController.Query02();
			DgvQuery02.Columns[0].HeaderText = "Идентификатор";
			DgvQuery02.Columns[1].HeaderText = "Наименование";
			DgvQuery02.Columns[2].HeaderText = "Цена";
			DgvQuery02.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;

			DgvQuery03.DataSource = _storeQueriesController.Query03();
			DgvQuery03.Columns[0].HeaderText = "Идентификатор";
			DgvQuery03.Columns[1].HeaderText = "Наименование";
			DgvQuery03.Columns[2].HeaderText = "Цена";
			DgvQuery03.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;

			DgvQuery04.DataSource = _storeQueriesController.Query04();
			DgvQuery04.Columns[0].HeaderText = "Идентификатор";
			DgvQuery04.Columns[1].HeaderText = "Фамилия И.О.";
			DgvQuery04.Columns[2].HeaderText = "Процент комиссионных";
			DgvQuery04.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;

			DgvQuery05.DataSource = _storeQueriesController.Query05();
			DgvQuery05.Columns[0].HeaderText = "Наименование";
			DgvQuery05.Columns[1].HeaderText = "Цена закупки";
			DgvQuery05.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			DgvQuery05.Columns[2].HeaderText = "Цена продажи";
			DgvQuery05.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			DgvQuery05.Columns[3].HeaderText = "Дата продажи";

			DgvQuery06.DataSource = _storeQueriesController.Query06();
			DgvQuery06.Columns[0].HeaderText = "Дата продажи";
			DgvQuery06.Columns[1].HeaderText = "Наименование";
			DgvQuery06.Columns[2].HeaderText = "Цена закупки";
			DgvQuery06.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			DgvQuery06.Columns[3].HeaderText = "Цена продажи";
			DgvQuery06.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			DgvQuery06.Columns[4].HeaderText = "Количество продаж";
			DgvQuery06.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			DgvQuery06.Columns[5].HeaderText = "Прибыль";
			DgvQuery06.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;

			DgvQuery07.DataSource = _storeQueriesController.Query07();
			DgvQuery07.Columns[0].HeaderText = "Наименование";
			DgvQuery07.Columns[1].HeaderText = "Средняя цена закупки";
			DgvQuery07.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			DgvQuery07.Columns[2].HeaderText = "Количество продаж";
			DgvQuery07.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			
			DgvQuery08.DataSource = _storeQueriesController.Query08();
			DgvQuery08.Columns[0].HeaderText = "Фамилия И.О.";
			DgvQuery08.Columns[1].HeaderText = "Средняя цена продаж";
			DgvQuery08.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			DgvQuery08.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
			DgvQuery08.Columns[2].HeaderText = "Количество продаж";

			DgvQuery09.DataSource = _storeQueriesController.Query09();
			DgvQuery10.DataSource = _storeQueriesController.Query10();
		}

		private void Exit_Command(object sender, EventArgs e) => this.Close();

		private void AboutForm_Command(object sender, EventArgs e) => new AboutForm().ShowDialog();
	}
}
