﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6AdoLINQtoSQL.Models
{
    // Класс для Представления продавцов для вычисления количества продаж
    public class CalculateSellesViewModel: SellerViewModel
    {
        public int IdSeller { get; set; }
        public int SalesAmount { get; set; }
        public int AvgPrice { get; set; }

        //public SellerViewModel SellerView { get; set; }

    }// class CalculateSallesViewModel
}
