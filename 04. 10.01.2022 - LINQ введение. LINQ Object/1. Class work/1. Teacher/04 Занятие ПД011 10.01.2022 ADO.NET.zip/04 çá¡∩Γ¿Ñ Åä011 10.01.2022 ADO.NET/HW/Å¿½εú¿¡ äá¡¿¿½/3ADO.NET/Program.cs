﻿using _3ADO.NET.Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _3ADO.NET
{
    class Program
    {
        static void Main(string[] args)
        {
            App app = new App();

            // простейшее меню приложения
            List<MenuItem> menu = new List<MenuItem>(new[]{
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Запрос 1." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Запрос 2." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Запрос 3." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Запрос 4." },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Запрос 5." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Запрос 6." },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Запрос 7." },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Запрос 8." },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Запрос 9." },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Шифрование конфигурационного файла" },
                new MenuItem { HotKey = ConsoleKey.X, Text = "Расшифрование конфигурационного файла" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.L, Text = "Выход" },
            });

            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {

                        // Запрос 1. 
                        case ConsoleKey.Q:
                            app.Query1();
                            break;

                        // Запрос 2. 
                        case ConsoleKey.W:
                            app.Query2();
                            break;

                        // Запрос 3. 
                        case ConsoleKey.E:
                            app.Query3();
                            break;

                        // Запрос 4. 
                        case ConsoleKey.R:
                            app.Query4();
                            break;

                        // Запрос 5. 
                        case ConsoleKey.T:
                            app.Query5();
                            break;

                        // Запрос 6. 
                        case ConsoleKey.Y:
                            app.Query6();
                            break;

                        // Запрос 7. 
                        case ConsoleKey.U:
                            app.Query7();
                            break;

                        // Запрос 8. 
                        case ConsoleKey.I:
                            app.Query8();
                            break;

                        // Запрос 9. 
                        case ConsoleKey.O:
                            app.Query9();
                            break;

                        case ConsoleKey.Z:
                            app.Protect();
                            break;

                        case ConsoleKey.X:
                            app.Unprotect();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.L:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");

                    } // switch

                    Console.ReadKey();

                }
                catch (Exception ex)
                {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(5, 9, $"                                                                                        ", ConsoleColor.White);
                    Utils.WriteXY(5, 10, $"  ┌──────────────────────────────────────────────────────────────────────────────────┐  ", ConsoleColor.White);
                    Utils.WriteXY(5, 11, $"  │                                   Исключение.                                    │  ", ConsoleColor.White);
                    Utils.WriteXY(5, 12, $"  │ {ex.Message,-79}  │  ", ConsoleColor.White);
                    Utils.WriteXY(5, 13, $"  │                                                                                  │  ", ConsoleColor.White);
                    Utils.WriteXY(5, 14, $"  └──────────────────────────────────────────────────────────────────────────────────┘  ", ConsoleColor.White);
                    Utils.WriteXY(5, 15, $"                                                                                        ", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                    Console.ReadKey();

                }
            }
        }
    }
}
