﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_NET_Procedures
{
    public static class Palette
    {

         static public ConsoleColor MainBackColor = ConsoleColor.Gray;
        //Базовый цвет символов 
         static public ConsoleColor MainFontColor = ConsoleColor.Black;

        #region Различные контекстные цвета
        static public ConsoleColor MaxColor = ConsoleColor.Red;
        static public ConsoleColor MinColor = ConsoleColor.Yellow;
        static public ConsoleColor BasicHiglihghtColor = ConsoleColor.White;
        #endregion

        //Создаём объект базового цвета
        public static Color MainColor = new Color { BackGround = MainBackColor, Foreground = MainFontColor }; //Устанавливаем занчения цвета через default C_TOR

        //Цввета для выделения заголовков
        public static Color TitleColor = new Color { BackGround = ConsoleColor.White, Foreground = MainFontColor };


    }
}
