﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4ADO.NET.Classes
{
    //класс, представляющий товар(наименование, цена, количество, год выпуска) 

    public class Good
    {
        public string Name { get; set; }
        public int Cost { get; set; }
        public int Amount { get; set; }
        public DateTime DateOfManufacture { get; set; }

        public Good(string name, int cost, int amount, DateTime date)
        {
            Name = name;
            Cost = cost;
            Amount = amount;
            DateOfManufacture = date;
        }

        public override string ToString()
            => $"{Name,-15} {Cost,-15} {Amount,-15} {DateOfManufacture.Year,-15}";

    }

    //разработать расширяющий метод, возвращающий процент скидки в зависимости 
    //от возраста товара – до 3х лет скидка не представляется, от 3х до 10 лет 
    //скидка 3%, свыше 10 лет – скидка 7%. 

    public static class GoodExtended
    {
        public static int GetDiscount(this Good good)
        {
            int difference = DateTime.Now.Year - good.DateOfManufacture.Year;
            int discount = 0;

            if (difference > 3 && difference <= 10)
                discount = 3;
            else if (difference > 10)
                discount = 7;

            return discount;
        }

        public static void Process1(this List<Good> goods)
        {
            Console.WriteLine("\n\t\t1.Tовары с заданным диапазоном цен(30 000, 70 000)");
            int lo = 30000, hi = 70000;
            Console.WriteLine("\t\t\tСинтаксис LINQ");

            var query = from item in goods
                        where item.Cost > lo && item.Cost < hi
                        select item;

            foreach (var item in query)
                Console.WriteLine($"\t{item:n2}");

            Console.WriteLine("\n\n\t\t\tРасширяющие методы");

            query = goods
                .Where(x => x.Cost > lo && x.Cost < hi)
                .Select(x => x);

            foreach (var item in query)
                Console.WriteLine($"\t{item:n2}");
        }
        public static void Process2(this List<Good> goods)
        {
            Console.WriteLine("\n\t\t2.Cумма товаров с заданным годом выпуска(2016)");
            int year = 2016;
            Console.WriteLine("\t\t\tСинтаксис LINQ");

            var query = from item in goods
                        where item.DateOfManufacture.Year == year
                        select item;

            int sum = query.Sum(item => item.Cost);

            Console.WriteLine($"Сумма стоимости товаров за {year} = {sum}");

            Console.WriteLine("\n\n\t\t\tРасширяющие методы");

            sum = goods
                .Where(x => x.DateOfManufacture.Year == year)
                .Sum(x => x.Cost);

            Console.WriteLine($"Сумма стоимости товаров за {year} = {sum}");

        }
        public static void Process3(this List<Good> goods)
        {
            Console.WriteLine("\n\t\t3.Cумма товаров с заданным наименованием (Ноутбук)");
            string good = "Ноутбук";
            Console.WriteLine("\t\t\tСинтаксис LINQ");

            var query = from item in goods
                        where item.Name.Contains(good)
                        select item;

            int sum = query.Sum(item => item.Cost * item.Amount);

            Console.WriteLine($"Сумма стоимости товаров {good} = {sum}");

            Console.WriteLine("\n\n\t\t\tРасширяющие методы");

            sum = goods
                .Where(x => x.Name.Contains(good))
                .Sum(x => x.Cost * x.Amount);

            Console.WriteLine($"Сумма стоимости товаров {good} = {sum}");

        }
        public static void Process4(this List<Good> goods)
        {
            Console.WriteLine("\n  4.Все товары, для которых произведение цены на количество находится в заданном диапазоне\n (20 000, 50 000)");
            int lo = 20000, hi = 50000;
            Console.WriteLine("\t\t\tСинтаксис LINQ");

            var query = from item in goods
                        where (item.Cost * item.Amount) > lo && (item.Cost * item.Amount) < hi
                        select item;

            foreach (var item in query)
                Console.WriteLine($"\t{item:n2}");


            Console.WriteLine("\n\n\t\t\tРасширяющие методы");

            query = goods
                .Where(x => (x.Cost * x.Amount) > lo && (x.Cost * x.Amount) < hi)
                .Select(x => x);

            foreach (var item in query)
                Console.WriteLine($"\t{item:n2}");

        }

    }
}
