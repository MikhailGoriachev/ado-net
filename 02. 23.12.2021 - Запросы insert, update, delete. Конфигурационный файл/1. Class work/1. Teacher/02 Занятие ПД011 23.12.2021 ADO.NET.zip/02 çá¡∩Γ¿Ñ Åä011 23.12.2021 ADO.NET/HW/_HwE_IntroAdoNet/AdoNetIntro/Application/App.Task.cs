﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AdoNetIntro.Helpers;

namespace AdoNetIntro.Application
{
    /* 
    * Методы для решения выполнения запросов по заданию
    */
    public partial class App {
        // Запрос 1. Квартиры с заданным количеством комнат на заданной улице
        public void ExecQuery01() {
            Utils.ShowNavBarTask("   Выполнение запроса 1");

            _queriesController.Query01(2, "ул. Садовая");
        } // ExecQuery01

        // Запрос 2. Риелторы с заданной фамилией и процентом вознаграждения
        public void ExecQuery02() {
            Utils.ShowNavBarTask("   Выполнение запроса 2");

            Utils.ShowUnderConstruction();
        } // ExecQuery02

        // Запрос 3. Однокомнатные квартиры со стоимостью в заданном диапазоне
        public void ExecQuery03() {
            Utils.ShowNavBarTask("   Выполнение запроса 3");

            // для проверки работы выбираем квартиры
            _queriesController.Query03(2);
        } // ExecQuery03

        // Запрос 4. Квартиры с заданным количеством комнат
        public void ExecQuery04() {
            Utils.ShowNavBarTask("   Выполнение запроса 4");

            // для проверки работы выбираем 2хкомнатные квартиры
            _queriesController.Query04(2);
        } // ExecQuery04

        // Запрос 5. 2-хкомнатные квартиры с площадью из заданного диапазона
        public void ExecQuery05() {
            Utils.ShowNavBarTask("   Выполнение запроса 5");

            _queriesController.Query05(2, 80, 120);
        } // ExecQuery05

        // Запрос 6. Комиссия по всем оформленным сделкам риэлторов
        public void ExecQuery06() {
            Utils.ShowNavBarTask("   Выполнение запроса 6");

            Utils.ShowUnderConstruction();
        } // ExecQuery06

        // Запрос 7. Все риэлторы, их клиенты и сделки, по убыванию суммы сделки
        public void ExecQuery07() {
            Utils.ShowNavBarTask("   Выполнение запроса 7");

            Utils.ShowUnderConstruction();
        } // ExecQuery07

        // Запрос 8. По всем улицам вывести сумму сделок, по убыванию суммы
        public void ExecQuery08() {
            Utils.ShowNavBarTask("   Выполнение запроса 8");

            Utils.ShowUnderConstruction();
        } // ExecQuery08

        // Запрос 9. По всем улицам вывести сумму сделок за заданный период, по убыванию суммы
        public void ExecQuery09() {
            Utils.ShowNavBarTask("   Выполнение запроса 9");

            Utils.ShowUnderConstruction();
        } // ExecQuery09
    } // App
}
