﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HomeWorkWPF22._12._2021.Models;

namespace HomeWorkWPF22._12._2021.Views
{
    /// <summary>
    /// Логика взаимодействия для SphereWindow.xaml
    /// </summary>
    public partial class SphereWindow : Window
    {
        // поле с фигурой
        private Sphere _sphere;

        // конструктор с зависимостями
        public SphereWindow() : this(new Sphere()) { }

        // конструктор по умолчанию
        public SphereWindow(Sphere sphere)
        {
            InitializeComponent();

            _sphere = sphere;

            Txb_r.Text = $"{_sphere.R}";          
            Txb_p.Text = $"{_sphere.P}";

            // очистка поля вывода результата
            Res_S.Text = "";
            Res_V.Text = "";
            Res_M.Text = "";

            // фокус на первом поле ввода
            Txb_r.Focus();

        }

        // Calculate
        private void Calculate_Command(object sender, RoutedEventArgs e)
        {
            try
            {
                _sphere.R = double.Parse(Txb_r.Text);            
                _sphere.P = double.Parse(Txb_p.Text);


                double ResS, ResV, ResM;

                ResS = _sphere.GetS();
                ResV = _sphere.GetV();
                ResM = _sphere.GetMass();


                Res_S.Text = $"{ResS:f3}";
                Res_V.Text = $"{ResV:f3}";
                Res_M.Text = $"{ResM:f3}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Geometric_Command


        // Очистка поля вывода результата при изменении значений в полях ввода
        private void TextChanged_Handler(object sender, TextChangedEventArgs e)
        {
            // очистка поля вывода результата
            Res_S.Text = "";
            Res_V.Text = "";
            Res_M.Text = "";
        } // TextChanged_Handler
    }
}

