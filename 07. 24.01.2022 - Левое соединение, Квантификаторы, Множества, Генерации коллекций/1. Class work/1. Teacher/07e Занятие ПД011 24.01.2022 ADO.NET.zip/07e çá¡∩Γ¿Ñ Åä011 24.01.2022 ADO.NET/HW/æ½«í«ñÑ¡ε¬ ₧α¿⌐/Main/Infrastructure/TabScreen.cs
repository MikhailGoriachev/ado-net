﻿using System.Windows.Input;
using Stylet;


namespace Main.Infrastructure
{
	public class TabScreen : Screen
	{
		public TabScreen(string displayName)
		{
			DisplayName    = displayName;
		}


		protected override void OnViewLoaded()
		{
			View.Focusable = true;
			Keyboard.Focus(View);
		}


		public void ActivateOtherTab(Screen tabScreen)
		{
			var parent = (IShell)Parent;

			parent.ActivateItem(tabScreen);
		}
	}
}