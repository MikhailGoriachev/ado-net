﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using TicketTrain_WPF_first.Utils;

namespace TicketTrain_WPF_first.Models
{
    [Serializable]
    [DataContract]
    // класс, описующий вагон поезда
    public class TrainCar
    {
        public const int _countTrainCarCompartment = 9;

        [DataMember]
        // тип вагона
        private string _typeTrainCar;
        public string TypeTrainCar
        {
            get { return _typeTrainCar; }
            set { _typeTrainCar = value; }
        }


        [DataMember]
        // номер вагона
        private int _numbTrainCar;
        public int NumbTrainCar
        {
            get { return _numbTrainCar; }
            set
            {
                if (value < 1 || value > 20)
                    throw new Exception("TrainCar: ошибка номера вагона");
                _numbTrainCar = value;
            }
        }

        [DataMember]
        // коллекция купе
        private Compartment[] _compartments;
        public Compartment[] Compartments
        {
            get { return _compartments; }
            set { _compartments = value; }
        }


        // конструктор
        public TrainCar(int trainCarType, int numbTrainCar)
        {

            NumbTrainCar = numbTrainCar;

            _compartments = new Compartment[_countTrainCarCompartment];

            // заполнение коллекции купе вагона соответсвующими купе

            for (int i = 0; i < _countTrainCarCompartment; i++)
            {
                _compartments[i] = new Compartment(trainCarType, i + 1);
            }


            // название вагона
            switch (trainCarType)
            {


                case (int)TypeTrains.sv:
                    _typeTrainCar = "СВ";
                    break;

                case (int)TypeTrains.coupe:
                    _typeTrainCar = "Купе";
                    break;

                case (int)TypeTrains.reserved:
                    _typeTrainCar = "Плацкарт";
                    break;

                default:
                    throw new Exception("TrainCar: тип вагона не поддерживается");

            }
        }


        // получение места
        public Seat GetSeat(int Numb)
        {

            foreach (var item in _compartments)
            {
                foreach (var itemSeat in item.Seats)
                {
                    if (itemSeat.Number == Numb) return itemSeat;
                }

            }

            return null;

        }

        // получение места
        public void StateSeat(int Numb, bool state)
        {

            foreach (var item in _compartments)
            {
                foreach (var itemSeat in item.Seats)
                {
                    if (itemSeat.Number == Numb)
                    {
                        itemSeat.State = state;
                        break;
                    }
                }

            }


        }

        // получить количесвто мест в купе
        public int GetCountSeatinCoupe() => _compartments[0].CountSeats;


        // получить количесвто мест в вагоне
        public int GetSeatCount()
        {
            return _countTrainCarCompartment * (Utils.Utils.types[_typeTrainCar]);
        }

        // получить количесвто мест в вагоне
        public int GetSaleSeatCount()
        {
            int count = 0;

            foreach (var item in _compartments)
            {
                foreach (var itemSeat in item.Seats)
                {
                    if (itemSeat.State) count++;
                }
            }

            return count;
        }


        // индексатор для доступа к массиву купе
        public Compartment this[int index]
        {
            get => _compartments[index];
            set => _compartments[index] = value;
        } // Compartment
    }
}
