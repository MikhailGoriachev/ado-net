﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;        // для ADO.NET
using System.Data;

namespace H_W2Ado.Application
{
    internal partial class App
    {
        // Выбирает информацию о 3-комнатных квартирах, расположенных на улице «Садовая».
        // Значения задавать параметрами запроса
        public void Query01(string connectingString)
        {
            Console.WriteLine("\n Запрос 1\n Выбирает информацию о 3-комнатных" +
                " квартирах, расположенных на улице «Садовая».\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery01");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@namestreet", "Садовая");
                cmd.Parameters.AddWithValue("@numRooms", 3);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0), 12} | {reader.GetName(1),-10} | " +
                        $"{reader.GetName(2), -8} | {reader.GetName(3),8} |" +
                        $" {reader.GetName(4),13:n2} | {reader.GetName(5),14} | " +
                        $"{reader.GetName(6),14} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),12} | {reader.GetString(1),-10} | " +
                            $"{reader.GetString(2),-8} | {reader.GetInt32(3), 8} | " +
                            $"{reader.GetDouble(4),13:n2} | {reader.GetInt32(5),14} | " +
                            $"{reader.GetInt32(6),14} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query01

        // Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%.
        // Значения задавать параметрами запроса
        public void Query02(string connectingString)
        {
            Console.WriteLine("\n Запрос 2\n Выбирает информацию о риэлторах," +
                " фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery02");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@surname", "И%");
                cmd.Parameters.AddWithValue("@percent", 10);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),12} | {reader.GetName(1),-15} | " +
                        $"{reader.GetName(2),-15} | {reader.GetName(3),-17} | " +
                        $"{reader.GetName(4),19} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),12} | {reader.GetString(1),-15} | " +
                            $"{reader.GetString(2),-15} | {reader.GetString(3),-17} | " +
                            $"{reader.GetInt32(4),19} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query02


        // Выбирает информацию об 1-комнатных квартирах,
        // цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб.
        // Значения задавать параметрами запроса
        public void Query03(string connectingString)
        {
            Console.WriteLine("\n Запрос 3\n Выбирает информацию об 1-комнатных квартирах,\n" +
                " цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery03");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@loPrice", 900_000);
                cmd.Parameters.AddWithValue("@hiPrice", 1_000_000);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),12} | {reader.GetName(1),-12} | " +
                        $"{reader.GetName(2),-8} | {reader.GetName(3),8} |" +
                        $" {reader.GetName(4),13:n2} | {reader.GetName(5),14} | " +
                        $"{reader.GetName(6),14} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),12} | {reader.GetString(1),-12} | " +
                            $"{reader.GetString(2),-8} | {reader.GetInt32(3),8} | " +
                            $"{reader.GetDouble(4),13:n2} | {reader.GetInt32(5),14} | " +
                            $"{reader.GetInt32(6),14} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query03


        // Выбирает информацию о квартирах с заданным числом комнат.
        // Значения задавать параметрами запроса
        public void Query04(string connectingString)
        {
            Console.WriteLine("\n Запрос 4\n Выбирает информацию о квартирах с заданным числом комнат.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery04");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@numRooms", 2);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),12} | {reader.GetName(1),-15} | " +
                        $"{reader.GetName(2),-8} | {reader.GetName(3),8} |" +
                        $" {reader.GetName(4),13:n2} | {reader.GetName(5),14} | " +
                        $"{reader.GetName(6),14} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),12} | {reader.GetString(1),-15} | " +
                            $"{reader.GetString(2),-8} | {reader.GetInt32(3),8} | " +
                            $"{reader.GetDouble(4),13:n2} | {reader.GetInt32(5),14} | " +
                            $"{reader.GetInt32(6),14} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query04


        // Выбирает информацию обо всех 2-комнатных квартирах,
        // площадь которых есть значение из некоторого диапазона.
        // Значения задавать параметрами запроса
        public void Query05(string connectingString)
        {
            Console.WriteLine("\n Запрос 5\n Выбирает информацию обо всех 2-комнатных квартирах\n," +
                " площадь которых есть значение из некоторого диапазона.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery05");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@numRooms", 2);
                cmd.Parameters.AddWithValue("@loArea", 45.5);
                cmd.Parameters.AddWithValue("@hiArea", 50.5);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),12} | {reader.GetName(1),-15} | " +
                        $"{reader.GetName(2),-8} | {reader.GetName(3),8} |" +
                        $" {reader.GetName(4),13:n2} | {reader.GetName(5),14} | " +
                        $"{reader.GetName(6),14} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),12} | {reader.GetString(1),-15} | " +
                            $"{reader.GetString(2),-8} | {reader.GetInt32(3),8} | " +
                            $"{reader.GetDouble(4),13:n2} | {reader.GetInt32(5),14} | " +
                            $"{reader.GetInt32(6),14} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query05


        // Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.
        // Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные.
        // Сортировка по полю Дата сделки
        public void Query06(string connectingString)
        {
            Console.WriteLine("\n Запрос 6\n Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора\n." +
                " Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные.\n" +
                " Сортировка по полю Дата сделки\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery06");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-11} | {reader.GetName(1),-12} | " +
                        $"{reader.GetName(2),-12} | {reader.GetName(3),13} |" +
                        $" {reader.GetName(4),15} | {reader.GetName(5),13} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-11} | " +
                            $"{reader.GetString(1),-12} | {reader.GetString(2),-12} | " +
                            $"{reader.GetDateTime(3),13:d} | {reader.GetInt32(4),15} | {reader.GetInt32(5),13} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query06


        // Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора.
        // Упорядочить выборку по убыванию суммы сделок
        public void Query07(string connectingString)
        {
            Console.WriteLine("\n Запрос 7\n Выбрать всех риэлторов, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора.\n" +
                " Упорядочить выборку по убыванию суммы сделок\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery07");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"|{reader.GetName(0),8} | {reader.GetName(1),-12} | " +
                        $"{reader.GetName(2),-12} | {reader.GetName(3),-12} | " +
                        $"{reader.GetName(4),15} | {reader.GetName(5),10} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),8} | {reader.GetString(1),-12} | " +
                            $"{reader.GetString(2),-12} | {reader.GetString(3),-12} | " +
                            $"{reader.GetInt32(4),15} | {reader.GetInt32(5),10} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query07


        // Для всех улиц вывести сумму сделок,
        // упорядочить выборку по убыванию суммы сделки
        public void Query08(string connectingString)
        {
            Console.WriteLine("\n Запрос 8\n Для всех улиц вывести сумму сделок," +
                " упорядочить выборку по убыванию суммы сделки\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery08");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-15} | " +
                        $"{reader.GetName(1),12} | {reader.GetName(2),12} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-15} | " +
                            $"{reader.GetInt32(1),12} | {reader.GetInt32(2),12} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query08


        // Для всех улиц вывести сумму сделок за заданный период,
        // упорядочить выборку по убыванию суммы сделки.
        // Диапазон задавать параметрами запроса
        public void Query09(string connectingString)
        {
            Console.WriteLine("\n Запрос 9\n Для всех улиц вывести сумму сделок за заданный период,\n" +
                " упорядочить выборку по убыванию суммы сделки.\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов
                Console.WriteLine(" Соединение открыто\n");

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"ProcQuery09");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@fromDate", "12-05-2021");
                cmd.Parameters.AddWithValue("@toDate", "02-01-2022");

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Если данные получены (есть строки в полученном ответе серврера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine(
                        $"| {reader.GetName(0),-15} | " +
                        $"{reader.GetName(1),12} | {reader.GetName(2),12} |");

                    while (reader.Read())
                    {
                        Console.WriteLine(
                            $"| {reader.GetString(0),-15} | " +
                            $"{reader.GetInt32(1),12} | {reader.GetInt32(2),12} |");
                    } // while
                } // if
            } // using
            Console.WriteLine(" Соединение закрыто");
            Console.WriteLine();
        }// Query09

    }// class App
}
