﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _4ADO.NET.Utilits;

namespace _4ADO.NET.Classes
{
    class MyDouble
    {
        public List<double> doubles;

        public MyDouble()
        {
            doubles = new List<double>();

            for (int i = 0; i < 10; i++)
                doubles.Add(Utils.Random.NextDouble() * Utils.Random.Next(-5, 12));
        }

        public void Process1(double lo, double hi)
        {
            if (lo > hi) (lo, hi) = (hi, lo);
            Console.WriteLine("\n\t\t1.Вычисление количества элементов массива, со значениями в диапазоне от A до B\n");

            Console.WriteLine("\t\t\tСинтаксис LINQ");

            var query = from item in doubles
                         where item > lo && item < hi
                         select item;

            foreach (var item in query)
                Console.Write($"\t{item:n2}");

            Console.WriteLine("\n\n\t\t\tРасширяющие методы");

            query = doubles
                .Where(x => x > lo && x < hi)
                .Select(x => x);

            foreach (var item in query)
                Console.Write($"\t{item:n2}");
        }
        public void Process2()
        {
            Console.WriteLine("\n\n\t\t2.Вычисление количества элементов массива, равных 0\n");

            Console.WriteLine("\t\t\tСинтаксис LINQ");

            var query = from item in doubles
                         where item > 0.1 && item < 0.9
                         select item;

            foreach (var item in query)
                Console.Write($"\t{item:n2}");

            Console.WriteLine("\n\n\t\t\tРасширяющие методы");

            query = doubles
                .Where(x => x > 0.1 && x < 0.9)
                .Select(x => x);

            foreach (var item in query)
                Console.Write($"\t{item:n2}");
        }
        public void Process3()
        {
            Console.WriteLine("\n\n\t3.Bычисление суммы элементов массива, расположенных после первого максимального элемента\n");


            Console.WriteLine("\n\n\t\t\tРасширяющие методы");

            var query = doubles
                .SkipWhile(x => x < doubles.Max())
                .Select(x => x);
            double sum = query.Sum();

            Console.WriteLine($"\tОтвет: {sum:n2}");;
        }
        public void Process4()
        {
            Console.WriteLine("\n\n\t4.Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом\n");


            Console.WriteLine("\n\n\t\t\tРасширяющие методы");
            double min = doubles.Min(x => Math.Abs(x));
            var query = doubles
                .Where(x => Math.Abs(x) > min)
                .Select(x=>x);
            double sum = query.Sum();
            Console.WriteLine($"\tОтвет: {sum:n2}");;
        }


        public override string ToString()
        {
            string str = "";
            foreach (var item in doubles)
                str += $"\t{item:n2}";

            return str;
        }
    }
}
