﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeriodicalsModels.Models
{
    public class Deliveries
    {
        public string PubType { get; set; }

        public int DeliveriesAmount { get; set; }

        public string ToTableRow() =>
            $"\t | {PubType,16} | {DeliveriesAmount, 15} |";
    }   
}
