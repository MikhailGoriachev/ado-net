﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W2Ado.Application
{
    internal partial class App
    {


    }// class App
}
