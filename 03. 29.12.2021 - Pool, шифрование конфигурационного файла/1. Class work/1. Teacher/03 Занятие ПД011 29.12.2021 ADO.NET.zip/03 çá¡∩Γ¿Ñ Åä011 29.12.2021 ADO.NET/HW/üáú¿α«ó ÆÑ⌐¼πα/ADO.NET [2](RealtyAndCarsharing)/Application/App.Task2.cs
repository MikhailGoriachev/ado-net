﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ADO.NET__2__RealtyAndCarsharing_.Helpers;

namespace ADO.NET__2__RealtyAndCarsharing_.Application
{
    public partial class App
    {                     


        // Запрос 1. Факты проката автомобиля с заданным госномером
        public void ExecQuery2_1()
        {
            Utils.ShowNavBarTask("   Выполнение запроса (2)1");

            _task2Controller2.Query1("X 305 BX");
        } // ExecQuery2_1

        // Запрос 2. Автомобиль с заданной моделью / брендом
        public void ExecQuery2_2()
        {
            Utils.ShowNavBarTask("   Выполнение запроса (2)2");

            _task2Controller2.Query2("BMW X5");
        } // ExecQuery2_2

        // Запрос 3. Автомобиль с заданной госномером 
        public void ExecQuery2_3()
        {
            Utils.ShowNavBarTask("   Выполнение запроса (2)3");

            _task2Controller2.Query3("T 799 MO");
        } // ExecQuery2_3

        // Запрос 4. Клиент с заданной серией и номером паспорта.
        public void ExecQuery2_4()
        {
            Utils.ShowNavBarTask("   Выполнение запроса (2)4");

            _task2Controller2.Query4("12 21 345675");
        } // ExecQuery2_4

        // Запрос 5. Факты проката автомобиля в заданном интервале времени. 
        public void ExecQuery2_5()
        {
            Utils.ShowNavBarTask("   Выполнение запроса (2)5");

            Utils.ShowUnderConstruction();
        } // ExecQuery2_5

        // Запрос 6. Стоимость каждого факта проката.Сортировка по полю "Дата проката" 
        public void ExecQuery2_6()
        {
            Utils.ShowNavBarTask("   Выполнение запроса (2)6");

            Utils.ShowUnderConstruction();
        } // ExecQuery2_6

        // Запрос 7. Все клиенты, кол - во фактов проката, сум. кол - во дней проката, по суммарному кол-во дней прокатов
        public void ExecQuery2_7()
        {
            Utils.ShowNavBarTask("   Выполнение запроса (2)7");

            Utils.ShowUnderConstruction();
        } // ExecQuery2_7

        // Запрос 8. Факты проката автомобиля по госномеру, кол-во фактов проката, сумма за прокаты, суммарная длительность прокатов
        public void ExecQuery2_8()
        {
            Utils.ShowNavBarTask("   Выполнение запроса (2)8");

            Utils.ShowUnderConstruction();
        } // ExecQuery2_8

    
    } // App
}
