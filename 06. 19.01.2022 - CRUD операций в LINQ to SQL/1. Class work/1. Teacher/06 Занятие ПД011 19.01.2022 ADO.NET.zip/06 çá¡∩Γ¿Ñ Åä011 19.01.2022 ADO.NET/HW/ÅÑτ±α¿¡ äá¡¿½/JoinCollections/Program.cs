﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using JoinCollections.Helpers;
using JoinCollections.Application;

namespace JoinCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 17.01.2022 - LINQ to SQL";

            MenuItem[] menu = new[]
            {
                new MenuItem { HotKey = ConsoleKey.Q, Text ="Вывести все книги коллекции, выводить фамилии и инициалы автора"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Вывести книги авторов, год рождения которых принадлежит заданном диапазону "},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Вывести книги, в названии которых содержится заданная подстрока и цена не превышает заданного значения"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Список авторов и количество их книг в коллекции"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Средняя цена книг по годам издания"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Список авторов по убыванию количества их книг в коллекции "},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Средний возраст книг по авторам, выводить список с упорядочиванием фамилий и инициалов авторов по алфавиту"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Задача2. Товары в штуках по заданной цене"},
                new MenuItem {HotKey = ConsoleKey.F, Text = ""},

                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" }
            };//Menu

            App app = new App();
            while (true)
            {

                try
                {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  JOIN в ADO.NET");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с базой данных «Оптовый магазин. Учет продаж»", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    switch (key)
                    {
                        case ConsoleKey.Q:
                            app.Task1();
                            break;
                        case ConsoleKey.W:
                            app.Task2();
                            break;
                        case ConsoleKey.E:
                            app.Task3();
                            break;
                        case ConsoleKey.R:
                            app.Task4();
                            break;
                        case ConsoleKey.T:
                            app.Task5();
                            break;
                        case ConsoleKey.A:
                            app.Task6();
                            break;
                        case ConsoleKey.S:
                            app.Task7();
                            break;
                        case ConsoleKey.D:
                            app.TaskQuery1();
                            break;
                    }

                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }

            }//while
            
        }
    }
}
