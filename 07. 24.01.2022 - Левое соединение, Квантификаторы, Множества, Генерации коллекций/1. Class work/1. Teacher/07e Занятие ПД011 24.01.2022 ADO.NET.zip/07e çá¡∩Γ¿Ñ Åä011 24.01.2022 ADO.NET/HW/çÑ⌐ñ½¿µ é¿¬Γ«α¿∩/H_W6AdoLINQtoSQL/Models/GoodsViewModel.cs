﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6AdoLINQtoSQL.Models
{
    // Класс для Представления товарa
    public class GoodsViewModel
    {
        public string Name { get; set; }
        public int Amount { get; set; }
        public string Short { get; set; }
        public int PricePurchase { get; set; }
        public DateTime DatePurchase { get; set; }

    }// class GoodsViewModel
}
