﻿using H_W3Ado.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace H_W3Ado.Application
{
    internal partial class App
    {

        // Выбирает из таблицы ИЗДАНИЯ информацию о доступных для
        // подписки изданиях заданного типа,
        // стоимость 1 экземпляра для которых меньше заданной.
        public void ExecQuery01()
        {
            
            Utils.ShowNavBarTask("    Запрос 1. \n Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях\n" +
            " заданного типа стоимость 1 экземпляра для которых меньше заданной.\n");

            List <Publication> list = _realEstateController.Query01(1000);

            Console.Write($"\n{Publication.Header()}");
            // вывод списка
            list.ForEach(a => Console.WriteLine(a.ToTableRow()));
            
            Console.Write($"{Publication.Footer()}");
        } // ExecQuery01


        // 	Выбирает из таблиц информацию о подписчиках, проживающих на заданной
        // 	параметром улице и номере дома, которые оформили подписку на издание с
        // 	заданным параметром наименованием
        public void ExecQuery02()
        {

            Utils.ShowNavBarTask("    Запрос 2. \n Выбирает из таблиц информацию о подписчиках,\n" +
                " проживающих на заданной параметром улице и номере дома,\n" +
                " которые оформили подписку на издание с заданным параметром наименованием. \n");

            List <Subscriber> list = _realEstateController.Query02("Артёма", "6", "В гостях у сказки");

            Console.Write($"\n{Subscriber.Header()}");
            // вывод списка
            list.ForEach(a => Console.WriteLine(a.ToTableRow()));

            Console.Write($"{Subscriber.Footer()}");
        } // ExecQuery02


        // 	Выбирает из таблицы ИЗДАНИЯ информацию об изданиях,
        // 	для которых значение в поле Цена 1 экземпляра находится в заданном диапазоне значений
        public void ExecQuery03()
        {

            Utils.ShowNavBarTask("    Запрос 3. \n Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в\n" +
                " поле Цена 1 экземпляра находится в заданном диапазоне значений.\n");

            List < Publication> list = _realEstateController.Query03(1000, 25000);

            Console.Write($"\n{Publication.Header()}");
            // вывод списка
            list.ForEach(a => Console.WriteLine(a.ToTableRow()));

            Console.Write($"{Publication.Footer()}");
        } // ExecQuery03


        // Выбирает из таблиц информацию о подписчиках,
        // подписавшихся на заданный параметром тип издания
        public void ExecQuery04()
        {

            Utils.ShowNavBarTask("    Запрос 4. \n Выбирает из таблиц информацию о подписчиках,\n" +
                " подписавшихся на заданный параметром тип издания. \n");

            List < Subscriber> list = _realEstateController.Query04("газета");

            Console.Write($"\n{Subscriber.Header()}");
            // вывод списка
            list.ForEach(a => Console.WriteLine(a.ToTableRow()));

            Console.Write($"{Subscriber.Footer()}");
        } // ExecQuery04


        // Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках,
        // для которых срок подписки есть значение из некоторого диапазона
        public void ExecQuery05()
        {

            Utils.ShowNavBarTask("    Запрос 5. \n Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках,\n" +
                " для которых срок подписки есть значение из некоторого диапазона. \n\n\n");

            _realEstateController.Query05(2, 5);
        } // ExecQuery05


        // Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС.
        // Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра,
        // Дата начала подписки, Срок подписки, Стоимость подписки без НДС.
        // Сортировка по полю Индекс издания
        public void ExecQuery06()
        {

            Utils.ShowNavBarTask("    Запрос 6. \n Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС.\n" +
                " Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра,\n" +
                " Дата начала подписки, Срок подписки, Стоимость подписки без НДС.\n" +
                " Сортировка по полю Индекс издания. \n\n\n");

            _realEstateController.Query06();
        } // ExecQuery06


        // Выполняет группировку по полю Вид издания.
        // Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
        public void ExecQuery07()
        {

            Utils.ShowNavBarTask("    Запрос 7. \n Выполняет группировку по полю Вид издания.\n" +
                " Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра. \n\n\n");

            _realEstateController.Query07();
        } // ExecQuery07


        // Выполняет группировку по полю Улица.
        // Для всех улиц вычисляет количество подписчиков,
        // проживающих на данной улице (итоги по полю Код получателя)
        public void ExecQuery08()
        {

            Utils.ShowNavBarTask("    Запрос 8. \n Выполняет группировку по полю Улица. Для всех улиц вычисляет количество подписчиков,\n" +
                " проживающих на данной улице (итоги по полю Код получателя). \n\n\n");

            _realEstateController.Query08();
        } // ExecQuery08


        // Для всех изданий выводит количество оформленных подписок
        public void ExecQuery09()
        {

            Utils.ShowNavBarTask("    Запрос 9. \n Для всех изданий выводит количество оформленных подписок. ");

            Console.WriteLine("\n\n\n");
            _realEstateController.Query09();
        } // ExecQuery09


        // Шифрование конфигурационного файла
        public void CodeConfigurationFile()
        {
            Utils.ShowNavBarTask("    Шифрование конфигурационного файла. ");
            Console.WriteLine("\n");

            // получение доступа к конфигурационному файлу
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            if (!section.SectionInformation.IsProtected)
            {
                // Зашифровать секцию.
                section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                // Сохранить файл конфигурации.
                config.Save();
            } // if

            // Проверка шифрования
            Console.WriteLine($"Protected={section.SectionInformation.IsProtected}\n" +
                              $"{ConfigurationManager.ConnectionStrings["AccountSubscriptions"].ConnectionString}");
        }// CodeConfigurationFile

        // Расшифрование конфигурационного файла
        public void ConfigurationFile()
        {
            Utils.ShowNavBarTask("    Расшифрование конфигурационного файла. ");
            Console.WriteLine("\n");

            // получение доступа к конфигурационному файлу
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;

            // расшифровкa секции
            section.SectionInformation.UnprotectSection();
            config.Save();

            // Проверка шифрования
            Console.WriteLine($"Protected={section.SectionInformation.IsProtected}\n" +
                              $"{ConfigurationManager.ConnectionStrings["RealEstateConnection"].ConnectionString}");
        }// ConfigurationFile

    }// class App
}
