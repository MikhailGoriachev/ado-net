﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// для работы с технологией ADO.NET
using System.Configuration;   // добавить сборку System.Configuration.dll
using System.Data;
using System.Data.SqlClient;

namespace ADO.NET__2__RealtyAndCarsharing_.Controllers
{
    public class Task1Controller {

        private string _connectingString;
        public string ConnectingString{
            get => _connectingString;
            set => _connectingString = string.IsNullOrWhiteSpace(value)
                ? throw new Exception("Строка подключения к базе данных не указана") : value;
        }

        public Task1Controller() : this(ConfigurationManager.ConnectionStrings["RealteConnectionSQLServer"].ConnectionString ) { }

        public Task1Controller(string connectingString) => ConnectingString = connectingString;

        //			-> Запрос №1 [Запрос с параметром] <-
        // Выбирает из таблицы КВАРТИРЫ информацию о 3-комнатных квартирах,
        // расположенных на улице «Садовая». Значения задавать параметрами запроса.
        public void Query1(int numberRoom, string street){
            Console.WriteLine("\n\n\n\tЗапрос 1.\n" +
                                $"\tКвартиры с количеством комнат {numberRoom}, расположенных на {street}\n");

            using (SqlConnection connection = new SqlConnection(ConnectingString)){
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                    ApartmentId
                    , Street          
                    , HouseNumber
                    , ApartmentNumber         
                    , Area		   
                    , NumberRooms    
                    , Price
                from
                    ViewApartments
                where
                    NumberRooms = @numRoom and Street = @street;"
                );

                cmd.Connection = connection;

                cmd.Parameters.AddWithValue("@street", street);
                cmd.Parameters.AddWithValue("@numRoom", numberRoom);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToApartment(cmd);
            } // using
        } // Query1


        //			-> Запрос №2 [Запрос с параметром] <-
        // Выбирает информацию о риэлторах,
        // фамилия которых начинается с буквы «И» и процент вознаграждения больше 10%.
        // Значения задавать параметрами запроса
        public void Query2(char firstLetterSurname, float percent)
        {
            Console.WriteLine("\n\n\n\tЗапрос 2.\n" +
                                $"\tРиэлтор с фамилией начинающаяся на букву {firstLetterSurname}\n" +
                                $"\tи процентом вознаграждения больше {percent}");

            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                    RealtorId
                    , RealtorSurname          
                    , RealtorName
                    , RealtorPatronymic         
                    , PercentageRemuneration		    
                from
                    ViewRealtors
                where
                    RealtorSurname like (@firstLetterSurname + N'%') and PercentageRemuneration > @percent"
                );

                cmd.Connection = connection;

                cmd.Parameters.AddWithValue("@firstLetterSurname", firstLetterSurname);
                cmd.Parameters.AddWithValue("@percent", percent);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // выводим имена столбцов (это не обязательно)
                Console.WriteLine("\t" +
                                  $"│ {reader.GetName(0),11} │ {reader.GetName(1),-15} " +
                                  $"│ {reader.GetName(2),-15} │ {reader.GetName(3),4} " +
                                  $"│ {reader.GetName(4),4} │ ");


                // Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetInt32(0),11} " +
                            $"│ {reader.GetString(1),-15} " +
                            $"│ {reader.GetString(2),-15} " +
                            $"│ {reader.GetString(3),-17} " +
                            $"│ {reader.GetDouble(4),22} │");
                    } // while
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\tНет данных");
                    Console.ForegroundColor = ConsoleColor.Gray;
                } // if
                 

            } // using
        } // Query2


        //			-> Запрос №3 [Запрос с параметром] <-
        // Выбирает информацию об 1-комнатных квартирах,
        // цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб.
        // Значения задавать параметрами запроса
        public void Query3(int numberRoom, int loPrice, int hiPrice)
        {
            Console.WriteLine("\n\n\n\n\tЗапрос 3.\n" +
                              $"\tКвартиры с количеством комнат {numberRoom}, и ценой в заданном диапазоне [{loPrice};{hiPrice}]\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();  

              
                SqlCommand cmd = new SqlCommand(@"
                select
                    ApartmentId
                    , Street          
                    , HouseNumber
                    , ApartmentNumber         
                    , Area		   
                    , NumberRooms    
                    , Price
                from
                    ViewApartments
                where
                    NumberRooms = @numRoom and Price between @loPrise and @hiPrice;"
                );

          
                cmd.Connection = connection;

    
                cmd.Parameters.AddWithValue("@numRoom", numberRoom);
                cmd.Parameters.AddWithValue("@loPrise", loPrice);
                cmd.Parameters.AddWithValue("@hiPrice", hiPrice);

               
                QueryToApartment(cmd);
            } // using
        } // Query3

        //			-> Запрос №4 [Запрос с параметром] <-
        // Выбирает информацию о квартирах с заданным числом комнат. Значения задавать 
        // параметрами запроса
        public void Query4(int numberRoom)
        {
            Console.WriteLine("\n\n\n\n\tЗапрос 4.\n" +
                              $"\tКвартиры с количеством комнат {numberRoom}\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();  

               
                SqlCommand cmd = new SqlCommand(@"
               select
                    ApartmentId
                    , Street          
                    , HouseNumber
                    , ApartmentNumber         
                    , Area		   
                    , NumberRooms    
                    , Price
                from
                    ViewApartments
                where
                    NumberRooms = @numRoom;"
                );

          
                cmd.Connection = connection;

              
                cmd.Parameters.AddWithValue("@numRoom", numberRoom);

               
                QueryToApartment(cmd);
            } // using
        } // Query4

        //			-> Запрос №5 [Запрос с параметром] <-
        // Выбирает информацию обо всех 2-комнатных квартирах,
        // площадь которых есть значение из некоторого диапазона.
        // Значения задавать параметрами запроса
        public void Query5(int numberRoom, int loArea, int hiArea)
        {
            Console.WriteLine("\n\n\n\n\tЗапрос 5.\n" +
                              $"\tКвартиры с количеством комнат {numberRoom} и площадью в диапазоне " +
                              $"[{loArea}, {hiArea}] м2\n");

          
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open(); 

               
                SqlCommand cmd = new SqlCommand(@"
                select
                    ApartmentId
                    , Street          
                    , HouseNumber
                    , ApartmentNumber         
                    , Area		   
                    , NumberRooms    
                    , Price
                from
                    ViewApartments
                where
                    NumberRooms = @numRoom and Area between @loArea and @hiArea;");

            
                cmd.Connection = connection;

            
                cmd.Parameters.AddWithValue("@numRoom", numberRoom);
                cmd.Parameters.AddWithValue("@loArea", loArea);
                cmd.Parameters.AddWithValue("@hiArea", hiArea);

              
                QueryToApartment(cmd);
            } // using
        } // Query5


        //			-> Запрос №6 [Запрос с параметром] <-
        // Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.
        // Включает поля Фамилия риэлтора, Имя риэлтора, Отчество риэлтора, Дата сделки,
        // Цена квартиры, Комиссионные.
        // Сортировка по полю Дата сделки
        public void Query6()
        {
            Console.WriteLine("\n\n\n\n\tЗапрос 6.\n" +
                              $"\tВычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора\n");


            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();


                SqlCommand cmd = new SqlCommand(@"
                select
                    TransactionId
                    , RealtorSurname
                    , RealtorName 
                    , RealtorPatronymic         
                    , DateExecution		       
                    , Price
                    , Price * PercentageRemuneration / 100 as PercentageRemuneration 
                from
                    ViewTransactions
                order by
                    DateExecution;");


                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // выводим имена столбцов (это не обязательно)
                Console.WriteLine("\t" +
                           $"│ {reader.GetName(0),11} │ {reader.GetName(1),-15} " +
                           $"│ {reader.GetName(2),-15} │ {reader.GetName(3),4} " +
                           $"│ {reader.GetName(4),18} │ {reader.GetName(5),11} " +
                           $"│ {reader.GetName(6),6} │");


                // Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                         $"│ {reader.GetInt32(0),13} " +
                         $"│ {reader.GetString(1),-15} " +
                         $"│ {reader.GetString(2),-15} " +
                         $"│ {reader.GetString(3),17} " +
                         $"│ {reader.GetDateTime(4),4} " +
                         $"│ {reader.GetInt32(5),11:n0} " +
                         $"│ {reader.GetDouble(6),22:n2} │");
                    } // while
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\tНет данных");
                    Console.ForegroundColor = ConsoleColor.Gray;
                } // if

            } // using
        } // Query6


        //			-> Запрос №7 [Запрос с параметром] <-
        // Выбрать всех риэлторов, количество клиентов,
        // оформивших с ним сделки и сумму сделок риэлтора.
        // Упорядочить выборку по убыванию суммы сделок.
        public void Query7()
        {
            Console.WriteLine("\n\n\n\tЗапрос 7.\n" +
                                $"\tСтатистика сделок риэлторов\n");

            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                    ViewRealtors.RealtorSurname          
                    , ViewRealtors.RealtorName
                    , ViewRealtors.RealtorPatronymic
                    , IsNull(Sum(ViewTransactions.Price),0) as SumTransaction
                    , Count(ViewTransactions.OwnerId) as AmocunClient
                from
                    	ViewRealtors left join ViewTransactions on ViewRealtors.RealtorId = ViewTransactions.RealtorId
                group by
                     ViewRealtors.RealtorSurname, ViewRealtors.RealtorName, ViewRealtors.RealtorPatronymic
                order by
                	SUM(ViewTransactions.Price) desc;"
                );  
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // выводим имена столбцов (это не обязательно)
                Console.WriteLine("\t" +
                                  $"│ {reader.GetName(0),11} │ {reader.GetName(1),-15} " +
                                  $"│ {reader.GetName(2),-15} │ {reader.GetName(3),4} " +
                                  $"│ {reader.GetName(4),4} │");


                // Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("\t" + 
                            $"│ {reader.GetString(0),-14} " +
                            $"│ {reader.GetString(1),-15} " +
                            $"│ {reader.GetString(2),-17} " +
                            $"│ {reader.GetInt32(3),-14:n2} " +
                            $"│ {reader.GetInt32(4),12} │");
                    } // while
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\tНет данных");
                    Console.ForegroundColor = ConsoleColor.Gray;
                } // if


            } // using
        } // Query7


        //			-> Запрос №8 [Запрос с параметром] <-
        // Для всех улиц вывести сумму сделок,
        // упорядочить выборку по убыванию суммы сделки
        public void Query8()
        {
            Console.WriteLine("\n\n\n\tЗапрос 8.\n" +
                                $"\tСумма сделок для всех улиц, упорядочено по убыванию суммы сделок\n");

            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                   Streets.Street
	               , IsNull(Sum(ViewTransactions.Price),0)  as SumTransactions          
                from
                    Streets left join ViewTransactions on Streets.Street = ViewTransactions.Street
                group by
                      Streets.Street
                order by
                	SUM(ViewTransactions.Price) desc;"
                );
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // выводим имена столбцов (это не обязательно)
                Console.WriteLine("\t" +
                                  $"│ {reader.GetName(0),-20} │ {reader.GetName(1),-15} │");


                // Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetString(0),-20} " + 
                            $"│ {reader.GetInt32(1),15} │");
                    } // while
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\tНет данных");
                    Console.ForegroundColor = ConsoleColor.Gray;
                } // if


            } // using
        } // Query8

        //			-> Запрос №9 [Запрос с параметром] <-
        // Для всех улиц вывести сумму сделок за заданный период,
        // упорядочить выборку по убыванию суммы сделки.
        // Диапазон задавать параметрами запроса
        public void Query9(DateTime loDate, DateTime hiDate)
        {
            Console.WriteLine("\n\n\n\tЗапрос 9.\n" +
                                $"\tСумма сделок для всех улиц за заданный период, упорядочено по убыванию суммы сделок\n");

            using (SqlConnection connection = new SqlConnection(ConnectingString))
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(@"
                select
                   Streets.Street
	               , IsNull(Sum(ViewTransactions.Price),0)  as SumTransactions          
                   , ViewTransactions.DateExecution
                from
                    Streets left join ViewTransactions on Streets.Street = ViewTransactions.Street
                where
                    ViewTransactions.DateExecution between @loDate and @hiDate
                group by
                      Streets.Street, ViewTransactions.DateExecution
                order by
                	SUM(ViewTransactions.Price) desc;"
                );
                cmd.Connection = connection;

                cmd.Parameters.AddWithValue("@loDate", loDate);
                cmd.Parameters.AddWithValue("@hiDate", hiDate);
                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // выводим имена столбцов (это не обязательно)
                Console.WriteLine("\t" +
                                  $"│ {reader.GetName(0),-20} │ {reader.GetName(1),-15} " +
                                  $"│ {reader.GetName(2),-18} │");


                // Если данные получены (есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("\t" +
                            $"│ {reader.GetString(0),-20} " +
                            $"│ {reader.GetInt32(1),15} " +
                            $"│ {reader.GetDateTime(2),12} │");
                    } // while
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\tНет данных");
                    Console.ForegroundColor = ConsoleColor.Gray;
                } // if


            } // using
        } // Query9


        // Вывод запроса, использующего данные квартиры
        private void QueryToApartment(SqlCommand cmd)
        {
            // выполнение запроса, ссылка на  выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // выводим имена столбцов (это не обязательно)
            Console.WriteLine("\t" +
                              $"│ {reader.GetName(0),11} │ {reader.GetName(1),-15} " +
                              $"│ {reader.GetName(2),-15} │ {reader.GetName(3),4} " +
                              $"│ {reader.GetName(4),4} │ {reader.GetName(5),7} " +
                              $"│ {reader.GetName(6),8}   │");

          
            // Если данные получены (есть строки в полученном ответе сервера)
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Console.WriteLine("\t" +
                        $"│ {reader.GetInt32(0),11} " +
                        $"│ {reader.GetString(1),-15} " +
                        $"│ {reader.GetString(2),-15} " +
                        $"│ {reader.GetString(3),15} " +
                        $"│ {reader.GetDouble(4),4} " +
                        $"│ {reader.GetInt32(5),11} " +
                        $"│ {reader.GetInt32(6),10:n0} │");
                } // while
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\tНет данных");
                Console.ForegroundColor = ConsoleColor.Gray;
            } // if
        } // QueryToApartment

    } // QueriesController

}
