﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
	class Program
	{
		static void Main(string[] args)
		{
			Utils.Init();

			App app = new App();

			app.Run();
		}
	}
}
