﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADoNET_3__PrintedEdition_.Models
{
    // Модель отображения таблицы Подписчики(Subscribers)
    public class Subscriber {
		public int Id { get; set; } // Первичный ключ
		public string Surname { get; set; } // Фамилия
		public string Name { get; set; } // Имя
		public string Patronymic { get; set; } // Отчество 
		public int Passport { get; set; } // Паспорт
		public string Street { get; set; } // Улица
		public string HouseNumber { get; set; } // Номер дома
		public string ApartmentNumber { get; set; } // Номер квартиры
		public DateTime SubscriptionDate { get; set; } // Дата начала подписки
		public int SubDuration { get; set; } // Срок подписки (в месяцах) максимум 12.
		public string TypeEdition { get; set; } // Тип издания (газета, журнал, альманах, задачник, энциклопедия) 
		public string NameEdition { get; set; } // Название издания

		// Конструктор с параметрами  
		public Subscriber(int id, string surname, string name, string patronymic, int passport
			,string street, string houseNumber, string apartmentNumber, DateTime subscriptionDate
			,int subDuration, string typeEdition, string nameEdition){
			Id               = id;
			Surname          = surname;
			Name             = name;
			Patronymic       = patronymic;
			Passport         = passport;
			Street           = street;
			HouseNumber      = houseNumber;
			ApartmentNumber  = apartmentNumber;
			SubscriptionDate = subscriptionDate;
			SubDuration      = subDuration;
			TypeEdition      = typeEdition;
			NameEdition      = nameEdition;
		} // Subscriber

		// Вывод данных в формате строки таблицы
		public string ToTableRow() =>
			$"\t│ {Id,2} │ {Surname,-11} │ {Name,-11} " +
			$"│ {Patronymic,-13} │ {Passport,8} │ {Street,-14} " +
			$"│ {HouseNumber,-5} │ {ApartmentNumber,-8} │ {SubscriptionDate.ToShortDateString(),13} " +
			$"│ {SubDuration,6} │ {TypeEdition,-13} │ {NameEdition,-35} │ ";

		// Шапка таблицы
		static public string Header() =>
			"\t┌────┬─────────────┬─────────────┬───────────────┬──────────┬────────────────┬───────┬──────────┬───────────────┬────────┬───────────────┬─────────────────────────────────────┐\n" +
			"\t│ Id │   Фамилия   │     Имя     │   Отчество    │ Пасспорт │     Улица      │ Номер │  Номер   │     Дата      │  Срок  │    Тип        │            Название                 │\n" +
			"\t│    │             │             │               │          │                │ дома  │ квартиры │начала подписки│подписки│      издания  │                 издания             │\n" +
			"\t├────┼─────────────┼─────────────┼───────────────┼──────────┼────────────────┼───────┼──────────┼───────────────┼────────┼───────────────┼─────────────────────────────────────┤\n";

		// Подвал таблицы
		public static string Footer() => "\t└────┴─────────────┴─────────────┴───────────────┴──────────┴────────────────┴───────┴──────────┴───────────────┴────────┴───────────────┴─────────────────────────────────────┘";



	}
}
