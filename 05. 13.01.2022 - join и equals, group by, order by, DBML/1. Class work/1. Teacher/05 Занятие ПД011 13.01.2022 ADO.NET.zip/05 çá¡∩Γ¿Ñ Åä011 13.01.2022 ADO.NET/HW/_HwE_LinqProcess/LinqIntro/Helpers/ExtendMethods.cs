﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LinqIntro.Models;

namespace LinqIntro.Helpers
{
    // класс для расширяющих методов
    public static class ExtendMethods
    {
        // Задача 1.
        // Для класса, представляющего товар (наименование, цена, количество, год выпуска)
        // разработать расширяющий метод, возвращающий процент скидки в зависимости от возраста
        // товара – до 3х лет скидка не представляется, от 3х до 10 лет скидка 3%, свыше
        // 10 лет – скидка 7%. Продемонстрировать работу метода на коллекции из 12 товаров.
        public static double Discount(this Goods goods) {
            double discount;                           // процент скидки
            int age = DateTime.Now.Year - goods.Year;  // возраст товара

            // вычисление скидки в зависимости от возраста товара
            if (age < 3)
                discount = 0;
            else if (age < 10)
                discount = 3;
            else
                discount = 7;

            return discount;
        } // Discount
    } // class ExtendMethods
}
