﻿using System;
using System.Text;
using System.Threading;

namespace LINQ_LeftJoin_Shop_DB.Utilities
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();
        
        // формирование случайных целых чисел в диапазоне от lo до hi
        public static double GetRandom(int lo, int hi)
            => Random.Next(lo,hi);

        #region Флаги исполнения запросов на каддой вкладке
        //Запрос 1
        public static bool Query_1_Executed = false;

        //Запрос 2
        public static bool Query_2_Executed = false;

        //Запрос 3
        public static bool Query_3_Executed = false;

        //Запрос 4
        public static bool Query_4_Executed = false;

        #endregion


    } // class Utils
}