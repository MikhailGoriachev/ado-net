﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
	public class PublicationsModel
	{
		public int Id { get; set; }
		public string PubType { get; set; }
		public string PubIndex { get; set; }
		public string Title { get; set; }
		public int Price { get; set; }

		public static string Header() =>
			$"\t┌────┬─────────────────┬────────────┬──────────────────────────────────────────┬────────┐\n" +
			$"\t│ Id │   Тип издания   │   Индекс   │               Название                   │  Цена  │\n" +
			$"\t├────┼─────────────────┼────────────┼──────────────────────────────────────────┼────────┤\n";

		public string ToTableRow() =>
			$"\t│ {Id,2} │ {PubType,-15} │ {PubIndex,10} │ {Title,-40} │ {Price,6} │";

		public static string Footer() =>
			$"\t└────┴─────────────────┴────────────┴──────────────────────────────────────────┴────────┘";
	}
}
