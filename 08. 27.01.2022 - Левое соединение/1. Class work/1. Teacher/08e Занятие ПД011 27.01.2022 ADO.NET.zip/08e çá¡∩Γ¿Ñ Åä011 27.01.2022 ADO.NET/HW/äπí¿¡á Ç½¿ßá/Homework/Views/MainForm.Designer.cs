﻿namespace Homework.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаЕдиницИзмеренияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаПерсонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаПродавцовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаТоваровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаЗакупокToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаПродажToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpMain = new System.Windows.Forms.TabPage();
            this.DgvGoods = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DgvPersons = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DgvSales = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DgvSellers = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DgvPurchases = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DgvUnits = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.longDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.LblMain = new System.Windows.Forms.Label();
            this.TbpQuery01 = new System.Windows.Forms.TabPage();
            this.DgvQuery01 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesTotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.queryViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.LblQuery01 = new System.Windows.Forms.Label();
            this.TbpQuery02 = new System.Windows.Forms.TabPage();
            this.DgvQuery02 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesAmountDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesTotalDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LblQuery02 = new System.Windows.Forms.Label();
            this.resultQuery06BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.resultQuery07and08BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvGoods)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPersons)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSales)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSellers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPurchases)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvUnits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitsBindingSource)).BeginInit();
            this.TbpQuery01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queryViewModelBindingSource)).BeginInit();
            this.TbpQuery02.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery06BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery07and08BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.таблицыToolStripMenuItem,
            this.запросыToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(862, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.файлToolStripMenuItem.Text = "&Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.выходToolStripMenuItem.Text = "&Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // таблицыToolStripMenuItem
            // 
            this.таблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.таблицаЕдиницИзмеренияToolStripMenuItem,
            this.таблицаПерсонToolStripMenuItem,
            this.таблицаПродавцовToolStripMenuItem,
            this.таблицаТоваровToolStripMenuItem,
            this.таблицаЗакупокToolStripMenuItem,
            this.таблицаПродажToolStripMenuItem});
            this.таблицыToolStripMenuItem.Name = "таблицыToolStripMenuItem";
            this.таблицыToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.таблицыToolStripMenuItem.Text = "Таблицы";
            // 
            // таблицаЕдиницИзмеренияToolStripMenuItem
            // 
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Image = global::Homework.Properties.Resources.box;
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Name = "таблицаЕдиницИзмеренияToolStripMenuItem";
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Text = "Таблица единиц измерения";
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Click += new System.EventHandler(this.ShowUnits_Command);
            // 
            // таблицаПерсонToolStripMenuItem
            // 
            this.таблицаПерсонToolStripMenuItem.Image = global::Homework.Properties.Resources.Owner;
            this.таблицаПерсонToolStripMenuItem.Name = "таблицаПерсонToolStripMenuItem";
            this.таблицаПерсонToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаПерсонToolStripMenuItem.Text = "Таблица персон";
            this.таблицаПерсонToolStripMenuItem.Click += new System.EventHandler(this.ShowPersons_Command);
            // 
            // таблицаПродавцовToolStripMenuItem
            // 
            this.таблицаПродавцовToolStripMenuItem.Image = global::Homework.Properties.Resources.seller;
            this.таблицаПродавцовToolStripMenuItem.Name = "таблицаПродавцовToolStripMenuItem";
            this.таблицаПродавцовToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаПродавцовToolStripMenuItem.Text = "Таблица продавцов";
            this.таблицаПродавцовToolStripMenuItem.Click += new System.EventHandler(this.ShowSellers_Command);
            // 
            // таблицаТоваровToolStripMenuItem
            // 
            this.таблицаТоваровToolStripMenuItem.Image = global::Homework.Properties.Resources.Select;
            this.таблицаТоваровToolStripMenuItem.Name = "таблицаТоваровToolStripMenuItem";
            this.таблицаТоваровToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаТоваровToolStripMenuItem.Text = "Таблица товаров";
            this.таблицаТоваровToolStripMenuItem.Click += new System.EventHandler(this.ShowGoods_Command);
            // 
            // таблицаЗакупокToolStripMenuItem
            // 
            this.таблицаЗакупокToolStripMenuItem.Image = global::Homework.Properties.Resources.purchase;
            this.таблицаЗакупокToolStripMenuItem.Name = "таблицаЗакупокToolStripMenuItem";
            this.таблицаЗакупокToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаЗакупокToolStripMenuItem.Text = "Таблица закупок";
            this.таблицаЗакупокToolStripMenuItem.Click += new System.EventHandler(this.ShowPurchases_Command);
            // 
            // таблицаПродажToolStripMenuItem
            // 
            this.таблицаПродажToolStripMenuItem.Image = global::Homework.Properties.Resources.sale;
            this.таблицаПродажToolStripMenuItem.Name = "таблицаПродажToolStripMenuItem";
            this.таблицаПродажToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаПродажToolStripMenuItem.Text = "Таблица продаж";
            this.таблицаПродажToolStripMenuItem.Click += new System.EventHandler(this.ShowSales_Command);
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запрос1ToolStripMenuItem,
            this.запросToolStripMenuItem});
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(84, 24);
            this.запросыToolStripMenuItem.Text = "Запросы";
            // 
            // запрос1ToolStripMenuItem
            // 
            this.запрос1ToolStripMenuItem.Image = global::Homework.Properties.Resources._1;
            this.запрос1ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос1ToolStripMenuItem.Name = "запрос1ToolStripMenuItem";
            this.запрос1ToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запрос1ToolStripMenuItem.Text = "Запрос №1";
            this.запрос1ToolStripMenuItem.Click += new System.EventHandler(this.Query01_Command);
            // 
            // запросToolStripMenuItem
            // 
            this.запросToolStripMenuItem.Image = global::Homework.Properties.Resources._2;
            this.запросToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запросToolStripMenuItem.Name = "запросToolStripMenuItem";
            this.запросToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запросToolStripMenuItem.Text = "Запрос №2";
            this.запросToolStripMenuItem.Click += new System.EventHandler(this.Query02_Command);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::Homework.Properties.Resources.help;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.оПрограммеToolStripMenuItem.Text = "О программе...";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton13,
            this.toolStripButton11,
            this.toolStripButton15,
            this.toolStripButton12,
            this.toolStripButton14,
            this.toolStripButton16,
            this.toolStripSeparator2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator1,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton9,
            this.toolStripButton10});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(862, 39);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = global::Homework.Properties.Resources.box;
            this.toolStripButton13.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton13.Text = "toolStripButton13";
            this.toolStripButton13.ToolTipText = "Вывести таблицу единиц измерения\r\n";
            this.toolStripButton13.Click += new System.EventHandler(this.ShowUnits_Command);
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = global::Homework.Properties.Resources.Owner;
            this.toolStripButton11.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.Size = new System.Drawing.Size(34, 36);
            this.toolStripButton11.Text = "toolStripButton11";
            this.toolStripButton11.ToolTipText = "Вывести таблицу персон";
            this.toolStripButton11.Click += new System.EventHandler(this.ShowPersons_Command);
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton15.Image = global::Homework.Properties.Resources.seller;
            this.toolStripButton15.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton15.Text = "toolStripButton15";
            this.toolStripButton15.ToolTipText = "Вывести таблицу продавцов";
            this.toolStripButton15.Click += new System.EventHandler(this.ShowSellers_Command);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = global::Homework.Properties.Resources.Select;
            this.toolStripButton12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.Size = new System.Drawing.Size(34, 36);
            this.toolStripButton12.Text = "toolStripButton12";
            this.toolStripButton12.ToolTipText = "Вывести таблицу товаров";
            this.toolStripButton12.Click += new System.EventHandler(this.ShowGoods_Command);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = global::Homework.Properties.Resources.purchase;
            this.toolStripButton14.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton14.Text = "toolStripButton14";
            this.toolStripButton14.ToolTipText = "Вывести таблицу закупок\r\n";
            this.toolStripButton14.Click += new System.EventHandler(this.ShowPurchases_Command);
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton16.Image = global::Homework.Properties.Resources.sale;
            this.toolStripButton16.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton16.Text = "toolStripButton16";
            this.toolStripButton16.ToolTipText = "Вывевсти таблицу продаж";
            this.toolStripButton16.Click += new System.EventHandler(this.ShowSales_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::Homework.Properties.Resources.add;
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.ToolTipText = "Добавить товар";
            this.toolStripButton3.Click += new System.EventHandler(this.AddGoods_Command);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::Homework.Properties.Resources.edit_button;
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.ToolTipText = "Редактировать товар";
            this.toolStripButton4.Click += new System.EventHandler(this.EditGoods_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::Homework.Properties.Resources._1;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Запрос №1.\r\nКоличество и суммы продаж продавцов\r\n";
            this.toolStripButton1.Click += new System.EventHandler(this.Query01_Command);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::Homework.Properties.Resources._2;
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Запрос №2.\r\nКоличество и суммы продаж всех товаров\r\n";
            this.toolStripButton2.Click += new System.EventHandler(this.Query02_Command);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = global::Homework.Properties.Resources.exit;
            this.toolStripButton9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(34, 36);
            this.toolStripButton9.Text = "toolStripButton9";
            this.toolStripButton9.ToolTipText = "Выход";
            this.toolStripButton9.Click += new System.EventHandler(this.Exit_Command);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = global::Homework.Properties.Resources.help;
            this.toolStripButton10.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton10.Text = "toolStripButton10";
            this.toolStripButton10.ToolTipText = "О программе...";
            this.toolStripButton10.Click += new System.EventHandler(this.About_Command);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpMain);
            this.TbcMain.Controls.Add(this.TbpQuery01);
            this.TbcMain.Controls.Add(this.TbpQuery02);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Location = new System.Drawing.Point(0, 67);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(862, 511);
            this.TbcMain.TabIndex = 2;
            // 
            // TbpMain
            // 
            this.TbpMain.Controls.Add(this.DgvGoods);
            this.TbpMain.Controls.Add(this.DgvPersons);
            this.TbpMain.Controls.Add(this.DgvSales);
            this.TbpMain.Controls.Add(this.DgvSellers);
            this.TbpMain.Controls.Add(this.DgvPurchases);
            this.TbpMain.Controls.Add(this.DgvUnits);
            this.TbpMain.Controls.Add(this.LblMain);
            this.TbpMain.Location = new System.Drawing.Point(4, 31);
            this.TbpMain.Name = "TbpMain";
            this.TbpMain.Padding = new System.Windows.Forms.Padding(3);
            this.TbpMain.Size = new System.Drawing.Size(854, 476);
            this.TbpMain.TabIndex = 0;
            this.TbpMain.Text = "Главная";
            this.TbpMain.UseVisualStyleBackColor = true;
            // 
            // DgvGoods
            // 
            this.DgvGoods.AllowUserToAddRows = false;
            this.DgvGoods.AllowUserToDeleteRows = false;
            this.DgvGoods.AutoGenerateColumns = false;
            this.DgvGoods.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvGoods.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn4,
            this.itemDataGridViewTextBoxColumn});
            this.DgvGoods.DataSource = this.goodsBindingSource;
            this.DgvGoods.Location = new System.Drawing.Point(3, 32);
            this.DgvGoods.MultiSelect = false;
            this.DgvGoods.Name = "DgvGoods";
            this.DgvGoods.ReadOnly = true;
            this.DgvGoods.RowHeadersVisible = false;
            this.DgvGoods.RowHeadersWidth = 51;
            this.DgvGoods.RowTemplate.Height = 24;
            this.DgvGoods.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvGoods.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvGoods.Size = new System.Drawing.Size(848, 440);
            this.DgvGoods.TabIndex = 4;
            this.DgvGoods.Visible = false;
            // 
            // idDataGridViewTextBoxColumn4
            // 
            this.idDataGridViewTextBoxColumn4.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn4.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn4.Name = "idDataGridViewTextBoxColumn4";
            this.idDataGridViewTextBoxColumn4.ReadOnly = true;
            this.idDataGridViewTextBoxColumn4.Width = 125;
            // 
            // itemDataGridViewTextBoxColumn
            // 
            this.itemDataGridViewTextBoxColumn.DataPropertyName = "Item";
            this.itemDataGridViewTextBoxColumn.HeaderText = "Наименование товара";
            this.itemDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.itemDataGridViewTextBoxColumn.Name = "itemDataGridViewTextBoxColumn";
            this.itemDataGridViewTextBoxColumn.ReadOnly = true;
            this.itemDataGridViewTextBoxColumn.Width = 750;
            // 
            // goodsBindingSource
            // 
            this.goodsBindingSource.DataSource = typeof(Homework.Models.Goods);
            // 
            // DgvPersons
            // 
            this.DgvPersons.AllowUserToAddRows = false;
            this.DgvPersons.AllowUserToDeleteRows = false;
            this.DgvPersons.AutoGenerateColumns = false;
            this.DgvPersons.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvPersons.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.surnameDataGridViewTextBoxColumn1,
            this.nameDataGridViewTextBoxColumn1,
            this.patronymicDataGridViewTextBoxColumn1,
            this.passportDataGridViewTextBoxColumn});
            this.DgvPersons.DataSource = this.personsBindingSource;
            this.DgvPersons.Location = new System.Drawing.Point(3, 33);
            this.DgvPersons.MultiSelect = false;
            this.DgvPersons.Name = "DgvPersons";
            this.DgvPersons.ReadOnly = true;
            this.DgvPersons.RowHeadersVisible = false;
            this.DgvPersons.RowHeadersWidth = 51;
            this.DgvPersons.RowTemplate.Height = 24;
            this.DgvPersons.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvPersons.Size = new System.Drawing.Size(848, 440);
            this.DgvPersons.TabIndex = 3;
            this.DgvPersons.Visible = false;
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn3.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            this.idDataGridViewTextBoxColumn3.ReadOnly = true;
            this.idDataGridViewTextBoxColumn3.Width = 125;
            // 
            // surnameDataGridViewTextBoxColumn1
            // 
            this.surnameDataGridViewTextBoxColumn1.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn1.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.surnameDataGridViewTextBoxColumn1.Name = "surnameDataGridViewTextBoxColumn1";
            this.surnameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.surnameDataGridViewTextBoxColumn1.Width = 170;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "Имя";
            this.nameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            this.nameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn1.Width = 170;
            // 
            // patronymicDataGridViewTextBoxColumn1
            // 
            this.patronymicDataGridViewTextBoxColumn1.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn1.HeaderText = "Отчество";
            this.patronymicDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.patronymicDataGridViewTextBoxColumn1.Name = "patronymicDataGridViewTextBoxColumn1";
            this.patronymicDataGridViewTextBoxColumn1.ReadOnly = true;
            this.patronymicDataGridViewTextBoxColumn1.Width = 170;
            // 
            // passportDataGridViewTextBoxColumn
            // 
            this.passportDataGridViewTextBoxColumn.DataPropertyName = "Passport";
            this.passportDataGridViewTextBoxColumn.HeaderText = "Серия и номер паспорта";
            this.passportDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passportDataGridViewTextBoxColumn.Name = "passportDataGridViewTextBoxColumn";
            this.passportDataGridViewTextBoxColumn.ReadOnly = true;
            this.passportDataGridViewTextBoxColumn.Width = 250;
            // 
            // personsBindingSource
            // 
            this.personsBindingSource.DataSource = typeof(Homework.Models.Persons);
            // 
            // DgvSales
            // 
            this.DgvSales.AllowUserToAddRows = false;
            this.DgvSales.AllowUserToDeleteRows = false;
            this.DgvSales.AutoGenerateColumns = false;
            this.DgvSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31});
            this.DgvSales.DataSource = this.saleBindingSource;
            this.DgvSales.Location = new System.Drawing.Point(3, 31);
            this.DgvSales.MultiSelect = false;
            this.DgvSales.Name = "DgvSales";
            this.DgvSales.ReadOnly = true;
            this.DgvSales.RowHeadersVisible = false;
            this.DgvSales.RowHeadersWidth = 51;
            this.DgvSales.RowTemplate.Height = 24;
            this.DgvSales.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvSales.Size = new System.Drawing.Size(854, 440);
            this.DgvSales.TabIndex = 8;
            this.DgvSales.Visible = false;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn24.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn24.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Width = 40;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Good";
            this.dataGridViewTextBoxColumn25.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn25.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 125;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn26.HeaderText = "Единица изм.";
            this.dataGridViewTextBoxColumn26.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Width = 125;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Seller";
            this.dataGridViewTextBoxColumn27.HeaderText = "Продавец";
            this.dataGridViewTextBoxColumn27.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Width = 150;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "SaleDate";
            this.dataGridViewTextBoxColumn28.HeaderText = "Дата продажи";
            this.dataGridViewTextBoxColumn28.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Width = 125;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "SalePrice";
            this.dataGridViewTextBoxColumn29.HeaderText = "Цена продажи";
            this.dataGridViewTextBoxColumn29.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Width = 125;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "PurchasePrice";
            this.dataGridViewTextBoxColumn30.HeaderText = "Цена закупки";
            this.dataGridViewTextBoxColumn30.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Width = 125;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn31.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn31.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Width = 120;
            // 
            // saleBindingSource
            // 
            this.saleBindingSource.DataSource = typeof(Homework.Models.Sale);
            // 
            // DgvSellers
            // 
            this.DgvSellers.AllowUserToAddRows = false;
            this.DgvSellers.AllowUserToDeleteRows = false;
            this.DgvSellers.AutoGenerateColumns = false;
            this.DgvSellers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSellers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23});
            this.DgvSellers.DataSource = this.sellerBindingSource;
            this.DgvSellers.Location = new System.Drawing.Point(3, 31);
            this.DgvSellers.MultiSelect = false;
            this.DgvSellers.Name = "DgvSellers";
            this.DgvSellers.ReadOnly = true;
            this.DgvSellers.RowHeadersVisible = false;
            this.DgvSellers.RowHeadersWidth = 51;
            this.DgvSellers.RowTemplate.Height = 24;
            this.DgvSellers.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvSellers.Size = new System.Drawing.Size(854, 440);
            this.DgvSellers.TabIndex = 7;
            this.DgvSellers.Visible = false;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn19.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn19.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 50;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn20.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn20.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 200;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn21.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn21.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 200;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Patronymic";
            this.dataGridViewTextBoxColumn22.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn22.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 200;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Interest";
            this.dataGridViewTextBoxColumn23.HeaderText = "Процент комиссионных";
            this.dataGridViewTextBoxColumn23.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 200;
            // 
            // sellerBindingSource
            // 
            this.sellerBindingSource.DataSource = typeof(Homework.Models.Seller);
            // 
            // DgvPurchases
            // 
            this.DgvPurchases.AllowUserToAddRows = false;
            this.DgvPurchases.AllowUserToDeleteRows = false;
            this.DgvPurchases.AutoGenerateColumns = false;
            this.DgvPurchases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvPurchases.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.DgvPurchases.DataSource = this.purchaseBindingSource;
            this.DgvPurchases.Location = new System.Drawing.Point(3, 31);
            this.DgvPurchases.MultiSelect = false;
            this.DgvPurchases.Name = "DgvPurchases";
            this.DgvPurchases.ReadOnly = true;
            this.DgvPurchases.RowHeadersVisible = false;
            this.DgvPurchases.RowHeadersWidth = 51;
            this.DgvPurchases.RowTemplate.Height = 24;
            this.DgvPurchases.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvPurchases.Size = new System.Drawing.Size(854, 440);
            this.DgvPurchases.TabIndex = 6;
            this.DgvPurchases.Visible = false;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn13.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 50;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Good";
            this.dataGridViewTextBoxColumn14.FillWeight = 200F;
            this.dataGridViewTextBoxColumn14.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 220;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn15.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 125;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "PurchaseDate";
            this.dataGridViewTextBoxColumn16.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn16.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 125;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn17.HeaderText = "Цена за единицу товара";
            this.dataGridViewTextBoxColumn17.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 200;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn18.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn18.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 125;
            // 
            // purchaseBindingSource
            // 
            this.purchaseBindingSource.DataSource = typeof(Homework.Models.Purchase);
            // 
            // DgvUnits
            // 
            this.DgvUnits.AllowUserToAddRows = false;
            this.DgvUnits.AllowUserToDeleteRows = false;
            this.DgvUnits.AutoGenerateColumns = false;
            this.DgvUnits.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvUnits.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn5,
            this.shortDataGridViewTextBoxColumn,
            this.longDataGridViewTextBoxColumn});
            this.DgvUnits.DataSource = this.unitsBindingSource;
            this.DgvUnits.Location = new System.Drawing.Point(3, 32);
            this.DgvUnits.MultiSelect = false;
            this.DgvUnits.Name = "DgvUnits";
            this.DgvUnits.ReadOnly = true;
            this.DgvUnits.RowHeadersVisible = false;
            this.DgvUnits.RowHeadersWidth = 51;
            this.DgvUnits.RowTemplate.Height = 24;
            this.DgvUnits.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvUnits.Size = new System.Drawing.Size(848, 440);
            this.DgvUnits.TabIndex = 5;
            this.DgvUnits.Visible = false;
            // 
            // idDataGridViewTextBoxColumn5
            // 
            this.idDataGridViewTextBoxColumn5.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn5.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn5.Name = "idDataGridViewTextBoxColumn5";
            this.idDataGridViewTextBoxColumn5.ReadOnly = true;
            this.idDataGridViewTextBoxColumn5.Width = 125;
            // 
            // shortDataGridViewTextBoxColumn
            // 
            this.shortDataGridViewTextBoxColumn.DataPropertyName = "Short";
            this.shortDataGridViewTextBoxColumn.HeaderText = "Сокращенное наименование";
            this.shortDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.shortDataGridViewTextBoxColumn.Name = "shortDataGridViewTextBoxColumn";
            this.shortDataGridViewTextBoxColumn.ReadOnly = true;
            this.shortDataGridViewTextBoxColumn.Width = 300;
            // 
            // longDataGridViewTextBoxColumn
            // 
            this.longDataGridViewTextBoxColumn.DataPropertyName = "Long";
            this.longDataGridViewTextBoxColumn.HeaderText = "Полное наименование";
            this.longDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.longDataGridViewTextBoxColumn.Name = "longDataGridViewTextBoxColumn";
            this.longDataGridViewTextBoxColumn.ReadOnly = true;
            this.longDataGridViewTextBoxColumn.Width = 450;
            // 
            // unitsBindingSource
            // 
            this.unitsBindingSource.DataSource = typeof(Homework.Models.Units);
            // 
            // LblMain
            // 
            this.LblMain.Location = new System.Drawing.Point(2, 3);
            this.LblMain.Name = "LblMain";
            this.LblMain.Size = new System.Drawing.Size(851, 41);
            this.LblMain.TabIndex = 2;
            // 
            // TbpQuery01
            // 
            this.TbpQuery01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.TbpQuery01.Controls.Add(this.DgvQuery01);
            this.TbpQuery01.Controls.Add(this.LblQuery01);
            this.TbpQuery01.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery01.Name = "TbpQuery01";
            this.TbpQuery01.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery01.Size = new System.Drawing.Size(854, 480);
            this.TbpQuery01.TabIndex = 1;
            this.TbpQuery01.Text = "Запрос №1";
            this.TbpQuery01.UseVisualStyleBackColor = true;
            // 
            // DgvQuery01
            // 
            this.DgvQuery01.AllowUserToAddRows = false;
            this.DgvQuery01.AllowUserToDeleteRows = false;
            this.DgvQuery01.AutoGenerateColumns = false;
            this.DgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery01.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.titleDataGridViewTextBoxColumn,
            this.salesAmountDataGridViewTextBoxColumn,
            this.salesTotalDataGridViewTextBoxColumn});
            this.DgvQuery01.DataSource = this.queryViewModelBindingSource;
            this.DgvQuery01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery01.Location = new System.Drawing.Point(3, 37);
            this.DgvQuery01.MultiSelect = false;
            this.DgvQuery01.Name = "DgvQuery01";
            this.DgvQuery01.ReadOnly = true;
            this.DgvQuery01.RowHeadersVisible = false;
            this.DgvQuery01.RowHeadersWidth = 51;
            this.DgvQuery01.RowTemplate.Height = 24;
            this.DgvQuery01.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery01.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvQuery01.Size = new System.Drawing.Size(848, 440);
            this.DgvQuery01.TabIndex = 1;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 125;
            // 
            // titleDataGridViewTextBoxColumn
            // 
            this.titleDataGridViewTextBoxColumn.DataPropertyName = "Title";
            this.titleDataGridViewTextBoxColumn.HeaderText = "Продавец";
            this.titleDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            this.titleDataGridViewTextBoxColumn.ReadOnly = true;
            this.titleDataGridViewTextBoxColumn.Width = 320;
            // 
            // salesAmountDataGridViewTextBoxColumn
            // 
            this.salesAmountDataGridViewTextBoxColumn.DataPropertyName = "SalesAmount";
            this.salesAmountDataGridViewTextBoxColumn.HeaderText = "Количество продаж";
            this.salesAmountDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.salesAmountDataGridViewTextBoxColumn.Name = "salesAmountDataGridViewTextBoxColumn";
            this.salesAmountDataGridViewTextBoxColumn.ReadOnly = true;
            this.salesAmountDataGridViewTextBoxColumn.Width = 200;
            // 
            // salesTotalDataGridViewTextBoxColumn
            // 
            this.salesTotalDataGridViewTextBoxColumn.DataPropertyName = "SalesTotal";
            this.salesTotalDataGridViewTextBoxColumn.HeaderText = "Сумма продаж";
            this.salesTotalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.salesTotalDataGridViewTextBoxColumn.Name = "salesTotalDataGridViewTextBoxColumn";
            this.salesTotalDataGridViewTextBoxColumn.ReadOnly = true;
            this.salesTotalDataGridViewTextBoxColumn.Width = 200;
            // 
            // queryViewModelBindingSource
            // 
            this.queryViewModelBindingSource.DataSource = typeof(Homework.Models.QueryViewModel);
            // 
            // LblQuery01
            // 
            this.LblQuery01.Location = new System.Drawing.Point(3, 3);
            this.LblQuery01.Name = "LblQuery01";
            this.LblQuery01.Size = new System.Drawing.Size(851, 41);
            this.LblQuery01.TabIndex = 0;
            // 
            // TbpQuery02
            // 
            this.TbpQuery02.Controls.Add(this.DgvQuery02);
            this.TbpQuery02.Controls.Add(this.LblQuery02);
            this.TbpQuery02.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery02.Name = "TbpQuery02";
            this.TbpQuery02.Size = new System.Drawing.Size(854, 480);
            this.TbpQuery02.TabIndex = 2;
            this.TbpQuery02.Text = "Запрос №2";
            this.TbpQuery02.UseVisualStyleBackColor = true;
            // 
            // DgvQuery02
            // 
            this.DgvQuery02.AllowUserToAddRows = false;
            this.DgvQuery02.AllowUserToDeleteRows = false;
            this.DgvQuery02.AutoGenerateColumns = false;
            this.DgvQuery02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery02.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.titleDataGridViewTextBoxColumn1,
            this.salesAmountDataGridViewTextBoxColumn1,
            this.salesTotalDataGridViewTextBoxColumn1});
            this.DgvQuery02.DataSource = this.queryViewModelBindingSource;
            this.DgvQuery02.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery02.Location = new System.Drawing.Point(0, 40);
            this.DgvQuery02.MultiSelect = false;
            this.DgvQuery02.Name = "DgvQuery02";
            this.DgvQuery02.ReadOnly = true;
            this.DgvQuery02.RowHeadersVisible = false;
            this.DgvQuery02.RowHeadersWidth = 51;
            this.DgvQuery02.RowTemplate.Height = 24;
            this.DgvQuery02.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery02.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery02.TabIndex = 3;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idDataGridViewTextBoxColumn1.Width = 125;
            // 
            // titleDataGridViewTextBoxColumn1
            // 
            this.titleDataGridViewTextBoxColumn1.DataPropertyName = "Title";
            this.titleDataGridViewTextBoxColumn1.HeaderText = "Наименование товара";
            this.titleDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.titleDataGridViewTextBoxColumn1.Name = "titleDataGridViewTextBoxColumn1";
            this.titleDataGridViewTextBoxColumn1.ReadOnly = true;
            this.titleDataGridViewTextBoxColumn1.Width = 320;
            // 
            // salesAmountDataGridViewTextBoxColumn1
            // 
            this.salesAmountDataGridViewTextBoxColumn1.DataPropertyName = "SalesAmount";
            this.salesAmountDataGridViewTextBoxColumn1.HeaderText = "Количество продаж";
            this.salesAmountDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.salesAmountDataGridViewTextBoxColumn1.Name = "salesAmountDataGridViewTextBoxColumn1";
            this.salesAmountDataGridViewTextBoxColumn1.ReadOnly = true;
            this.salesAmountDataGridViewTextBoxColumn1.Width = 200;
            // 
            // salesTotalDataGridViewTextBoxColumn1
            // 
            this.salesTotalDataGridViewTextBoxColumn1.DataPropertyName = "SalesTotal";
            this.salesTotalDataGridViewTextBoxColumn1.HeaderText = "Сумма продаж";
            this.salesTotalDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.salesTotalDataGridViewTextBoxColumn1.Name = "salesTotalDataGridViewTextBoxColumn1";
            this.salesTotalDataGridViewTextBoxColumn1.ReadOnly = true;
            this.salesTotalDataGridViewTextBoxColumn1.Width = 200;
            // 
            // LblQuery02
            // 
            this.LblQuery02.Location = new System.Drawing.Point(3, 2);
            this.LblQuery02.Name = "LblQuery02";
            this.LblQuery02.Size = new System.Drawing.Size(786, 41);
            this.LblQuery02.TabIndex = 2;
            this.LblQuery02.Text = "Количество и суммы продаж всех товаров\r\n";
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(862, 578);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 27.01.2022";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvGoods)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPersons)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSales)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSellers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPurchases)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvUnits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitsBindingSource)).EndInit();
            this.TbpQuery01.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queryViewModelBindingSource)).EndInit();
            this.TbpQuery02.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery06BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery07and08BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpMain;
        private System.Windows.Forms.TabPage TbpQuery01;
        private System.Windows.Forms.Label LblQuery01;
        private System.Windows.Forms.DataGridView DgvQuery01;
        private System.Windows.Forms.BindingSource purchaseBindingSource;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.TabPage TbpQuery02;
        private System.Windows.Forms.DataGridView DgvQuery02;
        private System.Windows.Forms.Label LblQuery02;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripMenuItem запрос1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросToolStripMenuItem;
        private System.Windows.Forms.BindingSource sellerBindingSource;
        private System.Windows.Forms.BindingSource saleBindingSource;
        private System.Windows.Forms.BindingSource resultQuery06BindingSource;
        private System.Windows.Forms.BindingSource resultQuery07and08BindingSource;
        private System.Windows.Forms.DataGridView DgvPersons;
        private System.Windows.Forms.BindingSource personsBindingSource;
        private System.Windows.Forms.Label LblMain;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.DataGridView DgvGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource goodsBindingSource;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.DataGridView DgvUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn longDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource unitsBindingSource;
        private System.Windows.Forms.DataGridView DgvPurchases;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.DataGridView DgvSellers;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.DataGridView DgvSales;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.ToolStripMenuItem таблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаЕдиницИзмеренияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаПерсонToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаПродавцовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаТоваровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаЗакупокToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаПродажToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.BindingSource queryViewModelBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salesAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salesTotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn salesAmountDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn salesTotalDataGridViewTextBoxColumn1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
    }
}

