﻿/* База данных «Оптовый магазин. Учет продаж»  */

-- справочник единиц измерения
select
   *
from
    Units;
go

-- справочник номенклатуры товаров
select
    *
from
    Goods;
go


-- персональные данные
select
    *
from
    Persons;
go

-- продавцы
select
   Sellers.Id
   , Persons.Surname
   , Persons.[Name]
   , Persons.Patronymic
   , Sellers.Interest
from
    Sellers join Persons on Sellers.IdPerson = Persons.Id;
go

-- закупки товаров 
select
    Purchases.Id
    , Goods.Item
    , Units.Short
    , Purchases.PurchaseDate
    , Purchases.Price
    , Purchases.Amount
from
    Purchases join Goods on Purchases.IdItem = Goods.Id
              join Units on Purchases.IdUnit = Units.Id;
go

-- факты продаж
select
    Sales.Id
    , Goods.Item
    , Units.Short
    , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
    , Sales.SaleDate
    , Purchases.Price   as PurchasePrice
    , Sales.Price       as SalePrice
    , Sales.Amount
from
    Sales join (Sellers join Persons on Sellers.IdPerson = Persons.Id) on Sales.IdSeller = Sellers.IdPerson
          join (Purchases join Goods on Purchases.IdItem = Goods.Id) on Sales.IdPurchase = Purchases.Id
          join Units on Sales.IdUnit = Units.Id;
go

-- запросы по заданию


-- Запрос  1. Запрос на левое соединение	
-- Выбирает всех продавцов (выводить Код продавца, фамилию и инициалы 
-- продавца), количество и суммы их продаж за заданный период, упорядочивать 
-- по фамилиям и инициалам
declare @from date = '11-01-2021', @to date = '11-30-2021';
select
   Sellers.Id
   , Persons.Surname + N' ' + Substring(Persons.[Name], 1, 1) + N'.' + Substring(Persons.Patronymic, 1, 1) + N'.' as Seller
   , Sellers.Interest
   , count(PeriodSales.IdSeller)                               as SalesAmount
   , isnull(sum(PeriodSales.Price*PeriodSales.Amount), 0)      as SalesTotal
from
    (Sellers join Persons on Sellers.IdPerson = Persons.Id)
    left join
    -- продажи за заданный период
    (select IdSeller, IdPurchase, Price, Amount from Sales where SaleDate between @from and @to) PeriodSales
    on Sellers.Id = PeriodSales.IdSeller 
group by
    Sellers.Id, Persons.Surname, Persons.[Name], Persons.Patronymic, Sellers.Interest
order by
    Seller;
go


-- Запрос  2. Запрос на левое соединение	
-- Выбирает все товары, количество и сумму продаж по этим товарам. 
-- Упорядочивать по убыванию суммы продаж
select
    Goods.Id
    , Goods.Item
    , count(Sales.IdUnit)                         as SalesAmount
    , isNull(sum(Sales.Price*Sales.Amount), 0)    as SalesTotal
from
    Goods left join (Sales join Purchases on Sales.IdPurchase = Purchases.Id) 
        on Goods.Id = Purchases.IdUnit
group by
    Goods.Id, Goods.Item
order by
    SalesTotal desc;
go