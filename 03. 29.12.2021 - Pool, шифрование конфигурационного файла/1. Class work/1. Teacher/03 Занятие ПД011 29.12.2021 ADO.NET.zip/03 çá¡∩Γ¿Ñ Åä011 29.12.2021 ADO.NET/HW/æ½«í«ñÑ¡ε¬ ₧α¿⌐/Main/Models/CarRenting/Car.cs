﻿using Main.Utilities.TableFormatter;


namespace Main.Models.CarRenting
{
	public class Car
	{
		[TableData("Номер", "{0, -10}")]
		public string? LicenseNumber { get; set; }

		[TableData("Модель", "{0, -25}")]
		public string? Model { get; set; }

		[TableData("Бренд", "{0, -20}")]
		public string? Brand { get; set; }

		[TableData("Цвет", "{0, -10}")]
		public string? Color { get; set; }

		[TableData("Цена за день", "{0, -14:F0}")]
		public decimal PriceForDay { get; set; }

		[TableData("Страховка", "{0, -14:F0}")]
		public decimal InsurancePayment { get; set; }

		[TableData("Год", "{0, -7:F0}")]
		public decimal ProductionYear { get; set; }
	}
}