﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;

using ADO_NET_Procedures.Utilities;
using ADO_NET_Procedures.Application;


namespace ADO_NET_Procedures
{
    public class Program
    {
        static void Main(string[] args)
        {
            App app = new App();
            app.ShowMenu("Задание на 29.12.21");

        }


       
    }
}
