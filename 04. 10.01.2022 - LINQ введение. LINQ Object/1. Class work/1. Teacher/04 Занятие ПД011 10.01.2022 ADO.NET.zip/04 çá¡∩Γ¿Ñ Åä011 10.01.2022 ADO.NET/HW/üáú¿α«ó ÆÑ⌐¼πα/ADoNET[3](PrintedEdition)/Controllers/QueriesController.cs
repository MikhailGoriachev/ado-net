﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// для работы с технологией ADO.NET
using System.Configuration;   // добавить сборку System.Configuration.dll
using System.Data;
using System.Data.SqlClient;

using ADoNET_3__PrintedEdition_.Models;

namespace ADoNET_3__PrintedEdition_.Controllers
{
    public class QueriesController {

        private string _connectingString;
        public string ConnectingString{
            get => _connectingString;
            set => _connectingString = string.IsNullOrWhiteSpace(value)
                ? throw new Exception("Строка подключения к базе данных не указана") : value;
        }

        private List<Edition> _editions = new List<Edition>();     // Список изданий
        private List<Subscriber> _subscribers = new List<Subscriber>(); //  Список подписчиков

        public QueriesController() : this(ConfigurationManager.ConnectionStrings["PeriodicalsConnectionSQLServer"].ConnectionString ) { }

        public QueriesController(string connectingString) => ConnectingString = connectingString;

        // Процедура №1	
        // Выбирает из таблицы ИЗДАНИЯ информацию 
        // о доступных для подписки изданиях заданного типа, 
        // стоимость 1 экземпляра для которых меньше заданной.
        public List<Edition> Query1(string type, float hiPrice){
            // Очищаем список изданий от данных 
            _editions.Clear();

            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("\n\n\n\tЗапрос 1.\n" +
                                $"\tИздания типа {type}, стоимость 1 экземпляра меньше {hiPrice}\n");
            
            Console.ForegroundColor = oldColor;
            
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc1");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@type", type);
                cmd.Parameters.AddWithValue("@hiPrice", hiPrice);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Читаем пока читается
                while (reader.Read()) {
                    _editions.Add(new Edition
                        (reader.GetInt32(0), reader.GetString(1), reader.GetString(2), 
                        reader.GetString(3), reader.GetDouble(4)));
                } // while
            } // using
            return _editions;
        } // Query1


        //			-> Запрос №2 [Запрос с параметром] <-
        // Выбирает из таблиц информацию о подписчиках,
        // проживающих на заданной параметром улице и номере дома,
        // которые оформили подписку на издание с заданным параметром наименованием
        public List<Subscriber> Query2(string street, string houseNum, string name)
        {
            // Очищаем список подписчиков от данных 
            _editions.Clear();

            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("\n\n\n\tЗапрос 2.\n" +
                                $"\tПодписчике живущие на улице {street} в {houseNum}\n" +
                                $"\tоформившие подписку на издание {name}");

            Console.ForegroundColor = oldColor;

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc2");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@street", street);
                cmd.Parameters.AddWithValue("@houseNum", houseNum);
                cmd.Parameters.AddWithValue("@name", name);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Читаем пока читается
                while (reader.Read())
                {
                    _subscribers.Add(new Subscriber
                        (reader.GetInt32(0), reader.GetString(1), reader.GetString(2),
                        reader.GetString(3), reader.GetInt32(4), reader.GetString(5),
                        reader.GetString(6), reader.GetString(7), reader.GetDateTime(8),
                        reader.GetInt32(9), reader.GetString(10), reader.GetString(11)));
                } // while
            } // using
            return _subscribers;
        } // Query2


        //			-> Запрос №3 [Запрос с параметром] <-
        // Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, 
        // для которых значение в поле Цена 1 экземпляра 
        // находится в заданном диапазоне значений
        public List<Edition> Query3(int loPrice, int hiPrice)
        {
            // Очищаем список изданий от данных 
            _editions.Clear();

            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;
            
            Console.WriteLine("\n\n\n\tЗапрос 3.\n" +
                                $"\tИздания цена которых находится в диапозоне от {loPrice} до {hiPrice}\n");
            
            Console.ForegroundColor = oldColor;
            
            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc3");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@loPrice", loPrice);
                cmd.Parameters.AddWithValue("@hiPrice", hiPrice);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Читаем пока читается
                while (reader.Read()) {
                    _editions.Add(new Edition
                        (reader.GetInt32(0), reader.GetString(1), reader.GetString(2),
                        reader.GetString(3), reader.GetDouble(4)));
                } // if
            } // using
            return _editions;

        } // Query3

        //			-> Запрос №4 [Запрос с параметром] <-
        // Выбирает из таблиц информацию о подписчиках, 
        // подписавшихся на заданный параметром тип издания
        public List<Subscriber> Query4(string type)
        {
            // Очищаем список подписчиков от данных 
            _editions.Clear();

            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("\n\n\n\n\tЗапрос 4.\n" +
                              $"\tИнформация о подписчиках подписавшихся на тип издания {type}\n");

            Console.ForegroundColor = oldColor;

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc4");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@type", type); 

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                // Читаем пока читается
                while (reader.Read())
                {
                    _subscribers.Add(new Subscriber
                        (reader.GetInt32(0), reader.GetString(1), reader.GetString(2),
                        reader.GetString(3), reader.GetInt32(4), reader.GetString(5),
                        reader.GetString(6), reader.GetString(7), reader.GetDateTime(8),
                        reader.GetInt32(9), reader.GetString(10), reader.GetString(11)));
                } // while
            } // using
            return _subscribers;
        } // Query4

        //			-> Запрос №5 [Запрос с параметром] <-
        // Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА 
        // информацию обо всех оформленных подписках,
        // для которых срок подписки есть значение из некоторого диапазона.
        // Нижняя и верхняя границы диапазона задаются при выполнении запроса
        public void Query5(int loSubDuration, int hiSubDuration)
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("\n\n\n\n\tЗапрос 5.\n" +
                              $"\tПодписки со сроком от {loSubDuration} до {hiSubDuration} месяцев\n");

            Console.ForegroundColor = oldColor;

            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc5");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@loSubDuration", loSubDuration);
                cmd.Parameters.AddWithValue("@hiSubDuration", hiSubDuration);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                Console.WriteLine(
                    "\t┌────┬─────────────┬─────────────┬───────────────┬──────────┬───────────────┬─────────────────────────────────────┬──────────────┬───────────────┬────────┐\n" +
                    "\t│ Id │   Фамилия   │     Имя     │   Отчество    │ Индекс   │    Тип        │            Название                 │    Цена      │     Дата      │  Срок  │\n" +
                    "\t│    │             │             │               │  издания │      издания  │                 издания             │ 1 экземпляра │начала подписки│подписки│\n" +
                    "\t├────┼─────────────┼─────────────┼───────────────┼──────────┼───────────────┼─────────────────────────────────────┼──────────────┼───────────────┼────────┤");

                // Читаем пока читается
                while (reader.Read())
                {
                    Console.WriteLine($"\t│ {reader.GetInt32(0),2} │ {reader.GetString(1),-11} │ {reader.GetString(2),-11} │" +
                        $" {reader.GetString(3),-13} │ {reader.GetString(4),-8} │ {reader.GetString(5),-13} │" +
                        $" {reader.GetString(6),-35} │ {reader.GetDouble(7),12:f2} │ {reader.GetDateTime(8).ToShortDateString(),13} │" +
                        $" {reader.GetInt32(9),6} │");
                } // while

                Console.WriteLine("\t└────┴─────────────┴─────────────┴───────────────┴──────────┴───────────────┴─────────────────────────────────────┴──────────────┴───────────────┴────────┘");

            } // using
        } // Query5


        //			-> Запрос №6 [Запрос с параметром] <-
        // Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
        // Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, 
        // Дата начала подписки, Срок подписки, Стоимость подписки без НДС.
        // Сортировка по полю Индекс издания
        public void Query6()
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("\n\n\n\n\tЗапрос 6.\n" +
                              $"\tСтоимость каждой оформленной подписки с доставкой и без НДС\n");


            Console.ForegroundColor = oldColor;

            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc6");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection; 

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                Console.WriteLine(
                    "\t┌────┬──────────┬─────────────────────────────────────┬──────────────┬───────────────┬────────┬──────────────────┐\n" +
                    "\t│ Id │ Индекс   │            Название                 │    Цена      │     Дата      │  Срок  │   Стоимость      │\n" +
                    "\t│    │  издания │                 издания             │ 1 экземпляра │начала подписки│подписки│ подписки без НДС │\n" +
                    "\t├────┼──────────┼─────────────────────────────────────┼──────────────┼───────────────┼────────┼──────────────────┤");

                // Читаем пока читается
                while (reader.Read())
                {
                    Console.WriteLine($"\t│ {reader.GetInt32(0),2} │ {reader.GetString(1),-8} │ {reader.GetString(2),-35} │" +
                        $" {reader.GetDouble(3),12:f2} │ {reader.GetDateTime(4).ToShortDateString(),13} │ {reader.GetInt32(5), 6} │" +
                        $" {reader.GetDouble(6),16:f2} │");
                } // while

                Console.WriteLine("\t└────┴──────────┴─────────────────────────────────────┴──────────────┴───────────────┴────────┴──────────────────┘");

            } // using
        } // Query6


        //			-> Запрос №7 [Запрос с параметром] <-
        // Выполняет группировку по полю Вид издания.
        // Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
        public void Query7()
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("\n\n\n\n\tЗапрос 7.\n" +
                                $"\tМаксимальная, средняя, миинимальная цена 1 экземпляра\n" +
                                $"\tдля всех типов изданий\n");


            Console.ForegroundColor = oldColor;

            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc7");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                Console.WriteLine(
                    "\t┌───────────────┬───────────────┬───────────────┬───────────────┐\n" +
                    "\t│    Тип        │  Минимальная  │    Средняя    │  Максимальная │\n" +
                    "\t│      издания  │     цена      │     цена      │     цена      │\n" +
                    "\t├───────────────┼───────────────┼───────────────┼───────────────┤");

                // Читаем пока читается
                while (reader.Read())
                {
                    Console.WriteLine($"\t│ {reader.GetString(0),-13} │ {reader.GetDouble(1),13:f2} │ {reader.GetDouble(2),13:f2} │" +
                        $" {reader.GetDouble(3),13:f2} │");
                } // while

                Console.WriteLine("\t└───────────────┴───────────────┴───────────────┴───────────────┘");

            } // using
        } // Query7


        //			-> Запрос №8 [Запрос с параметром] <-
        // Выполняет группировку по полю Улица.
        // Для всех улиц вычисляет количество подписчиков,
        // проживающих на данной улице(итоги по полю Код получателя)
        public void Query8()
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("\n\n\n\n\tЗапрос 8.\n" +
                                $"\tКоличество подписчиков проживающих на заданной улице\n");


            Console.ForegroundColor = oldColor;

            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc8");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                Console.WriteLine(
                    "\t┌──────────────────┬───────────────┐\n" +
                    "\t│      Улица       │  Количество   │\n" +
                    "\t│                  │  подписчиков  │\n" +
                    "\t├──────────────────┼───────────────┤");

                // Читаем пока читается
                while (reader.Read())
                {
                    Console.WriteLine($"\t│ {reader.GetString(0),-16} │ {reader.GetInt32(1),13} │");
                } // while

                Console.WriteLine("\t└──────────────────┴───────────────┘");

            } // using
        } // Query8

        //			-> Запрос №9 [Запрос с параметром] <-
        // Для всех изданий выводит количество оформленных подписок
        public void Query9(DateTime loDate, DateTime hiDate)
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("\n\n\n\n\tЗапрос 9.\n" +
                                $"\tКоличество подписок для всех изданий\n");


            Console.ForegroundColor = oldColor;

            using (SqlConnection connection = new SqlConnection(_connectingString))
            {
                connection.Open();   // подключение к серверу, блокирующий вызов

                SqlCommand cmd = new SqlCommand(@"Proc9");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                Console.WriteLine(
                    "\t┌────┬──────────┬───────────────┬─────────────────────────────────────┬──────────────┬───────────────┐\n" +
                    "\t│ Id │ Индекс   │    Тип        │            Название                 │    Цена      │  Количество   │\n" +
                    "\t│    │  издания │      издания  │                 издания             │ 1 экземпляра │   подписок    │\n" +
                    "\t├────┼──────────┼───────────────┼─────────────────────────────────────┼──────────────┼───────────────┤");

                // Читаем пока читается
                while (reader.Read())
                {
                    Console.WriteLine($"\t│ {reader.GetInt32(0),2} │ {reader.GetString(1),-8} │ {reader.GetString(2),-13} │" +
                        $" {reader.GetString(3),-35} │ {reader.GetDouble(4),12:f2} │ {reader.GetInt32(5),13} │");
                } // while

                Console.WriteLine("\t└────┴──────────┴───────────────┴─────────────────────────────────────┴──────────────┴───────────────┘");

            } // using
        } // Query9


    } // QueriesController

}
