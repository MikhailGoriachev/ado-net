﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models.Task01;

namespace Homework.Controllers
{
    internal class Task1Controller {
        // коллекция книг
        private List<Book> _books;

        // коллекция авторов
        private List<Author> _authors;

        public Task1Controller() {
            Initialize();
        } // Task1Controller


        // формирование коллекций
        public void Initialize(int n = 12) {
            // заполнить коллекцию книг набором данных
            _books = new List<Book>(new Book[] {
                new Book{Id = 1	, IdAuthor = 2, Title = "Экстремальное программирование",              Year = 2001, Price = 150},
                new Book{Id = 2	, IdAuthor = 3, Title = "Задачник по программированию",                Year = 2005, Price = 349},
                new Book{Id = 3	, IdAuthor = 4, Title = "Как программировать на Android",              Year = 2011, Price = 520},
                new Book{Id = 4	, IdAuthor = 5, Title = "Мои походы за бугор",                         Year = 1988, Price = 15},
                new Book{Id = 5	, IdAuthor = 4, Title = "Как программировать на C++",                  Year = 1995, Price = 590},
                new Book{Id = 6	, IdAuthor = 6, Title = "WPF - введение в технологию",                 Year = 2007, Price = 890},
                new Book{Id = 7	, IdAuthor = 7, Title = "Android для профессионалов",                  Year = 2016, Price = 510},
                new Book{Id = 8	, IdAuthor = 4, Title = "Как программировать в C#.NET",                Year = 2009, Price = 480},
                new Book{Id = 9	, IdAuthor = 3, Title = "Сборник задач по LINQ",                       Year = 2012, Price = 389},
                new Book{Id = 10, IdAuthor = 5, Title = "С хоббитом туда и обратно",                   Year = 2011, Price = 35},
                new Book{Id = 11, IdAuthor = 1, Title = "Базовый курс C++",                            Year = 2010, Price = 280},
                new Book{Id = 12, IdAuthor = 6, Title = "WCF - технология распреденных приложений",    Year = 2012, Price = 360},
                new Book{Id = 13, IdAuthor = 1, Title = "Полное руководство по Java SE 8",             Year = 2014, Price = 490},
                new Book{Id = 14, IdAuthor = 4, Title = "Руководство по разработке под Android",       Year = 2016, Price = 680},
                new Book{Id = 15, IdAuthor = 6, Title = "Типичные задачи по LINQ в оперативном учете", Year = 2012, Price = 350},
                new Book{Id = 16, IdAuthor = 4, Title = "Взгляд на Android для профессионалов",        Year = 2016, Price = 580}
            });

            // заполнить коллекцию авторов набором данных
            _authors = new List<Author>(new Author[] { 
                new Author{Id =  1, FullName = "Шилдт Г.",      Year = 1951},
                new Author{Id =  2, FullName = "Кент Дж.",      Year = 1849},
                new Author{Id =  3, FullName = "Абрамян М.Э.",  Year = 1965},
                new Author{Id =  4, FullName = "Дейтел П.",     Year = 1965},
                new Author{Id =  5, FullName = "Кузнецов И.А.", Year = 1963},
                new Author{Id =  6, FullName = "Егоренко В.Н.", Year = 1985},
                new Author{Id =  7, FullName = "Кривец С.А.",   Year = 1965},
                new Author{Id =  8, FullName = "Олифер Д.",     Year = 1978},
                new Author{Id =  9, FullName = "Макаров М.И.",  Year = 1975},
                new Author{Id = 10, FullName = "Шарп Дж.",      Year = 1928},
                new Author{Id = 11, FullName = "Васильев А.Н.", Year = 1965},
                new Author{Id = 12, FullName = "Дейтел Р. ",    Year = 1965}
            });
        } // Initialize



        // Вывести все книги коллекции, выводить фамилии и инициалы автора
        // синтаксис LINQ
        public void Query01A() {
            var request =
                from book in _books
                join author in _authors on book.IdAuthor equals author.Id // условие объединения (связи) коллекций
                select new ResultQuery01and02 {
                    Id = book.Id,
                    Title = book.Title,
                    Year = book.Year,
                    FullName = author.FullName,
                    Price = book.Price,
                    YearOfBirth = author.Year
                };


            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(ResultQuery01and02.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery01and02.Footer());
        } // Query01А

        // Вывести все книги коллекции, выводить фамилии и инициалы автора
        // синтаксис расширяющих методов
        public void Query01B() {
            var request = _books
               .Join(
               _authors,
               book => book.IdAuthor,
               author => author.Id,
               (book, author) => new ResultQuery01and02{
                   Id = book.Id,
                   Title = book.Title,
                   Year = book.Year,
                   FullName = author.FullName,
                   Price = book.Price,
                   YearOfBirth = author.Year
               }
            );


            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(ResultQuery01and02.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery01and02.Footer());
        } // Query01B


        // Вывести книги авторов, год рождения которых принадлежит заданном диапазону 
        // синтаксис LINQ
        public void Query02A(int lo, int hi) {
            var request =
                from book in _books
                join author in _authors on book.IdAuthor equals author.Id  // условие объединения (связи) коллекций
                where author.Year >= lo && author.Year <= hi
                select new ResultQuery01and02 {
                    Id = book.Id,
                    Title = book.Title,
                    Year = book.Year,
                    FullName = author.FullName,
                    Price = book.Price,
                    YearOfBirth = author.Year
                };


            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(ResultQuery01and02.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery01and02.Footer());
        } // Query02А


        // Вывести книги авторов, год рождения которых принадлежит заданном диапазону 
        // синтаксис расширяющих методов
        public void Query02B(int lo, int hi) {
            var request = _books
               .Join(
               _authors.Where(a => a.Year >= lo && a.Year <= hi),
               book => book.IdAuthor,
               author => author.Id,
               (book, author) => new ResultQuery01and02 {
                   Id = book.Id,
                   Title = book.Title,
                   Year = book.Year,
                   FullName = author.FullName,
                   Price = book.Price,
                   YearOfBirth = author.Year
               });


            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(ResultQuery01and02.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery01and02.Footer());
        } // Query02B


        // Вывод книг, в названии которых содержится подстрока и цена меньше заданного значения.
        // синтаксис LINQ
        public void Query03A(string str, int price) {
            var request =
                from book in _books
                where book.Title.ToLower().Contains(str.ToLower()) && book.Price < price
                select book;


            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(Book.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Book.Footer());
        } // Query03А


        // Вывод книг, в названии которых содержится подстрока и цена меньше заданного значения.
        // синтаксис расширяющих методов
        public void Query03B(string str, int price) {
            var request = _books.Where(b => b.Title.ToLower().Contains(str.ToLower()) && b.Price < price);


            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(Book.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(Book.Footer());
        } // Query03B


        // Список авторов и количество их книг в коллекции.
        // синтаксис LINQ
        public void Query04A() {
            var request =
                from book in _books
                join author in _authors on book.IdAuthor equals author.Id
                group author by author.FullName into grAuthor
                select new ResultQuery04and06 {
                    FullName = grAuthor.Key,
                    Amount = grAuthor.Count()
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(ResultQuery04and06.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery04and06.Footer());
        } // Query04A


        // Список авторов и количество их книг в коллекции.
        // синтаксис расширяющих методов
        public void Query04B() {
            var request = _books
                .Join(_authors, book => book.IdAuthor, author => author.Id,
                    (book, author) => new ResultQuery01and02 {
                        Id = book.Id,
                        Title = book.Title,
                        Year = book.Year,
                        FullName = author.FullName,
                        Price = book.Price,
                        YearOfBirth = author.Year
                    })
                .GroupBy(item => item.FullName,
                    (key, group) => new ResultQuery04and06 {
                        FullName = key,
                        Amount = group.Count()
                    });

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(ResultQuery04and06.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery04and06.Footer());
        } // Query04B


        // Средняя цена книг по годам издания.
        // синтаксис LINQ
        public void Query05A() {
            var request =
                from book in _books
                join author in _authors on book.IdAuthor equals author.Id
                group book by book.Year into grBook
                select new ResultQuery05{
                    Year = grBook.Key,
                    AvgPrice = grBook.Average(x => x.Price)
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(ResultQuery05.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery05.Footer());
        } // Query05A


        // Средняя цена книг по годам издания.
        // синтаксис расширяющих методов
        public void Query05B() {
            var request = _books
                .Join(_authors, book => book.IdAuthor, author => author.Id,
                    (book, author) => new ResultQuery01and02 {
                        Id = book.Id,
                        Title = book.Title,
                        Year = book.Year,
                        FullName = author.FullName,
                        Price = book.Price,
                        YearOfBirth = author.Year
                    })
                .GroupBy(item => item.Year,
                    (key, group) => new ResultQuery05 {
                        Year = key,
                        AvgPrice= group.Average(x => x.Price)
                    });

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(ResultQuery05.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery05.Footer());
        } // Query05B


        // Список авторов по убыванию количества их книг в коллекции.
        // синтаксис LINQ
        public void Query06A() {
            var request =
                from book in _books
                join author in _authors on book.IdAuthor equals author.Id
                group author by author.FullName into grAuthor
                orderby grAuthor.Count() descending
                select new ResultQuery04and06 {
                    FullName = grAuthor.Key,
                    Amount = grAuthor.Count()
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(ResultQuery04and06.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery04and06.Footer());
        } // Query06A


        // Список авторов по убыванию количества их книг в коллекции.
        // синтаксис расширяющих методов
        public void Query06B() {
            var request = _books
                .Join(_authors, book => book.IdAuthor, author => author.Id,
                    (book, author) => new ResultQuery01and02 {
                        Id = book.Id,
                        Title = book.Title,
                        Year = book.Year,
                        FullName = author.FullName,
                        Price = book.Price,
                        YearOfBirth = author.Year
                    })
                .GroupBy(item => item.FullName,
                    (key, group) => new ResultQuery04and06 {
                        FullName = key,
                        Amount = group.Count()
                    }).OrderByDescending(a => a.Amount);

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(ResultQuery04and06.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery04and06.Footer());
        } // Query06B


        // Средний возраст книг по авторам, выводить список с упорядочиванием фамилий и инициалов авторов.
        // синтаксис LINQ
        public void Query07A() {
            var request =
                from item in
                    from book in _books
                    join author in _authors on book.IdAuthor equals author.Id
                    select new  ResultQuery01and02{
                        Id = book.Id,
                        Title = book.Title,
                        Year = book.Year,
                        FullName = author.FullName,
                        Price = book.Price,
                        YearOfBirth = author.Year
                    }
                group item by item.FullName into grAuthor
                orderby grAuthor.Key descending
                select new ResultQuery07 {
                    FullName = grAuthor.Key,
                    AvgAge = grAuthor.Average(x => DateTime.Now.Year - x.Year)
                };

            Console.WriteLine("\n\tСинтаксис LINQ:");

            Console.WriteLine(ResultQuery07.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery07.Footer());
        } // Query07A


        // Средний возраст книг по авторам, выводить список с упорядочиванием фамилий и инициалов авторов.
        // синтаксис расширяющих методов
        public void Query07B() {
            var request = _books
                .Join(_authors, book => book.IdAuthor, author => author.Id,
                    (book, author) => new ResultQuery01and02 {
                        Id = book.Id,
                        Title = book.Title,
                        Year = book.Year,
                        FullName = author.FullName,
                        Price = book.Price,
                        YearOfBirth = author.Year
                    })
                .GroupBy(item => item.FullName,
                    (key, group) => new ResultQuery07 {
                        FullName = key,
                        AvgAge = group.Average(x => DateTime.Now.Year - x.Year)
                    }).OrderByDescending(a => a.FullName);

            Console.WriteLine("\n\tСинтаксис расширяющих методов:");

            Console.WriteLine(ResultQuery07.Header());
            request.ToList().ForEach(item => Console.WriteLine(item.ToTableRow()));
            Console.WriteLine(ResultQuery07.Footer());
        } // Query07B

    } // Task1Controller
}
