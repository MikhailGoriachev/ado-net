﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W3Ado.Models
{
    // модель для отображения подписчиков - все поля представления
    public class Subscriber
    {
        public int SubscriberId { get; set; }
        public string Surname { get; set; }
        public string NameSubscriber { get; set; }
        public string Patronymic { get; set; }
        public string PassportNum { get; set; }
        public string NameStreet { get; set; }
        public string HouseNum { get; set; }
        public string ApartmentNum { get; set; }
        public string TypeSubscribers { get; set; }
        public string TitleSubscribers { get; set; }


        // шапка таблицы, статическое свойство
        public static string Header()
        {
            return
            $"┌────┬────────────┬────────────┬────────────┬──────────┬─────────────────┬──────┬───────┬─────────┬───────────────────┐\n" +
            $"│ ID │  Фамилия   │    Имя     │  Отчество  │ Паспорт. │ Название        │  №   │   №   │   Тип   │    Название       │\n" +
            $"│    │ подписчика │ подписчика │ подписчика │  данные  │       улицы     │ дома │ кв-ры │ издания │        издания    │\n" +
            $"├────┼────────────┼────────────┼────────────┼──────────┼─────────────────┼──────┼───────┼─────────┼───────────────────┤\n";
        } // Header

        // подвал таблицы, статическое свойство
        public static string Footer() =>
            $"└────┴────────────┴────────────┴────────────┴──────────┴─────────────────┴──────┴───────┴─────────┴───────────────────┘\n";

        // вывод в строку таблицы
        public string ToTableRow() =>
            $"│ {SubscriberId,2} │ {Surname,-10} │ {NameSubscriber,-10} │ {Patronymic,-10} │ {PassportNum, -8} │ {NameStreet,-15} │ {HouseNum,4} │ {ApartmentNum, 5} │ {TypeSubscribers,-7} │ {TitleSubscribers,-17} │";

    }// class Subscriber
}
