﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Practice

{
    //Класс цвета консоли
   public class Color
    {
        //Цвет символов
        public ConsoleColor Foreground 
        {
            get;
            set;
        }
        //Цвет фона
        public ConsoleColor BackGround 
        {
            get;
            set;
        }

        //В качестве знчений по умолчанию - текущий цвет
        public Color(): this(Console.BackgroundColor,Console.ForegroundColor)
        {

        }

        //Инициирующий C_TOR
        public Color(ConsoleColor Back,ConsoleColor FontColor)
        {
            //Установка занчений через неполные свойства
            BackGround = Back;
            Foreground = FontColor;
        }

        //Устанавливаем занчение цветов в зависимости от знчений заданный при создании объекта
        public void EstablishColor()
        {
            //Через getters свойсв
            Console.ForegroundColor = Foreground;
            Console.BackgroundColor = BackGround;
        }
        
        //Устанавливаем занчение цветов в зависимости от знчений заданных в аргументах без создания обекта
        static public void SetNewColor(ConsoleColor Back, ConsoleColor FontColor)
        {
            //Через getters свойсв
            Console.ForegroundColor = FontColor;
            Console.BackgroundColor = Back;
        }

    }
}
