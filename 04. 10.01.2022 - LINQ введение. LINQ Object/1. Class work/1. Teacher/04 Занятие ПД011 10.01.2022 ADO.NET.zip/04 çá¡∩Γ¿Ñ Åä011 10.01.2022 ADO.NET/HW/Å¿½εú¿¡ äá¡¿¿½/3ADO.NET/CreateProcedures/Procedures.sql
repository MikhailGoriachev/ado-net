﻿--создание процедур

--1. Выбирает из таблицы ИЗДАНИЯ информацию о доступных для 
--подписки изданиях заданного типа, стоимость 1 экземпляра 
--для которых меньше заданной.
--Требуется модель для вывода данных – данные выборки помещать
--в коллекцию
drop proc if exists ShowPubByTypeAndCost
go
create proc ShowPubByTypeAndCost
	@type nvarchar(80)
	,@cost int
as
select 	* from PublicationsView
where EditionType = @type and Cost < @cost

exec ShowPubByTypeAndCost N'Журнал', 1000
go
--2. Выбирает из таблиц информацию о подписчиках, 
--проживающих на заданной параметром улице и номере дома, 
--которые оформили подписку на издание с заданным параметром наименованием
drop proc if exists ShowSubByStreetAndPub
go
create proc ShowSubByStreetAndPub
	@street nvarchar(80)
	,@numHouse nvarchar(20)
	,@pub nvarchar(80)
as
select 
	DelivsView.idSub
	,DelivsView.[Name]
	,DelivsView.Surname
	,DelivsView.Patronymic
	,DelivsView.NumberOfPassport
	,DelivsView.Street
	,DelivsView.NumHouse
	,DelivsView.NumApartment
from DelivsView
where DelivsView.Street = @street 
	and DelivsView.NumHouse = @numHouse
	and DelivsView.EditionName = @pub

exec ShowSubByStreetAndPub N'Свободы', N'23B', N'Утренний Донецк'
go

--3.Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение 
--в поле Цена 1 экземпляра находится в заданном диапазоне значений
drop proc if exists ShowPubByCost
go
create proc ShowPubByCost
	@lo int
	,@hi int
as
select * from PublicationsView 
where Cost between @lo and @hi
go

--4.Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный 
--параметром тип издания
drop proc if exists ShowSubByPubName 
go
create proc ShowSubByPubName
	@editName nvarchar(80)
as
select
	idSub
	,[Name]
	,Surname
	,Patronymic
	,NumberOfPassport
	,Street
	,NumHouse
	,NumApartment
from DelivsView 
where DelivsView.EditionName like @editName;
go


--5.Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных 
--подписках, для которых срок подписки есть значение из некоторого диапазона. 
--Нижняя и верхняя границы диапазона задаются при выполнении запроса
drop proc if exists ShowDelivsByDate
go
create proc ShowDelivsByDate
	@lo date
	,@hi date
as
select
	DelivsView.idSub
	,[Name]
	,Surname
	,Patronymic
	,EditionName
	,EditionType
	,DateOfSub
from DelivsView 
where DateOfSub between @lo and @hi
go


--6.Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
--Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала 
--подписки, Срок подписки, Стоимость подписки без НДС. Сортировка по полю Индекс издания
drop proc if exists ShowCostOfDelivs
go
create proc ShowCostOfDelivs
as
select
	idPub				as [Индекс издания]
	,EditionName			as [Наименование издания]
	,Cost					as [Цена 1 экземпляра]
	,DateOfSub				as [Дата начала подписки]
	,Term					as [Срок подписки]
	,(Cost * Term) * 1.01	as [Стоимость подписки без НДС]
from DelivsView
order by idPub
go
--7.Выполняет группировку по полю Вид издания. 
--Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
drop proc if exists ShowPubMaxMinCost
go
create proc ShowPubMaxMinCost
as
select 
	EditionType
	,Max(Cost)	as Max
	,Min(Cost)	as Min
from DelivsView
group by EditionType
go

--8.Выполняет группировку по полю Улица. Для всех улиц вычисляет количество подписчиков, 
--проживающих на данной улице (итоги по полю Код получателя)
drop proc if exists ShowSubsStatByStreet
go
create proc ShowSubsStatByStreet
as
select
	Street
	,COUNT(Subs.Id) as [Kоличество подписчиков]
from Streets left join Subs on Streets.Id = Subs.idStreet
group by Street
go


--9.Для всех изданий выводит количество оформленных подписок
drop proc if exists ShowPubStat
go
create proc ShowPubStat
as
select
	EditionNames.EditionName
	,COUNT(Delivs.Id) as [Kоличество оформленных подписок]
from EditionNames left join (Pubs left join Delivs on Pubs.Id = Delivs.idPub)
				on EditionNames.Id = Pubs.idEditionName
group by EditionName
go

