﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW.Models
{
    public class Item
    {
        public static int MinYear = 2010; // минимальный год выпуска товара

        private string _name;   // наименование
        private int    _price;   // цена
        private int    _count;  // кол-во
        private int    _year;   // год выпуска

        public string Name {
            get => _name;
            set => _name = !string.IsNullOrWhiteSpace(value)?value:throw new Exception("Item: Наименование не может быть пустым!");
        } // наименование

        public int Price {
            get=>_price;
            set=>_price = value>0?value:throw new Exception("Item: стоимость товара не может быть меньше либо равна нулю!");
        } // Стоимость

        public int Count {
            get=>_count;
            set => _count = value > 0 ? value : throw new Exception("Item: Кол-во товара не может быть меньше или равно нулю!");
        } // Кол-во товара

        public int Year
        {
            get=>_year; 
            set=>_year = value>=MinYear?value:throw new Exception($"Item: Год выпуска товара не может быть меньше {MinYear}!");
        } // Год выпуска товара


        // конструктор по умолчанию
        public Item() : this("Мишка", 199, 10, 2015)
        { }

        // конструктор с параметрами
        public Item(string name, int price, int count, int year) {
            Name = name;
            Price = price;
            Count = count;
            Year = year;
        } // Item

        public override string ToString() => $"{Name}, {Price}, {Count}, {Year}";

        public static string Header => "+----------------------------------------------+\n" +
                                       "| Наименование |  Цена  | Кол-во | Год выпуска |\n" +
                                       "+----------------------------------------------+\n";
        public static string Footer => "+----------------------------------------------+\n";

        public string ToRow() => $"| {Name, -12} | {Price, 5} | {Count, 7} | {Year, 11} |";

    } // Item


    // Отдельный класс для метода/методов расширения
    public static class ItemExtensions {
        
        // расширяющий метод для класса Item - возвращает процент скидки в зависимости от возраста товара
        public static int Discount(this Item x) {
            int discount = 0; // переменная для скидки
            int year = DateTime.Now.Year-x.Year; // год для вычисления скидки

            if (year<3)
                discount = 0;
            else if (year < 10)
                discount = 3;
            else
                discount = 7;

            return discount;
        } // Discount

    } // ItemExtensions

}
