﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigSecurityModels.Models
{
    // модель для представления одной записи с данными издания
    public class Publication
    {
        // Id в таблице/представлении
        public int PublicationId { get; set; }

        // Индекс по каталогу подписных изданий 
        public string PubIndex { get; set; }

        // Тип издания
        public string PubType    { get; set; }
        
        // Название издания
        public string Title      { get; set; }

        // Стоимость 1 экземпляра
        public int Price         { get; set; }


        // Для табличного вывода
        // Шапка таблицы
        public static string Header =>
            "\t┌───────┬────────┬────────────────┬─────────────┬──────────────────────────────────┬───────────────────┐\n" +
            "\t│ # п/п │ Идент. │ Индекс издания │ Тип издания │ Название издания                 │ 1 экз., руб./мес. │\n" +
            "\t├───────┼────────┼────────────────┼─────────────┼──────────────────────────────────┼───────────────────┤";

        // Подвал таблицы
        public static string Footer =>
            "\t└───────┴────────┴────────────────┴─────────────┴──────────────────────────────────┴───────────────────┘";

        // Вывод одной строки таблицы
        public string ToTableRow(int row) =>
            $"\t│ {row,5} │ {PublicationId,6} │ {PubIndex,-14} │ {PubType,-11} │ {Title,-32} │ {Price,17:n2} │";
    } // class Publication
}
