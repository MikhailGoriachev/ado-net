﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ADOIntro
{
    class Application
    {
        private string _connectingString;

        public Application() : this(@"Data Source=(LocalDB)\MSSQLLocalDB;
                      AttachDbFilename=""D:\Students\ПД011\06 ADO.NET\02 Занятие ПД011 23.12.2021 ADO.NET\HW\Печёрин Данил\ADOIntro\App_Data\RealEstateDb.mdf"";
                      Integrated Security=True") { }

        public Application(string connectingString) {
            _connectingString = connectingString;
        }

        public void Query1()
        {
            try
            {



                // подключение к БД
                using (SqlConnection connection = new SqlConnection(_connectingString))
                {
                    connection.Open();   // подключение к серверу, блокирующий вызов
                    Console.WriteLine("Соединение открыто");

                    SqlCommand cmd = new SqlCommand(
                    @"
                           select
                                  Apartments.Id
                                , Streets.Street
                                , Apartments.Building
                                , Apartments.Flat
                                , Apartments.Area
                                , Apartments.RoomNum
                           from
                              Apartments join Streets on Apartments.IdStreet = Streets.Id
                           where
                                Apartments.RoomNum = @roomNum and Streets.Street = @street;
                ");

                    // задать соединение с БД
                    cmd.Connection = connection;
                    cmd.Parameters.AddWithValue("@roomNum", 3);
                    cmd.Parameters.AddWithValue("@street", "ул. Садовая");


                    // выполнение запроса, ссылка на  выбранные данные - reader
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Если данные получены (есть строки в полученном ответе серврера)
                    if (reader.HasRows) {
                        // выводим имена столбцов (это не обязательно)
                        Console.WriteLine(
                            $"| {reader.GetName(0), 2} | " +
                                $"{reader.GetName(1),-15} | {reader.GetName(2),-15} | " +
                                $"{reader.GetName(3)} | {reader.GetName(4)} | {reader.GetName(5)} |");

                        while (reader.Read()) {
                            Console.WriteLine(
                                $"| {reader.GetInt32(0),2} | " +
                                $"{reader.GetString(1),-15} | {reader.GetString(2),-15} | " +
                                $"{reader.GetInt32(3)} | {reader.GetInt32(4)} | {reader.GetInt32(5)} |");
                        } // while
                    } // if
                    Console.WriteLine("Соединение закрыто");
                    Console.WriteLine();

                }// using

                Console.WriteLine("Соединение закрыто");
                Console.WriteLine();


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }// Query

        public void Query2()
        {
            try
            {
                // подключение к БД
                using (SqlConnection connection = new SqlConnection(_connectingString))
                {

                    connection.Open();   // подключение к серверу, блокирующий вызов
                    Console.WriteLine("Соединение открыто");

                    SqlCommand cmd = new SqlCommand(
                        @"declare @surname nvarchar(60) = N'И', @percent float = 10;

                    select
                           Realtors.Id
                           , Persons.Surname
                           , Persons.[Name]
                           , Persons.Patronymic
                           , Realtors.[Percent]
                          from
                             Realtors join Persons on Realtors.IdPerson = Persons.Id
                          where
                            Persons.Surname like(@surname + N'%') and Realtors.[Percent] > @percent;"
                        );
                    // задать соединение с БД
                    cmd.Connection = connection;


                    // выполнение запроса, ссылка на  выбранные данные - reader
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // выводим имена столбцов (это не обязательно)
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),2} | " +
                                $"{reader.GetString(1),-15} | {reader.GetString(2),-15} | " +
                                $"{reader.GetString(3)} | {reader.GetDouble(4)} |");

                        while (reader.Read())
                        {
                            Console.WriteLine(
                                $"| {reader.GetInt32(0),2} | " +
                                $"{reader.GetString(1),-15} | {reader.GetString(2),-15} | " +
                                $"{reader.GetString(3)} | {reader.GetDouble(4)} |");
                        } // while
                    } // if
                    Console.WriteLine("Соединение закрыто");
                    Console.WriteLine();



                }//using 


            }//try
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }//catch
            Console.ReadKey();
        }//query2

        public void Query3()
        {
            try
            {
                // подключение к БД
                using (SqlConnection connection = new SqlConnection(_connectingString)) 
                {

                    connection.Open();   // подключение к серверу, блокирующий вызов
                    Console.WriteLine("Соединение открыто");

                    SqlCommand cmd = new SqlCommand(
                        @" declare @roomNum int = 1, @lo int =  900000, @hi int = 1000000;

                     select
                           Apartments.Id
                           , Streets.Street
                           , Apartments.Building
                           , Apartments.Flat
                           , Apartments.Area
                           , Apartments.RoomNum
                           , Offers.Price
                      from
                          Apartments join Streets on Apartments.IdStreet = Streets.Id
                          join Offers on Apartments.Id = Offers.IdApartment
                    where
                         Apartments.RoomNum = @roomNum and Offers.Price between @lo and @hi;"

                        );

                    // задать соединение с БД
                    cmd.Connection = connection;


                    // выполнение запроса, ссылка на  выбранные данные - reader
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // выводим имена столбцов (это не обязательно)
                        Console.WriteLine(
                            $"| {reader.GetInt32(0),2} | " +
                                $"{reader.GetString(1),-15} | {reader.GetString(2),-15} | " +
                                $"{reader.GetInt32(3)} | {reader.GetInt32(4)} | {reader.GetInt32(5)} | {reader.GetInt32(6)}");

                        while (reader.Read())
                        {
                            Console.WriteLine(
                                $"| {reader.GetInt32(0),2} | " +
                                $"{reader.GetString(1),-15} | {reader.GetString(2),-15} | " +
                                $"{reader.GetInt32(3)} | {reader.GetInt32(4)} | {reader.GetInt32(5)} | {reader.GetInt32(6)}");
                        } // while
                    } // if
                    Console.WriteLine("Соединение закрыто");
                    Console.WriteLine();

                }

            }//try
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }//catch
            Console.ReadKey();
        }//query3

    }
}
