﻿-- База данных «Учет сделок с недвижимостью»

-- Создание хранимых процедур

-- 1. Хранимая процедура.
-- Выбирает информацию о 3-комнатных квартирах,
-- расположенных на улице «Садовая». Значения задавать параметрами запроса
drop proc if exists ProcQuery01;
go

create proc ProcQuery01 @namestreet nvarchar(30), @numRooms int
as begin
      select
         *
      from
         ViewApartments
      where
         NameStreet = @namestreet and NumberOfRooms = @numRooms;
end;
go

exec ProcQuery01 N'Садовая', 3;
go


-- 2. Хранимая процедура.
-- Выбирает информацию о риэлторах, фамилия которых начинается с буквы «И» и
-- процент вознаграждения больше 10%. Значения задавать параметрами запроса
drop proc if exists ProcQuery02;
go

create proc ProcQuery02 @surname nvarchar(30), @percent int 
as begin
      select
         *
      from
         ViewRealtors
      where
         RealtorSurname like @surname and PercentRemuneration > @percent;
end;
go

exec ProcQuery02 N'И%', 10;
go


-- 3. Хранимая процедура.
-- Выбирает информацию об 1-комнатных квартирах,
-- цена на которые находится в диапазоне от 900 000 руб. до 1000 000 руб.
-- Значения задавать параметрами запроса
drop proc if exists ProcQuery03;
go

create proc ProcQuery03 @loPrice int, @hiPrice int  
as begin
     select
        *
     from
        ViewApartments
     where
        PriceApartment between @loPrice and @hiPrice;
end;
go

exec ProcQuery03 900000, 1000000;
go


-- 4. Хранимая процедура.
-- Выбирает информацию о квартирах с заданным числом комнат.
-- Значения задавать параметрами запроса
drop proc if exists ProcQuery04;
go

create proc ProcQuery04 @numRooms int  
as begin
      select
         *
      from
         ViewApartments
      where
         NumberOfRooms = @numRooms;
end;
go
     
exec ProcQuery04 2;
go   


-- 5. Хранимая процедура.
-- Выбирает информацию обо всех 2-комнатных квартирах,
-- площадь которых есть значение из некоторого диапазона.
-- Значения задавать параметрами запроса
drop proc if exists ProcQuery05;
go

create proc ProcQuery05 @loArea float, @hiArea float, @numRooms int
as begin
     select
        *
     from
        ViewApartments
     where
        NumberOfRooms = @numRooms and AreaApartment between @loArea and @hiArea;
end;
go

exec ProcQuery05 45.5, 50.5, 2;
go


-- 6. Хранимая процедура.
-- Вычисляет для каждой оформленной сделки размер комиссионного вознаграждения риэлтора.
-- Включает поля Фамилия риэлтора, Имя риэлтора,
-- Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные.
-- Сортировка по полю Дата сделки
drop proc if exists ProcQuery06;
go

create proc ProcQuery06
as begin
      select
         Persons.Surname
         , Persons.[Name]
         , Persons.Patronymic
         , Dealings.DateDeal
         , Apartments.PriceApartment
       -- Риэлтор, оформивший сделку купли-продажи,
       -- получает комиссионное вознаграждение, которое вычисляется как 
       -- Стоимость квартиры * Процент вознаграждения
         , (Apartments.PriceApartment * Realtors.PercentRemuneration) / 100 as Commission
      from 
         Dealings join(Realtors join Persons on Realtors.IdPerson = Persons.Id)
                  on Dealings.IdRealtor = Realtors.Id
                  join(Apartments join Streets on Apartments.IdNameStreet = Streets.Id)
                  on Dealings.IdApartment = Apartments.Id
      order by
         Dealings.DateDeal;
end;
go

exec ProcQuery06;
go


-- 7. Хранимая процедура.
-- Выбрать всех риэлторов, количество клиентов,
-- оформивших с ним сделки и сумму сделок риэлтора.
-- Упорядочить выборку по убыванию суммы сделок.
drop proc if exists ProcQuery07;
go

create proc ProcQuery07
as begin
      select
         Dealings.IdRealtor
         , Persons.Surname
         , Persons.[Name]
         , Persons.Patronymic
        -- агрегатные функции
         , Count(Dealings.IdRealtor) as AmountRealtors 
         , Sum(Apartments.PriceApartment) as SumDeal
     from
        Dealings left join(Realtors join Persons on Realtors.IdPerson = Persons.Id) 
                 on Dealings.IdRealtor = Realtors.Id
                 left join(Apartments join Streets on Apartments.IdNameStreet = Streets.Id)
                 on Dealings.IdApartment = Apartments.Id      
     group by
        Dealings.IdRealtor, Persons.Surname, Persons.[Name], Persons.Patronymic
     order by
        SumDeal desc;
end;
go

exec ProcQuery07;
go


-- 8. Хранимая процедура.
-- Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
drop proc if exists ProcQuery08;
go

create proc ProcQuery08
as begin
      select
         Streets.NameStreet
         , Count(Dealings.IdRealtor) as DealAmount
         , IsNull(Sum(Apartments.PriceApartment),0) as DealSum
     from
        Streets left join (Apartments join Dealings on Apartments.Id = Dealings.IdApartment) 
                on Streets.Id = Apartments.IdNameStreet
     group by
        Streets.NameStreet
     order by 
        DealSum desc;
end;
go

exec ProcQuery08;
go


-- 9. Хранимая процедура.
-- Для всех улиц вывести сумму сделок за заданный период,
-- упорядочить выборку по убыванию суммы сделки.
-- Диапазон задавать параметрами запроса
drop proc if exists ProcQuery09;
go

create proc ProcQuery09 @fromDate date, @toDate date
as begin
      select
         Streets.NameStreet
         , Count(PeriodDeals.PriceApartment) as DealAmount
         , IsNull(Sum(PeriodDeals.PriceApartment),0) as DealSum
      from
         Streets left join 
        -- данные по сделкам за период извлекаем при помощи подзапроса, требуется назначить 
        -- псевдоним этому подзапросу
         (select Dealings.DateDeal, Apartments.PriceApartment, Apartments.IdNameStreet
          from (Dealings join Apartments on Dealings.IdApartment = Apartments.Id)  
          where Dealings.DateDeal between @fromDate and @todate) PeriodDeals
         on Streets.Id = PeriodDeals.IdNameStreet
     group by
         Streets.NameStreet
     order by 
         DealSum desc;
end;
go

exec ProcQuery09 '12-05-2021', '02-01-2022';
go
