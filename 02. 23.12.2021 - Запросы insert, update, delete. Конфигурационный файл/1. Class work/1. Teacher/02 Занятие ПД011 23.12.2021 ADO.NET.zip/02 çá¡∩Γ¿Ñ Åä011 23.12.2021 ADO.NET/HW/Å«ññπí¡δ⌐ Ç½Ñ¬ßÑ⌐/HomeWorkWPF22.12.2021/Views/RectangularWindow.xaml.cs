﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HomeWorkWPF22._12._2021.Models;

namespace HomeWorkWPF22._12._2021.Views
{
    /// <summary>
    /// Логика взаимодействия для RectangularWindow.xaml
    /// </summary>
    public partial class RectangularWindow : Window
    {
        // поле с фигурой
        private Rectangular _rectangular;

        // конструктор с зависимостями
        public RectangularWindow() : this(new Rectangular()) { }

        // конструктор по умолчанию
        public RectangularWindow(Rectangular rectangular)
        {
            InitializeComponent();

            _rectangular = rectangular;

            Txb_a.Text = $"{_rectangular.A}";
            Txb_b.Text = $"{_rectangular.B}";
            Txb_h.Text = $"{_rectangular.H}";
            Txb_p.Text = $"{_rectangular.P}";

            // очистка поля вывода результата
            Res_S.Text = "";
            Res_V.Text = "";
            Res_M.Text = "";

            // фокус на первом поле ввода
            Txb_a.Focus();

        }

        // Calculate
        private void Calculate_Command(object sender, RoutedEventArgs e)
        {
            try
            {
                _rectangular.A = double.Parse(Txb_a.Text);
                _rectangular.B = double.Parse(Txb_b.Text);
                _rectangular.H = double.Parse(Txb_h.Text);
                _rectangular.P = double.Parse(Txb_p.Text);


                double ResS, ResV, ResM;

                ResS = _rectangular.GetS();
                ResV = _rectangular.GetV();
                ResM = _rectangular.GetMass();


                Res_S.Text = $"{ResS:f3}";
                Res_V.Text = $"{ResV:f3}";
                Res_M.Text = $"{ResM:f3}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Geometric_Command


        // Очистка поля вывода результата при изменении значений в полях ввода
        private void TextChanged_Handler(object sender, TextChangedEventArgs e)
        {
            // очистка поля вывода результата
            Res_S.Text = "";
            Res_V.Text = "";
            Res_M.Text = "";
        } // TextChanged_Handler
    }
}
