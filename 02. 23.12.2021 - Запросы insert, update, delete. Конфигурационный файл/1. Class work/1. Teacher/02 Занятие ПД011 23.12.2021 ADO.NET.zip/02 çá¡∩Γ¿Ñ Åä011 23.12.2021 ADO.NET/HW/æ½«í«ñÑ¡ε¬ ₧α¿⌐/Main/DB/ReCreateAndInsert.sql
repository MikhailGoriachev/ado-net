﻿drop table if exists Deals;
drop table if exists Apartments;
drop table if exists Agents;
drop table if exists Clients;
drop table if exists Persons;

drop view if exists DealsView;
drop view if exists ApartmentsView;
drop view if exists AgentsView;
drop view if exists ClientsView;
go


begin -- Persons


CREATE TABLE [dbo].[Persons]
(
	[PersonsId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Firstname] NVARCHAR(80) NOT NULL, 
    [Surname] NVARCHAR(80) NOT NULL, 
    [Patronymic] NVARCHAR(80) NOT NULL
);


INSERT INTO Persons 
VALUES
  ('Hilda','Sargent','G'),
  ('Doris','Mullins','I'),
  ('Whitney','Benson','Y'),
  ('George','Randall','C'),
  ('Len','Ortega','D'),
  ('Olga','Fitzpatrick','C'),
  ('Edan','Mooney','V'),
  ('Ian','Burgess','R'),
  ('Octavius','Glass','G'),
  ('Clio','Stokes','P'),
  ('Ivana','Riggs','H'),
  ('Troy','Long','B'),
  ('Jeanette','Robertson','T'),
  ('Doris','Schwartz','T'),
  ('Darrel','Holder','L'),
  ('Madonna','Salas','N'),
  ('Kitra','Waters','Z'),
  ('Troy','Benton','S'),
  ('Nomlanga','Wise','P'),
  ('Kamal','Hardin','W'),
  ('Wylie','Hunter','B'),
  ('Roth','Ramirez','C'),
  ('Meredith','Meyers','L'),
  ('Nerea','Contreras','L'),
  ('Regina','Myers','H'),
  ('Tamara','Faulkner','J'),
  ('Amy','Mcclain','O'),
  ('Rogan','Delgado','P'),
  ('Jerome','Koch','H'),
  ('Michael','Savage','J'),
  ('Eve','Small','S'),
  ('Thor','Hogan','C'),
  ('Jerome','Harding','C'),
  ('Shelby','Savage','O'),
  ('Stacey','Freeman','C'),
  ('Gisela','Martin','J'),
  ('Mollie','Daniel','U'),
  ('Carlos','Dawson','X'),
  ('Kiayada','Green','O'),
  ('Kevin','Mckay','B'),
  ('Branden','Frost','F'),
  ('Christopher','Washington','B'),
  ('Serina','Waller','W'),
  ('Beatrice','Kelly','K'),
  ('Hayley','Hebert','R'),
  ('Karyn','Terry','K'),
  ('Jerry','Nixon','F'),
  ('Heidi','Aguilar','P'),
  ('Hunter','Fulton','E'),
  ('Armando','William','Y'),
  ('Maya','Calhoun','N'),
  ('Nicole','Mooney','J'),
  ('Abbot','Mack','I'),
  ('Ulysses','Woodard','C'),
  ('Macon','Craig','O'),
  ('Alfonso','Barron','G'),
  ('Amos','Bentley','I'),
  ('Quail','Hall','Y'),
  ('Adena','Stone','W'),
  ('Ainsley','Cain','T'),
  ('Rebekah','Murphy','W'),
  ('Forrest','Freeman','X'),
  ('Hillary','Cotton','Z'),
  ('Aidan','Bishop','S'),
  ('Wesley','Perez','E'),
  ('Cathleen','Fitzgerald','G'),
  ('Destiny','Mckinney','P'),
  ('Talon','Dunn','W'),
  ('Lareina','Wallace','L'),
  ('Adrian','Odom','I'),
  ('Tashya','Mcintyre','U'),
  ('Gisela','Weeks','H'),
  ('Jordan','Knox','Y'),
  ('Hope','Arnold','F'),
  ('Blaze','Burnett','J'),
  ('Jennifer','Ramirez','P'),
  ('Dalton','Payne','M'),
  ('Rinah','Steele','E'),
  ('Robert','Gould','F'),
  ('Paki','Wall','B'),
  ('Chelsea','Fernandez','S'),
  ('Emi','Barr','J'),
  ('Macy','Conner','W'),
  ('Chava','Rodriquez','X'),
  ('Jasmine','Lowery','N'),
  ('Baker','Mcpherson','E'),
  ('Abel','Alston','Q'),
  ('Lars','Fischer','S'),
  ('Shafira','Moses','M'),
  ('Wesley','Wells','S'),
  ('Aladdin','May','F'),
  ('Keelie','Estes','Q'),
  ('Tara','Kim','M'),
  ('Harding','Todd','L'),
  ('Hasad','Maynard','S'),
  ('Sybil','Livingston','U'),
  ('Cynthia','Horton','J'),
  ('Nerea','Morton','T'),
  ('Sylvia','Olsen','Z'),
  ('Aline','Kaufman','O');


end
go


begin -- Clients


CREATE TABLE [dbo].[Clients]
(
	[ClientsId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [PersonId] INT NOT NULL, 
    [PassportNumber] VARCHAR(40) NOT NULL, 
    CONSTRAINT [FK_Clients_Persons] FOREIGN KEY ([ClientsId]) REFERENCES [Persons]([PersonsId])
);


INSERT INTO Clients
VALUES
  (75,'ES2064574771645257430336'),
  (8,'RS06356552046137541594'),
  (17,'EE511890845578625480'),
  (83,'SI06187525304762833'),
  (88,'RO33GPSV4920634731782633'),
  (53,'IL862138922745912381925'),
  (89,'IE82MZED69235572325458'),
  (4,'AZ09201467186488721279452985'),
  (22,'EE254871881263655675'),
  (92,'CH3872112718585412152'),
  (77,'DK6282055251153495'),
  (85,'GR8116181256841692887854783'),
  (82,'MR5347735871856424805844917'),
  (23,'GR3847294375641445012785624'),
  (35,'FI8312972728347569'),
  (12,'GE17447657250334155577'),
  (60,'DO45918338354227674141684844'),
  (90,'EE122207555773187545'),
  (69,'AL60255020938352535115581525'),
  (38,'FR4132893184835510338370123'),
  (16,'GT72304215848102027343416512'),
  (36,'RO26FUOB1065365844323842'),
  (80,'ME39147169064280898388'),
  (51,'PK4233158164557825138566'),
  (37,'PS731381729897524076610741338'),
  (23,'CR1838992129852548286'),
  (86,'HU75057914168128374773318685'),
  (71,'BA831241442577052828'),
  (52,'HU96924370513215790498749775'),
  (74,'LU664775586182298252'),
  (27,'AL97230017486753046262822134'),
  (40,'FR3013288459401184861431229'),
  (95,'GR2734274176435316278347466'),
  (48,'ES0878472375196741673853'),
  (67,'DK7113508815614451'),
  (9,'MT51XGCP34579605766644745559239'),
  (74,'ES9647553306617302113167'),
  (11,'SA3979250148748696162664'),
  (89,'KZ766657211556220484'),
  (14,'LU919060158490354210'),
  (72,'ES7822352857904771875428'),
  (26,'IS938436548112756651477228'),
  (52,'KZ353813373847433865'),
  (13,'PT98853475581382417717571'),
  (92,'LV48TOFL6337347818530'),
  (41,'TN5087892063423440292825'),
  (55,'SE2380846622464246851830'),
  (40,'LV18VGCJ1653733010852'),
  (34,'PS782562861468732517372102447'),
  (80,'EE438574721343822293'),
  (83,'IL814839225135733815981'),
  (89,'MU2185172148089594468093700582'),
  (17,'PS585563813685887727313667875'),
  (72,'PL78039615166451504338189854'),
  (48,'BG77TUWP69636733383114'),
  (10,'LU064219674474886713'),
  (46,'PL05722922185557644334199879'),
  (98,'IE54IEXK95317925522281'),
  (8,'MC9332655412874718173781066'),
  (30,'PT81855336093183375218874'),
  (79,'CR6283649698894444363'),
  (73,'EE664953836241235085'),
  (32,'DO80395288114467260314072866'),
  (64,'GB33BXJE75735936873586'),
  (49,'MK45243486175343442'),
  (81,'LB04662048957236370164954692'),
  (46,'FO5717155958301034'),
  (71,'KW8826287853528784236318743668'),
  (60,'CZ9020893751728745075240'),
  (4,'FI9455605717271957'),
  (79,'LT648211912773861824'),
  (79,'SA8426507833987577497635'),
  (44,'FI3445559413538128'),
  (6,'BG74ZTQM81783153619131'),
  (75,'LU636308941433112793'),
  (21,'ME84348178214945635235'),
  (58,'CZ7444112674123601481583'),
  (58,'TN7477061694039126927300'),
  (36,'FO3333599618483221'),
  (94,'MT76KOFO15785542795824898382834'),
  (89,'RO67CKNS1327980238968485'),
  (93,'FI8801523024781458'),
  (94,'MC1973401248613427884764667'),
  (63,'AD1581225872487864387232'),
  (72,'KW6226920723517215865908608546'),
  (11,'HR8554816675027859634'),
  (11,'AL55941565652789347515812887'),
  (34,'CY07162143940458398301547864'),
  (99,'AZ58601877812577345697853747'),
  (14,'IE27RJXD52410430345239'),
  (26,'ES1609346661474624323681'),
  (56,'RS50522954232178799711'),
  (10,'SE9362141349340779606751'),
  (90,'MU0361202734262797838446433794'),
  (39,'DE09042582603317619241'),
  (7,'KZ024340365674634212'),
  (47,'MD2495836873968423412222'),
  (81,'RO98RQRB4282512571059325'),
  (24,'LT205607421111124120'),
  (63,'RO07TEPL3915726761858132');


end
go


begin -- Agents


CREATE TABLE [dbo].[Agents]
(
	[AgentsId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [PersonId] INT NOT NULL, 
    [DealPercent] FLOAT NOT NULL, 
    CONSTRAINT [FK_Agents_Persons] FOREIGN KEY ([PersonId]) REFERENCES [Persons]([PersonsId]), 
    CONSTRAINT [CK_Agents_DealPercent] CHECK ([DealPercent] >= 0)
);


INSERT INTO Agents
VALUES
  (18,8),
  (41,6),
  (88,1),
  (54,5),
  (68,7),
  (78,3),
  (68,4),
  (71,2),
  (8,5),
  (60,6),
  (2,9),
  (17,7),
  (82,5),
  (80,8),
  (85,10),
  (88,1),
  (74,0),
  (17,9),
  (46,5),
  (34,6),
  (83,3),
  (95,4),
  (10,1),
  (38,7),
  (23,4),
  (23,2),
  (45,9),
  (45,2),
  (62,7),
  (99,8),
  (1,7),
  (100,7),
  (90,4),
  (39,3),
  (96,6),
  (86,6),
  (82,4),
  (97,7),
  (88,9),
  (51,9),
  (7,4),
  (88,8),
  (55,9),
  (98,8),
  (16,8),
  (39,6),
  (75,7),
  (28,2),
  (86,2),
  (37,1),
  (79,8),
  (75,8),
  (3,4),
  (84,6),
  (33,5),
  (54,5),
  (31,5),
  (5,6),
  (83,2),
  (54,7),
  (32,3),
  (95,9),
  (23,8),
  (23,7),
  (96,5),
  (36,3),
  (39,10),
  (24,3),
  (50,2),
  (66,8),
  (63,7),
  (87,6),
  (4,1),
  (70,1),
  (19,5),
  (47,5),
  (10,8),
  (44,4),
  (21,2),
  (41,9),
  (20,5),
  (26,8),
  (37,8),
  (53,0),
  (37,4),
  (28,3),
  (31,3),
  (17,9),
  (29,9),
  (18,4),
  (91,8),
  (25,4),
  (24,3),
  (99,6),
  (55,10),
  (84,1),
  (47,4),
  (65,9),
  (41,9),
  (7,8);


end
go


begin -- Apartments


CREATE TABLE [dbo].[Apartments]
(
	[ApartmentsId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Street] NVARCHAR(50) NOT NULL, 
    [House] NVARCHAR(20) NOT NULL, 
    [Number] NVARCHAR(10) NOT NULL,
    [Area] FLOAT NOT NULL,
    [Rooms] INT NOT NULL,
    [Price] MONEY NOT NULL, 
    [OwnerId] INT NOT NULL, 
    CONSTRAINT [FK_Apartments_Clients] FOREIGN KEY ([OwnerId]) REFERENCES [Clients]([ClientsId]), 
    CONSTRAINT [CK_Apartments_Price] CHECK ([Price] >= 0),
    CONSTRAINT [CK_Apartments_Rooms] CHECK ([Rooms] >= 0),
    CONSTRAINT [CK_Apartments_Area] CHECK ([Area] > 0),
);


INSERT INTO Apartments
VALUES
  ('magna,',76,68,23,5,58634728,69),
  ('id,',56,88,107,3,53579106,49),
  ('nec,',15,37,133,5,12400333,46),
  ('commodo',10,40,199,1,35213941,65),
  ('hymenaeos.',24,12,35,2,47204588,17),
  ('vel',64,36,110,5,22956497,35),
  ('pede.',79,63,198,2,66818567,20),
  ('a, scelerisque',38,81,48,4,22050718,90),
  ('ornare lectus justo',99,28,194,3,25560943,40),
  ('mauris sit',95,77,120,5,59490137,14),
  ('eros.',13,14,30,3,36984777,19),
  ('eleifend',8,60,165,1,16078960,4),
  ('facilisis lorem tristique',38,2,188,3,42438628,51),
  ('nec',96,54,124,2,53858050,97),
  ('tincidunt adipiscing.',94,20,183,2,50183971,42),
  ('vitae dolor.',3,63,182,3,10634308,94),
  ('erat nonummy',18,78,95,5,46359911,74),
  ('arcu vel',84,68,83,4,30721607,47),
  ('dictum magna.',22,31,161,3,33374051,55),
  ('ac, fermentum',80,56,37,3,54040553,5),
  ('lorem eu',56,6,132,5,3203377,34),
  ('ac',16,56,64,5,9618459,79),
  ('mauris elit, dictum',29,57,178,2,28418469,92),
  ('euismod urna.',3,47,32,5,43365458,58),
  ('Phasellus libero mauris,',14,31,27,3,52116359,76),
  ('egestas a, scelerisque',78,44,78,3,11266354,48),
  ('sapien imperdiet ornare.',15,99,111,4,1699551,2),
  ('risus. Donec nibh',21,89,33,2,18598661,24),
  ('interdum. Sed',98,80,170,3,20240697,14),
  ('eu tellus.',82,62,58,2,61835070,37),
  ('sagittis felis. Donec',49,71,46,3,67601344,90),
  ('mi. Duis',13,70,140,1,37292498,36),
  ('sit amet orci.',58,97,66,4,11960348,40),
  ('arcu. Vestibulum ante',95,91,129,4,12485269,62),
  ('nisl elementum',36,62,123,2,36457665,92),
  ('ante bibendum',61,38,91,3,18547643,48),
  ('amet, consectetuer',18,53,184,3,60597246,66),
  ('purus. Duis',4,59,128,5,40730928,66),
  ('in consequat',89,74,91,3,11683498,12),
  ('Nullam enim. Sed',90,74,24,4,15762969,72),
  ('Cras',90,65,186,5,31594030,81),
  ('Nam ligula',52,14,41,2,37126539,43),
  ('Mauris vestibulum, neque',82,36,41,4,24176650,4),
  ('Integer',76,11,91,5,59610530,8),
  ('congue a,',57,95,88,2,8583373,59),
  ('pede. Cum sociis',6,50,118,4,53636612,44),
  ('vestibulum',33,76,109,2,19727621,74),
  ('accumsan neque et',98,24,38,1,23905816,71),
  ('ultricies dignissim lacus.',83,82,31,4,48002320,30),
  ('eu eros. Nam',37,56,165,3,63516842,3),
  ('nunc sit',92,43,103,1,58793048,38),
  ('tincidunt',90,88,69,4,69289092,75),
  ('magna sed dui.',38,80,149,3,69373401,35),
  ('dui, in',78,68,164,4,44978675,32),
  ('arcu.',37,66,41,3,56722161,53),
  ('Sed',14,98,93,1,46920924,86),
  ('lacinia',57,18,27,3,31960633,52),
  ('magna. Phasellus dolor',18,67,28,4,13154347,34),
  ('tristique senectus',22,4,44,2,27114789,64),
  ('Duis sit amet',32,65,32,2,24816036,65),
  ('Nullam feugiat',23,67,84,1,1619856,73),
  ('semper tellus id',20,23,163,3,24684227,89),
  ('justo. Proin',37,5,63,3,39712135,21),
  ('adipiscing',47,25,63,4,33435406,59),
  ('dis',28,44,123,2,30410194,48),
  ('nec, euismod',12,8,29,5,45103057,93),
  ('quam a',1,58,132,4,42161708,68),
  ('sollicitudin adipiscing',12,58,118,2,34508930,81),
  ('tortor nibh sit',38,90,32,1,31931272,99),
  ('Nunc commodo',98,55,182,2,47322504,93),
  ('amet',56,20,21,2,64593169,58),
  ('dis parturient montes,',69,76,92,1,52409276,16),
  ('Etiam',71,23,118,4,45366498,98),
  ('turpis non',98,44,49,4,24671172,2),
  ('ac, fermentum',41,29,173,3,21476776,72),
  ('Aliquam',49,52,136,4,33106578,93),
  ('gravida',13,9,35,3,7926023,2),
  ('Donec feugiat metus',63,88,140,1,21598898,15),
  ('laoreet, libero',24,71,190,1,25273151,92),
  ('leo, in',36,65,135,4,62087693,74),
  ('consequat dolor',18,23,105,4,44543029,70),
  ('luctus vulputate, nisi',93,77,104,4,47723063,99),
  ('ornare, lectus',26,29,47,2,57020186,50),
  ('massa lobortis ultrices.',35,95,53,3,62237830,80),
  ('dolor dolor,',45,83,146,3,15530727,29),
  ('a',51,66,181,1,30653426,20),
  ('molestie dapibus ligula.',18,30,88,5,53003042,48),
  ('justo sit amet',69,95,131,3,54185577,58),
  ('consequat, lectus',68,88,128,3,67067120,89),
  ('felis purus',26,26,62,2,67970615,20),
  ('Pellentesque ut ipsum',90,33,64,5,7686073,37),
  ('et, commodo at,',82,41,178,3,48463194,28),
  ('pede. Nunc',70,75,34,1,14166350,7),
  ('Nam',42,17,183,3,59219052,11),
  ('erat',67,37,25,3,59459561,7),
  ('tellus sem',40,72,84,1,41823396,93),
  ('ac',11,61,185,3,59574470,33),
  ('diam.',48,17,126,4,8795524,7),
  ('velit. Quisque',4,24,65,5,61838595,13),
  ('non',42,12,199,3,15970185,65);


end
go


begin -- Deals


CREATE TABLE [dbo].[Deals]
(
	[DealsId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [RegistrationDate] DATE NOT NULL, 
    [AgentId] INT NOT NULL, 
    [ApartmentId] INT NOT NULL, 
    CONSTRAINT [FK_Deals_Agents] FOREIGN KEY ([AgentId]) REFERENCES [Agents]([AgentsId]), 
    CONSTRAINT [FK_Deals_Apartments] FOREIGN KEY ([ApartmentId]) REFERENCES [Apartments]([ApartmentsId])
);


INSERT INTO Deals
VALUES
  ('03/14/2021',36,37),
  ('12/30/2021',5,20),
  ('08/12/2021',49,73),
  ('08/19/2021',20,73),
  ('10/25/2021',58,19),
  ('07/06/2022',97,82),
  ('11/30/2021',87,39),
  ('11/21/2020',35,88),
  ('05/12/2021',92,3),
  ('04/18/2021',82,28),
  ('03/24/2021',23,27),
  ('09/05/2022',79,18),
  ('02/17/2021',80,38),
  ('02/09/2021',38,61),
  ('11/06/2021',91,43),
  ('08/12/2022',80,93),
  ('10/11/2021',10,60),
  ('06/30/2022',43,20),
  ('10/21/2022',29,34),
  ('07/10/2021',31,59),
  ('12/28/2021',88,57),
  ('10/28/2022',99,40),
  ('09/28/2021',27,25),
  ('03/02/2022',64,26),
  ('07/31/2021',62,25),
  ('12/02/2021',33,91),
  ('08/23/2022',31,9),
  ('07/04/2021',82,32),
  ('06/21/2021',17,44),
  ('05/27/2022',80,13),
  ('02/26/2022',86,88),
  ('08/06/2022',66,51),
  ('03/26/2022',66,25),
  ('09/26/2022',57,98),
  ('11/10/2021',92,61),
  ('04/21/2021',30,73),
  ('05/08/2021',88,25),
  ('01/07/2021',13,84),
  ('12/06/2021',96,1),
  ('04/17/2021',89,63),
  ('10/23/2021',15,9),
  ('05/06/2021',22,82),
  ('12/14/2021',24,92),
  ('10/16/2021',44,94),
  ('04/27/2022',80,37),
  ('09/13/2021',78,39),
  ('03/29/2021',26,48),
  ('03/12/2021',76,33),
  ('09/19/2021',81,83),
  ('04/04/2021',72,96),
  ('06/27/2021',88,86),
  ('02/12/2022',14,4),
  ('11/18/2020',82,34),
  ('03/29/2022',85,12),
  ('08/15/2022',46,48),
  ('12/10/2020',57,27),
  ('09/02/2022',2,79),
  ('10/23/2021',46,21),
  ('12/11/2020',41,13),
  ('01/02/2022',92,18),
  ('05/04/2021',31,75),
  ('07/29/2021',48,79),
  ('05/21/2021',54,35),
  ('02/08/2021',82,10),
  ('06/17/2021',12,10),
  ('10/16/2021',73,25),
  ('06/06/2022',90,65),
  ('10/22/2021',70,27),
  ('02/19/2021',3,68),
  ('04/24/2021',25,40),
  ('09/13/2022',5,89),
  ('02/02/2021',39,21),
  ('09/08/2022',14,52),
  ('11/04/2021',60,61),
  ('11/03/2021',89,81),
  ('09/17/2022',3,49),
  ('12/12/2020',76,26),
  ('10/01/2021',73,71),
  ('12/07/2021',71,96),
  ('04/25/2021',71,51),
  ('11/25/2021',90,31),
  ('10/10/2022',28,48),
  ('08/29/2022',25,13),
  ('10/07/2021',69,53),
  ('02/17/2022',44,64),
  ('07/21/2021',75,2),
  ('10/26/2021',81,84),
  ('11/02/2021',33,32),
  ('12/14/2021',76,58),
  ('05/09/2021',16,48),
  ('07/06/2022',2,70),
  ('11/02/2021',95,41),
  ('04/15/2022',41,2),
  ('12/15/2020',60,46),
  ('03/04/2022',39,88),
  ('07/28/2022',48,14),
  ('12/03/2020',81,85),
  ('05/01/2022',68,91),
  ('04/26/2022',8,19),
  ('04/27/2021',12,11);


end
go


-- VIEWS
CREATE VIEW [dbo].[ClientsView]
    AS 
	select * from Clients c
	join Persons p on c.PersonId = p.PersonsId
go


CREATE VIEW [dbo].[AgentsView]
    AS 
	select * from Agents a
	join Persons p on a.PersonId = p.PersonsId
go


CREATE VIEW [dbo].[ApartmentsView]
    AS 
	select * from Apartments a
	join ClientsView c on a.OwnerId = c.ClientsId
go


CREATE VIEW [dbo].[DealsView]
    AS 
	select 
        d.DealsId,
        d.RegistrationDate,

        ag.AgentsId,
        ag.DealPercent,
        ag.Firstname as AgentFirstname,
        ag.Patronymic as AgentPatronymic,
        ag.Surname as AgentSurname,

        ap.ApartmentsId,
        ap.Price,
        ap.Area,
        ap.Rooms,
        ap.Street,
        ap.House,
        ap.Number,
        ap.ClientsId,
        ap.Firstname as ClientFirstname,
        ap.Patronymic as ClientPatronymic,
        ap.Surname as ClientSurname,
        ap.PassportNumber
    from Deals d
	join AgentsView ag on d.AgentId = ag.AgentsId
    join ApartmentsView ap on d.ApartmentId = ap.ApartmentsId
go