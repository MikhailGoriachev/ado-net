﻿-- 1. Хранимая процедура
--    Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа,
--    стоимость 1 экземпляра для которых меньше заданной.
--    Требуется модельдля вывода данных – данные выборки помещать в коллекцию
drop proc if exists ProcQuery01;
go

create proc ProcQuery01
    @price int,
    @pubType nvarchar(30)
as
begin
    select
        Id
        , PubIndex
        , PubType
        , Title
        , Price
    from 
        ViewPublications
    where
        PubType = @pubType and Price < @price;
end;
go

-- демонстрация процедуры
exec ProcQuery01 250,  N'журнал';
go


-- 2. Хранимая процедура	
--    Выбирает из таблиц информацию о подписчиках, проживающих на заданной 
--    параметром улице и номере дома, которые оформили подписку на издание 
--    с заданным параметром наименованием
drop proc if exists ProcQuery02;
go

create proc ProcQuery02
    @title nvarchar(80),
    @street nvarchar(30),
    @building nvarchar(10)
as
begin
    select
        Id
        , Surname + N' ' + Substring([Name], 1, 1) + N'.' + Substring(Patronymic, 1, 1) + N'.' as Subscriber 
        , Passport
        , Street + N',  д. ' + Building + N', кв. ' + LTrim(Str(Flat, 5)) as [Address] 
        , PubType
        , Title
    from
        ViewDeliveries
    where
        Street = @street and Building = @building and Title = @title;
end;
go

-- демонстрация процедуры
exec ProcQuery02 N'Юный техник',  N'ул. Садовая', N'118';
go

-- 3. Хранимая процедура	
--    Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение
--    в поле Цена 1 экземпляра находится в заданном диапазоне значений
--    Требуется модель для вывода данных – данные выборки помещать в коллекцию
drop proc if exists ProcQuery03;
go

create proc ProcQuery03
    @lo int,
    @hi int
as
begin
     select
        Id
        , PubIndex
        , PubType
        , Title
        , Price
    from 
        ViewPublications
    where
        Price between @lo and @hi;
end;
go

-- демонстрация процедуры
exec ProcQuery03 100, 150;
go



-- 4. Хранимая процедура	
--    Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания
--    Требуется модель для вывода данных – данные выборки помещать в коллекцию
drop proc if exists ProcQuery04;
go

create proc ProcQuery04
    @pubType nvarchar(30)
as
begin
    select
        Id
        , Surname + N' ' + Substring([Name], 1, 1) + N'.' + Substring(Patronymic, 1, 1) + N'.' as Subscriber 
        , Passport
        , Street + N',  д. ' + Building + N', кв. ' + LTrim(Str(Flat, 5)) as [Address] 
        , PubType
        , Title
    from
        ViewDeliveries
    where
        PubType = @pubType;
end;
go

-- демонстрация процедуры
exec ProcQuery04 N'газета';
go

-- 5. Хранимая процедура	
--    Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКИ информацию обо всех оформленных 
--    подписках, для которых срок подписки есть значение из некоторого диапазона. 
drop proc if exists ProcQuery05;
go

create proc ProcQuery05
    @lo int,
    @hi int
as
begin
     select
        Id
        , Title
        , PubType
        , Duration
        , DateStart
    from 
        ViewDeliveries
    where
        Duration between @lo and @hi;
end;
go

-- демонстрация процедуры
exec ProcQuery05 3, 4;
go


-- 6. Хранимая процедура		
--    Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС 
--    Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата 
--    начала подписки, Срок подписки, Стоимость подписки без НДС. Сортировка по 
--    полю Индекс издания
drop proc if exists ProcQuery06;
go

create proc ProcQuery06
as
begin
    select
        Id
        , PubIndex
        , Title
        , Price
        , DateStart
        , Duration
        -- стоимость подписки с доставкой (1%) и без НДС 
        , 1.01 * (Price * Duration) as SubscribeCost
    from
        ViewDeliveries
    order by
        PubIndex;
end;
go

-- демонстрация процедуры
exec ProcQuery06;
go

-- 7. Хранимая процедура
--    Выполняет группировку по полю Вид издания. Для каждого вида вычисляет 
--    максимальную и минимальную цену 1 экземпляра
drop proc if exists ProcQuery07;
go

create proc ProcQuery07
as
begin
    select
        PubTypes.PubType
        , Count(Publications.Id) as Amount
        , Max(Publications.Price) as MaxPrice
        , Min(Publications.Price) as MinPrice
    from
        Publications join PubTypes on Publications.IdPubType = PubTypes.Id
    group by
        PubTypes.PubType;
end;
go

-- демонстрация процедуры
exec ProcQuery07;
go

-- 8. Хранимая процедура	
--    Выполняет группировку по полю Улица. Для всех улиц вычисляет количество 
--    подписчиков, проживающих на данной улице (итоги по полю Код получателя)
drop proc if exists ProcQuery08;
go

create proc ProcQuery08
as
begin
    select
        Streets.Street
        , Count(Deliveries.IdSubscriber) as Amount
    from
        Streets left join (Subscribers join Deliveries on Subscribers.Id = Deliveries.IdSubscriber)
            on Streets.Id = Subscribers.IdStreet
    group by
        Streets.Street;
end;
go

-- демонстрация процедуры
exec ProcQuery08;
go


-- 9. Хранимая процедура	
--    Для всех изданий выводит количество оформленных подписок
drop proc if exists ProcQuery09;
go

create proc ProcQuery09
as
begin
    select
        Title
        , Count(Id) as Amount
    from
        ViewDeliveries
    group by
        Title;
end;
go

-- демонстрация процедуры
exec ProcQuery09;
go

