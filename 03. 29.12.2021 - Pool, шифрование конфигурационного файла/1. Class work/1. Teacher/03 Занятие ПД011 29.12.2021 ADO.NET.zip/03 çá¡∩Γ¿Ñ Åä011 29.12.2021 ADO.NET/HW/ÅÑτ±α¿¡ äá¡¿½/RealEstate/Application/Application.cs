﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RealEstate.Controllers;

namespace RealEstate.Application
{
    // данные для обработки и конструкторы
    public partial class App
    {
        private QueriesController _queriesController;

        //  конструктор по умолчанию

        public App():this(new QueriesController()) { }
        public App(string connectingString): this(new QueriesController(connectingString)) { }

        public App(QueriesController queriesController)
        {
            _queriesController = queriesController;
        }
    }
}
