﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Railway.Models
{
	// Структура данных для формирования строки таблицы
	public class CarTableModel
	{
		public int CarNumber { get; set; }
		// Тип вагона
		public string CarType { get; set; }
		// Номер купе
		public int CompartmentNumber { get; set; }
		// Номер места
		public int PlaceNumber { get; set; }
		// Состояние места
		public string PlaceState { get; set; }
	}
}
