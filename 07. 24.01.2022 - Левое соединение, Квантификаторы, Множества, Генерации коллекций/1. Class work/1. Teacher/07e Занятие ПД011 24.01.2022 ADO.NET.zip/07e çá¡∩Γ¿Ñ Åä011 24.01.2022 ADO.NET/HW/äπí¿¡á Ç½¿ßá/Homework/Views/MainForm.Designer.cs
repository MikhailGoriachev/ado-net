﻿namespace Homework.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpMain = new System.Windows.Forms.TabPage();
            this.DgvUnits = new System.Windows.Forms.DataGridView();
            this.DgvGoods = new System.Windows.Forms.DataGridView();
            this.DgvPersons = new System.Windows.Forms.DataGridView();
            this.LblMain = new System.Windows.Forms.Label();
            this.TbpQuery01 = new System.Windows.Forms.TabPage();
            this.DgvQuery01 = new System.Windows.Forms.DataGridView();
            this.LblQuery01 = new System.Windows.Forms.Label();
            this.TbpQuery02 = new System.Windows.Forms.TabPage();
            this.DgvQuery02 = new System.Windows.Forms.DataGridView();
            this.LblQuery02 = new System.Windows.Forms.Label();
            this.TbpQuery03 = new System.Windows.Forms.TabPage();
            this.DgvQuery03 = new System.Windows.Forms.DataGridView();
            this.LblQuery03 = new System.Windows.Forms.Label();
            this.TbpQuery04 = new System.Windows.Forms.TabPage();
            this.DgvQuery04 = new System.Windows.Forms.DataGridView();
            this.LblQuery04 = new System.Windows.Forms.Label();
            this.TbpQuery05 = new System.Windows.Forms.TabPage();
            this.DgvQuery05 = new System.Windows.Forms.DataGridView();
            this.LblQuery05 = new System.Windows.Forms.Label();
            this.TbpQuery06 = new System.Windows.Forms.TabPage();
            this.DgvQuery06 = new System.Windows.Forms.DataGridView();
            this.LblQuery06 = new System.Windows.Forms.Label();
            this.TbpQuery07 = new System.Windows.Forms.TabPage();
            this.DgvQuery07 = new System.Windows.Forms.DataGridView();
            this.LblQuery07 = new System.Windows.Forms.Label();
            this.TbpQuery08 = new System.Windows.Forms.TabPage();
            this.DgvQuery08 = new System.Windows.Forms.DataGridView();
            this.LblQuery08 = new System.Windows.Forms.Label();
            this.DgvPurchases = new System.Windows.Forms.DataGridView();
            this.DgvSellers = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.longDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.запрос1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DgvSales = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronymicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleDateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salePriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasePriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.profitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultQuery06BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.averageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultQuery07and08BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.titleDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.averageDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.таблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаЕдиницИзмеренияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаПерсонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаПродавцовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаТоваровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаЗакупокToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.таблицаПродажToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvUnits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvGoods)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPersons)).BeginInit();
            this.TbpQuery01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).BeginInit();
            this.TbpQuery02.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).BeginInit();
            this.TbpQuery03.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery03)).BeginInit();
            this.TbpQuery04.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).BeginInit();
            this.TbpQuery05.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).BeginInit();
            this.TbpQuery06.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).BeginInit();
            this.TbpQuery07.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery07)).BeginInit();
            this.TbpQuery08.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPurchases)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSellers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSales)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery06BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery07and08BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.таблицыToolStripMenuItem,
            this.запросыToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(862, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.файлToolStripMenuItem.Text = "&Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.выходToolStripMenuItem.Text = "&Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запрос1ToolStripMenuItem,
            this.запросToolStripMenuItem,
            this.запрос3ToolStripMenuItem,
            this.запрос4ToolStripMenuItem,
            this.запрос5ToolStripMenuItem,
            this.запрос6ToolStripMenuItem,
            this.запрос7ToolStripMenuItem,
            this.запрос8ToolStripMenuItem});
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(84, 24);
            this.запросыToolStripMenuItem.Text = "Запросы";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton13,
            this.toolStripButton11,
            this.toolStripButton15,
            this.toolStripButton12,
            this.toolStripButton14,
            this.toolStripButton16,
            this.toolStripSeparator1,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripButton10});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(862, 39);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpMain);
            this.TbcMain.Controls.Add(this.TbpQuery01);
            this.TbcMain.Controls.Add(this.TbpQuery02);
            this.TbcMain.Controls.Add(this.TbpQuery03);
            this.TbcMain.Controls.Add(this.TbpQuery04);
            this.TbcMain.Controls.Add(this.TbpQuery05);
            this.TbcMain.Controls.Add(this.TbpQuery06);
            this.TbcMain.Controls.Add(this.TbpQuery07);
            this.TbcMain.Controls.Add(this.TbpQuery08);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Location = new System.Drawing.Point(0, 67);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(862, 511);
            this.TbcMain.TabIndex = 2;
            // 
            // TbpMain
            // 
            this.TbpMain.Controls.Add(this.DgvSales);
            this.TbpMain.Controls.Add(this.DgvSellers);
            this.TbpMain.Controls.Add(this.DgvPurchases);
            this.TbpMain.Controls.Add(this.DgvUnits);
            this.TbpMain.Controls.Add(this.DgvGoods);
            this.TbpMain.Controls.Add(this.DgvPersons);
            this.TbpMain.Controls.Add(this.LblMain);
            this.TbpMain.Location = new System.Drawing.Point(4, 31);
            this.TbpMain.Name = "TbpMain";
            this.TbpMain.Padding = new System.Windows.Forms.Padding(3);
            this.TbpMain.Size = new System.Drawing.Size(854, 476);
            this.TbpMain.TabIndex = 0;
            this.TbpMain.Text = "Главная";
            this.TbpMain.UseVisualStyleBackColor = true;
            // 
            // DgvUnits
            // 
            this.DgvUnits.AllowUserToAddRows = false;
            this.DgvUnits.AllowUserToDeleteRows = false;
            this.DgvUnits.AutoGenerateColumns = false;
            this.DgvUnits.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvUnits.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn5,
            this.shortDataGridViewTextBoxColumn,
            this.longDataGridViewTextBoxColumn});
            this.DgvUnits.DataSource = this.unitsBindingSource;
            this.DgvUnits.Location = new System.Drawing.Point(3, 32);
            this.DgvUnits.MultiSelect = false;
            this.DgvUnits.Name = "DgvUnits";
            this.DgvUnits.ReadOnly = true;
            this.DgvUnits.RowHeadersVisible = false;
            this.DgvUnits.RowHeadersWidth = 51;
            this.DgvUnits.RowTemplate.Height = 24;
            this.DgvUnits.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvUnits.Size = new System.Drawing.Size(848, 440);
            this.DgvUnits.TabIndex = 5;
            this.DgvUnits.Visible = false;
            // 
            // DgvGoods
            // 
            this.DgvGoods.AllowUserToAddRows = false;
            this.DgvGoods.AllowUserToDeleteRows = false;
            this.DgvGoods.AutoGenerateColumns = false;
            this.DgvGoods.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvGoods.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn4,
            this.itemDataGridViewTextBoxColumn});
            this.DgvGoods.DataSource = this.goodsBindingSource;
            this.DgvGoods.Location = new System.Drawing.Point(3, 32);
            this.DgvGoods.MultiSelect = false;
            this.DgvGoods.Name = "DgvGoods";
            this.DgvGoods.ReadOnly = true;
            this.DgvGoods.RowHeadersVisible = false;
            this.DgvGoods.RowHeadersWidth = 51;
            this.DgvGoods.RowTemplate.Height = 24;
            this.DgvGoods.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvGoods.Size = new System.Drawing.Size(848, 440);
            this.DgvGoods.TabIndex = 4;
            this.DgvGoods.Visible = false;
            // 
            // DgvPersons
            // 
            this.DgvPersons.AllowUserToAddRows = false;
            this.DgvPersons.AllowUserToDeleteRows = false;
            this.DgvPersons.AutoGenerateColumns = false;
            this.DgvPersons.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvPersons.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.surnameDataGridViewTextBoxColumn1,
            this.nameDataGridViewTextBoxColumn1,
            this.patronymicDataGridViewTextBoxColumn1,
            this.passportDataGridViewTextBoxColumn});
            this.DgvPersons.DataSource = this.personsBindingSource;
            this.DgvPersons.Location = new System.Drawing.Point(3, 33);
            this.DgvPersons.MultiSelect = false;
            this.DgvPersons.Name = "DgvPersons";
            this.DgvPersons.ReadOnly = true;
            this.DgvPersons.RowHeadersVisible = false;
            this.DgvPersons.RowHeadersWidth = 51;
            this.DgvPersons.RowTemplate.Height = 24;
            this.DgvPersons.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvPersons.Size = new System.Drawing.Size(848, 440);
            this.DgvPersons.TabIndex = 3;
            this.DgvPersons.Visible = false;
            // 
            // LblMain
            // 
            this.LblMain.Location = new System.Drawing.Point(2, 3);
            this.LblMain.Name = "LblMain";
            this.LblMain.Size = new System.Drawing.Size(851, 41);
            this.LblMain.TabIndex = 2;
            // 
            // TbpQuery01
            // 
            this.TbpQuery01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.TbpQuery01.Controls.Add(this.DgvQuery01);
            this.TbpQuery01.Controls.Add(this.LblQuery01);
            this.TbpQuery01.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery01.Name = "TbpQuery01";
            this.TbpQuery01.Padding = new System.Windows.Forms.Padding(3);
            this.TbpQuery01.Size = new System.Drawing.Size(854, 482);
            this.TbpQuery01.TabIndex = 1;
            this.TbpQuery01.Text = "Запрос №1";
            this.TbpQuery01.UseVisualStyleBackColor = true;
            // 
            // DgvQuery01
            // 
            this.DgvQuery01.AllowUserToAddRows = false;
            this.DgvQuery01.AllowUserToDeleteRows = false;
            this.DgvQuery01.AutoGenerateColumns = false;
            this.DgvQuery01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery01.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.goodDataGridViewTextBoxColumn,
            this.unitDataGridViewTextBoxColumn,
            this.purchaseDateDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn});
            this.DgvQuery01.DataSource = this.purchaseBindingSource;
            this.DgvQuery01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery01.Location = new System.Drawing.Point(3, 39);
            this.DgvQuery01.MultiSelect = false;
            this.DgvQuery01.Name = "DgvQuery01";
            this.DgvQuery01.ReadOnly = true;
            this.DgvQuery01.RowHeadersVisible = false;
            this.DgvQuery01.RowHeadersWidth = 51;
            this.DgvQuery01.RowTemplate.Height = 24;
            this.DgvQuery01.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery01.Size = new System.Drawing.Size(848, 440);
            this.DgvQuery01.TabIndex = 1;
            // 
            // LblQuery01
            // 
            this.LblQuery01.Location = new System.Drawing.Point(3, 3);
            this.LblQuery01.Name = "LblQuery01";
            this.LblQuery01.Size = new System.Drawing.Size(851, 41);
            this.LblQuery01.TabIndex = 0;
            this.LblQuery01.Text = "Информация о товарах, единица измерения которых «шт» и цена закупки меньше 200 ру" +
    "б\r\n";
            // 
            // TbpQuery02
            // 
            this.TbpQuery02.Controls.Add(this.DgvQuery02);
            this.TbpQuery02.Controls.Add(this.LblQuery02);
            this.TbpQuery02.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery02.Name = "TbpQuery02";
            this.TbpQuery02.Size = new System.Drawing.Size(854, 482);
            this.TbpQuery02.TabIndex = 2;
            this.TbpQuery02.Text = "Запрос №2";
            this.TbpQuery02.UseVisualStyleBackColor = true;
            // 
            // DgvQuery02
            // 
            this.DgvQuery02.AllowUserToAddRows = false;
            this.DgvQuery02.AllowUserToDeleteRows = false;
            this.DgvQuery02.AutoGenerateColumns = false;
            this.DgvQuery02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery02.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.DgvQuery02.DataSource = this.purchaseBindingSource;
            this.DgvQuery02.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery02.Location = new System.Drawing.Point(0, 42);
            this.DgvQuery02.MultiSelect = false;
            this.DgvQuery02.Name = "DgvQuery02";
            this.DgvQuery02.ReadOnly = true;
            this.DgvQuery02.RowHeadersVisible = false;
            this.DgvQuery02.RowHeadersWidth = 51;
            this.DgvQuery02.RowTemplate.Height = 24;
            this.DgvQuery02.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery02.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery02.TabIndex = 3;
            // 
            // LblQuery02
            // 
            this.LblQuery02.Location = new System.Drawing.Point(3, 2);
            this.LblQuery02.Name = "LblQuery02";
            this.LblQuery02.Size = new System.Drawing.Size(786, 41);
            this.LblQuery02.TabIndex = 2;
            this.LblQuery02.Text = "Информация о товарах, цена закупки которых больше 500 руб";
            // 
            // TbpQuery03
            // 
            this.TbpQuery03.Controls.Add(this.DgvQuery03);
            this.TbpQuery03.Controls.Add(this.LblQuery03);
            this.TbpQuery03.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery03.Name = "TbpQuery03";
            this.TbpQuery03.Size = new System.Drawing.Size(854, 482);
            this.TbpQuery03.TabIndex = 3;
            this.TbpQuery03.Text = "Запрос №3";
            this.TbpQuery03.UseVisualStyleBackColor = true;
            // 
            // DgvQuery03
            // 
            this.DgvQuery03.AllowUserToAddRows = false;
            this.DgvQuery03.AllowUserToDeleteRows = false;
            this.DgvQuery03.AutoGenerateColumns = false;
            this.DgvQuery03.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery03.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.DgvQuery03.DataSource = this.purchaseBindingSource;
            this.DgvQuery03.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery03.Location = new System.Drawing.Point(0, 42);
            this.DgvQuery03.MultiSelect = false;
            this.DgvQuery03.Name = "DgvQuery03";
            this.DgvQuery03.ReadOnly = true;
            this.DgvQuery03.RowHeadersVisible = false;
            this.DgvQuery03.RowHeadersWidth = 51;
            this.DgvQuery03.RowTemplate.Height = 24;
            this.DgvQuery03.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery03.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery03.TabIndex = 3;
            // 
            // LblQuery03
            // 
            this.LblQuery03.Location = new System.Drawing.Point(3, 2);
            this.LblQuery03.Name = "LblQuery03";
            this.LblQuery03.Size = new System.Drawing.Size(848, 41);
            this.LblQuery03.TabIndex = 2;
            this.LblQuery03.Text = "Информация о товарах, с заданным наименованием, для которых цена закупки меньше 1" +
    "800 руб\r\n";
            // 
            // TbpQuery04
            // 
            this.TbpQuery04.Controls.Add(this.DgvQuery04);
            this.TbpQuery04.Controls.Add(this.LblQuery04);
            this.TbpQuery04.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery04.Name = "TbpQuery04";
            this.TbpQuery04.Size = new System.Drawing.Size(854, 482);
            this.TbpQuery04.TabIndex = 4;
            this.TbpQuery04.Text = "Запрос №4";
            this.TbpQuery04.UseVisualStyleBackColor = true;
            // 
            // DgvQuery04
            // 
            this.DgvQuery04.AllowUserToAddRows = false;
            this.DgvQuery04.AllowUserToDeleteRows = false;
            this.DgvQuery04.AutoGenerateColumns = false;
            this.DgvQuery04.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery04.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.surnameDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.patronymicDataGridViewTextBoxColumn,
            this.interestDataGridViewTextBoxColumn});
            this.DgvQuery04.DataSource = this.sellerBindingSource;
            this.DgvQuery04.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery04.Location = new System.Drawing.Point(0, 42);
            this.DgvQuery04.MultiSelect = false;
            this.DgvQuery04.Name = "DgvQuery04";
            this.DgvQuery04.ReadOnly = true;
            this.DgvQuery04.RowHeadersVisible = false;
            this.DgvQuery04.RowHeadersWidth = 51;
            this.DgvQuery04.RowTemplate.Height = 24;
            this.DgvQuery04.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery04.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery04.TabIndex = 4;
            // 
            // LblQuery04
            // 
            this.LblQuery04.Location = new System.Drawing.Point(3, 0);
            this.LblQuery04.Name = "LblQuery04";
            this.LblQuery04.Size = new System.Drawing.Size(851, 41);
            this.LblQuery04.TabIndex = 3;
            this.LblQuery04.Text = "Информация о продавцах с заданным значением процента комиссионных.";
            // 
            // TbpQuery05
            // 
            this.TbpQuery05.Controls.Add(this.DgvQuery05);
            this.TbpQuery05.Controls.Add(this.LblQuery05);
            this.TbpQuery05.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery05.Name = "TbpQuery05";
            this.TbpQuery05.Size = new System.Drawing.Size(854, 482);
            this.TbpQuery05.TabIndex = 5;
            this.TbpQuery05.Text = "Запрос №5";
            this.TbpQuery05.UseVisualStyleBackColor = true;
            // 
            // DgvQuery05
            // 
            this.DgvQuery05.AllowUserToAddRows = false;
            this.DgvQuery05.AllowUserToDeleteRows = false;
            this.DgvQuery05.AutoGenerateColumns = false;
            this.DgvQuery05.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery05.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.goodDataGridViewTextBoxColumn1,
            this.unitDataGridViewTextBoxColumn1,
            this.sellerDataGridViewTextBoxColumn,
            this.saleDateDataGridViewTextBoxColumn,
            this.salePriceDataGridViewTextBoxColumn,
            this.purchasePriceDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn1});
            this.DgvQuery05.DataSource = this.saleBindingSource;
            this.DgvQuery05.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery05.Location = new System.Drawing.Point(0, 42);
            this.DgvQuery05.MultiSelect = false;
            this.DgvQuery05.Name = "DgvQuery05";
            this.DgvQuery05.ReadOnly = true;
            this.DgvQuery05.RowHeadersVisible = false;
            this.DgvQuery05.RowHeadersWidth = 51;
            this.DgvQuery05.RowTemplate.Height = 24;
            this.DgvQuery05.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery05.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery05.TabIndex = 5;
            // 
            // LblQuery05
            // 
            this.LblQuery05.Location = new System.Drawing.Point(3, 0);
            this.LblQuery05.Name = "LblQuery05";
            this.LblQuery05.Size = new System.Drawing.Size(851, 41);
            this.LblQuery05.TabIndex = 4;
            this.LblQuery05.Text = "Информация о фактах продажи, для которых цена продажи в заданном диапазоне\r\n";
            // 
            // TbpQuery06
            // 
            this.TbpQuery06.Controls.Add(this.DgvQuery06);
            this.TbpQuery06.Controls.Add(this.LblQuery06);
            this.TbpQuery06.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery06.Name = "TbpQuery06";
            this.TbpQuery06.Size = new System.Drawing.Size(854, 482);
            this.TbpQuery06.TabIndex = 6;
            this.TbpQuery06.Text = "Запрос №6";
            this.TbpQuery06.UseVisualStyleBackColor = true;
            // 
            // DgvQuery06
            // 
            this.DgvQuery06.AllowUserToAddRows = false;
            this.DgvQuery06.AllowUserToDeleteRows = false;
            this.DgvQuery06.AutoGenerateColumns = false;
            this.DgvQuery06.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery06.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.saleDateDataGridViewTextBoxColumn1,
            this.goodDataGridViewTextBoxColumn2,
            this.salePriceDataGridViewTextBoxColumn1,
            this.purchasePriceDataGridViewTextBoxColumn1,
            this.amountDataGridViewTextBoxColumn2,
            this.profitDataGridViewTextBoxColumn});
            this.DgvQuery06.DataSource = this.resultQuery06BindingSource;
            this.DgvQuery06.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery06.Location = new System.Drawing.Point(0, 42);
            this.DgvQuery06.MultiSelect = false;
            this.DgvQuery06.Name = "DgvQuery06";
            this.DgvQuery06.ReadOnly = true;
            this.DgvQuery06.RowHeadersVisible = false;
            this.DgvQuery06.RowHeadersWidth = 51;
            this.DgvQuery06.RowTemplate.Height = 24;
            this.DgvQuery06.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery06.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery06.TabIndex = 6;
            // 
            // LblQuery06
            // 
            this.LblQuery06.Location = new System.Drawing.Point(3, 0);
            this.LblQuery06.Name = "LblQuery06";
            this.LblQuery06.Size = new System.Drawing.Size(851, 41);
            this.LblQuery06.TabIndex = 4;
            this.LblQuery06.Text = "Вычислить прибыль от продажи за каждый проданный товар";
            // 
            // TbpQuery07
            // 
            this.TbpQuery07.Controls.Add(this.DgvQuery07);
            this.TbpQuery07.Controls.Add(this.LblQuery07);
            this.TbpQuery07.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery07.Name = "TbpQuery07";
            this.TbpQuery07.Size = new System.Drawing.Size(854, 482);
            this.TbpQuery07.TabIndex = 7;
            this.TbpQuery07.Text = "Запрос №7";
            this.TbpQuery07.UseVisualStyleBackColor = true;
            // 
            // DgvQuery07
            // 
            this.DgvQuery07.AllowUserToAddRows = false;
            this.DgvQuery07.AllowUserToDeleteRows = false;
            this.DgvQuery07.AutoGenerateColumns = false;
            this.DgvQuery07.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery07.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.titleDataGridViewTextBoxColumn,
            this.averageDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn3});
            this.DgvQuery07.DataSource = this.resultQuery07and08BindingSource;
            this.DgvQuery07.Location = new System.Drawing.Point(0, 44);
            this.DgvQuery07.MultiSelect = false;
            this.DgvQuery07.Name = "DgvQuery07";
            this.DgvQuery07.ReadOnly = true;
            this.DgvQuery07.RowHeadersVisible = false;
            this.DgvQuery07.RowHeadersWidth = 51;
            this.DgvQuery07.RowTemplate.Height = 24;
            this.DgvQuery07.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery07.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery07.TabIndex = 6;
            // 
            // LblQuery07
            // 
            this.LblQuery07.Location = new System.Drawing.Point(0, 0);
            this.LblQuery07.Name = "LblQuery07";
            this.LblQuery07.Size = new System.Drawing.Size(851, 41);
            this.LblQuery07.TabIndex = 4;
            this.LblQuery07.Text = "Вычислить среднюю цену закупки товара и количество закупок для каждого товара";
            // 
            // TbpQuery08
            // 
            this.TbpQuery08.Controls.Add(this.DgvQuery08);
            this.TbpQuery08.Controls.Add(this.LblQuery08);
            this.TbpQuery08.Location = new System.Drawing.Point(4, 25);
            this.TbpQuery08.Name = "TbpQuery08";
            this.TbpQuery08.Size = new System.Drawing.Size(854, 482);
            this.TbpQuery08.TabIndex = 8;
            this.TbpQuery08.Text = "Запрос №8";
            this.TbpQuery08.UseVisualStyleBackColor = true;
            // 
            // DgvQuery08
            // 
            this.DgvQuery08.AllowUserToAddRows = false;
            this.DgvQuery08.AllowUserToDeleteRows = false;
            this.DgvQuery08.AutoGenerateColumns = false;
            this.DgvQuery08.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvQuery08.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.titleDataGridViewTextBoxColumn1,
            this.averageDataGridViewTextBoxColumn1,
            this.amountDataGridViewTextBoxColumn4});
            this.DgvQuery08.DataSource = this.resultQuery07and08BindingSource;
            this.DgvQuery08.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvQuery08.Location = new System.Drawing.Point(0, 42);
            this.DgvQuery08.MultiSelect = false;
            this.DgvQuery08.Name = "DgvQuery08";
            this.DgvQuery08.ReadOnly = true;
            this.DgvQuery08.RowHeadersVisible = false;
            this.DgvQuery08.RowHeadersWidth = 51;
            this.DgvQuery08.RowTemplate.Height = 24;
            this.DgvQuery08.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvQuery08.Size = new System.Drawing.Size(854, 440);
            this.DgvQuery08.TabIndex = 6;
            // 
            // LblQuery08
            // 
            this.LblQuery08.Location = new System.Drawing.Point(0, 0);
            this.LblQuery08.Name = "LblQuery08";
            this.LblQuery08.Size = new System.Drawing.Size(851, 60);
            this.LblQuery08.TabIndex = 4;
            this.LblQuery08.Text = "Вычислить среднюю цену продажи единицы товара и кол-во продаж для каждого продавц" +
    "а";
            // 
            // DgvPurchases
            // 
            this.DgvPurchases.AllowUserToAddRows = false;
            this.DgvPurchases.AllowUserToDeleteRows = false;
            this.DgvPurchases.AutoGenerateColumns = false;
            this.DgvPurchases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvPurchases.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.DgvPurchases.DataSource = this.purchaseBindingSource;
            this.DgvPurchases.Location = new System.Drawing.Point(3, 31);
            this.DgvPurchases.MultiSelect = false;
            this.DgvPurchases.Name = "DgvPurchases";
            this.DgvPurchases.ReadOnly = true;
            this.DgvPurchases.RowHeadersVisible = false;
            this.DgvPurchases.RowHeadersWidth = 51;
            this.DgvPurchases.RowTemplate.Height = 24;
            this.DgvPurchases.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvPurchases.Size = new System.Drawing.Size(854, 440);
            this.DgvPurchases.TabIndex = 6;
            this.DgvPurchases.Visible = false;
            // 
            // DgvSellers
            // 
            this.DgvSellers.AllowUserToAddRows = false;
            this.DgvSellers.AllowUserToDeleteRows = false;
            this.DgvSellers.AutoGenerateColumns = false;
            this.DgvSellers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSellers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23});
            this.DgvSellers.DataSource = this.sellerBindingSource;
            this.DgvSellers.Location = new System.Drawing.Point(3, 31);
            this.DgvSellers.MultiSelect = false;
            this.DgvSellers.Name = "DgvSellers";
            this.DgvSellers.ReadOnly = true;
            this.DgvSellers.RowHeadersVisible = false;
            this.DgvSellers.RowHeadersWidth = 51;
            this.DgvSellers.RowTemplate.Height = 24;
            this.DgvSellers.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvSellers.Size = new System.Drawing.Size(854, 440);
            this.DgvSellers.TabIndex = 7;
            this.DgvSellers.Visible = false;
            // 
            // idDataGridViewTextBoxColumn5
            // 
            this.idDataGridViewTextBoxColumn5.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn5.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn5.Name = "idDataGridViewTextBoxColumn5";
            this.idDataGridViewTextBoxColumn5.ReadOnly = true;
            this.idDataGridViewTextBoxColumn5.Width = 125;
            // 
            // shortDataGridViewTextBoxColumn
            // 
            this.shortDataGridViewTextBoxColumn.DataPropertyName = "Short";
            this.shortDataGridViewTextBoxColumn.HeaderText = "Сокращенное наименование";
            this.shortDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.shortDataGridViewTextBoxColumn.Name = "shortDataGridViewTextBoxColumn";
            this.shortDataGridViewTextBoxColumn.ReadOnly = true;
            this.shortDataGridViewTextBoxColumn.Width = 300;
            // 
            // longDataGridViewTextBoxColumn
            // 
            this.longDataGridViewTextBoxColumn.DataPropertyName = "Long";
            this.longDataGridViewTextBoxColumn.HeaderText = "Полное наименование";
            this.longDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.longDataGridViewTextBoxColumn.Name = "longDataGridViewTextBoxColumn";
            this.longDataGridViewTextBoxColumn.ReadOnly = true;
            this.longDataGridViewTextBoxColumn.Width = 450;
            // 
            // unitsBindingSource
            // 
            this.unitsBindingSource.DataSource = typeof(Homework.Models.Units);
            // 
            // idDataGridViewTextBoxColumn4
            // 
            this.idDataGridViewTextBoxColumn4.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn4.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn4.Name = "idDataGridViewTextBoxColumn4";
            this.idDataGridViewTextBoxColumn4.ReadOnly = true;
            this.idDataGridViewTextBoxColumn4.Width = 125;
            // 
            // itemDataGridViewTextBoxColumn
            // 
            this.itemDataGridViewTextBoxColumn.DataPropertyName = "Item";
            this.itemDataGridViewTextBoxColumn.HeaderText = "Наименование товара";
            this.itemDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.itemDataGridViewTextBoxColumn.Name = "itemDataGridViewTextBoxColumn";
            this.itemDataGridViewTextBoxColumn.ReadOnly = true;
            this.itemDataGridViewTextBoxColumn.Width = 750;
            // 
            // goodsBindingSource
            // 
            this.goodsBindingSource.DataSource = typeof(Homework.Models.Goods);
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn3.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            this.idDataGridViewTextBoxColumn3.ReadOnly = true;
            this.idDataGridViewTextBoxColumn3.Width = 125;
            // 
            // surnameDataGridViewTextBoxColumn1
            // 
            this.surnameDataGridViewTextBoxColumn1.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn1.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.surnameDataGridViewTextBoxColumn1.Name = "surnameDataGridViewTextBoxColumn1";
            this.surnameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.surnameDataGridViewTextBoxColumn1.Width = 170;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "Имя";
            this.nameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            this.nameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn1.Width = 170;
            // 
            // patronymicDataGridViewTextBoxColumn1
            // 
            this.patronymicDataGridViewTextBoxColumn1.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn1.HeaderText = "Отчество";
            this.patronymicDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.patronymicDataGridViewTextBoxColumn1.Name = "patronymicDataGridViewTextBoxColumn1";
            this.patronymicDataGridViewTextBoxColumn1.ReadOnly = true;
            this.patronymicDataGridViewTextBoxColumn1.Width = 170;
            // 
            // passportDataGridViewTextBoxColumn
            // 
            this.passportDataGridViewTextBoxColumn.DataPropertyName = "Passport";
            this.passportDataGridViewTextBoxColumn.HeaderText = "Серия и номер паспорта";
            this.passportDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passportDataGridViewTextBoxColumn.Name = "passportDataGridViewTextBoxColumn";
            this.passportDataGridViewTextBoxColumn.ReadOnly = true;
            this.passportDataGridViewTextBoxColumn.Width = 250;
            // 
            // personsBindingSource
            // 
            this.personsBindingSource.DataSource = typeof(Homework.Models.Persons);
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = global::Homework.Properties.Resources.box;
            this.toolStripButton13.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton13.Text = "toolStripButton13";
            this.toolStripButton13.ToolTipText = "Вывести таблицу единиц измерения\r\n";
            this.toolStripButton13.Click += new System.EventHandler(this.ShowUnits_Command);
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = global::Homework.Properties.Resources.Owner;
            this.toolStripButton11.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.Size = new System.Drawing.Size(34, 36);
            this.toolStripButton11.Text = "toolStripButton11";
            this.toolStripButton11.ToolTipText = "Вывести таблицу персон";
            this.toolStripButton11.Click += new System.EventHandler(this.ShowPersons_Command);
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton15.Image = global::Homework.Properties.Resources.seller;
            this.toolStripButton15.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton15.Text = "toolStripButton15";
            this.toolStripButton15.ToolTipText = "Вывести таблицу продавцов";
            this.toolStripButton15.Click += new System.EventHandler(this.ShowSellers_Command);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = global::Homework.Properties.Resources.Select;
            this.toolStripButton12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.Size = new System.Drawing.Size(34, 36);
            this.toolStripButton12.Text = "toolStripButton12";
            this.toolStripButton12.ToolTipText = "Вывести таблицу товаров";
            this.toolStripButton12.Click += new System.EventHandler(this.ShowGoods_Command);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = global::Homework.Properties.Resources.purchase;
            this.toolStripButton14.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton14.Text = "toolStripButton14";
            this.toolStripButton14.ToolTipText = "Вывести таблицу закупок\r\n";
            this.toolStripButton14.Click += new System.EventHandler(this.ShowPurchases_Command);
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton16.Image = global::Homework.Properties.Resources.sale;
            this.toolStripButton16.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton16.Text = "toolStripButton16";
            this.toolStripButton16.ToolTipText = "Вывевсти таблицу продаж";
            this.toolStripButton16.Click += new System.EventHandler(this.ShowSales_Command);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::Homework.Properties.Resources._1;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Запрос №1.\r\nИнформация о товарах, единица измерения которых «шт» \r\nи цена закупки" +
    " меньше 200 руб";
            this.toolStripButton1.Click += new System.EventHandler(this.Query01_Command);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::Homework.Properties.Resources._2;
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Запрос №2.\r\nИнформация о товарах, цена закупки которых больше 500 руб";
            this.toolStripButton2.Click += new System.EventHandler(this.Query02_Command);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::Homework.Properties.Resources._3;
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.ToolTipText = "Запрос №3.\r\nИнформация о товарах, с заданным наименованием, \r\nдля которых цена за" +
    "купки меньше 1800 руб";
            this.toolStripButton3.Click += new System.EventHandler(this.Query03_Command);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::Homework.Properties.Resources._4;
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton4.Text = "toolStripButton1";
            this.toolStripButton4.ToolTipText = "Запрос №4.\r\nИнформация о продавцах с заданным значением процента комиссионных.";
            this.toolStripButton4.Click += new System.EventHandler(this.Query04_Command);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::Homework.Properties.Resources._5;
            this.toolStripButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton5.Text = "toolStripButton2";
            this.toolStripButton5.ToolTipText = "Запрос №5.\r\nИнформация о фактах продажи, для которых \r\nцена продажи в заданном ди" +
    "апазоне";
            this.toolStripButton5.Click += new System.EventHandler(this.Query05_Command);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::Homework.Properties.Resources._6;
            this.toolStripButton6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton6.Text = "toolStripButton3";
            this.toolStripButton6.ToolTipText = "Запрос №6\r\nВычислить прибыль от продажи за каждый проданный товар";
            this.toolStripButton6.Click += new System.EventHandler(this.Query06_Command);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = global::Homework.Properties.Resources._7;
            this.toolStripButton7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton7.Text = "toolStripButton1";
            this.toolStripButton7.ToolTipText = "Запрос №7.\r\nВычислить среднюю цену закупки товара и\r\nколичество закупок для каждо" +
    "го товара";
            this.toolStripButton7.Click += new System.EventHandler(this.Query07_Command);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = global::Homework.Properties.Resources._8;
            this.toolStripButton8.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton8.Text = "toolStripButton2";
            this.toolStripButton8.ToolTipText = "Запрос №8.\r\nВычислить среднюю цену продажи единицы товара и кол-во продаж для каж" +
    "дого продавца\r\n";
            this.toolStripButton8.Click += new System.EventHandler(this.Query08_Command);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = global::Homework.Properties.Resources.exit;
            this.toolStripButton9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(34, 36);
            this.toolStripButton9.Text = "toolStripButton9";
            this.toolStripButton9.ToolTipText = "Выход";
            this.toolStripButton9.Click += new System.EventHandler(this.Exit_Command);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = global::Homework.Properties.Resources.help;
            this.toolStripButton10.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton10.Text = "toolStripButton10";
            this.toolStripButton10.ToolTipText = "О программе...";
            this.toolStripButton10.Click += new System.EventHandler(this.About_Command);
            // 
            // запрос1ToolStripMenuItem
            // 
            this.запрос1ToolStripMenuItem.Image = global::Homework.Properties.Resources._1;
            this.запрос1ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос1ToolStripMenuItem.Name = "запрос1ToolStripMenuItem";
            this.запрос1ToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запрос1ToolStripMenuItem.Text = "Запрос №1";
            this.запрос1ToolStripMenuItem.Click += new System.EventHandler(this.Query01_Command);
            // 
            // запросToolStripMenuItem
            // 
            this.запросToolStripMenuItem.Image = global::Homework.Properties.Resources._2;
            this.запросToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запросToolStripMenuItem.Name = "запросToolStripMenuItem";
            this.запросToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запросToolStripMenuItem.Text = "Запрос №2";
            this.запросToolStripMenuItem.Click += new System.EventHandler(this.Query02_Command);
            // 
            // запрос3ToolStripMenuItem
            // 
            this.запрос3ToolStripMenuItem.Image = global::Homework.Properties.Resources._3;
            this.запрос3ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос3ToolStripMenuItem.Name = "запрос3ToolStripMenuItem";
            this.запрос3ToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запрос3ToolStripMenuItem.Text = "Запрос №3";
            this.запрос3ToolStripMenuItem.Click += new System.EventHandler(this.Query03_Command);
            // 
            // запрос4ToolStripMenuItem
            // 
            this.запрос4ToolStripMenuItem.Image = global::Homework.Properties.Resources._4;
            this.запрос4ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос4ToolStripMenuItem.Name = "запрос4ToolStripMenuItem";
            this.запрос4ToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запрос4ToolStripMenuItem.Text = "Запрос №4";
            this.запрос4ToolStripMenuItem.Click += new System.EventHandler(this.Query04_Command);
            // 
            // запрос5ToolStripMenuItem
            // 
            this.запрос5ToolStripMenuItem.Image = global::Homework.Properties.Resources._5;
            this.запрос5ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос5ToolStripMenuItem.Name = "запрос5ToolStripMenuItem";
            this.запрос5ToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запрос5ToolStripMenuItem.Text = "Запрос №5";
            this.запрос5ToolStripMenuItem.Click += new System.EventHandler(this.Query05_Command);
            // 
            // запрос6ToolStripMenuItem
            // 
            this.запрос6ToolStripMenuItem.Image = global::Homework.Properties.Resources._6;
            this.запрос6ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос6ToolStripMenuItem.Name = "запрос6ToolStripMenuItem";
            this.запрос6ToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запрос6ToolStripMenuItem.Text = "Запрос №6";
            this.запрос6ToolStripMenuItem.Click += new System.EventHandler(this.Query06_Command);
            // 
            // запрос7ToolStripMenuItem
            // 
            this.запрос7ToolStripMenuItem.Image = global::Homework.Properties.Resources._7;
            this.запрос7ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос7ToolStripMenuItem.Name = "запрос7ToolStripMenuItem";
            this.запрос7ToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запрос7ToolStripMenuItem.Text = "Запрос №7";
            this.запрос7ToolStripMenuItem.Click += new System.EventHandler(this.Query07_Command);
            // 
            // запрос8ToolStripMenuItem
            // 
            this.запрос8ToolStripMenuItem.Image = global::Homework.Properties.Resources._8;
            this.запрос8ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.запрос8ToolStripMenuItem.Name = "запрос8ToolStripMenuItem";
            this.запрос8ToolStripMenuItem.Size = new System.Drawing.Size(183, 38);
            this.запрос8ToolStripMenuItem.Text = "Запрос №8";
            this.запрос8ToolStripMenuItem.Click += new System.EventHandler(this.Query08_Command);
            // 
            // DgvSales
            // 
            this.DgvSales.AllowUserToAddRows = false;
            this.DgvSales.AllowUserToDeleteRows = false;
            this.DgvSales.AutoGenerateColumns = false;
            this.DgvSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31});
            this.DgvSales.DataSource = this.saleBindingSource;
            this.DgvSales.Location = new System.Drawing.Point(3, 31);
            this.DgvSales.MultiSelect = false;
            this.DgvSales.Name = "DgvSales";
            this.DgvSales.ReadOnly = true;
            this.DgvSales.RowHeadersVisible = false;
            this.DgvSales.RowHeadersWidth = 51;
            this.DgvSales.RowTemplate.Height = 24;
            this.DgvSales.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvSales.Size = new System.Drawing.Size(854, 440);
            this.DgvSales.TabIndex = 8;
            this.DgvSales.Visible = false;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn24.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn24.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Width = 40;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Good";
            this.dataGridViewTextBoxColumn25.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn25.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 125;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn26.HeaderText = "Единица изм.";
            this.dataGridViewTextBoxColumn26.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Width = 125;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Seller";
            this.dataGridViewTextBoxColumn27.HeaderText = "Продавец";
            this.dataGridViewTextBoxColumn27.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Width = 150;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "SaleDate";
            this.dataGridViewTextBoxColumn28.HeaderText = "Дата продажи";
            this.dataGridViewTextBoxColumn28.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Width = 125;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "SalePrice";
            this.dataGridViewTextBoxColumn29.HeaderText = "Цена продажи";
            this.dataGridViewTextBoxColumn29.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Width = 125;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "PurchasePrice";
            this.dataGridViewTextBoxColumn30.HeaderText = "Цена закупки";
            this.dataGridViewTextBoxColumn30.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Width = 125;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn31.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn31.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Width = 120;
            // 
            // saleBindingSource
            // 
            this.saleBindingSource.DataSource = typeof(Homework.Models.Sale);
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn19.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn19.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 50;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn20.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn20.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 200;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn21.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn21.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 200;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Patronymic";
            this.dataGridViewTextBoxColumn22.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn22.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 200;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Interest";
            this.dataGridViewTextBoxColumn23.HeaderText = "Процент комиссионных";
            this.dataGridViewTextBoxColumn23.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 200;
            // 
            // sellerBindingSource
            // 
            this.sellerBindingSource.DataSource = typeof(Homework.Models.Seller);
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn13.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 50;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Good";
            this.dataGridViewTextBoxColumn14.FillWeight = 200F;
            this.dataGridViewTextBoxColumn14.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 220;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn15.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 125;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "PurchaseDate";
            this.dataGridViewTextBoxColumn16.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn16.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 125;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn17.HeaderText = "Цена за единицу товара";
            this.dataGridViewTextBoxColumn17.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 200;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn18.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn18.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 125;
            // 
            // purchaseBindingSource
            // 
            this.purchaseBindingSource.DataSource = typeof(Homework.Models.Purchase);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 50;
            // 
            // goodDataGridViewTextBoxColumn
            // 
            this.goodDataGridViewTextBoxColumn.DataPropertyName = "Good";
            this.goodDataGridViewTextBoxColumn.FillWeight = 200F;
            this.goodDataGridViewTextBoxColumn.HeaderText = "Наименование товара";
            this.goodDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.goodDataGridViewTextBoxColumn.Name = "goodDataGridViewTextBoxColumn";
            this.goodDataGridViewTextBoxColumn.ReadOnly = true;
            this.goodDataGridViewTextBoxColumn.Width = 220;
            // 
            // unitDataGridViewTextBoxColumn
            // 
            this.unitDataGridViewTextBoxColumn.DataPropertyName = "Unit";
            this.unitDataGridViewTextBoxColumn.HeaderText = "Единица измерения";
            this.unitDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.unitDataGridViewTextBoxColumn.Name = "unitDataGridViewTextBoxColumn";
            this.unitDataGridViewTextBoxColumn.ReadOnly = true;
            this.unitDataGridViewTextBoxColumn.Width = 125;
            // 
            // purchaseDateDataGridViewTextBoxColumn
            // 
            this.purchaseDateDataGridViewTextBoxColumn.DataPropertyName = "PurchaseDate";
            this.purchaseDateDataGridViewTextBoxColumn.HeaderText = "Дата закупки";
            this.purchaseDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.purchaseDateDataGridViewTextBoxColumn.Name = "purchaseDateDataGridViewTextBoxColumn";
            this.purchaseDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.purchaseDateDataGridViewTextBoxColumn.Width = 125;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Цена за единицу товара";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.Width = 200;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "Количество";
            this.amountDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Good";
            this.dataGridViewTextBoxColumn2.FillWeight = 200F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 220;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn3.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "PurchaseDate";
            this.dataGridViewTextBoxColumn4.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn5.HeaderText = "Цена за единицу товара";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 200;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn6.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn7.HeaderText = "Ид";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 50;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Good";
            this.dataGridViewTextBoxColumn8.FillWeight = 200F;
            this.dataGridViewTextBoxColumn8.HeaderText = "Наименование товара";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 220;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Unit";
            this.dataGridViewTextBoxColumn9.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 125;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "PurchaseDate";
            this.dataGridViewTextBoxColumn10.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 125;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn11.HeaderText = "Цена за единицу товара";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 200;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn12.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 125;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idDataGridViewTextBoxColumn1.Width = 50;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.surnameDataGridViewTextBoxColumn.Width = 200;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 200;
            // 
            // patronymicDataGridViewTextBoxColumn
            // 
            this.patronymicDataGridViewTextBoxColumn.DataPropertyName = "Patronymic";
            this.patronymicDataGridViewTextBoxColumn.HeaderText = "Отчество";
            this.patronymicDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.patronymicDataGridViewTextBoxColumn.Name = "patronymicDataGridViewTextBoxColumn";
            this.patronymicDataGridViewTextBoxColumn.ReadOnly = true;
            this.patronymicDataGridViewTextBoxColumn.Width = 200;
            // 
            // interestDataGridViewTextBoxColumn
            // 
            this.interestDataGridViewTextBoxColumn.DataPropertyName = "Interest";
            this.interestDataGridViewTextBoxColumn.HeaderText = "Процент комиссионных";
            this.interestDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.interestDataGridViewTextBoxColumn.Name = "interestDataGridViewTextBoxColumn";
            this.interestDataGridViewTextBoxColumn.ReadOnly = true;
            this.interestDataGridViewTextBoxColumn.Width = 200;
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "Ид";
            this.idDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.ReadOnly = true;
            this.idDataGridViewTextBoxColumn2.Width = 40;
            // 
            // goodDataGridViewTextBoxColumn1
            // 
            this.goodDataGridViewTextBoxColumn1.DataPropertyName = "Good";
            this.goodDataGridViewTextBoxColumn1.HeaderText = "Товар";
            this.goodDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.goodDataGridViewTextBoxColumn1.Name = "goodDataGridViewTextBoxColumn1";
            this.goodDataGridViewTextBoxColumn1.ReadOnly = true;
            this.goodDataGridViewTextBoxColumn1.Width = 125;
            // 
            // unitDataGridViewTextBoxColumn1
            // 
            this.unitDataGridViewTextBoxColumn1.DataPropertyName = "Unit";
            this.unitDataGridViewTextBoxColumn1.HeaderText = "Единица изм.";
            this.unitDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.unitDataGridViewTextBoxColumn1.Name = "unitDataGridViewTextBoxColumn1";
            this.unitDataGridViewTextBoxColumn1.ReadOnly = true;
            this.unitDataGridViewTextBoxColumn1.Width = 125;
            // 
            // sellerDataGridViewTextBoxColumn
            // 
            this.sellerDataGridViewTextBoxColumn.DataPropertyName = "Seller";
            this.sellerDataGridViewTextBoxColumn.HeaderText = "Продавец";
            this.sellerDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sellerDataGridViewTextBoxColumn.Name = "sellerDataGridViewTextBoxColumn";
            this.sellerDataGridViewTextBoxColumn.ReadOnly = true;
            this.sellerDataGridViewTextBoxColumn.Width = 150;
            // 
            // saleDateDataGridViewTextBoxColumn
            // 
            this.saleDateDataGridViewTextBoxColumn.DataPropertyName = "SaleDate";
            this.saleDateDataGridViewTextBoxColumn.HeaderText = "Дата продажи";
            this.saleDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.saleDateDataGridViewTextBoxColumn.Name = "saleDateDataGridViewTextBoxColumn";
            this.saleDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.saleDateDataGridViewTextBoxColumn.Width = 125;
            // 
            // salePriceDataGridViewTextBoxColumn
            // 
            this.salePriceDataGridViewTextBoxColumn.DataPropertyName = "SalePrice";
            this.salePriceDataGridViewTextBoxColumn.HeaderText = "Цена продажи";
            this.salePriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.salePriceDataGridViewTextBoxColumn.Name = "salePriceDataGridViewTextBoxColumn";
            this.salePriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.salePriceDataGridViewTextBoxColumn.Width = 125;
            // 
            // purchasePriceDataGridViewTextBoxColumn
            // 
            this.purchasePriceDataGridViewTextBoxColumn.DataPropertyName = "PurchasePrice";
            this.purchasePriceDataGridViewTextBoxColumn.HeaderText = "Цена закупки";
            this.purchasePriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.purchasePriceDataGridViewTextBoxColumn.Name = "purchasePriceDataGridViewTextBoxColumn";
            this.purchasePriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.purchasePriceDataGridViewTextBoxColumn.Width = 125;
            // 
            // amountDataGridViewTextBoxColumn1
            // 
            this.amountDataGridViewTextBoxColumn1.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn1.HeaderText = "Количество";
            this.amountDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn1.Name = "amountDataGridViewTextBoxColumn1";
            this.amountDataGridViewTextBoxColumn1.ReadOnly = true;
            this.amountDataGridViewTextBoxColumn1.Width = 120;
            // 
            // saleDateDataGridViewTextBoxColumn1
            // 
            this.saleDateDataGridViewTextBoxColumn1.DataPropertyName = "SaleDate";
            this.saleDateDataGridViewTextBoxColumn1.HeaderText = "Дата продажи";
            this.saleDateDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.saleDateDataGridViewTextBoxColumn1.Name = "saleDateDataGridViewTextBoxColumn1";
            this.saleDateDataGridViewTextBoxColumn1.ReadOnly = true;
            this.saleDateDataGridViewTextBoxColumn1.Width = 130;
            // 
            // goodDataGridViewTextBoxColumn2
            // 
            this.goodDataGridViewTextBoxColumn2.DataPropertyName = "Good";
            this.goodDataGridViewTextBoxColumn2.HeaderText = "Наименование товара";
            this.goodDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.goodDataGridViewTextBoxColumn2.Name = "goodDataGridViewTextBoxColumn2";
            this.goodDataGridViewTextBoxColumn2.ReadOnly = true;
            this.goodDataGridViewTextBoxColumn2.Width = 200;
            // 
            // salePriceDataGridViewTextBoxColumn1
            // 
            this.salePriceDataGridViewTextBoxColumn1.DataPropertyName = "SalePrice";
            this.salePriceDataGridViewTextBoxColumn1.HeaderText = "Цена продажи";
            this.salePriceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.salePriceDataGridViewTextBoxColumn1.Name = "salePriceDataGridViewTextBoxColumn1";
            this.salePriceDataGridViewTextBoxColumn1.ReadOnly = true;
            this.salePriceDataGridViewTextBoxColumn1.Width = 160;
            // 
            // purchasePriceDataGridViewTextBoxColumn1
            // 
            this.purchasePriceDataGridViewTextBoxColumn1.DataPropertyName = "PurchasePrice";
            this.purchasePriceDataGridViewTextBoxColumn1.HeaderText = "Цена закупки";
            this.purchasePriceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.purchasePriceDataGridViewTextBoxColumn1.Name = "purchasePriceDataGridViewTextBoxColumn1";
            this.purchasePriceDataGridViewTextBoxColumn1.ReadOnly = true;
            this.purchasePriceDataGridViewTextBoxColumn1.Width = 150;
            // 
            // amountDataGridViewTextBoxColumn2
            // 
            this.amountDataGridViewTextBoxColumn2.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn2.HeaderText = "Количество";
            this.amountDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn2.Name = "amountDataGridViewTextBoxColumn2";
            this.amountDataGridViewTextBoxColumn2.ReadOnly = true;
            this.amountDataGridViewTextBoxColumn2.Width = 110;
            // 
            // profitDataGridViewTextBoxColumn
            // 
            this.profitDataGridViewTextBoxColumn.DataPropertyName = "Profit";
            this.profitDataGridViewTextBoxColumn.HeaderText = "Прибыль";
            this.profitDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.profitDataGridViewTextBoxColumn.Name = "profitDataGridViewTextBoxColumn";
            this.profitDataGridViewTextBoxColumn.ReadOnly = true;
            this.profitDataGridViewTextBoxColumn.Width = 120;
            // 
            // resultQuery06BindingSource
            // 
            this.resultQuery06BindingSource.DataSource = typeof(Homework.Models.ResultQuery06);
            // 
            // titleDataGridViewTextBoxColumn
            // 
            this.titleDataGridViewTextBoxColumn.DataPropertyName = "Title";
            this.titleDataGridViewTextBoxColumn.HeaderText = "Наименование товара";
            this.titleDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            this.titleDataGridViewTextBoxColumn.ReadOnly = true;
            this.titleDataGridViewTextBoxColumn.Width = 300;
            // 
            // averageDataGridViewTextBoxColumn
            // 
            this.averageDataGridViewTextBoxColumn.DataPropertyName = "Average";
            this.averageDataGridViewTextBoxColumn.HeaderText = "Средняя цена закупки товара";
            this.averageDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.averageDataGridViewTextBoxColumn.Name = "averageDataGridViewTextBoxColumn";
            this.averageDataGridViewTextBoxColumn.ReadOnly = true;
            this.averageDataGridViewTextBoxColumn.Width = 290;
            // 
            // amountDataGridViewTextBoxColumn3
            // 
            this.amountDataGridViewTextBoxColumn3.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn3.HeaderText = "Кол-во закупок товара";
            this.amountDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn3.Name = "amountDataGridViewTextBoxColumn3";
            this.amountDataGridViewTextBoxColumn3.ReadOnly = true;
            this.amountDataGridViewTextBoxColumn3.Width = 260;
            // 
            // resultQuery07and08BindingSource
            // 
            this.resultQuery07and08BindingSource.DataSource = typeof(Homework.Models.ResultQuery07and08);
            // 
            // titleDataGridViewTextBoxColumn1
            // 
            this.titleDataGridViewTextBoxColumn1.DataPropertyName = "Title";
            this.titleDataGridViewTextBoxColumn1.HeaderText = "Продавец";
            this.titleDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.titleDataGridViewTextBoxColumn1.Name = "titleDataGridViewTextBoxColumn1";
            this.titleDataGridViewTextBoxColumn1.ReadOnly = true;
            this.titleDataGridViewTextBoxColumn1.Width = 300;
            // 
            // averageDataGridViewTextBoxColumn1
            // 
            this.averageDataGridViewTextBoxColumn1.DataPropertyName = "Average";
            this.averageDataGridViewTextBoxColumn1.HeaderText = "Средняя цена продажи единицы товара";
            this.averageDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.averageDataGridViewTextBoxColumn1.Name = "averageDataGridViewTextBoxColumn1";
            this.averageDataGridViewTextBoxColumn1.ReadOnly = true;
            this.averageDataGridViewTextBoxColumn1.Width = 290;
            // 
            // amountDataGridViewTextBoxColumn4
            // 
            this.amountDataGridViewTextBoxColumn4.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn4.HeaderText = "Количество продаж";
            this.amountDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.amountDataGridViewTextBoxColumn4.Name = "amountDataGridViewTextBoxColumn4";
            this.amountDataGridViewTextBoxColumn4.ReadOnly = true;
            this.amountDataGridViewTextBoxColumn4.Width = 260;
            // 
            // таблицыToolStripMenuItem
            // 
            this.таблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.таблицаЕдиницИзмеренияToolStripMenuItem,
            this.таблицаПерсонToolStripMenuItem,
            this.таблицаПродавцовToolStripMenuItem,
            this.таблицаТоваровToolStripMenuItem,
            this.таблицаЗакупокToolStripMenuItem,
            this.таблицаПродажToolStripMenuItem});
            this.таблицыToolStripMenuItem.Name = "таблицыToolStripMenuItem";
            this.таблицыToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.таблицыToolStripMenuItem.Text = "Таблицы";
            // 
            // таблицаЕдиницИзмеренияToolStripMenuItem
            // 
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Image = global::Homework.Properties.Resources.box;
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Name = "таблицаЕдиницИзмеренияToolStripMenuItem";
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Text = "Таблица единиц измерения";
            this.таблицаЕдиницИзмеренияToolStripMenuItem.Click += new System.EventHandler(this.ShowUnits_Command);
            // 
            // таблицаПерсонToolStripMenuItem
            // 
            this.таблицаПерсонToolStripMenuItem.Image = global::Homework.Properties.Resources.Owner;
            this.таблицаПерсонToolStripMenuItem.Name = "таблицаПерсонToolStripMenuItem";
            this.таблицаПерсонToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаПерсонToolStripMenuItem.Text = "Таблица персон";
            this.таблицаПерсонToolStripMenuItem.Click += new System.EventHandler(this.ShowPersons_Command);
            // 
            // таблицаПродавцовToolStripMenuItem
            // 
            this.таблицаПродавцовToolStripMenuItem.Image = global::Homework.Properties.Resources.seller;
            this.таблицаПродавцовToolStripMenuItem.Name = "таблицаПродавцовToolStripMenuItem";
            this.таблицаПродавцовToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаПродавцовToolStripMenuItem.Text = "Таблица продавцов";
            this.таблицаПродавцовToolStripMenuItem.Click += new System.EventHandler(this.ShowSellers_Command);
            // 
            // таблицаТоваровToolStripMenuItem
            // 
            this.таблицаТоваровToolStripMenuItem.Image = global::Homework.Properties.Resources.Select;
            this.таблицаТоваровToolStripMenuItem.Name = "таблицаТоваровToolStripMenuItem";
            this.таблицаТоваровToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаТоваровToolStripMenuItem.Text = "Таблица товаров";
            this.таблицаТоваровToolStripMenuItem.Click += new System.EventHandler(this.ShowGoods_Command);
            // 
            // таблицаЗакупокToolStripMenuItem
            // 
            this.таблицаЗакупокToolStripMenuItem.Image = global::Homework.Properties.Resources.purchase;
            this.таблицаЗакупокToolStripMenuItem.Name = "таблицаЗакупокToolStripMenuItem";
            this.таблицаЗакупокToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаЗакупокToolStripMenuItem.Text = "Таблица закупок";
            this.таблицаЗакупокToolStripMenuItem.Click += new System.EventHandler(this.ShowPurchases_Command);
            // 
            // таблицаПродажToolStripMenuItem
            // 
            this.таблицаПродажToolStripMenuItem.Image = global::Homework.Properties.Resources.sale;
            this.таблицаПродажToolStripMenuItem.Name = "таблицаПродажToolStripMenuItem";
            this.таблицаПродажToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.таблицаПродажToolStripMenuItem.Text = "Таблица продаж";
            this.таблицаПродажToolStripMenuItem.Click += new System.EventHandler(this.ShowSales_Command);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::Homework.Properties.Resources.help;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.оПрограммеToolStripMenuItem.Text = "О программе...";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(862, 578);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 24.01.2022";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvUnits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvGoods)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPersons)).EndInit();
            this.TbpQuery01.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery01)).EndInit();
            this.TbpQuery02.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery02)).EndInit();
            this.TbpQuery03.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery03)).EndInit();
            this.TbpQuery04.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery04)).EndInit();
            this.TbpQuery05.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery05)).EndInit();
            this.TbpQuery06.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery06)).EndInit();
            this.TbpQuery07.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery07)).EndInit();
            this.TbpQuery08.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvQuery08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPurchases)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSellers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSales)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery06BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultQuery07and08BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpMain;
        private System.Windows.Forms.TabPage TbpQuery01;
        private System.Windows.Forms.Label LblQuery01;
        private System.Windows.Forms.DataGridView DgvQuery01;
        private System.Windows.Forms.BindingSource purchaseBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.TabPage TbpQuery02;
        private System.Windows.Forms.DataGridView DgvQuery02;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Label LblQuery02;
        private System.Windows.Forms.TabPage TbpQuery03;
        private System.Windows.Forms.DataGridView DgvQuery03;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Label LblQuery03;
        private System.Windows.Forms.TabPage TbpQuery04;
        private System.Windows.Forms.TabPage TbpQuery05;
        private System.Windows.Forms.TabPage TbpQuery06;
        private System.Windows.Forms.TabPage TbpQuery07;
        private System.Windows.Forms.TabPage TbpQuery08;
        private System.Windows.Forms.Label LblQuery04;
        private System.Windows.Forms.Label LblQuery05;
        private System.Windows.Forms.Label LblQuery06;
        private System.Windows.Forms.Label LblQuery07;
        private System.Windows.Forms.Label LblQuery08;
        private System.Windows.Forms.DataGridView DgvQuery04;
        private System.Windows.Forms.DataGridView DgvQuery05;
        private System.Windows.Forms.DataGridView DgvQuery06;
        private System.Windows.Forms.DataGridView DgvQuery07;
        private System.Windows.Forms.DataGridView DgvQuery08;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripMenuItem запрос1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос8ToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sellerBindingSource;
        private System.Windows.Forms.BindingSource saleBindingSource;
        private System.Windows.Forms.BindingSource resultQuery06BindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleDateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn salePriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasePriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn profitDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource resultQuery07and08BindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn averageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn averageDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridView DgvPersons;
        private System.Windows.Forms.BindingSource personsBindingSource;
        private System.Windows.Forms.Label LblMain;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronymicDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.DataGridView DgvGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource goodsBindingSource;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.DataGridView DgvUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn longDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource unitsBindingSource;
        private System.Windows.Forms.DataGridView DgvPurchases;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.DataGridView DgvSellers;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.DataGridView DgvSales;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salePriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasePriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn1;
        private System.Windows.Forms.ToolStripMenuItem таблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаЕдиницИзмеренияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаПерсонToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаПродавцовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаТоваровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаЗакупокToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem таблицаПродажToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
    }
}

