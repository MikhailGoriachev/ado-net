﻿using Stylet;


namespace Main.Infrastructure
{
	public interface IShell
	{
		void ActivateItem(Screen screen);
	}
}