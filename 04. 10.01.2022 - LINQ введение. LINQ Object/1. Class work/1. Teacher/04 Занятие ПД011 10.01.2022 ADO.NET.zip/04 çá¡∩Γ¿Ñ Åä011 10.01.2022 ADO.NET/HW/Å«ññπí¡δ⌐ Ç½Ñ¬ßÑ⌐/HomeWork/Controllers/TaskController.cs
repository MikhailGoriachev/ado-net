﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// для работы с технологией ADO.NET
using System.Configuration;   // добавить сборку System.Configuration.dll
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

using HomeWork.Models;

namespace HomeWork.Controllers
{
    public class TaskController
    {

        // создание строки соединения с базой данных - чтение из app.config
        // индексируем свойство ConnectionStrings именем строки соединения
        private static string connectionString =
            ConfigurationManager.ConnectionStrings["AccountingConnection"].ConnectionString;


        // 1	Хранимая процедура	Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа, стоимость 1 экземпляра для которых меньше заданной.
        //      Требуется модель для вывода данных – данные выборки помещать в коллекцию     
        public List<PublicationModel> Query01(string TypeOfPublications, int price)
        {
            Console.WriteLine("1	Хранимая процедура");
            Console.WriteLine("Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа, стоимость 1 экземпляра для которых меньше заданной.");
            Console.WriteLine("Требуется модель для вывода данных – данные выборки помещать в коллекцию.");
            Console.WriteLine($"Заданные параметры : {TypeOfPublications}, {price} ");



            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению                
                SqlCommand cmd = new SqlCommand(@"Proc1");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@TypeOfPublications", TypeOfPublications);
                cmd.Parameters.AddWithValue("@price", price);

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<PublicationModel> publicationModels = new List<PublicationModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                 if (reader.HasRows)
                 {        
                      while (reader.Read())
                      {     
                        PublicationModel model = new PublicationModel(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetInt32(4));
                        publicationModels.Add(model);

                      } // while

                } // if


                return publicationModels;
            } // using
        } // Query01

        // 2	Хранимая процедура	Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома, которые оформили подписку на издание с заданным параметром наименованием
        //      Требуется модель для вывода данных – данные выборки помещать в коллекцию
        public List<SubscribersModel> Query02(string NameOfPublications, string NameOfStreet, string HouseNumber)
        {
            Console.WriteLine("2	Хранимая процедура");
            Console.WriteLine("Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома, которые оформили подписку на издание с заданным параметром наименованием.");
            Console.WriteLine("Требуется модель для вывода данных – данные выборки помещать в коллекцию.");
            Console.WriteLine($"Заданные параметры : {NameOfPublications}, {NameOfStreet}, {HouseNumber} ");



            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                // SqlCommand cmd = new SqlCommand(@"exec ProcQuery01 @roomNum, @street");
                SqlCommand cmd = new SqlCommand(@"Proc2");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@NameOfPublications", NameOfPublications);
                cmd.Parameters.AddWithValue("@NameOfStreet", NameOfStreet);
                cmd.Parameters.AddWithValue("@HouseNumber", HouseNumber);

                
                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<SubscribersModel> subscriberModels = new List<SubscribersModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        SubscribersModel model = 
                            new SubscribersModel(reader.GetInt32(0), 
                                                 reader.GetString(1), 
                                                 reader.GetString(2), 
                                                 reader.GetString(3), 
                                                 reader.GetString(4), 
                                                 reader.GetString(5),
                                                 reader.GetString(6),
                                                 reader.GetString(7),
                                                 reader.GetString(8),
                                                 reader.GetInt32(9),
                                                 reader.GetDateTime(10),
                                                 reader.GetInt32(11)
                                                 );
                        subscriberModels.Add(model);

                    } // while

                } // if


                return subscriberModels;
            } // using
        } // Query02

        // 3	Хранимая процедура	Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле Цена 1 экземпляра находится в заданном диапазоне значений
        //      Требуется модель для вывода данных – данные выборки помещать в коллекцию
        public List<PublicationModel> Query03(int lo, int hi)
        {
            Console.WriteLine("3	Хранимая процедура");
            Console.WriteLine("Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле Цена 1 экземпляра находится в заданном диапазоне значений.");
            Console.WriteLine("Требуется модель для вывода данных – данные выборки помещать в коллекцию.");
            Console.WriteLine($"Заданные параметры : {lo}, {hi}");



            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению                
                SqlCommand cmd = new SqlCommand(@"Proc3");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);
                

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<PublicationModel> publicationModels = new List<PublicationModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        PublicationModel model = new PublicationModel(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetInt32(4));
                        publicationModels.Add(model);

                    } // while

                } // if


                return publicationModels;
            } // using
        } // Query03

        // 4	Хранимая процедура	Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания
        //      Требуется модель для вывода данных – данные выборки помещать в коллекцию
        public List<SubscribersModel> Query04(string TypeOfPrintEdition)
        {
            Console.WriteLine("4	Хранимая процедура");
            Console.WriteLine("Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания.");
            Console.WriteLine("Требуется модель для вывода данных – данные выборки помещать в коллекцию.");
            Console.WriteLine($"Заданные параметры : {TypeOfPrintEdition}");



            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению               
                SqlCommand cmd = new SqlCommand(@"Proc4");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@TypeOfPublications", TypeOfPrintEdition);
               

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<SubscribersModel> subscriberModels = new List<SubscribersModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        SubscribersModel model =
                            new SubscribersModel(reader.GetInt32(0),
                                                 reader.GetString(1),
                                                 reader.GetString(2),
                                                 reader.GetString(3),
                                                 reader.GetString(4),
                                                 reader.GetString(5),
                                                 reader.GetString(6),
                                                 reader.GetString(7),
                                                 reader.GetString(8),
                                                 reader.GetInt32(9),
                                                 reader.GetDateTime(10),
                                                 reader.GetInt32(11)
                                                 );
                        subscriberModels.Add(model);

                    } // while

                } // if


                return subscriberModels;
            } // using
        } // Query04

        // 5	Хранимая процедура	Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках, для которых срок подписки есть значение из некоторого диапазона
        public List<SubscribersModel> Query05(int lo, int hi)
        {
            Console.WriteLine("5	Хранимая процедура");
            Console.WriteLine("Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках, для которых срок подписки есть значение из некоторого диапазона.");
            Console.WriteLine($"Заданные параметры : {lo}, {hi}");



            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению               
                SqlCommand cmd = new SqlCommand(@"Proc5");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@lo", lo);
                cmd.Parameters.AddWithValue("@hi", hi);


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<SubscribersModel> subscriberModels = new List<SubscribersModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        SubscribersModel model =
                            new SubscribersModel(reader.GetInt32(0),
                                                 reader.GetString(1),
                                                 reader.GetString(2),
                                                 reader.GetString(3),
                                                 reader.GetString(4),
                                                 reader.GetString(5),
                                                 reader.GetString(6),
                                                 reader.GetString(7),
                                                 reader.GetString(8),
                                                 reader.GetInt32(9),
                                                 reader.GetDateTime(10),
                                                 reader.GetInt32(11)
                                                 );
                        subscriberModels.Add(model);

                    } // while

                } // if


                return subscriberModels;
            } // using
        } // Query05

        // 6	Хранимая процедура  Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
        //      Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки, Срок подписки, Стоимость подписки без НДС. 
        //      Сортировка по полю Индекс издания
        public void Query06()
        {
            Console.WriteLine("6	Хранимая процедура");
            Console.WriteLine("Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки, Срок подписки, Стоимость подписки без НДС.");
            Console.WriteLine("Сортировка по полю Индекс издания");



            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению               
                SqlCommand cmd = new SqlCommand(@"Proc6");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;
                              

                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<SubscribersModel> subscriberModels = new List<SubscribersModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌──────────────┬─────────────────────────────┬──────────────────────────────────────────┬──────────┬────────────┬──────────┬──────────────────────────┐");
                    Console.WriteLine($"|    Индекс    │         Тип издания         │             Название издания             │   Цена   │    Дата    │   Срок   |Стоимость подписки без НДС|");
                    Console.WriteLine($"├──────────────┼─────────────────────────────┼──────────────────────────────────────────┼──────────┼────────────┼──────────┼──────────────────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetString(0),-12} | " +            
                             $"{reader.GetString(1),-27} | " +              
                             $"{reader.GetString(2),-40} | " +             
                             $"{reader.GetInt32(3),8} | " +              
                             $"{reader.GetDateTime(4).ToShortDateString(),8} | " +              
                             $"{reader.GetInt32(5),8} | " +           
                             $"{reader.GetDecimal(6),24} | ");            

                    } // while

                    Console.WriteLine($"└──────────────┴─────────────────────────────┴──────────────────────────────────────────┴──────────┴────────────┴──────────┴──────────────────────────┘");


                } // if


                
            } // using
        } // Query06



        // 7	Итоговый запрос Хранимая процедура
        //      Выполняет группировку по полю Вид издания.Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
        public void Query07()
        {
            Console.WriteLine("7	Итоговый запрос Хранимая процедура");
            Console.WriteLine("Выполняет группировку по полю Вид издания.Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра.");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению               
                SqlCommand cmd = new SqlCommand(@"Proc7");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<SubscribersModel> subscriberModels = new List<SubscribersModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌─────────────────────────────┬────────────┬──────────────────┬───────────────────┐");
                    Console.WriteLine($"|         Тип издания         │ Количество │ Минимальная цена │ Максимальная цена |");
                    Console.WriteLine($"├─────────────────────────────┼────────────┼──────────────────┼───────────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetString(0),-27} | " +
                             $"{reader.GetInt32(1),10} | " +
                             $"{reader.GetInt32(2),16} | " +
                             $"{reader.GetInt32(3),17} | " );

                    } // while

                    Console.WriteLine($"└─────────────────────────────┴────────────┴──────────────────┴───────────────────┘");


                } // if



            } // using
        } // Query07


        // 8	Итоговый запрос с левым соединением
        //      Хранимая процедура  Выполняет группировку по полю Улица.Для всех улиц вычисляет количество подписчиков, проживающих на данной улице(итоги по полю Код получателя)
        public void Query08()
        {
            Console.WriteLine("8	Итоговый запрос с левым соединением. Хранимая процедура");
            Console.WriteLine("Выполняет группировку по полю Улица.Для всех улиц вычисляет количество подписчиков, проживающих на данной улице(итоги по полю Код получателя).");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению               
                SqlCommand cmd = new SqlCommand(@"Proc8");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<SubscribersModel> subscriberModels = new List<SubscribersModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌─────────────────────────────┬────────────┐");
                    Console.WriteLine($"|         Название улицы      │ Количество |");
                    Console.WriteLine($"├─────────────────────────────┼────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetString(0),-27} | " +
                             $"{reader.GetInt32(1),10} | " );

                    } // while

                    Console.WriteLine($"└─────────────────────────────┴────────────┘");


                } // if



            } // using
        } // Query08


        // 9	Итоговый запрос с левым соединением
        //      Хранимая процедура  Для всех изданий выводит количество оформленных подписок
        public void Query09()
        {
            Console.WriteLine("9	Итоговый запрос с левым соединением. Хранимая процедура");
            Console.WriteLine("Для всех изданий выводит количество оформленных подписок.");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению               
                SqlCommand cmd = new SqlCommand(@"Proc9");
                cmd.CommandType = CommandType.StoredProcedure;

                // задать соединение с БД
                cmd.Connection = connection;


                // выполнение запроса, ссылка на  выбранные данные - reader
                SqlDataReader reader = cmd.ExecuteReader();

                List<SubscribersModel> subscriberModels = new List<SubscribersModel>();

                // Если данные получены(есть строки в полученном ответе сервера)
                if (reader.HasRows)
                {
                    // выводим имена столбцов (это не обязательно)
                    Console.WriteLine($"┌─────────────────────────────┬────────────┐");
                    Console.WriteLine($"|         Тип издания         │ Количество |");
                    Console.WriteLine($"├─────────────────────────────┼────────────┤");


                    while (reader.Read())
                    {

                        Console.WriteLine(
                             $"| {reader.GetString(0),-27} | " +
                             $"{reader.GetInt32(1),10} | ");

                    } // while

                    Console.WriteLine($"└─────────────────────────────┴────────────┘");


                } // if



            } // using
        } // Query08

    }


}
