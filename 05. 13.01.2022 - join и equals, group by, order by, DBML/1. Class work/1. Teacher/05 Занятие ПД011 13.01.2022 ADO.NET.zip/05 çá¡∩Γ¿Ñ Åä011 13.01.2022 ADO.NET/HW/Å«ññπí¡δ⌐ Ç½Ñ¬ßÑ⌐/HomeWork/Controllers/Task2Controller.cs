﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Controllers
{
    public class Task2Controller
    {
        // массиив для вычислений
        private double[] _array;
        public double[] Array
        {
            get { return _array; }
            set { _array = value; }
        }

        // конструктор по умолчанию
        public Task2Controller()
        {
            _array = new double[Utils.GetRandom(8,15)];
            InitArray();
        }

        // заполнение массива 
        public void InitArray()
        {
            for (int i = 0; i < _array.Length; i++)
            {
                _array[i] = Utils.GetRandom(-100d, 100d);
            }
        }



        public void ShowArray() {

            foreach (var item in _array)
            {
                Console.Write($"  { item:f3}  " );
            }
        
        }
        public void ShowArray(double[] array)
        {

            foreach (var item in array)
            {
                Console.Write($"  { item:f3}  ");
            }

        }

        /*
         *  	Задача 2.   С использованием LINQ (создавайте 2 варианта запросов – в синтаксисе LINQ и в синтаксисе расширяющих методов)
         *                  выполнить обработки для одномерного массива из n вещественных элементов:
                                o	Вычисление количества элементов массива, со значениями в диапазоне от A до B
                                o	Вычисление количества элементов массива, равных 0
                                o	Вычисление суммы элементов массива, расположенных после первого максимального элемента
                                o	Вычисление суммы элементов массива, расположенных перед 
         */


        // Вычисление количества элементов массива, со значениями в диапазоне от A до B        
        public void Task1(double lo, double hi)
        {

            Console.WriteLine($"Вычисление количества элементов массива, со значениями в диапазоне от {lo:f3} до {hi:f3}");
            Console.WriteLine("\nМассив чисел:");
            ShowArray();
            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 
            int query1 =  ( from item in _array
                                 where item >= lo && item <= hi
                                 select item).Count();    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"Количество элементов массива: {query1}\n\n");


            Console.WriteLine("Cинтаксис методов расширения");

            // синтаксис методов расширения 
            int query2 = _array
               .Where(item => item >= lo && item <= hi)
               .Count();
            Console.WriteLine($"Количество элементов массива: {query2}\n\n");
        }//  Task1()


        // Вычисление количества элементов массива, равных 0
        public void Task2()
        {
            
            Console.WriteLine($"Вычисление количества элементов массива, равных 0");
            Console.WriteLine("\nМассив чисел:");
            ShowArray();
            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 
            int query1 = (from item in _array
                               where item == 0
                               select item).Count();    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"Количество элементов массива: {query1}\n\n");


            Console.WriteLine("Cинтаксис методов расширения");

            // синтаксис методов расширения 
            int query2 = _array
               .Where(item => item == 0)
               .Count();
            Console.WriteLine($"Количество элементов массива: {query2}\n\n");
        }// Task2()


        // Вычисление суммы элементов массива, расположенных после первого максимального элемента
        public void Task3()
        {

            Console.WriteLine($"Вычисление суммы элементов массива, расположенных после первого максимального элемента");
            Console.WriteLine("\nМассив чисел:");
            ShowArray();
            double max = _array.Max();

            Console.WriteLine($"\nПервый максимальный элемент: {max:f3}");


            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 

            // определяем количество пропускаемых элементов - до первого минимального
            // элемента включительно
            double query1 =(from item  in _array.SkipWhile(item => item < max).Skip(1)                         
                         select item).Sum();    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"Сумма элементов массива: {query1:f3}\n\n");




            Console.WriteLine("Cинтаксис методов расширения");
            // синтаксис методов расширения 
            double query2 = _array
                .SkipWhile(item => item < max)  // пропуск элементов до первого максимального
                .Skip(1)                       // пропуск максимального
                .Sum();
            Console.WriteLine($"Сумма элементов массива: {query2:f3}\n\n");
        }//  Task3()


        // Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом
        public void Task4()
        {

            Console.WriteLine($" Вычисление суммы элементов массива, расположенных перед последним минимальным по модулю элементом");
            Console.WriteLine("\nМассив чисел:");
            ShowArray();
            double min = _array.Reverse().Min(item => Math.Abs(item));

            Console.WriteLine($"\nПоследний минимальный по модулю элемент: {min:f3}");


            Console.WriteLine("\n\nCинтаксис LINQ");

            // синтаксис LINQ 

            // определяем количество пропускаемых элементов - до минимальным
            // элемента включительно
            double query1 = (from item in _array.Reverse().SkipWhile(item => Math.Abs(item) > min).Skip(1)
                             select item).Sum();    // SQL: select item from data where item between lo and hi;

            Console.WriteLine($"Сумма элементов массива: {query1:f3}\n\n");




            Console.WriteLine("Cинтаксис методов расширения");
            // синтаксис методов расширения 
            double query2 = _array
                .Reverse()
                .SkipWhile(item => Math.Abs(item) > min)  // пропуск элементов до минимальным
                .Skip(1)                       // пропуск максимального
                .Sum();
            Console.WriteLine($"Сумма элементов массива: {query2:f3}\n\n");
        }//  Task3()


    }
}
