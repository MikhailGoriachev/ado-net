﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADoNET_3__PrintedEdition_.Models
{
	// Модель отображения таблицы Издания(Editions)
	public class Edition {
		// Первичный ключ 
		public int Id { get; set; }
		
		// id издания
		public string IndexEdition { get; set; }
		
		// Название
		public string Name { get; set; }

		// Тип (газета, журнал, альманах, задачник, энциклопедия) 
		public string Type { get; set; }

		// Цена за 1 экземпляр
		public double Price { get; set; }

		// Конструктор с парамметрами
		public Edition(int id, string indexEdition, string name, string type, double price){
			Id = id;
			IndexEdition = indexEdition;
			Name = name;
			Type = type;
			Price = price;
		} // Edition

		// Вывод данных в формате строки таблицы
		public string ToTableRow() =>
			$"\t│ {Id, 2} │ {IndexEdition,-8} │ {Name,-35} " +
			$"│ {Type,-13} │ {Price, 12:f2} │ ";

		// Шапка таблицы
		static public string Header() =>
			"\t┌────┬──────────┬─────────────────────────────────────┬───────────────┬──────────────┐\n" +
			"\t│ Id │ Индекс   │            Название                 │    Тип        │    Цена      │\n" +
			"\t│    │  издания │                 издания             │      издания  │ 1 экземпляра │\n" +
			"\t├────┼──────────┼─────────────────────────────────────┼───────────────┼──────────────┤\n";

		// Подвал таблицы
		public static string Footer() => "\t└────┴──────────┴─────────────────────────────────────┴───────────────┴──────────────┘";


	}
}
