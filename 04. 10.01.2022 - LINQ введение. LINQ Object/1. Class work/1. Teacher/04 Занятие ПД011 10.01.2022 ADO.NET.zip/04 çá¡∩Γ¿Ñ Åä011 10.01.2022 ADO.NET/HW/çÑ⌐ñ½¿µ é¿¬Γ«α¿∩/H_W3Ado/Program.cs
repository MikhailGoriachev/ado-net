﻿using H_W3Ado.Application;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;        // для ADO.NET
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Configuration;


namespace H_W3Ado
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 3.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Запрос 1.Выбирает информацию о доступных для подписки изданиях заданного типа." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Запрос 2.Выбирает информацию о подписчиках, проживающих на заданной улице и домe." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Запрос 3.Выбирает информацию о изданиях с заданной ценной в некотором диапазоне." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Запрос 4.Выбирает информацию о подписчиках, подписавшихся на заданный тип издания." },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Запрос 5.Выбирет все подписки, для которых срок подписки есть значение из диапазона." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Запрос 6.Вычисляет для каждой оформленной подписки ее стоимость." },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Запрос 7.Вычисляет для каждого вида макс. и мин. цену 1 экземпляра." },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Запрос 8.Вычисляет для всех улиц количество подписчиков, проживающих на данной улице." },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Запрос 9.Для всех изданий выводит количество оформленных подписок." },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Шифрование конфигурационного файла." },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Расшифрование конфигурационного файла." },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App(ConfigurationManager.ConnectionStrings["AccountSubscriptions"].ConnectionString);

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(20, 5, "Запросы к базe данных «Учет подписки на периодические печатные издания» : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Выбирает информацию о доступных для подписки изданиях заданного типа
                        case ConsoleKey.Q:
                            app.ExecQuery01();
                            break;

                        // Выбирает информацию о подписчиках, проживающих на заданной улице и домe
                        case ConsoleKey.W:
                            app.ExecQuery02();
                            break;

                        // Выбирает информацию о изданиях с заданной ценной в некотором диапазоне
                        case ConsoleKey.E:
                            app.ExecQuery03();
                            break;

                        // Выбирает информацию о подписчиках, подписавшихся на заданный тип издания
                        case ConsoleKey.R:
                            app.ExecQuery04();
                            break;

                        // Выбирет все подписки, для которых срок подписки есть значение из диапазона
                        case ConsoleKey.T:
                            app.ExecQuery05();
                            break;

                        // Вычисляет для каждой оформленной подписки ее стоимость
                        case ConsoleKey.Y:
                            app.ExecQuery06();
                            break;

                        // Вычисляет для каждого вида макс. и мин. цену 1 экземпляра
                        case ConsoleKey.U:
                            app.ExecQuery07();
                            break;

                        // Вычисляет для всех улиц количество подписчиков, проживающих на данной улице
                        case ConsoleKey.I:
                            app.ExecQuery08();
                            break;

                        // Для всех изданий выводит количество оформленных подписок
                        case ConsoleKey.O:
                            app.ExecQuery09();
                            break;

                        // Шифрование конфигурационного файла
                        case ConsoleKey.A:
                            app.CodeConfigurationFile();
                            break;

                        // Расшифрование конфигурационного файла
                        case ConsoleKey.S:
                            app.ConfigurationFile();
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;

        }// Main
    }
}
