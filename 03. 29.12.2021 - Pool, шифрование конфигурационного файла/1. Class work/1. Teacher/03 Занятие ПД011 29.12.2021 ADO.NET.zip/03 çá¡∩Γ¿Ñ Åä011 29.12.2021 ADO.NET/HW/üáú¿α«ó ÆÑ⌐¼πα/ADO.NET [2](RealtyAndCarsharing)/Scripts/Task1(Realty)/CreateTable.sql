﻿ -- ==================>  Создание таблиц  <==================

 -- удаление существующих таблиц, работает в MS SQL Server 2016+
drop table if exists Transactions;
drop table if exists Owners;
drop table if exists Realtors;
drop table if exists Apartments;
drop table if exists HouseNumbers;
drop table if exists Streets;
drop table if exists Persons;
go


 -- Таблица хранящая название улицы
create table dbo.Streets(
	Id		    int              not null primary key identity(1,1),
	Street      nvarchar(70)     not null -- название улицы
);
go

-- Таблица хранящая номер дома (решил, что венести ее не помешает) 
create table dbo.HouseNumbers(
	Id		    int              not null primary key identity(1,1),
	HouseNumber nvarchar(15)     not null  -- номер дома
);
go

-- Таблица хранящая информацию о персоне (Фамилия, Имя, Отчество) 
create table dbo.Persons(
	Id int                  not null primary key identity (1,1),
	Surname    nvarchar(40) not null,  -- Фамилия
	[Name]     nvarchar(50) not null,  -- Имя
	Patronymic nvarchar(40) not null   -- Отчество
);

-- Основная таблица "Квартиры" (Apartments)
create table dbo.Apartments(
	Id		        int          not null primary key identity (1,1),
	IdStreet        int          not null, -- Внешний ключ. Связь с таблицей улиц (Streets)
	IdHouseNumber   int          not null, -- Внешний ключ. Связь с таблицей номеров домов (HouseNumbers)
	ApartmentNumber nvarchar(15) not null, -- Номер квартиры
	Area		    float        not null, -- Площадь квартиры
	NumberRooms     int          not null, -- Количество комнат
	Price           int          not null  -- Зафиксированная цена продажи
						           
	-- Проверка стоимости квартиры
	constraint CK_Apartments_Price check (Price > 0),
	-- Проверка площади квартиры
	constraint CK_Apartments_Area check (Area > 0),
	-- Проверка на количество комнат 
	constraint CK_Apartments_NumberRooms check (NumberRooms > 0),

	-- внешний ключ - связь М:1 к таблице Streets(улица)
	constraint FC_Apartments_Streets foreign key(IdStreet) references dbo.Streets(Id),
	-- внешний ключ - связь М:1 к таблице HouseNumbers(номер дома)
	constraint FC_Apartments_HouseNumbers foreign key (IdHouseNumber) references dbo.HouseNumbers(Id)
);
go

-- Основная таблица "Владельцы" (Owners) -- Я не знал,как правильнее назвать :D
-- (содержит информацию о владельце квартиры и ее данных)
create table dbo.Owners(
	Id          int          not null primary key identity (1,1),
	IdPerson    int          not null, -- Внешний ключ. Связь с таблицей персон(Persons)
	Passport    nvarchar(15) not null, -- Серия и номер паспорта
	IdApartment int          not null  -- Внешний ключ. Связь с таблицей квартир(Apartments)

	-- внешний ключ - связь 1:1 к таблице Persons(персона)
	constraint FK_Owners_Persons foreign key (IdPerson) references dbo.Persons(Id),

	-- внешний ключ - связь 1:М к таблице Apartments(квартиры)
	constraint FK_Owners_Apartments foreign key (IdApartment) references dbo.Apartments(Id)
);
go

-- Основная таблица	"Риэлторы" (Realtors)
create table dbo.Realtors(
	Id					    int  not null primary key identity (1,1),
	IdPerson			    int  not null,  -- Внешний ключ. Связь с таблицей персон (Persons)
	PercentageRemuneration float not null   -- Процент вознаграждения, выплачиваемый риэлтору 
											-- за факт оформления сделки купли-продажи
	
	-- внешний ключ - связь 1:1 к таблице Persons(персона)
	constraint CK_Realtors_PercentageRemuneration check (PercentageRemuneration > 0),    

	-- внешний ключ - связь 1:1 к таблице Persons(персона)
	constraint FK_Realtors_Persons foreign key (IdPerson) references dbo.Persons(Id)
);
go

-- Основная таблица "Сделка" (Transactions)
create table dbo.Transactions(
	Id            int  not null primary key identity (1,1),
	IdOwner       int  not null, -- Внешний ключ. Связь с таблицей владельцев(Owners)
	IdRealtor     int  not null, -- Внешний ключ. Связь с таблицей реэлторов(Realtors)
	DateExecution Date not null  -- Дата оформления сделки купли-продаже

	-- внешний ключ - связь М:1 к таблице Owners(владелец)
	constraint FK_Transactions_Owners foreign key (IdOwner) references dbo.Owners(Id),
	
	-- внешний ключ - связь М:1 к таблице Owners(владелец)
	constraint FK_Transactions_Realtors foreign key (IdRealtor) references dbo.Realtors(Id),

);
go