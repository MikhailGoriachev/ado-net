﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqWinForms.Models;

namespace LinqWinForms.Controllers
{
    public class QueryControllers
    {
        //класс для поключения к базt данных
        private WholeSaleDataContext _db;

        public QueryControllers(): this(new WholeSaleDataContext() ) {}

        public QueryControllers(WholeSaleDataContext db)
        {
            _db = db;
        }

        //запросы

        //Запрос 1 Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых является «шт» (штуки)
        //и цена закупки составляет меньше 200 руб.
        public IEnumerable Query1() => _db.Purchases
            .Where(p => p.Unit.Short == "шт" && p.Price < 200)
            .ToList();

        //Запрос 2. Выбирает из таблицы ТОВАРЫ информацию о товарах, цена закупки которых больше 500 руб.
        //за единицу товара

        public IEnumerable Query2() => _db.Purchases
            .Where(p => p.Price > 500)
            .ToList();

        //Запрос 3. Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием
        //(например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
        public IEnumerable Query3() => _db.Purchases
            .Where(p => p.Good.Item == "чехол защитный"  && p.Price < 1800)
            .ToList();

        // Запрос 4. Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением процента комиссионных. 
        public IEnumerable Query4()
        {
            var r = _db.Sellers
                .Where(s => Math.Abs(s.Interest - 10) < 0.5)
                .ToList();
            return r;
        }

        //Запрос 5. Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех зафиксированных
        //фактах продажи товаров (Наименование товара, Цена закупки, Цена продажи, дата продажи),
        //для которых Цена продажи оказалась в некоторых заданных границах. 
        public IEnumerable Query5() => _db.Sales
            .Where(s => s.Price >= 500 && s.Price <= 1000)
            .ToList();
        //Запрос 6. Вычисляет прибыль от продажи за каждый проданный товар.
        //Включает поля Дата продажи, Наименование товара, Цена закупки,
        //Цена продажи, Количество проданных единиц, Прибыль. Сортировка по полю Наименование товара

        public IEnumerable Query6() => _db.Sales.OrderBy(s => s.Purchase.Good.Item)
            .Select(s => new
            {
                s.Id,
                s.SaleDate,
                Goods = s.Purchase.Good.Item,
                Seller = $"{s.Seller.Person.Surname} {s.Seller.Person.Name[0]}. {s.Seller.Person.Patronymic[0]}",
                s.Amount,
                s.Price,
                Unit = s.Unit.Short,
                SumPrice = s.Price * s.Amount
            });

        //Запрос 7. Выполняет группировку по полю Наименование товара. Для каждого наименования вычисляет среднюю цену
        //закупки товара, количество закупок
        public IEnumerable Query7() => _db.Purchases.GroupBy(purchase => new
            {
                purchase.Good.Item, purchase.Unit.Long

            })
            .Select(a => new
            {
                a.Key.Item,
                a.Key.Long,
                Avg = a.Average(b => b.Price),
                Nmr = a.Count()
            });

        //Запрос 8. Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ. Для каждого продавца
        //вычисляет среднее значение по полю Цена продажи единицы товара, количество продаж

        public IEnumerable Query8() => _db.Sales.GroupBy(sales => new
            {
                sales.Id, sales.Seller.Person.Name, sales.Seller.Person.Surname
            })
            .Select(a => new
            {
                a.Key.Id,
                a.Key.Name,
                a.Key.Surname,
                Avg = a.Average(b => b.Price),
                Nmr = a.Count()
            });
    }
}
