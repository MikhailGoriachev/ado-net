﻿using System.Windows;
using Main.Controllers;
using Main.Models;


namespace Main.Views
{
	public sealed partial class MainWindow : Window
	{
		private readonly MainController _controller;
		public MathModel Model { get; }


		public MainWindow()
		{
			Model       = new();
			_controller = new(Model);

			InitializeComponent();
		}


		private void ArithmeticButton_OnClick(object sender, RoutedEventArgs e) =>
			ResultTextBlock.Text = $"Среднее арифметическое: {_controller.CalculateAverageArithmetic():F}";


		private void GeometricButton_OnClick(object sender, RoutedEventArgs e) =>
			ResultTextBlock.Text = $"Среднее геометрическое: {_controller.CalculateAverageGeometric():F}";


		private void EquationButton_OnClick(object sender, RoutedEventArgs e)
		{
			var (x1, x2) = _controller.CalculateEquation();

			ResultTextBlock.Text = $"x1 = {x1:F}, \tx2 = {x1:F}";
		}
	}
}