﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
	public class StoreQueriesController
	{
		// связь с базой данных
		private StoreDataContext _storeDb;


		#region Конструкторы

		public StoreQueriesController() : this(new StoreDataContext()) { }

		public StoreQueriesController(StoreDataContext storeDb)
		{
			_storeDb = storeDb;
		}

		#endregion

		#region Запросы для вывода таблиц (основных)

		// таблица наименований товаров
		public IEnumerable GetGoodsAll() => _storeDb.Goods
			.Select(g => new {
				g.Id,
				g.Name
			})
			.ToList();


		// таблица сведений о продавцах
		public IEnumerable GetSellersAll() => _storeDb.Sellers
			.Select(s => new {
				s.Id,
				s.Surname,
				s.Name,
				s.Patronymic,
				s.Interest
			})
			.ToList();

		// таблица сведений о закупках
		public IEnumerable GetPurchasesAll() => _storeDb.Purchases
			.Select(p => new {
				p.Id,
				p.Goods.Name,
				p.PurchaseDate,
				p.PurchasePrice,
				p.Amount,
				p.Units.Short
			})
			.ToList();

		// таблица сведений о продажах
		public IEnumerable GetSalesAll() => _storeDb.Sales
			.Select(s => new {
				s.Id,
				s.Purchases.Goods.Name,
				SurnameNP = $"{s.Sellers.Surname} {s.Sellers.Name[0]}.{s.Sellers.Patronymic[0]}",
				s.SellDate,
				s.Price,
				s.Amount,
				s.Units.Short,
			})
			.ToList();

		#endregion

		#region Запросы

		// Tовары, единицей измерения которых является «шт» и цена закупки составляет меньше 200 руб.
		public IEnumerable Query01() => _storeDb.Purchases
			.Where(x => x.Units.Short.Contains("шт") && x.PurchasePrice < 200)
			.Select(x => new GoodsPurchaseViewModel()
			{
				Id = x.Id,
				Title = x.Goods.Name,
				Price = x.PurchasePrice,
			});

		// Товары, цена закупки которых больше 500 руб. за единицу товара
		public IEnumerable Query02() => _storeDb.Purchases
			.Where(x => x.PurchasePrice > 500)
			.Select(x => new GoodsPurchaseViewModel()
			{
				Id = x.Id,
				Title = x.Goods.Name,
				Price = x.PurchasePrice,
			});

		//Товары с заданным наименованием, для которых цена закупки меньше 1800 руб.
		public IEnumerable Query03() => _storeDb.Purchases
			.Where(x => x.PurchasePrice < 1800 && x.Goods.Name == "Гайка М 3 ЦБ")
			.Select(x => new GoodsPurchaseViewModel()
			{
				Id = x.Id,
				Title = x.Goods.Name,
				Price = x.PurchasePrice,
			});

		//Продавцы с заданным значением процента комиссионных.
		public IEnumerable Query04() =>
			_storeDb.Sellers
			.Where(s => s.Interest.Equals(9))
			.Select(s => new SellerViewModel
			{
				Id = s.Id,
				SurnameNP = s.Surname + " " + s.Name[0] + "." + s.Patronymic[0] + ".",
				Interest = s.Interest
			});


		//Все зафиксированные факты продажи товаров, с ценой продажи в заданных границах. 
		public IEnumerable Query05() =>
			_storeDb.Sales.Where(s => s.Price >= 300 && s.Price <= 600)
			.Select(s => new SaleViewModel
			{
				Title = s.Purchases.Goods.Name,
				PurchasePrice = s.Purchases.PurchasePrice,
				SalePrice = s.Price,
				SellDate = s.SellDate
			});


		// Прибыль от продажи за каждый проданный товар. Сортировка по полю Наименование товара
		public IEnumerable Query06() =>
			_storeDb.Sales.Select(s => new ProfitModelView()
			{
				Title = s.Purchases.Goods.Name,
				SellDate = s.SellDate,
				PurchasePrice = s.Purchases.PurchasePrice,
				SellPrice = s.Price,
				Amount = s.Amount,
				Profit = (s.Price - s.Purchases.PurchasePrice) * s.Amount
			})
				.OrderBy(s => s.Title);

		// Cредняя цена закупки товара для каждого наименования и количество закупок, группировка по наименованию товара:
		public IEnumerable Query07() =>
			_storeDb.Purchases.GroupBy(p => p.Goods.Name, (key, group) => new Query07ViewModel()
			{
				Title = key,
				AvgPurchasePrice = group.Average(p => p.PurchasePrice),
				SalesAmount = group.Count()
			});


		// Среднее значение цены продажи единицы товара для каждого продавца, количество продаж
		public IEnumerable Query08() =>
			_storeDb.Sales.GroupBy(s => s.IdSeller, (key, group) => new Query08ViewModel()
			{
				SurnameNP = group.Where(s => s.IdSeller == key).Select(s => s.Sellers.Surname + " " + s.Sellers.Name[0] + "." + s.Sellers.Patronymic[0] + ".").First(),
				AvgSalePrice = group.Average(s => s.Price),
				SalesAmount = group.Count()
			});

		// Выбирает всех продавцов (выводить Код продавца, фамилию и инициалы продавца),
		// количество и суммы их продаж за заданный период, упорядочивать по фамилиям и инициалам 
		public IEnumerable Query09() =>
				_storeDb.Sellers
					.GroupJoin(_storeDb.Sales
							.Where(s => s.SellDate > new DateTime(2021, 08, 01) 
							            && s.SellDate < new DateTime(2021, 11, 01)), 
						seller => seller.Id, 
						sale => sale.IdSeller,
						(seller, group_join) => new
						{
							seller, group_join
						})
					.SelectMany(t => t.group_join.DefaultIfEmpty(),
						(t, subSale) => new
						{
							t.seller.Id,
							Seller = $"{t.seller.Surname} {t.seller.Name[0]}.{t.seller.Patronymic[0]}.",
							Amount = (int?) subSale.Amount,
							Price = (int?) subSale.Price
						}).ToList()
					.GroupBy(s => s.Seller, (key, group) => new
					{
						Seller = key,
						SalesCount = group.Count(s => s.Price != 0),
						SumSales = group.Sum(s => s.Price * s.Amount)
					}).OrderBy(s => s.Seller)
					.ToList();


					// На формате запросов дальше этого не получалось
					//(from seller in _storeDb.Sellers
					//	join sale in _storeDb.Sales on seller.Id equals sale.IdSeller into group_join
					//	from subSale in group_join.DefaultIfEmpty()
					//	select new
					//{
					//	seller.Id,
					//	Seller = $"{seller.Surname} {seller.Name[0]}.{seller.Patronymic[0]}.",
					//	Amount = (int?) subSale.Amount ?? 0,
					//	Price = (int?)subSale.Price ?? 0
					//}
					//).ToList();

		// Выбирает все товары, количество и сумму продаж по этим товарам.
		// Упорядочивать по убыванию суммы продаж

		public IEnumerable Query10() =>
			_storeDb.Goods.GroupJoin(_storeDb.Sales,
				goods => goods.Id,
				sale => sale.Purchases.IdGood,
				(goods, group_join) => new
				{
					goods,
					group_join
				}).SelectMany(g => g.group_join.DefaultIfEmpty(),
				(g, subGood) => new
				{
					g.goods.Id,
					g.goods.Name,
					Amount = (int?)subGood.Amount,
					Price = (int?)subGood.Price
				}).ToList()
				.GroupBy(g => g.Name, (key, group) => new
				{
					Title = key,
					SalesCount = group.Count(s => s.Price != 0),
					SumSales = group.Sum(s => s.Price * s.Amount)
				}).OrderByDescending(s => s.SumSales)
				.ToList();


		#endregion
	}
}
