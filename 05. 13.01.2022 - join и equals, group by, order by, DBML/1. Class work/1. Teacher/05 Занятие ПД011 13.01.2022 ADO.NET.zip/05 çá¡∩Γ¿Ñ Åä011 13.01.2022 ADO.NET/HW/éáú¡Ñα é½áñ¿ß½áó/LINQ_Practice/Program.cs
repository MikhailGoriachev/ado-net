﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;

using LINQ_Practice.Utilities;
using LINQ_Practice.App;


namespace LINQ_Practice
{
    public class Program
    {
        static void Main(string[] args)
        {
            Application app = new Application();
            app.ShowMenu("Задание на 13.01.22");

        }


       
    }
}
