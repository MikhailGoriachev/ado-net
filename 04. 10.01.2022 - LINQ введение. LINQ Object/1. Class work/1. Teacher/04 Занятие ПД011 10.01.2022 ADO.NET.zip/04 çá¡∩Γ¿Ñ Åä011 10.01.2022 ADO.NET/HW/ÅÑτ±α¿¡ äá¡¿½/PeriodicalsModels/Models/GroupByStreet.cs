﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeriodicalsModels.Models
{
    public class GroupByStreet
    {
        public string Street { get; set; }

        public int SubscriberAmount { get; set; }

        public string ToTableRow() =>
            $"\t | {Street, 16} | {SubscriberAmount, 15}|"; 
    }
}
