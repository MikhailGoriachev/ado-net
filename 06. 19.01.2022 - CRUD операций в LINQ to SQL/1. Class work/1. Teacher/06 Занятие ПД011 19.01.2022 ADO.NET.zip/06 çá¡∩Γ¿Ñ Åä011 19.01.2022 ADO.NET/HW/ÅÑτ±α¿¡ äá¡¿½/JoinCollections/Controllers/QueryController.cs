﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using JoinCollections.Models;

namespace JoinCollections.Controllers
{
    class QueryController
    {
        public List<Book> books = new List<Book>()
        {
            new Book{ Id = 1, Title = "Степной Волк", Published = 2001, Price = 400, IdAuthor = 1},
            new Book {Id = 2, Title = "Так говорил Заратустра", Published = 2001, Price = 534, IdAuthor = 2},
            new Book {Id=3, Title = "Постфилософия", Published = 2020, Price = 1200, IdAuthor = 3},
            new Book{Id = 4, Title = "Мораль и Догма", Published = 2007, Price = 600, IdAuthor = 4},
            new Book{Id = 5, Title = "Tertium Organum",Published = 2002, Price = 567, IdAuthor = 5},
            new Book{Id = 6, Title = "У врат Теософии", Published = 2004, Price = 756, IdAuthor = 6},
            new Book{Id = 7, Title = "Оседлать тигра", Published = 2016, Price = 1000, IdAuthor = 7},
            new Book{Id = 8, Title = "Воспоминания о будущем", Published = 2020,Price = 1100, IdAuthor = 8},
            new Book{Id = 9, Title = "Философские Обители", Published = 2004, Price = 908, IdAuthor = 9},
            new Book{Id = 10, Title = "Царство количества и знамения времени", Published = 2011,Price = 429, IdAuthor = 10},
            new Book{Id = 11, Title = "Лук и булава", Published = 2004,Price = 450, IdAuthor = 7}
        };

        public List<Author> authors = new List<Author>()
        {
            new Author {Id = 1, SurnameNP = "Герман Гессе", BirthYear = 1877},
            new Author {Id = 2, SurnameNP = "Фридрих Ницше", BirthYear = 1844},
            new Author {Id = 3, SurnameNP = "Дугин А.Г.", BirthYear = 1962},
            new Author {Id = 4, SurnameNP = "Альберт Пайк", BirthYear = 1809},
            new Author {Id = 5, SurnameNP = "Успенски П.Д", BirthYear = 1878},
            new Author {Id = 6, SurnameNP = "Штайнер Рудольф", BirthYear = 1861},
            new Author {Id = 7, SurnameNP = "Юлиус Эвола", BirthYear = 1898},
        };

        // Вывести все книги коллекции, выводить фамилии и инициалы автора
        public  void Exec1(List<Book> books, List<Author> authors)
        {
            var request =
                from book in books
                from author in authors
                where book.IdAuthor == author.Id
                select new
                {
                    book.Title,
                    author.SurnameNP
                };
            var result = request.ToList();
            ShowList(result, "\nВсе книги коллекции");
        }

        public void Exec1Join(List<Book> books, List<Author> authors)
        {
            var request =
                from book in books
                join author in authors on book.IdAuthor equals author.Id
                select new
                {
                    book.Title,
                    author.SurnameNP
                };
            var result = request.ToList();
            ShowList(result,"\nВсе книги коллекции, синтаксис JOIN");
        }

        public void Exec1JoinExtended(List<Book> books, List<Author> authors)
        {
            var request = books
                .Join(authors, book => book.IdAuthor, city => city.Id,
                (book, author) => new {book.Title, author.SurnameNP});
            var result = request.ToList();

            ShowList(result, "\nВсе книги колеекции, расширяющий метод JOIN");
        }

        //Вывести книги авторов, год рождения которых принадлежит заданном диапазону
        public void Exce2(List<Book> books, List<Author> authors)
        {
            var request = books.Join(authors.Where(a => a.BirthYear > 1850 && a.BirthYear < 1900),
                    b => b.IdAuthor,
                    a => a.Id, (b, c) => new {b.Title, c.SurnameNP, BirthYear = c.BirthYear})
                .ToList();
            ShowList(request,"\n Список книг авторов, с годом рождения от 1850 до 1900");
        }

        //Вывести книги, в названии которых содержится заданная подстрока и цена не превышает заданного значения
        public void Exec3(List<Book> books, List<Author> authors)
        {
            var request = books
                .Where(a => (a.Title.IndexOf("фил", 0, StringComparison.OrdinalIgnoreCase) > -1) && a.Price <= 1300)
                .ToList();
            ShowList(request, "Книги с подстрокой\"фил\" и ценой не более 1300 рублей\n\n");
        }

        //Список авторов и количество их книг в коллекции
        public void Exec4(List<Book> books, List<Author> authors)
        {
            var request = authors.Join(books, b => b.Id, a => a.IdAuthor, (b, a) => new {b, a})
                .GroupBy(name => name.b, name => name.a)
                .Select(Authors => new
                {
                    Author = Authors.Key, BooksCount = Authors.Count()
                }).ToList();
            ShowList(request, "Авторы и количество их книг");
        }

        //Средняя цена книг по годам издания
        public void Exec5(List<Book> books, List<Author> authors)
        {
            var request = books.Join(authors, b => b.IdAuthor, a => a.Id, (a, b) => new {a, b})
                .GroupBy(name => name.a.Published, name => name.a)
                .Select(Books => new
                {
                    PublishedOn = Books.Key, AveragePrice = Books.Average((Book) => Book.Price)
                }).ToList();
            ShowList(request, "\nСредняя цена книг по годам издания");
        }

        //Список авторов по убыванию количества их книг в коллекции 
        public void Exec6(List<Book> books, List<Author> authors)
        {
            var request = authors.Join(books, a => a.Id, b => b.IdAuthor, (a, b) => new {a, b})
                .GroupBy(name => name.a, name => name.b)
                .Select(name => new
                {
                    Author = name.Key, NumberOfBooks = name.Count()
                })
                .OrderByDescending((name) => name.NumberOfBooks)
                .ToList();
            ShowList(request, "\nСписок авторов, по убыванию книг");
        }

        //Средний возраст книг по авторам, выводить список с упорядочиванием
        //фамилий и инициалов авторов по алфавиту
        public void Exec7(List<Book> books, List<Author> authors)
        {
            var request = books.Join(authors, b => b.IdAuthor, a => a.Id, (a, b) => new {a, b})
                .GroupBy(name => name.b, name => name.a)
                .Select(name => new
                {
                    Author = name.Key, AverageBookAge = name.Average((name1) => DateTime.Now.Year - name1.Published)
                }).OrderBy((name) => name.Author.SurnameNP)
                .ToList();
            ShowList(request,"\nСредний возраст книг по авторам");

        }

        public static void ShowList <T>(List<T> list, string title)
        {
            Console.WriteLine(title);
            foreach (var item in list)
            {
                Console.WriteLine($"{item}");
            }

        }



    }
}
