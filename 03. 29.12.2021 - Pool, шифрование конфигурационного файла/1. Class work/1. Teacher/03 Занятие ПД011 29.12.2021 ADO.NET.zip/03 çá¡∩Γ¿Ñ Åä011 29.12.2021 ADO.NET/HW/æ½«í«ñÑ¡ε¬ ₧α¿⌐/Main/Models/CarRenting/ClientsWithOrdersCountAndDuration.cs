﻿using Main.Utilities.TableFormatter;


namespace Main.Models.CarRenting
{
	public sealed class ClientsWithOrdersCountAndDuration
	{
		[TableData("Имя", "{0, -15}")]
		public string? Firstname { get; set; }

		[TableData("Фамилия", "{0, -15}")]
		public string? Surname { get; set; }

		[TableData("Отчество", "{0, -10}")]
		public string? Patronymic { get; set; }

		[TableData("Паспорт", "{0, -35}")]
		public string? Passport { get; set; }

		[TableData("Кол-во заказов", "{0, -16}")]
		public int Count { get; set; }

		[TableData("Кол-во дней", "{0, -14}")]
		public int Days { get; set; }
	}
}