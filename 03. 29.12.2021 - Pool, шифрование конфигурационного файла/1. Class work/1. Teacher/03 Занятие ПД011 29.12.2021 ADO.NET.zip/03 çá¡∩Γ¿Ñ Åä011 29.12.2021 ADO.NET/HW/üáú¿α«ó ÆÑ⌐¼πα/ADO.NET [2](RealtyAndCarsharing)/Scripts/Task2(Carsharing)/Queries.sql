﻿
--			Вывод  представления ViewRentals  
select
	*
from 
	ViewRentals;
go
 
 
 --			Вывод  представления ViewCars  
select
	*
from 
	ViewCars;
go
 
 ---------------------------- 

--			-> Запрос №1 [ Запрос к представлению ] <-
-- Выбирает информацию обо всех фактах проката автомобиля с заданным госномером
declare @plate nvarchar(9) = N'X 305 BX';
select
	*
from
	ViewRentals
where
	Plate = @plate;
go
	 

--			-> Запрос №2 [ Запрос к представлению ] <-
-- Выбирает информацию обо всех фактах проката автомобиля с заданной моделью/брендом
declare @brandModel  nvarchar(80) = N'BMW X5';
select
	*
from
	ViewRentals
where
	BrandModelCar = @brandModel;
go


--			-> Запрос №3 [ Запрос к представлению ] <-
-- Выбирает информацию об автомобиле с заданным госномером
declare @plate nvarchar(10) = N'T 799 MO';
select
	*
from
	ViewCars
where
	Plate = @plate;
go


--			-> Запрос №4 [ Запрос с параметром ] <-
-- Выбирает информацию о клиентах по серии и номеру паспорта
declare @passport nvarchar(12) = N'12 21 345675';
select
	 *
from
	Clients
where
	Passport = @passport;
go


--			-> Запрос №5 [ Запрос к представлению ] <-
-- Выбирает информацию обо всех зафиксированных фактах проката автомобилей в некоторый заданный интервал времени.
declare @loDate Date = '2021-10-11', @hiDate Date = '2021-11-22';
select
	*
from
	ViewRentals
where
	DateStartRental between @loDate and @hiDate
order by
	DateStartRental;
go


--			-> Запрос №6 [ Запрос к представлению ] <-
-- Вычисляет для каждого факта проката стоимость проката.
-- Включает поля Дата проката, Госномер автомобиля, Модель автомобиля, Стоимость проката.
-- Сортировка по полю Дата проката
select
	DateStartRental
	,Plate
	,BrandModelCar
	,RentalsPrice  
from
	ViewRentals
order by 
	DateStartRental;
go
	


--			-> Запрос №7 [ Запрос с левым соединением ] <-
-- Для всех клиентов прокатной фирмы вычисляет количество фактов проката, 
-- суммарное количество дней проката, упорядочивание по убыванию суммарного количества дней проката
select
	Clients.Surname + N' ' + SUBSTRING(Clients.[Name],1,1) + N'. ' + SUBSTRING(Clients.Patronymic,1,1) + N'.' as Client
	,Clients.Passport
	,COUNT(Rentals.IdCar   ) as AmountRental
	,Sum  (Rentals.Duration) as SumDayRental
from
	Clients left join Rentals on Clients.Id = Rentals.IdClient
group by
	Clients.[Name],Clients.Surname,Clients.Patronymic, Clients.Passport
order by
	Sum (Rentals.Duration) desc;
go


--			-> Запрос №8 [ Итоговый запрос ] <-
-- Выполняет группировку по полю Модель автомобиля. 
-- Для каждой модели вычисляет количество фактов проката, сумму за прокат
select
	 Brands.Brand 
	 ,Count(Brands.Brand)			       as AmountRental
	 ,Sum(Cars.Rental * Rentals.Duration)  as SumRental
from 
	(Brands  join Cars  on Brands.Id = Cars.IdBrand ) left join Rentals on Cars.Id  = Rentals.IdCar
group by
	Brands.Brand;
go	


--			-> Запрос №9 [ Запрос на добавление ] <-
-- Добавляет данные о новом клиенте. Данные передавайте параметрами	

--				[ Вывод до добавления нового клиента ]
select
	*
from
	Clients;
 

--				     [ Само добавление клиента ]     
declare @surname    nvarchar(60) = N'Петров',
        @name       nvarchar(50) = N'Илья',
        @patronymic nvarchar(60) = N'Георгиевич',
        @passport   nvarchar(15) = N'09 20 000222';
insert into Clients
	(Surname,[Name],Patronymic,Passport)
values
	(@surname,@name,@patronymic,@passport);
 

--				[ Вывод после добавления нового клиента ]
select
	*
from
	Clients;
go


	 

--			-> Запрос №10 [ Запрос на обновление ] <-
-- Изменяет данные клиента (все поля, кроме идентификатора). Данные передавайте параметрами

--				[ Вывод до изменения данных клиента ]
select
	*
from
	Clients;
 

--				     [ Само изменение клиента ]     
declare @surname   nvarchar(60) = N'Кошечкин',
        @name      nvarchar(50) = N'Степан',
        @patonymic nvarchar(60) = N'Артурович',
        @passport  nvarchar(15) = N'09 20 000222',
        @id        int  = FLOOR(Rand()* (16-1)+1);

update 
	Clients
set
	Surname     = @surname
	,[Name]     = @name
	,Patronymic = @patonymic
	,Passport   = @passport
	 
where
	Clients.Id = @id;
 

--				[ Вывод после изменения данных клиента ]
select @id as IndexEdit;  -- индекс измененного элемента
select
	* 
from
	Clients;
go


--			-> Запрос №11 [ Запрос на обновление ] <-
-- Изменяет данные автомобиля (все поля, кроме идентификатора). Данные передавайте параметрами
		
		-- [Вывод перед изменениями в таблице Cars]
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
go
	
	-- [Изменение данных в таблице Cars]
declare @brand         nvarchar(80) = N'Skoda Octavia Tour'  ,
	    @color         nvarchar(50) = N'Фиолетовый'   ,
	    @plate         nvarchar(12) = N'A 210 MP'    ,
	    @yearMount     nvarchar(12) = 2009           ,
	    @insurancePay  nvarchar(12) = 245000         ,
	    @rental        nvarchar(12) = 2500           ,
		@id            int  = FLOOR(Rand()* (16-1)+1);
update  
	Cars
set
	Cars.IdBrand      = (select Id from Brands where Brand = @brand),
	Cars.IdColor      = (select Id from Colors where Color = @color),
	Cars.Plate        = @plate, 
	Cars.YearMount    = @yearMount,
	Cars.InsurancePay = @insurancePay,
	Cars.Rental       = @rental
where
	Cars.Id = @id ;

	
		-- [Вывод после изменений в таблице Cars]
select @id as IndexEdit;  -- индекс измененного элемента
select
	 Cars.Id
	,Brands.Brand
	,Colors.Color
	,Cars.Plate
	,Cars.YearMount
	,Cars.InsurancePay
	,Cars.Rental
from
	Cars join Brands on Cars.IdBrand =  Brands.Id
		 join Colors on Cars.IdColor = Colors.Id
go


--			-> Запрос №12 [ Изучение T-SQL ] <-
-- Задача If13. Даны три числа. Найти среднее из них 
-- (то есть число, расположенное между наименьшими наибольшим). 
-- Числа формируйте генератором случайных чисел
 
 
declare @a int = -200 + 300*rand(),
		@b int = -200 + 300*rand(),
		@c int = -200 + 300*rand(),
		@mid int;
if (@a > @b and @b > @c) or (@c > @b and @b > @a) 
	set @mid = @b;
else if  (@b > @a and @a > @c) or (@c > @a and @a > @b) 
	set @mid = @a;
else set @mid = @c;

select @a as 'a', @b as 'b', @c as 'c', @mid as 'mid';
print N'Результат:' + char(10) +  
      char(9) + 'a   = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b   = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c   = ' + ltrim(str(@c)) + char(10) + 
      char(9) + 'avg = ' + ltrim(str(@mid));
go 


--			-> Запрос №13 [ Изучение T-SQL ] <-
-- Задача If14. Даны три числа. Вывести вначале наименьшее, а затем наибольшее их данных чисел.
-- Числа формируйте генератором случайных чисел
declare @a int = -200 + 300*rand(),
		@b int = -200 + 300*rand(),
		@c int = -200 + 300*rand(),
		@min int, @max int;

if @a < @b and @a < @c begin
   set @min = @a;
end else if @b < @a and @b < @c begin
   set @min = @b;
end else begin
	set @min = @c;
end;

if @a <> @min and @a > @b and @a > @c begin
	set @max = @a;
end else if @b <> @min and @b > @c and @b > @a begin
	set @max = @b;
end else begin
	set @max = @c;
end;

select @a as 'a', @b as 'b', @c as 'c', @min as 'min', @max as 'max';
print N'Результат:' + char(10) +    
      char(9) + 'a   = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b   = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c   = ' + ltrim(str(@c)) + char(10) + 
      char(9) + 'min = ' + ltrim(str(@min)) + char(10) + 
      char(9) + 'max = ' + ltrim(str(@max));
go



--			-> Запрос №14 [ Изучение T-SQL ] <-
-- Задача If15. Даны три числа. Найти сумму двух наибольших из них.
-- Числа формируйте генератором случайных чисел

declare @a    int = -200 + 300*rand(),
		@b    int = -200 + 300*rand(),
		@c    int = -200 + 300*rand(),
		@sumTwoMax  int;

if @a <= @b and @a <= @c begin
	set @sumTwoMax = @b + @c
end else if @b <= @a and @b <= @c begin
	set @sumTwoMax = @a +@c
end else if @c <= @a and @c <= @b begin
	set @sumTwoMax = @a + @b
end;

select @a as 'a', @b as 'b', @c as 'c', @sumTwoMax as 'sumTwoMax';
print N'Результат:' + char(10) +    
      char(9) + 'a         = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b         = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c         = ' + ltrim(str(@c)) + char(10) + 
      char(9) + 'sumTwoMax = ' + ltrim(str(@sumTwoMax));
go

--			-> Запрос №15 [ Изучение T-SQL ] <-
-- Задача If17. Даны три числа. 
-- Если их значения упорядочены по возрастанию или убыванию, то удвоить их; 
-- в противном случае заменить значение каждой переменной на противоположное.
-- Числа формируйте генератором случайных чисел или присваиванием

declare @a    int = -200 + 300*rand(),
		@b    int = -200 + 300*rand(),
		@c    int = -200 + 300*rand();

select N'До обработки:'  as [State], @a as 'a', @b as 'b', @c as 'c' ;
print N'До обработки:' + char(10) +  
   char(9) + 'a    = ' + ltrim(str(@a)) + char(10) +
   char(9) + 'b    = ' + ltrim(str(@b)) + char(10) + 
   char(9) + 'c    = ' + ltrim(str(@c)); 


if (@a < @b and @b < @c) or (@a > @b and @b > @c) begin
	set @a *= 2;
	set @b *= 2;
	set @c *= 2;
end else begin
	set @a = -@a;
	set @b = -@b;
	set @c = -@c;
end

select  N'После обработки:' as [State], @a as 'a', @b as 'b', @c as 'c'  ;
print char(10) + N'После обработки:' + char(10) +   
      char(9) + 'a    = ' + ltrim(str(@a)) + char(10) +
      char(9) + 'b    = ' + ltrim(str(@b)) + char(10) + 
      char(9) + 'c    = ' + ltrim(str(@c)); 
go
