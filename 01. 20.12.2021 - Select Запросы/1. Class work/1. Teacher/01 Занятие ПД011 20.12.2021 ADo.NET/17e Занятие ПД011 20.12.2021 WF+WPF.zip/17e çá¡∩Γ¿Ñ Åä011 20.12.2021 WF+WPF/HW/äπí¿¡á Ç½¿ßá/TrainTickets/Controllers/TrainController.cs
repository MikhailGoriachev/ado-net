﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using TrainTickets.Helpers;
using TrainTickets.Models;
using TrainTickets.ViewModels;

namespace TrainTickets.Controllers
{
    public class TrainController {
        // данные поезда, которым мы управляем 
        private Train _train;
        public Train Train {
            get => _train;
            private set => _train = value;
        } // Train


        // имя папки для хранения файла данных 
        public string InitialFolderName { get; set; } = "App_Data";

        // имя файла для хранения данных 
        public string FileName { get; set; } = "train.json";


        #region Ансамбль конструкторов

         public TrainController() : this(new Train())
         {
         
         } // ApartmentController

        public TrainController(Train train) {
            _train = train;
            if (_train.TrainCars.Count == 0) {
                _train.Initialize(Utils.GetRandom(5, 10));

                // сохранить данные в файле, при необходимости - создать папку
                FileName = InitialFolderName + "\\" + FileName;
                SerializeData();
            } // if

        } // TrainController

        #endregion

        // -----------------------------------------------------------------------------------

        // сериализация данных в формате JSON
        public void SerializeData() {
            // если нет папки для хранения данных - создать папку
            if (!Directory.Exists(InitialFolderName))
                Directory.CreateDirectory(InitialFolderName);

            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Train));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(FileName, FileMode.Create))
                jsonFormatter.WriteObject(fs, _train);
        } // SerializeData


        // десериализация данных из формата JSON
        public void DeserializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Train));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate)) {
                _train = (Train)jsonFormatter.ReadObject(fs);
            }
        } // DeserializeData

        // -----------------------------------------------------------------------------------
        // Запрос на выборку в коллекцию информации о вагоне для отображения в DataGridView
        public List<CarriageView> SelectWhereNumber(int carriageNumber) =>
            _train.MapToCarriageView(carriageNumber);
        // -----------------------------------------------------------------------------------
        // сортировка поезда по возрастанию номеров вагонов
        public void OrderByNumber() =>
           _train.OrderBy((x, y) => x.Number.CompareTo(y.Number));

        // сортировка поезда по убыванию номеров вагонов
        public void OrderByNumberDesc() =>
            _train.OrderBy((x, y) => y.Number.CompareTo(x.Number));

        // сортировка вагонов по убыванию количества проданных мест
        public void OrderByCountSold() =>
            _train.OrderBy((x, y) => y.CountSales().CompareTo(x.CountSales()));

    }
}
