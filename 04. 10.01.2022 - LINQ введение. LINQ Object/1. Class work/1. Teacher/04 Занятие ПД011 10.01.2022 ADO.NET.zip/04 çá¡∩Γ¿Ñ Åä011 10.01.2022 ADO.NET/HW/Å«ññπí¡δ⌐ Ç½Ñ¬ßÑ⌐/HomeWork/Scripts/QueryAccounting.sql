﻿-- запросы по заданию

-- 1	Запрос с параметром	
--		Выбирает из таблицы ИЗДАНИЯ информацию о доступных для подписки изданиях заданного типа,
--		стоимость 1 экземпляра для которых меньше заданной.

drop proc if exists Proc1;
go

create proc Proc1
    @TypeOfPublications nvarchar(50),    
    @price int            
as
    begin 
        select
        Id
        , [Index]
        , TypeOfPrintEdition
        , NameOfPublications
        , Price
    from
        ViewPublications
    where
        Price < @price and TypeOfPrintEdition = @TypeOfPublications
end;
go

-- проверка
declare @TypeOfPublications nvarchar(50) = N'газета', 
        @price int = 80;

exec Proc1 @TypeOfPublications, @price;
go

--2	    Запрос с параметром	
--      Выбирает из таблиц информацию о подписчиках, проживающих на заданной параметром улице и номере дома, 
--      которые оформили подписку на издание с заданным параметром наименованием

drop proc if exists Proc2;
go

create proc Proc2
    @NameOfPublications nvarchar(50), 
    @NameOfStreet nvarchar(60),
    @HouseNumber nvarchar(10)           
as
    begin 
        select      
            Id
            , Surname
            , [Name]
            , Patronymic    
            , PassportID
            , StreetType + N' ' + StreetName + N' ' + HouseNumber + N'/' + ApartmentNumber as [Address] 
            , [Index]
            , TypeOfPrintEdition
            , NameOfPublications
            , Price
            , DateStartSubsribe
            , SubscriptionTerm
        
        
        from
            ViewSubscribers
        where
            NameOfPublications = @NameOfPublications
            and StreetName = @NameOfStreet
            and HouseNumber = @HouseNumber
    end;
go


declare @NameOfPublications nvarchar(50) = N'Ведомости', 
        @NameOfStreet nvarchar(60) = N'Артёма',
        @HouseNumber nvarchar(10) = N'5а';

exec Proc2 @NameOfPublications, @NameOfStreet, @HouseNumber;
go

--3	   Запрос с параметром	
--     Выбирает из таблицы ИЗДАНИЯ информацию об изданиях, для которых значение в поле 
--     Цена 1 экземпляра находится в заданном диапазоне значений

drop proc if exists Proc3;
go

create proc Proc3
    @lo int, 
    @hi int           
as
    begin 
        select
        Id
        , [Index]
        , TypeOfPrintEdition
        , NameOfPublications
        , Price
    from
        ViewPublications
    where
        Price between @lo and @hi
end;
go

-- проверка
declare @lo int = 50, 
        @hi int = 80;

exec Proc3 @lo, @hi;
go





--4	    Запрос с параметром	
--      Выбирает из таблиц информацию о подписчиках, подписавшихся на заданный параметром тип издания

drop proc if exists Proc4;
go

create proc Proc4
   @TypeOfPublications nvarchar(50)         
as
    begin 
        select    
        Id
            , Surname
            , [Name]
            , Patronymic    
            , PassportID
            , StreetType + N' ' + StreetName + N' ' + HouseNumber + N'/' + ApartmentNumber as [Address] 
            , [Index]
            , TypeOfPrintEdition
            , NameOfPublications
            , Price
            , DateStartSubsribe
            , SubscriptionTerm
        
        
        from
            ViewSubscribers
        where
            TypeOfPrintEdition = @TypeOfPublications 
    end;
go

-- проверка
declare @TypeOfPublications nvarchar(50) = N'газета';   
exec Proc4 @TypeOfPublications;
go



-- 5	    Запрос с параметром	
--          Выбирает из таблиц ИЗДАНИЯ и ПОДПИСКА информацию обо всех оформленных подписках, 
--          для которых срок подписки есть значение из некоторого диапазона. 
drop proc if exists Proc5;
go

create proc Proc5
     @lo int, 
     @hi int       
as
    begin 

        select
            ViewSubscribers.Id
            , Surname
            , [Name]
            , Patronymic    
            , PassportID
            , StreetType + N' ' + StreetName + N' ' + HouseNumber + N'/' + ApartmentNumber as [Address] 
            , [Index]
            , TypeOfPrintEdition
            , NameOfPublications
            , Price
            , DateStartSubsribe
            , SubscriptionTerm
        from
            ViewSubscribers  
        where
            SubscriptionTerm between @lo and @hi    
end;
go

-- проверка
declare @lo int = 6, 
        @hi int = 9;
exec Proc5 @lo, @hi;
go

--6	    Запрос с вычисляемыми полями	
--      Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС. 
--      Включает поля Индекс издания, Наименование издания, Цена 1 экземпляра, Дата начала подписки, 
--      Срок подписки, Стоимость подписки без НДС. Сортировка по полю Индекс издания
drop proc if exists Proc6;
go

create proc Proc6
as
    begin 
        select
            [Index]
            , TypeOfPrintEdition
            , NameOfPublications
            , Price
            , DateStartSubsribe
            , SubscriptionTerm
            , (Price * SubscriptionTerm)*1.01 as Cost
        from
            ViewSubscribers  
         order by
            [Index]    
end;
go
-- проверка
exec Proc6;
go

--7	    Итоговый запрос	
--      Выполняет группировку по полю Вид издания. 
--      Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
drop proc if exists Proc7;
go

create proc Proc7
as
    begin 
        select
            TypeOfPrintEdition
            , COUNT(Price) as Amount
            , MIN(Price) as MinPrice    
            , MAX(Price) as MaxPrice
        from
            ViewPublications
        group by
            TypeOfPrintEdition;
end;
go

-- проверка
exec Proc7;
go



--8	    Итоговый запрос с левым соединением	
--      Выполняет группировку по полю Улица. 
--      Для всех улиц вычисляет количество подписчиков, проживающих на данной улице (итоги по полю Код получателя)
drop proc if exists Proc8;
go

create proc Proc8
as
    begin 
        select
           StreetName.NameOfStreet
           , COUNT(Subscribers.Id)  as Amount 
           
        from   
           (Person join StreetType on Person.IdStreetType = StreetType.id
                   join StreetName on Person.IdStreetName = StreetName.id) left join Subscribers on Subscribers.IdPerson = Person.Id     
        group by
            StreetName.NameOfStreet;
end;
go

-- проверка
exec Proc8;
go




--9	    Итоговый запрос с левым соединением
--      Для всех изданий выводит количество оформленных подписок
drop proc if exists Proc9;
go

create proc Proc9
as
    begin 
        select
            PrintEdition.TypeOfPrintEdition
            , COUNT(Subscribers.Id) as Amount
           
        from   
            (PrintEdition left join Publications on Publications.IdTypeOfPublications =  PrintEdition.Id) 
             left join Subscribers on Subscribers.IdPublication = Publications.Id     
        group by
            PrintEdition.TypeOfPrintEdition;
end;
go

-- проверка
exec Proc9;
go

 