using Main.Utilities.TableFormatter;


namespace Main.Models
{
	public sealed class Good
	{
		[TableData("Наименование", "{0, -20}")]
		public string Name { get; set; }
		
		[TableData("Цена", "{0, -15:N0}")]
		public decimal Price { get; set; }
		
		[TableData("Количество", "{0, -12}")]
		public int Count { get; set; }
		
		[TableData("Год выпуска", "{0, -13}")]
		public int Year { get; set; }
	}
}