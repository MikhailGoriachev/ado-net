﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RealEstate.Helpers;

namespace RealEstate.Application
{
    // методы для выполнеяни запросов по заданию 
    public partial class App
    {
        // Запрос 1. Квартиры с заданным количеством комнат на заданной улице

        public void ExecQuery01()
        {
            Utils.ShowNavBarTask("         Выполнение запроса 1");

            _queriesController.Query01(2, "ул. Садовая");

            Console.ReadKey();
        }

        // Запрос 2. Вывод сведений о риелторе с фамилией и процентом от продаж
        public void ExecQuery02()
        {
            Utils.ShowNavBarTask("     Выполнение запроса 2");

            _queriesController.Query02("И", 10);

            Console.ReadKey();
        }

        //Запрос 3. Вывод сведений об однокомнатных квартирах в ценовом диапазоне
        public void ExecQuery03()
        {
            Utils.ShowNavBarTask("       Выполнение запроса 3");

            _queriesController.Query03(1, 900000, 1000000);

            Console.ReadKey();
        }

        //Запрос 4. Выбирает информацию о квартирах с заданным числом комнат.
        
        public void ExecQuery04()
        {
            Utils.ShowNavBarTask("    Выполнение запроса 4");

            _queriesController.Query04(1);

            Console.ReadKey();
        }

        // Запрос 5. Выбирает информацию о двухкомнатных квартирах

        public void ExecQuery05()
        {
            Utils.ShowNavBarTask("    Выполнение запроса 5");

            _queriesController.Query05(2, 80, 120);

            Console.ReadKey();
        }

        //Запрос 6. Вычисляет для каждой сделки вознограждение риэлтора
        
        public void ExecQuery06()
        {
            Utils.ShowNavBarTask("     Выполнение запроса 6");

            _queriesController.Query06();

            Console.ReadKey();
        }

    }
}
