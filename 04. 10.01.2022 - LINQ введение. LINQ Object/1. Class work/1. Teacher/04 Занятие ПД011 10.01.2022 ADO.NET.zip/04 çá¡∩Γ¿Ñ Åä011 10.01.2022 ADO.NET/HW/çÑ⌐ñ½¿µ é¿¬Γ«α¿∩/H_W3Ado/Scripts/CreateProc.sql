﻿-- База данных «Учет подписки на периодические печатные издания»


-- Создание хранимых процедур
-- 1. Хранимая процедура.	
-- Выбирает из таблицы ИЗДАНИЯ информацию о доступных для
-- подписки изданиях заданного типа,
-- стоимость 1 экземпляра для которых меньше заданной.
drop proc if exists ProcQuery01;
go

create proc ProcQuery01 @price float
as begin
      select
         *
      from
         ViewPublications
      where
         PricePublication < @price;
end;
go

exec ProcQuery01 1000;
go


-- 2. Хранимая процедура.
-- Выбирает из таблиц информацию о подписчиках,
-- проживающих на заданной параметром улице и номере дома,
-- которые оформили подписку на издание с заданным параметром наименованием
drop proc if exists ProcQuery02;
go

create proc ProcQuery02 @namestreet nvarchar(30), @numHouse nvarchar(10), @namePubl nvarchar(50)
as begin
      select
         *
      from
         ViewSubscribers
      where
         NameStreet = @namestreet and HouseNum = @numHouse and TitlePublication = @namePubl;
end;
go

exec ProcQuery02 N'Артёма', N'6', N'В гостях у сказки';
go


-- 3. Хранимая процедура.
-- Выбирает из таблицы ИЗДАНИЯ информацию об изданиях,
-- для которых значение в поле Цена 1 экземпляра находится в заданном диапазоне значений
drop proc if exists ProcQuery03;
go

create proc ProcQuery03 @loPrice float, @hiPrice float
as begin
      select
         *
      from
         ViewPublications
      where
         PricePublication between @loPrice and @hiPrice;
end;
go

exec ProcQuery03 1000, 25000;
go


-- 4. Хранимая процедура.
-- Выбирает из таблиц информацию о подписчиках,
-- подписавшихся на заданный параметром тип издания
drop proc if exists ProcQuery04;
go

create proc ProcQuery04 @typeEdition nvarchar(15)
as begin
      select
         *
      from
         ViewSubscribers
      where 
         TypePublication = @typeEdition;
end;
go

exec ProcQuery04 N'газета';
go


-- 5. Хранимая процедура.
-- Выбирает из таблиц ИЗДАНИЯ и ДОСТАВКА информацию обо всех оформленных подписках,
-- для которых срок подписки есть значение из некоторого диапазона
drop proc if exists ProcQuery05;
go

create proc ProcQuery05 @loTermin int, @hiTermin int
as begin
      select
         Publications.IndexPublication
         , Publications.TitlePublication
         , TypesOfEdotion.TypePublication
         , Delivery.TerminSubscription
      from
         Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                      on Delivery.IdPublication = Publications.Id
      where
         Delivery.TerminSubscription between @loTermin and @hiTermin;
end;
go

exec ProcQuery05 2, 5;
go


-- 6. Хранимая процедура.
-- Вычисляет для каждой оформленной подписки ее стоимость с доставкой и без НДС.
-- Включает поля Индекс издания, Наименование издания,
-- Цена 1 экземпляра, Дата начала подписки,
-- Срок подписки, Стоимость подписки без НДС.
-- Сортировка по полю Индекс издания
drop proc if exists ProcQuery06;
go

create proc ProcQuery06
as begin
      select
         Publications.IndexPublication
         , Publications.TitlePublication
         , Publications.PricePublication
         , Delivery.DateSubscription
         , Delivery.TerminSubscription
        -- Стоимость подписки может быть вычислена как Цена 1 экземпляра * Срок подписки
         , 1.01 * (Publications.PricePublication * Delivery.TerminSubscription) as PriceSubscription
      from
         Delivery join (Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id) 
                   on Delivery.IdPublication = Publications.Id
      order by
        Publications.IndexPublication;
end;
go

exec ProcQuery06;
go


-- 7. Итоговый запрос. Хранимая процедура.
-- Выполняет группировку по полю Вид издания.
-- Для каждого вида вычисляет максимальную и минимальную цену 1 экземпляра
drop proc if exists ProcQuery07;
go

create proc ProcQuery07
as begin
      select
         TypesOfEdotion.TypePublication
         , COUNT(Publications.Id) as AmountPublication
         , MIN(Publications.PricePublication) as MinPrice
         , MAX(Publications.PricePublication) as MaxPrice
      from
         Publications join TypesOfEdotion on Publications.IdTypePublication = TypesOfEdotion.Id
      group by 
         TypesOfEdotion.TypePublication;
end;
go

exec ProcQuery07;
go


-- 8. Итоговый запрос с левым соединением. Хранимая процедура.
-- Выполняет группировку по полю Улица.
-- Для всех улиц вычисляет количество подписчиков,
-- проживающих на данной улице (итоги по полю Код получателя)
drop proc if exists ProcQuery08;
go

create proc ProcQuery08
as begin
      select
         Streets.NameStreet
        , COUNT(Delivery.IdSubscriber) as AmountSubscribers
      from
        (Subscribers join Streets on Subscribers.IdStreet = Streets.Id)
                    left join Delivery on Delivery.IdSubscriber = Subscribers.Id
      group by
        Streets.NameStreet;
end;
go

exec ProcQuery08;
go


-- 9. Итоговый запрос с левым соединением. Хранимая процедура.
-- Для всех изданий выводит количество оформленных подписок
drop proc if exists ProcQuery09;
go

alter proc ProcQuery09
as begin
      select
        TypesOfEdotion.TypePublication
        , COUNT(Delivery.Id) as AmountSubscriptions
      from
        TypesOfEdotion left join (Delivery join Publications on Delivery.IdPublication = Publications.Id) 
                       on TypesOfEdotion.Id = Publications.IdTypePublication
      group by
        TypesOfEdotion.TypePublication;
end;
go

exec ProcQuery09;
go

