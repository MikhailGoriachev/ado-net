﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _4ADO.NET.Classes;
using _4ADO.NET.Utilits;

namespace _4ADO.NET.Application
{
    class App
    {
        public void Task1()
        {
            List<Good> goods = new List<Good>();
            goods.Add(new Good("Ноутбук", 100000, 1, new DateTime(2021, 05, 23)));
            goods.Add(new Good("Ноутбук", 70000, 1, new DateTime(2021, 05, 23)));
            goods.Add(new Good("Ноутбук", 60000, 1, new DateTime(2020, 05, 23)));
            goods.Add(new Good("Ноутбук", 75000, 1, new DateTime(2019, 05, 23)));
            goods.Add(new Good("Ноутбук", 60000, 1, new DateTime(2018, 05, 23)));
            goods.Add(new Good("Ноутбук", 40000, 1, new DateTime(2016, 05, 23)));
            goods.Add(new Good("Ноутбук", 45000, 1, new DateTime(2015, 05, 23)));
            goods.Add(new Good("Ноутбук", 46000, 1, new DateTime(2016, 05, 23)));
            goods.Add(new Good("Ноутбук", 74000, 1, new DateTime(2016, 05, 23)));
            goods.Add(new Good("Ноутбук", 43000, 1, new DateTime(2000, 05, 23)));
            goods.Add(new Good("Ноутбук", 89000, 1, new DateTime(2009, 05, 23)));
            goods.Add(new Good("Ноутбук", 39999, 1, new DateTime(2008, 05, 23)));


            Console.WriteLine("\tНаименование\tСтоимсоть\tКоличество\tГод приобретения\tСкидка");

            foreach (var item in goods)
                Console.WriteLine("\t" + item + "\t\t" + item.GetDiscount().ToString());

        }
        public void Task2()
        {
            MyDouble listOfDoubles = new MyDouble();

            Console.WriteLine("\t\t\tИсходный массив\n" + listOfDoubles);

            listOfDoubles.Process1(5.0,10.0);
            listOfDoubles.Process2();
            listOfDoubles.Process3();
            listOfDoubles.Process4();
        }
        public void Task3()
        {
            List<Good> goods = new List<Good>();
            goods.Add(new Good("Ноутбук", 100000, 1, new DateTime(2021, 05, 23)));
            goods.Add(new Good("Телефон", 70000, 1, new DateTime(2021, 05, 23)));
            goods.Add(new Good("Ноутбук", 60000, 1, new DateTime(2020, 05, 23)));
            goods.Add(new Good("Ноутбук", 75000, 1, new DateTime(2019, 05, 23)));
            goods.Add(new Good("Ноутбук", 60000, 1, new DateTime(2018, 05, 23)));
            goods.Add(new Good("Ноутбук", 40000, 1, new DateTime(2016, 05, 23)));
            goods.Add(new Good("Ноутбук", 45000, 1, new DateTime(2015, 05, 23)));
            goods.Add(new Good("Телефон", 46000, 1, new DateTime(2016, 05, 23)));
            goods.Add(new Good("Телефон", 74000, 1, new DateTime(2016, 05, 23)));
            goods.Add(new Good("Телефон", 43000, 1, new DateTime(2000, 05, 23)));
            goods.Add(new Good("Телефон", 89000, 1, new DateTime(2009, 05, 23)));
            goods.Add(new Good("Телефон", 39999, 1, new DateTime(2008, 05, 23)));


            Console.WriteLine("\tНаименование\tСтоимсоть\tКоличество\tГод приобретения\tСкидка");

            foreach (var item in goods)
                Console.WriteLine("\t" + item + "\t\t" + item.GetDiscount().ToString());

            goods.Process1();
            goods.Process2();
            goods.Process3();
            goods.Process4();

        }
    }
}
