﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text.Encodings.Web;
using System.Text.Json;
using Main.DataAccess;
using Main.Utilities;


namespace Main.Controllers
{
	public sealed class MainController
	{
		private readonly DapperDataAccess _dataAccess;
		private readonly JsonSerializerOptions _options = new()
		{
			WriteIndented = true,
			Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
		};

		public MainController(string connectionString) => _dataAccess = new(connectionString);


		public void Query1(decimal price)
		{
			IEnumerable<dynamic> result = _dataAccess.QueryObject(new(
				"EditionsByPriceLesserThan",
				new { price },
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		public void Query2(string street, string title, int house)
		{
			var result = _dataAccess.QueryObject(new(
				"DeliveriesByStreetHouseAndPublicationTitle",
				new { street, house, title },
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		public void Query3(Range<decimal> priceRange)
		{
			var (min, max) = priceRange;

			var result = _dataAccess.QueryObject(new(
				"EditionsByPriceInRange",
				new { min, max },
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		public void Query4(int typeId)
		{
			var result = _dataAccess.QueryObject(new(
				"DeliveriesByPublicationType",
				new { typeId },
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		public void Query5(Range<int> termRange)
		{
			var (min, max) = termRange;

			var result = _dataAccess.QueryObject(new(
				"DeliveriesByTermRange",
				new { min, max },
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		public void Query6()
		{
			var result = _dataAccess.QueryObject(new(
				"DeliveriesWithSubscriptionPrice",
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		public void Query7()
		{
			var result = _dataAccess.QueryObject(new(
				"EditionsGroupingTypeWithMinMaxPrice",
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		public void Query8()
		{
			var result = _dataAccess.QueryObject(new(
				"DeliveriesGroupingStreetWithSubscribersCount",
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		public void Query9()
		{
			var result = _dataAccess.QueryObject(new(
				"DeliveriesGroupingTypeWithSubscribersCount",
				commandType: CommandType.StoredProcedure
			));

			ShowJsonResult(result);
		}


		private void ShowJsonResult<T>(IEnumerable<T> items) =>
			Console.WriteLine(JsonSerializer.Serialize(items, _options));
	}
}