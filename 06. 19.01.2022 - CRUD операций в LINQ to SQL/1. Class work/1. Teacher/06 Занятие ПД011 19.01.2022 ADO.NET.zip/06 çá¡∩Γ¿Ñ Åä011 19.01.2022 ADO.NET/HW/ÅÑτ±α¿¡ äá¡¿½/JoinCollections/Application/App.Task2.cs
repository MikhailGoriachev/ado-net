﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using JoinCollections.Helpers;
using JoinCollections.Models;

namespace JoinCollections.Application
{
    public partial class App
    {

        public void TaskQuery1()
        {
            Utils.ShowNavBarTask("\n Товарах, единицей измерения которых является «шт» и цена закупки меньше 200 руб.");

            Console.WriteLine("\n Запрос в синтаксисе LINQ");
            _queryController2.Query1();

            Console.WriteLine("\n Запрос с раширяющими методами");
            _queryController2.Query1Extension();

            Console.ReadKey();

        }
    }
}
