﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNetIntro.Controllers
{
    // Выполнение запросов к базе данных RealEstateDb по заданию 
    public class QueriesController
    {
        // строка подключения к базе данных
        private string _connectingString;
        public string ConnectingString {
            get => _connectingString;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Не указана строка подключения к базе данных");

                _connectingString = value;
            } // set
        } // ConnectionString

        public QueriesController():this(@"
            Data Source=(LocalDB)\MSSQLLocalDB;
            AttachDbFilename=""D:\Students\ПД011\06 ADO.NET\02 Занятие ПД011 23.12.2021 ADO.NET\HW\_HwE_IntroAdoNet\AdoNetIntro\App_Data\RealEstateDb.mdf"";
            Integrated Security=True
        ") 
        { } // QueriesController

        
        public QueriesController(string connectingString) {
            ConnectingString = connectingString;
        } // QueriesController

        // Запрос  1. Запрос с параметрами	
        // Выбирает информацию о 3-комнатных квартирах, расположенных на улице 
        // «Садовая». Значения задавать параметрами запроса
        public void Query01(int roomNumber, string street) {
            Console.WriteLine("\n\n\n\n\tЗапрос 01.\n" +
                              $"\tКвартиры с количеством комнат {roomNumber} на {street}\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"
                select
                    ApartmentId
                    , Street
                    , Building
                    , Flat
                    , Area
                    , RoomNum
                    , Price
                from
                    ViewOffers
                where
                    RoomNum = @roomNum and Street = @street;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNumber);
                cmd.Parameters.AddWithValue("@street", street);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToApartment(cmd);
            } // using
        } // Query01

        // Запрос  3. Запрос с параметрами	
        // Выбирает информацию о квартирах, с заданным количеством комнат
        // и ценой в заданном диапазоне
        public void Query03(int roomNumber, int loPrice, int hiPrice) {
            Console.WriteLine("\n\n\n\n\tЗапрос 04.\n" +
                              $"\tКвартиры с количеством комнат {roomNumber}, и ценой в" +
                              $"\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"
                select
                    ApartmentId
                    , Street
                    , Building
                    , Flat
                    , Area
                    , RoomNum
                    , Price
                from
                    ViewOffers
                where
                    RoomNum = @roomNum;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNumber);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToApartment(cmd);
            } // using
        } // Query04

        // Запрос  4. Запрос с параметрами	
        // Выбирает информацию о квартирах с заданным числом комнат. Значения задавать 
        // параметрами запроса
        public void Query04(int roomNumber) {
            Console.WriteLine("\n\n\n\n\tЗапрос 04.\n" +
                              $"\tКвартиры с количеством комнат {roomNumber}\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"
                select
                    ApartmentId
                    , Street
                    , Building
                    , Flat
                    , Area
                    , RoomNum
                    , Price
                from
                    ViewOffers
                where
                    RoomNum = @roomNum;"
                );

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNumber);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToApartment(cmd);
            } // using
        } // Query04


        // Запрос 5. 2-хкомнатные квартиры с площадью из заданного диапазона
        public void Query05(int roomNumber, int loArea, int hiArea) {
            Console.WriteLine("\n\n\n\n\tЗапрос 05.\n" +
                              $"\tКвартиры с количеством комнат {roomNumber} и площадью в диапазоне " +
                              $"[{loArea}, {hiArea}] м2\n");

            // подключение к БД
            using (SqlConnection connection = new SqlConnection(_connectingString)) {
                connection.Open(); // подключение к серверу, блокирующий вызов

                // создание команды (запрос SQL), привязка к соединению
                SqlCommand cmd = new SqlCommand(@"
                select
                    ApartmentId
                    , Street
                    , Building
                    , Flat
                    , Area
                    , RoomNum
                    , Price
                from
                    ViewOffers
                where
                    RoomNum = @roomNum and Area between @lo and @hi;");

                // задать соединение с БД
                cmd.Connection = connection;

                // задать параметры запроса
                cmd.Parameters.AddWithValue("@roomNum", roomNumber);
                cmd.Parameters.AddWithValue("@lo", loArea);
                cmd.Parameters.AddWithValue("@hi", hiArea);

                // выполнение запроса и вывод выборки данных из таблиц БД
                QueryToApartment(cmd);
            } // using
        }

        // Вывод запроса, использующего данные квартиры
        private void QueryToApartment(SqlCommand cmd) {
            // выполнение запроса, ссылка на  выбранные данные - reader
            SqlDataReader reader = cmd.ExecuteReader();

            // выводим имена столбцов (это не обязательно)
            Console.WriteLine("\t" +
                              $"│ {reader.GetName(0),11} │ {reader.GetName(1),-15} " +
                              $"│ {reader.GetName(2),-15} │ {reader.GetName(3),4} " +
                              $"│ {reader.GetName(4),4} │ {reader.GetName(5),7} " +
                              $"│ {reader.GetName(6),5}   │");

            // Если данные получены (есть строки в полученном ответе сервера)
            if (reader.HasRows) {
                while (reader.Read()) {
                    Console.WriteLine("\t" +
                        $"│ {reader.GetInt32(0),11} " +
                        $"│ {reader.GetString(1),-15} " +
                        $"│ {reader.GetString(2),-15} " +
                        $"│ {reader.GetInt32(3),4} " +
                        $"│ {reader.GetInt32(4),4} " +
                        $"│ {reader.GetInt32(5),7} " +
                        $"│ {reader.GetInt32(6),5} │");
                } // while
            } else {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\tНет данных");
                Console.ForegroundColor = ConsoleColor.Gray;
            } // if
        } // QueryToApartment

    } // class QueriesController
}
