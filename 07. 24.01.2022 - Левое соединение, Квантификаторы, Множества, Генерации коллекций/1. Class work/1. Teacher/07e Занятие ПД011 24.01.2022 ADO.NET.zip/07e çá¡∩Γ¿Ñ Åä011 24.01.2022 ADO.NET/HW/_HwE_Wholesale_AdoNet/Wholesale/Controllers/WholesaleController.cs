﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wholesale.Models;

namespace Wholesale.Controllers
{
    // Выполнение запросов к базе данных "Оптовый магазин. Учет продаж"
    public class WholesaleController
    {
        // связь с базой данных
        private WholesaleDataContext _db;


        #region Конструкторы
        public WholesaleController():this(new WholesaleDataContext()) {}
        public WholesaleController(WholesaleDataContext db) {
            _db = db;
        } // WholesaleController
        #endregion


        #region Запросы для вывода таблиц (основных)

        // таблица наименований товаров
        public IEnumerable GetGoodsAll() => _db.Goods
            .Select(g => new {
                g.Id,
                g.Item})
            .ToList();


        // таблица сведений о продавцах
        public IEnumerable GetSellersAll() => _db.Sellers
            .Select(s => new {
                s.Id,
                s.Persons.Surname,
                s.Persons.Name,
                s.Persons.Patronymic,
                s.Persons.Passport,
                s.Interest})
            .ToList();


        // получить список единиц измерения
        public List<Units> GetUnitsAll() => _db.Units.ToList();

        #endregion


        #region Запросы выборки данных

        // Запрос 1
        // Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых 
        // является «шт» (штуки) и цена закупки составляет меньше 200 руб.
        public IEnumerable Query01(string shortUnit, int price) => _db.Purchases
            .Where(p => p.Units.Short == shortUnit && p.Price < price)
            .Select(p => new {
                p.Id,
                p.Goods.Item,                   // наименование товара
                p.Units.Short,                  // кр. форма ед. измерения
                Date = $"{p.PurchaseDate:d}",   // т.к. данные только для отображения в DGV - сами форматируем 
                p.Price,
                p.Amount})
            .ToList();

        // Запрос  2	
        // Выбирает из таблицы ТОВАРЫ информацию о товарах, цена закупки которых больше 
        // 500 руб. за единицу товара
        public IEnumerable Query02(int price) => _db.Purchases
            .Where(p => p.Price > price)
            .Select(p => new {
                p.Id,
                p.Goods.Item,
                p.Units.Short,
                Date = $"{p.PurchaseDate:d}",
                p.Price,
                p.Amount})
            .ToList();

        // Запрос  3
        // Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием 
        // (например, «чехол защитный»), для которых цена закупки меньше 1800 руб.
        public IEnumerable Query03(string item, int price) => _db.Purchases
            .Where(p => p.Goods.Item == item && p.Price < price)
            .Select(p => new {
                p.Id,
                p.Goods.Item,
                p.Units.Short,
                Date = $"{p.PurchaseDate:d}",
                p.Price,
                p.Amount})
            .ToList();

        // Запрос  4	
        // Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением
        // процента комиссионных.
        public IEnumerable Query04(double interest) => _db.Sellers
            .Where(s => Math.Abs(s.Interest - interest) < 1e-6)
            .Select(s => new {
                s.Id,
                s.Persons.Surname,
                s.Persons.Name,
                s.Persons.Patronymic,
                s.Interest})
            .ToList();

        // Запрос  5	
        // Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех 
        // зафиксированных фактах продажи товаров (Наименование товара, Цена закупки,
        // Цена продажи, дата продажи), для которых Цена продажи оказалась в некоторых 
        // заданных границах
        public IEnumerable Query05(int fromPrice, int toPrice) => _db.Sales
            .Where(sales => fromPrice <= sales.Price && sales.Price <= toPrice)
            .Select(sales => new {
                sales.Id,
                sales.Purchases.Goods.Item,
                sales.Units.Short,
                Seller = $"{sales.Sellers.Persons.Surname} {sales.Sellers.Persons.Name[0]}.{sales.Sellers.Persons.Patronymic[0]}.",
                SaleDate = $"{sales.SaleDate:d}",
                PurchasePrice = sales.Purchases.Price,
                SalePrice = sales.Price,
                sales.Amount})
            .ToList();

        // Запрос  6	
        // Вычисляет прибыль от продажи за каждый проданный товар. Включает поля
        // Дата продажи, Наименование товара, Цена закупки, Цена продажи, Количество
        // проданных единиц, Прибыль.Сортировка по полю Наименование товара
        public IEnumerable Query06() => _db.Sales
            .Select(sales => new {
                sales.Id,
                sales.Purchases.Goods.Item,
                sales.Units.Short,
                Seller = $"{sales.Sellers.Persons.Surname} {sales.Sellers.Persons.Name[0]}.{sales.Sellers.Persons.Patronymic[0]}.",
                SaleDate = $"{sales.SaleDate:d}",
                PurchasePrice = sales.Purchases.Price,
                SalePrice = sales.Price,
                sales.Amount,
                Profit = (sales.Price - sales.Purchases.Price) * sales.Amount})
            .ToList();

        #endregion


        #region Итоговые запросы

        // Запрос  7	
        // Выполняет группировку по полю Наименование товара. Для каждого наименования
        // вычисляет среднюю цену закупки товара, количество закупок
        public IEnumerable Query07() => _db.Goods
            .Join(_db.Purchases, g => g.Id, p => p.IdItem,
                (g, p) => new {
                    g.Item,
                    p.Units.Long,
                    p.Price
                })
            // key - ключ группировки
            // gr  - коллекция записей, входящих в группировку
            // !!! группировка по несколькм полям !!
            .GroupBy(g => new { g.Item, g.Long }, (key, gr) => new {
                Item = key.Item,
                Long = key.Long,
                PurchasesAmount = gr.Count(),
                PurchasesAvg = gr.Average(group => group.Price)
            })
            .ToList();

        // Запрос  8	
        // Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ.Для каждого 
        // продавца вычисляет среднее значение по полю Цена продажи единицы товара,
        // количество продаж
        public IEnumerable Query08() => _db.Sales
            .GroupBy(s => new {
                    s.IdSeller,
                    s.Sellers.Persons.Surname,
                    s.Sellers.Persons.Name,
                    s.Sellers.Persons.Patronymic,
                    s.Sellers.Persons.Passport
                },
                (key, gr) => new {
                    key.IdSeller,
                    Seller = $"{key.Surname} {key.Name[0]}.{key.Patronymic[0]}.",
                    key.Passport,
                    SalesAmount = gr.Count(),                  // кол-во продаж
                    AvgPrice = gr.Average(g => g.Price)   // ср. цена продажи
                })
            .ToList();

        #endregion

    } // class WholesaleController
}
