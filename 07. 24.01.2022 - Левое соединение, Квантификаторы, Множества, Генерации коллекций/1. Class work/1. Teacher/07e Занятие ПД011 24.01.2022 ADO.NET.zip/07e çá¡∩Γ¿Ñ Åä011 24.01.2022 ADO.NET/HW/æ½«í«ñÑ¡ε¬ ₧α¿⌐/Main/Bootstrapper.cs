﻿using Main.Pages.Shell;
using Stylet;


namespace Main
{
	public sealed class Bootstrapper : Bootstrapper<ShellViewModel> { }
}