﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W5AdoLINQtoSQL
{
    class Utils
    {
        // объект для получения случайных чисел
        public static Random Random = new Random();

        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo) * Random.NextDouble();

        public static double GetRandomAbs(double lo, double hi)
        {
            double t = lo + (hi - lo) * Random.NextDouble();
            return Math.Abs(t) < 1.9 ? 0 : t;
        }


        // Подготовка строки к записи в файл - копировать символы
        // строки str в буферный массив байт для вывода
        public static byte[] ToArray(string str, int length)
        {
            byte[] buf = new byte[length];
            Encoding.UTF8
                .GetBytes(str)
                .CopyTo(buf, 0);

            return buf;
        } // ToArray

        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line)
        {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса string :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Magenta);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask


        // Вывод сообщения "Метод в разработке" по центру экрана
        public static void ShowUnderConstruction()
        {
            (ConsoleColor fg, ConsoleColor bg) = (Console.ForegroundColor, Console.BackgroundColor);
            (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);

            string[] lines = {
                 " ".PadRight(40),
                 " ".PadRight(40),
                 "     [К сведению]".PadRight(40),
                 " ".PadRight(40),
                 "     Метод в разработке".PadRight(40),
                 " ".PadRight(40),
                 " ".PadRight(40),
            };

            int x = (Console.WindowWidth - 40) / 2;
            int y = (Console.WindowHeight - lines.Length) / 2;
            foreach (var line in lines)
                WriteXY(x, y++, line, ConsoleColor.DarkGray);

            (Console.ForegroundColor, Console.BackgroundColor) = (fg, bg);
            Console.SetCursorPosition(0, Console.WindowHeight - 1);
        } // ShowUnderConstruction


        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu)
        {
            WriteXY(x, y, title, ConsoleColor.White);
            int offsetY = 2;

            foreach (var menuItem in menu)
            {
                WriteXY(x, y + offsetY, menuItem.HotKey.ToString(), ConsoleColor.Red);
                WriteXY(x + 3, y + offsetY++, menuItem.Text, ConsoleColor.White);
            } // foreach menuItem
        } // ShowMenu

    }
}
