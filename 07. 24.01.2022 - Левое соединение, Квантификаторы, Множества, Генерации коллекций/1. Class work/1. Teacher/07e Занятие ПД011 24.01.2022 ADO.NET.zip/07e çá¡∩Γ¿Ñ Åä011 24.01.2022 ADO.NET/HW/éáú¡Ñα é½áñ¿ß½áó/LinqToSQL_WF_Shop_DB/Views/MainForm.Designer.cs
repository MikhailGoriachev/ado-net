﻿namespace LinqToSQL_WF_Shop_DB.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Tbc_Main = new System.Windows.Forms.TabControl();
            this.Tab_Query_1 = new System.Windows.Forms.TabPage();
            this.Tbx_Selected = new System.Windows.Forms.TextBox();
            this.Gbx_Tab_Query1 = new System.Windows.Forms.GroupBox();
            this.Lbl_Query_1 = new System.Windows.Forms.Label();
            this.Dgv_Query_1 = new System.Windows.Forms.DataGridView();
            this.Tab_Query_2 = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Gbx_Tab_Query2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Dgv_Query_2 = new System.Windows.Forms.DataGridView();
            this.Tab_Query_3 = new System.Windows.Forms.TabPage();
            this.Lbl_Cbx_Tab_Query3 = new System.Windows.Forms.Label();
            this.Cbx_Query_3 = new System.Windows.Forms.ComboBox();
            this.Gbx_Tab_Query = new System.Windows.Forms.GroupBox();
            this.Lbl_Query3 = new System.Windows.Forms.Label();
            this.Dgv_Query_3 = new System.Windows.Forms.DataGridView();
            this.Tab_Query_4 = new System.Windows.Forms.TabPage();
            this.StatusStr = new System.Windows.Forms.StatusStrip();
            this.Lbl_Status_Qantity = new System.Windows.Forms.ToolStripStatusLabel();
            this.Lbl_Query_Num = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Lbl_Price_Query3 = new System.Windows.Forms.Label();
            this.Nud_Price = new System.Windows.Forms.NumericUpDown();
            this.Gbx_Query_4 = new System.Windows.Forms.GroupBox();
            this.Lbl_Query4 = new System.Windows.Forms.Label();
            this.Dgv_Query_4 = new System.Windows.Forms.DataGridView();
            this.Lbl_Query_4 = new System.Windows.Forms.Label();
            this.Cbx_Query_4 = new System.Windows.Forms.ComboBox();
            this.goodsNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitShortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasesViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerSNPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellersViewModelBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.sellersViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sellersViewModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.Tbc_Main.SuspendLayout();
            this.Tab_Query_1.SuspendLayout();
            this.Gbx_Tab_Query1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_1)).BeginInit();
            this.Tab_Query_2.SuspendLayout();
            this.Gbx_Tab_Query2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_2)).BeginInit();
            this.Tab_Query_3.SuspendLayout();
            this.Gbx_Tab_Query.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_3)).BeginInit();
            this.Tab_Query_4.SuspendLayout();
            this.StatusStr.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Nud_Price)).BeginInit();
            this.Gbx_Query_4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchasesViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // Tbc_Main
            // 
            this.Tbc_Main.Controls.Add(this.Tab_Query_1);
            this.Tbc_Main.Controls.Add(this.Tab_Query_2);
            this.Tbc_Main.Controls.Add(this.Tab_Query_3);
            this.Tbc_Main.Controls.Add(this.Tab_Query_4);
            this.Tbc_Main.Location = new System.Drawing.Point(0, 50);
            this.Tbc_Main.Name = "Tbc_Main";
            this.Tbc_Main.SelectedIndex = 0;
            this.Tbc_Main.Size = new System.Drawing.Size(798, 528);
            this.Tbc_Main.TabIndex = 0;
            // 
            // Tab_Query_1
            // 
            this.Tab_Query_1.Controls.Add(this.Tbx_Selected);
            this.Tab_Query_1.Controls.Add(this.Gbx_Tab_Query1);
            this.Tab_Query_1.Controls.Add(this.Dgv_Query_1);
            this.Tab_Query_1.Location = new System.Drawing.Point(4, 22);
            this.Tab_Query_1.Name = "Tab_Query_1";
            this.Tab_Query_1.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_Query_1.Size = new System.Drawing.Size(790, 502);
            this.Tab_Query_1.TabIndex = 0;
            this.Tab_Query_1.Text = "Запрос 1";
            this.Tab_Query_1.ToolTipText = "Выбирает из таблицы ТОВАРЫ информацию о товарах, единицей измерения которых являе" +
    "тся «шт» (штуки) и цена закупки составляет меньше 20000 руб";
            this.Tab_Query_1.UseVisualStyleBackColor = true;
            this.Tab_Query_1.Enter += new System.EventHandler(this.Tab_Query_1_Enter);
            // 
            // Tbx_Selected
            // 
            this.Tbx_Selected.Location = new System.Drawing.Point(382, 10);
            this.Tbx_Selected.Multiline = true;
            this.Tbx_Selected.Name = "Tbx_Selected";
            this.Tbx_Selected.Size = new System.Drawing.Size(402, 73);
            this.Tbx_Selected.TabIndex = 3;
            // 
            // Gbx_Tab_Query1
            // 
            this.Gbx_Tab_Query1.AutoSize = true;
            this.Gbx_Tab_Query1.Controls.Add(this.Lbl_Query_1);
            this.Gbx_Tab_Query1.Location = new System.Drawing.Point(8, 6);
            this.Gbx_Tab_Query1.Name = "Gbx_Tab_Query1";
            this.Gbx_Tab_Query1.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Tab_Query1.Size = new System.Drawing.Size(368, 77);
            this.Gbx_Tab_Query1.TabIndex = 2;
            this.Gbx_Tab_Query1.TabStop = false;
            this.Gbx_Tab_Query1.Text = "Запрос 1";
            // 
            // Lbl_Query_1
            // 
            this.Lbl_Query_1.AutoSize = true;
            this.Lbl_Query_1.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Query_1.Location = new System.Drawing.Point(9, 16);
            this.Lbl_Query_1.Name = "Lbl_Query_1";
            this.Lbl_Query_1.Size = new System.Drawing.Size(336, 45);
            this.Lbl_Query_1.TabIndex = 1;
            this.Lbl_Query_1.Text = "Выбирает из таблицы ТОВАРЫ информацию о товарах, \r\n единицей измерения которых яв" +
    "ляется «шт» (штуки) \r\n и цена закупки составляет меньше 200 руб.";
            // 
            // Dgv_Query_1
            // 
            this.Dgv_Query_1.AllowUserToAddRows = false;
            this.Dgv_Query_1.AllowUserToDeleteRows = false;
            this.Dgv_Query_1.AutoGenerateColumns = false;
            this.Dgv_Query_1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Query_1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.Dgv_Query_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Query_1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.goodsNameDataGridViewTextBoxColumn,
            this.unitShortDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn});
            this.Dgv_Query_1.DataSource = this.purchasesViewModelBindingSource;
            this.Dgv_Query_1.Location = new System.Drawing.Point(8, 93);
            this.Dgv_Query_1.MultiSelect = false;
            this.Dgv_Query_1.Name = "Dgv_Query_1";
            this.Dgv_Query_1.ReadOnly = true;
            this.Dgv_Query_1.RowHeadersVisible = false;
            this.Dgv_Query_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Query_1.Size = new System.Drawing.Size(776, 391);
            this.Dgv_Query_1.TabIndex = 0;
            // 
            // Tab_Query_2
            // 
            this.Tab_Query_2.Controls.Add(this.textBox1);
            this.Tab_Query_2.Controls.Add(this.Gbx_Tab_Query2);
            this.Tab_Query_2.Controls.Add(this.Dgv_Query_2);
            this.Tab_Query_2.Location = new System.Drawing.Point(4, 22);
            this.Tab_Query_2.Name = "Tab_Query_2";
            this.Tab_Query_2.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_Query_2.Size = new System.Drawing.Size(790, 502);
            this.Tab_Query_2.TabIndex = 1;
            this.Tab_Query_2.Text = "Запрос 2";
            this.Tab_Query_2.ToolTipText = "Выбирает из таблицы ТОВАРЫ информацию о товарах, цена закупки которых больше 500 " +
    "руб. за единицу товара";
            this.Tab_Query_2.UseVisualStyleBackColor = true;
            this.Tab_Query_2.Enter += new System.EventHandler(this.Tab_Query_2_Enter);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(382, 16);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(402, 73);
            this.textBox1.TabIndex = 5;
            // 
            // Gbx_Tab_Query2
            // 
            this.Gbx_Tab_Query2.Controls.Add(this.label1);
            this.Gbx_Tab_Query2.Location = new System.Drawing.Point(7, 12);
            this.Gbx_Tab_Query2.Name = "Gbx_Tab_Query2";
            this.Gbx_Tab_Query2.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Tab_Query2.Size = new System.Drawing.Size(369, 77);
            this.Gbx_Tab_Query2.TabIndex = 4;
            this.Gbx_Tab_Query2.TabStop = false;
            this.Gbx_Tab_Query2.Text = "Запрос 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(9, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(358, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "Выбирает из таблицы ТОВАРЫ информацию о товарах, \r\nцена закупки которых больше 5\'" +
    "000 руб. за единицу товара";
            // 
            // Dgv_Query_2
            // 
            this.Dgv_Query_2.AllowUserToAddRows = false;
            this.Dgv_Query_2.AllowUserToDeleteRows = false;
            this.Dgv_Query_2.AutoGenerateColumns = false;
            this.Dgv_Query_2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Query_2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.Dgv_Query_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Query_2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.Dgv_Query_2.DataSource = this.purchasesViewModelBindingSource;
            this.Dgv_Query_2.Location = new System.Drawing.Point(7, 99);
            this.Dgv_Query_2.MultiSelect = false;
            this.Dgv_Query_2.Name = "Dgv_Query_2";
            this.Dgv_Query_2.ReadOnly = true;
            this.Dgv_Query_2.RowHeadersVisible = false;
            this.Dgv_Query_2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Query_2.Size = new System.Drawing.Size(776, 391);
            this.Dgv_Query_2.TabIndex = 3;
            // 
            // Tab_Query_3
            // 
            this.Tab_Query_3.Controls.Add(this.groupBox1);
            this.Tab_Query_3.Controls.Add(this.Gbx_Tab_Query);
            this.Tab_Query_3.Controls.Add(this.Dgv_Query_3);
            this.Tab_Query_3.Location = new System.Drawing.Point(4, 22);
            this.Tab_Query_3.Name = "Tab_Query_3";
            this.Tab_Query_3.Size = new System.Drawing.Size(790, 502);
            this.Tab_Query_3.TabIndex = 2;
            this.Tab_Query_3.Text = "Запрос 3";
            this.Tab_Query_3.ToolTipText = "Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием (наприме" +
    "р, «чехол защитный»), для которых цена закупки меньше 18 000 руб.";
            this.Tab_Query_3.UseVisualStyleBackColor = true;
            this.Tab_Query_3.Enter += new System.EventHandler(this.Tab_Query_3_Enter);
            // 
            // Lbl_Cbx_Tab_Query3
            // 
            this.Lbl_Cbx_Tab_Query3.AutoSize = true;
            this.Lbl_Cbx_Tab_Query3.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Cbx_Tab_Query3.Location = new System.Drawing.Point(9, 18);
            this.Lbl_Cbx_Tab_Query3.Name = "Lbl_Cbx_Tab_Query3";
            this.Lbl_Cbx_Tab_Query3.Size = new System.Drawing.Size(156, 15);
            this.Lbl_Cbx_Tab_Query3.TabIndex = 6;
            this.Lbl_Cbx_Tab_Query3.Text = "Выберите наименование";
            // 
            // Cbx_Query_3
            // 
            this.Cbx_Query_3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Query_3.FormattingEnabled = true;
            this.Cbx_Query_3.Location = new System.Drawing.Point(9, 36);
            this.Cbx_Query_3.Name = "Cbx_Query_3";
            this.Cbx_Query_3.Size = new System.Drawing.Size(175, 21);
            this.Cbx_Query_3.TabIndex = 5;
            this.Cbx_Query_3.SelectedIndexChanged += new System.EventHandler(this.Cbx_Query3_SelectedChanged);
            // 
            // Gbx_Tab_Query
            // 
            this.Gbx_Tab_Query.Controls.Add(this.Lbl_Query3);
            this.Gbx_Tab_Query.Location = new System.Drawing.Point(7, 12);
            this.Gbx_Tab_Query.Name = "Gbx_Tab_Query";
            this.Gbx_Tab_Query.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Tab_Query.Size = new System.Drawing.Size(368, 69);
            this.Gbx_Tab_Query.TabIndex = 4;
            this.Gbx_Tab_Query.TabStop = false;
            this.Gbx_Tab_Query.Text = "Запрос 3";
            // 
            // Lbl_Query3
            // 
            this.Lbl_Query3.AutoSize = true;
            this.Lbl_Query3.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Query3.Location = new System.Drawing.Point(9, 16);
            this.Lbl_Query3.Name = "Lbl_Query3";
            this.Lbl_Query3.Size = new System.Drawing.Size(333, 45);
            this.Lbl_Query3.TabIndex = 1;
            this.Lbl_Query3.Text = "Выбирает из таблицы ТОВАРЫ информацию о товарах \r\n с заданным наименованием , \r\n " +
    "для которых цена закупки меньше 18\'000 руб.";
            // 
            // Dgv_Query_3
            // 
            this.Dgv_Query_3.AllowUserToAddRows = false;
            this.Dgv_Query_3.AllowUserToDeleteRows = false;
            this.Dgv_Query_3.AutoGenerateColumns = false;
            this.Dgv_Query_3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Query_3.BackgroundColor = System.Drawing.SystemColors.Control;
            this.Dgv_Query_3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Query_3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.Dgv_Query_3.DataSource = this.purchasesViewModelBindingSource;
            this.Dgv_Query_3.Location = new System.Drawing.Point(7, 87);
            this.Dgv_Query_3.MultiSelect = false;
            this.Dgv_Query_3.Name = "Dgv_Query_3";
            this.Dgv_Query_3.ReadOnly = true;
            this.Dgv_Query_3.RowHeadersVisible = false;
            this.Dgv_Query_3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Query_3.Size = new System.Drawing.Size(776, 403);
            this.Dgv_Query_3.TabIndex = 3;
            // 
            // Tab_Query_4
            // 
            this.Tab_Query_4.Controls.Add(this.Lbl_Query_4);
            this.Tab_Query_4.Controls.Add(this.Cbx_Query_4);
            this.Tab_Query_4.Controls.Add(this.Dgv_Query_4);
            this.Tab_Query_4.Controls.Add(this.Gbx_Query_4);
            this.Tab_Query_4.Location = new System.Drawing.Point(4, 22);
            this.Tab_Query_4.Name = "Tab_Query_4";
            this.Tab_Query_4.Size = new System.Drawing.Size(790, 502);
            this.Tab_Query_4.TabIndex = 3;
            this.Tab_Query_4.Text = "Запрос 4";
            this.Tab_Query_4.ToolTipText = "Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением процента" +
    " комиссионных. ";
            this.Tab_Query_4.UseVisualStyleBackColor = true;
            this.Tab_Query_4.Enter += new System.EventHandler(this.Tab_Query_4_Enter);
            // 
            // StatusStr
            // 
            this.StatusStr.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Lbl_Status_Qantity,
            this.Lbl_Query_Num});
            this.StatusStr.Location = new System.Drawing.Point(0, 581);
            this.StatusStr.Name = "StatusStr";
            this.StatusStr.Size = new System.Drawing.Size(800, 22);
            this.StatusStr.TabIndex = 1;
            this.StatusStr.Text = "statusStrip1";
            // 
            // Lbl_Status_Qantity
            // 
            this.Lbl_Status_Qantity.Name = "Lbl_Status_Qantity";
            this.Lbl_Status_Qantity.Size = new System.Drawing.Size(13, 17);
            this.Lbl_Status_Qantity.Text = "1";
            // 
            // Lbl_Query_Num
            // 
            this.Lbl_Query_Num.Name = "Lbl_Query_Num";
            this.Lbl_Query_Num.Size = new System.Drawing.Size(13, 17);
            this.Lbl_Query_Num.Text = "2";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Nud_Price);
            this.groupBox1.Controls.Add(this.Lbl_Price_Query3);
            this.groupBox1.Controls.Add(this.Lbl_Cbx_Tab_Query3);
            this.groupBox1.Controls.Add(this.Cbx_Query_3);
            this.groupBox1.Location = new System.Drawing.Point(381, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.groupBox1.Size = new System.Drawing.Size(368, 69);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Запрос 3";
            // 
            // Lbl_Price_Query3
            // 
            this.Lbl_Price_Query3.AutoSize = true;
            this.Lbl_Price_Query3.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Price_Query3.Location = new System.Drawing.Point(192, 18);
            this.Lbl_Price_Query3.Name = "Lbl_Price_Query3";
            this.Lbl_Price_Query3.Size = new System.Drawing.Size(156, 15);
            this.Lbl_Price_Query3.TabIndex = 7;
            this.Lbl_Price_Query3.Text = "Выберите наименование";
            // 
            // Nud_Price
            // 
            this.Nud_Price.Location = new System.Drawing.Point(195, 37);
            this.Nud_Price.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.Nud_Price.Name = "Nud_Price";
            this.Nud_Price.Size = new System.Drawing.Size(153, 20);
            this.Nud_Price.TabIndex = 8;
            this.Nud_Price.ValueChanged += new System.EventHandler(this.Nud_Query3_Changed);
            // 
            // Gbx_Query_4
            // 
            this.Gbx_Query_4.Controls.Add(this.Lbl_Query4);
            this.Gbx_Query_4.Location = new System.Drawing.Point(7, 12);
            this.Gbx_Query_4.Name = "Gbx_Query_4";
            this.Gbx_Query_4.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.Gbx_Query_4.Size = new System.Drawing.Size(368, 69);
            this.Gbx_Query_4.TabIndex = 6;
            this.Gbx_Query_4.TabStop = false;
            this.Gbx_Query_4.Text = "Запрос 4";
            // 
            // Lbl_Query4
            // 
            this.Lbl_Query4.AutoSize = true;
            this.Lbl_Query4.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Query4.Location = new System.Drawing.Point(9, 16);
            this.Lbl_Query4.Name = "Lbl_Query4";
            this.Lbl_Query4.Size = new System.Drawing.Size(13, 15);
            this.Lbl_Query4.TabIndex = 1;
            this.Lbl_Query4.Text = "1";
            // 
            // Dgv_Query_4
            // 
            this.Dgv_Query_4.AllowUserToAddRows = false;
            this.Dgv_Query_4.AllowUserToDeleteRows = false;
            this.Dgv_Query_4.AutoGenerateColumns = false;
            this.Dgv_Query_4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Query_4.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Dgv_Query_4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Query_4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sellerSNPDataGridViewTextBoxColumn,
            this.interestDataGridViewTextBoxColumn});
            this.Dgv_Query_4.DataSource = this.sellersViewModelBindingSource2;
            this.Dgv_Query_4.Location = new System.Drawing.Point(9, 88);
            this.Dgv_Query_4.Name = "Dgv_Query_4";
            this.Dgv_Query_4.ReadOnly = true;
            this.Dgv_Query_4.RowHeadersVisible = false;
            this.Dgv_Query_4.Size = new System.Drawing.Size(776, 403);
            this.Dgv_Query_4.TabIndex = 7;
            // 
            // Lbl_Query_4
            // 
            this.Lbl_Query_4.AutoSize = true;
            this.Lbl_Query_4.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Query_4.Location = new System.Drawing.Point(381, 28);
            this.Lbl_Query_4.Name = "Lbl_Query_4";
            this.Lbl_Query_4.Size = new System.Drawing.Size(219, 15);
            this.Lbl_Query_4.TabIndex = 9;
            this.Lbl_Query_4.Text = "Выберите процент вознограждения";
            // 
            // Cbx_Query_4
            // 
            this.Cbx_Query_4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Query_4.FormattingEnabled = true;
            this.Cbx_Query_4.Location = new System.Drawing.Point(381, 46);
            this.Cbx_Query_4.Name = "Cbx_Query_4";
            this.Cbx_Query_4.Size = new System.Drawing.Size(219, 21);
            this.Cbx_Query_4.TabIndex = 8;
            this.Cbx_Query_4.SelectedIndexChanged += new System.EventHandler(this.Cbx_Query4_Changed);
            // 
            // goodsNameDataGridViewTextBoxColumn
            // 
            this.goodsNameDataGridViewTextBoxColumn.DataPropertyName = "GoodsName";
            this.goodsNameDataGridViewTextBoxColumn.HeaderText = "Нименование товара";
            this.goodsNameDataGridViewTextBoxColumn.Name = "goodsNameDataGridViewTextBoxColumn";
            this.goodsNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // unitShortDataGridViewTextBoxColumn
            // 
            this.unitShortDataGridViewTextBoxColumn.DataPropertyName = "UnitShort";
            this.unitShortDataGridViewTextBoxColumn.HeaderText = "Единица измерения";
            this.unitShortDataGridViewTextBoxColumn.Name = "unitShortDataGridViewTextBoxColumn";
            this.unitShortDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Стоимость закупки";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "Кол-во закуплено";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Дата закупки";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // purchasesViewModelBindingSource
            // 
            this.purchasesViewModelBindingSource.DataSource = typeof(LinqToSQL_WF_Shop_DB.Models.PurchasesViewModel);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "GoodsName";
            this.dataGridViewTextBoxColumn1.HeaderText = "Нименование товара";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "UnitShort";
            this.dataGridViewTextBoxColumn2.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn3.HeaderText = "Стоимость закупки";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn4.HeaderText = "Кол-во закуплено";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn5.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "GoodsName";
            this.dataGridViewTextBoxColumn6.HeaderText = "Нименование товара";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "UnitShort";
            this.dataGridViewTextBoxColumn7.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn8.HeaderText = "Стоимость закупки";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn9.HeaderText = "Кол-во закуплено";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn10.HeaderText = "Дата закупки";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // sellerSNPDataGridViewTextBoxColumn
            // 
            this.sellerSNPDataGridViewTextBoxColumn.DataPropertyName = "SellerSNP";
            this.sellerSNPDataGridViewTextBoxColumn.HeaderText = "Фио продавца";
            this.sellerSNPDataGridViewTextBoxColumn.Name = "sellerSNPDataGridViewTextBoxColumn";
            this.sellerSNPDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // interestDataGridViewTextBoxColumn
            // 
            this.interestDataGridViewTextBoxColumn.DataPropertyName = "Interest";
            this.interestDataGridViewTextBoxColumn.HeaderText = "Процент от продаж";
            this.interestDataGridViewTextBoxColumn.Name = "interestDataGridViewTextBoxColumn";
            this.interestDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sellersViewModelBindingSource2
            // 
            this.sellersViewModelBindingSource2.DataSource = typeof(LinqToSQL_WF_Shop_DB.Models.SellersViewModel);
            // 
            // sellersViewModelBindingSource
            // 
            this.sellersViewModelBindingSource.DataSource = typeof(LinqToSQL_WF_Shop_DB.Models.SellersViewModel);
            // 
            // sellersViewModelBindingSource1
            // 
            this.sellersViewModelBindingSource1.DataSource = typeof(LinqToSQL_WF_Shop_DB.Models.SellersViewModel);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 603);
            this.Controls.Add(this.StatusStr);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.Tbc_Main);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Tbc_Main.ResumeLayout(false);
            this.Tab_Query_1.ResumeLayout(false);
            this.Tab_Query_1.PerformLayout();
            this.Gbx_Tab_Query1.ResumeLayout(false);
            this.Gbx_Tab_Query1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_1)).EndInit();
            this.Tab_Query_2.ResumeLayout(false);
            this.Tab_Query_2.PerformLayout();
            this.Gbx_Tab_Query2.ResumeLayout(false);
            this.Gbx_Tab_Query2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_2)).EndInit();
            this.Tab_Query_3.ResumeLayout(false);
            this.Gbx_Tab_Query.ResumeLayout(false);
            this.Gbx_Tab_Query.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_3)).EndInit();
            this.Tab_Query_4.ResumeLayout(false);
            this.Tab_Query_4.PerformLayout();
            this.StatusStr.ResumeLayout(false);
            this.StatusStr.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Nud_Price)).EndInit();
            this.Gbx_Query_4.ResumeLayout(false);
            this.Gbx_Query_4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Query_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchasesViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellersViewModelBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl Tbc_Main;
        private System.Windows.Forms.TabPage Tab_Query_1;
        private System.Windows.Forms.TabPage Tab_Query_2;
        private System.Windows.Forms.StatusStrip StatusStr;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.TabPage Tab_Query_3;
        private System.Windows.Forms.TabPage Tab_Query_4;
        private System.Windows.Forms.DataGridView Dgv_Query_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitShortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource purchasesViewModelBindingSource;
        private System.Windows.Forms.Label Lbl_Query_1;
        private System.Windows.Forms.TextBox Tbx_Selected;
        private System.Windows.Forms.GroupBox Gbx_Tab_Query1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox Gbx_Tab_Query2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView Dgv_Query_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.GroupBox Gbx_Tab_Query;
        private System.Windows.Forms.Label Lbl_Query3;
        private System.Windows.Forms.DataGridView Dgv_Query_3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.Label Lbl_Cbx_Tab_Query3;
        private System.Windows.Forms.ComboBox Cbx_Query_3;
        private System.Windows.Forms.ToolStripStatusLabel Lbl_Status_Qantity;
        private System.Windows.Forms.ToolStripStatusLabel Lbl_Query_Num;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown Nud_Price;
        private System.Windows.Forms.Label Lbl_Price_Query3;
        private System.Windows.Forms.GroupBox Gbx_Query_4;
        private System.Windows.Forms.Label Lbl_Query4;
        private System.Windows.Forms.BindingSource sellersViewModelBindingSource;
        private System.Windows.Forms.BindingSource sellersViewModelBindingSource1;
        private System.Windows.Forms.BindingSource sellersViewModelBindingSource2;
        private System.Windows.Forms.DataGridView Dgv_Query_4;
        private System.Windows.Forms.Label Lbl_Query_4;
        private System.Windows.Forms.ComboBox Cbx_Query_4;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellerSNPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestDataGridViewTextBoxColumn;
    }
}