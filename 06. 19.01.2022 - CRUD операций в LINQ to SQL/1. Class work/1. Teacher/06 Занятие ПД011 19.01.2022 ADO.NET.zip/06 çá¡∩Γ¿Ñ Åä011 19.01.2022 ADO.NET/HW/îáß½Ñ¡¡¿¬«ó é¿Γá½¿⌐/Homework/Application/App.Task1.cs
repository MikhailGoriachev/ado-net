﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Application
{
	internal partial class App
	{
		private void Task1Item1()
		{
			Utilities.ShowNavBar("  Вывести все книги коллекции, выводить фамилии и инициалы автора.");

			Utilities.ShowList(_task1Controller.Query01A(), "\n\n  Запрос с помощью синтаксиса LINQ:\n");
			
			Utilities.ShowList(_task1Controller.Query01B(), "\n\n  Запрос с помощью расширяющего метода:\n");
		}

		private void Task1Item2()
		{
			Utilities.ShowNavBar("  Вывести книги авторов, год рождения которых принадлежит заданном диапазону");

			int from = 1955, to = 1960;
			Console.Write($"\n\n  Книги авторов с годом рождения в диапазоне от {from} до {to}.");

			Utilities.ShowList(_task1Controller.Query02A(from,to), "\n\n  Запрос с помощью синтаксиса LINQ:\n");

			Utilities.ShowList(_task1Controller.Query02B(from, to), "\n\n  Запрос с помощью расширяющего метода:\n");
		}

		private void Task1Item3()
		{
			Utilities.ShowNavBar("  Вывести книги, в названии которых содержится заданная подстрока и цена не превышает заданного значения");

			string substr = "программир";
			int price = 350;

			Console.Write($"\n\n  Книги, в названии которых содержится подстрока {substr} и цена не превышает {price}.");

			Utilities.ShowList(_task1Controller.Query03A(substr, price), "\n\n  Запрос с помощью синтаксиса LINQ:\n");

			Utilities.ShowList(_task1Controller.Query03B(substr, price), "\n\n  Запрос с помощью расширяющего метода:\n");
		}

		private void Task1Item4()
		{
			Utilities.ShowNavBar("  Список авторов и количество их книг в коллекции");

			Utilities.ShowList(_task1Controller.Query04A(), "\n\n  Запрос с помощью синтаксиса LINQ:\n");

			Utilities.ShowList(_task1Controller.Query04B(), "\n\n  Запрос с помощью расширяющего метода:\n");
		}

		private void Task1Item5()
		{
			Utilities.ShowNavBar("  Средняя цена книг по годам издания");

			Utilities.ShowList(_task1Controller.Query05A(), "\n\n  Запрос с помощью синтаксиса LINQ:\n");

			Utilities.ShowList(_task1Controller.Query05B(), "\n\n  Запрос с помощью расширяющего метода:\n");
		}

		private void Task1Item6()
		{
			Utilities.ShowNavBar("  Список авторов по убыванию количества их книг в коллекции");

			Utilities.ShowList(_task1Controller.Query06A(), "\n\n  Запрос с помощью синтаксиса LINQ:\n");

			Utilities.ShowList(_task1Controller.Query06B(), "\n\n  Запрос с помощью расширяющего метода:\n");
		}

		private void Task1Item7()
		{
			Utilities.ShowNavBar("  Средний возраст книг по авторам, с упорядочиванием фамилий и инициалов авторов по алфавиту");

			Utilities.ShowList(_task1Controller.Query07A(), "\n\n  Запрос с помощью синтаксиса LINQ:\n");

			Utilities.ShowList(_task1Controller.Query07B(), "\n\n  Запрос с помощью расширяющего метода:\n");
		}

	}
}
