﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Homework.App_Data;

namespace Homework.Controllers
{
	public class Task2Controller
	{
		private StoreDataContext _store;

		public Task2Controller()
		{
			_store = new StoreDataContext();
		}

		public void ShowAllTables()
		{
			Console.WriteLine("\n  Таблица товаров:\n");
			ShowGoods(_store.Goods);
			Console.WriteLine("\n  Таблица продавцов:\n");
			ShowSellers(_store.Sellers);
			Console.WriteLine("\n  Таблица закупок:\n");
			ShowPurchases(_store.Purchases);
			Console.WriteLine("\n  Таблица продаж:\n");
			ShowSales(_store.Sales);
		}


		// Tовары, единицей измерения которых является «шт» и цена закупки составляет меньше 200 руб.
		public void Query01A() => ShowGoods(
				from p in _store.Purchases
				where p.Units.Short.Contains("шт") && p.PurchasePrice < 200
				select p.Goods);


		public void Query01B() =>
			ShowGoods(_store.Purchases
			.Where(x => x.Units.Short.Contains("шт") && x.PurchasePrice < 200)
			.Select(x => x.Goods));

		// Товары, цена закупки которых больше 500 руб. за единицу товара
		public void Query02A() =>
			ShowGoods(from p in _store.Purchases
					  where p.PurchasePrice > 500
					  select p.Goods);


		public void Query02B() =>
			ShowGoods(_store.Purchases
				.Where(x =>x.PurchasePrice > 500)
				.Select(x => x.Goods));


		//Товары с заданным наименованием, для которых цена закупки меньше 1800 руб.
		public void Query03A() =>
			ShowGoods(from p in _store.Purchases
					  where p.PurchasePrice < 1800 && p.Goods.Name == "Гайка М 3 ЦБ"
					  select p.Goods);

		public void Query03B() =>
			ShowGoods(_store.Purchases
				.Where(x => x.PurchasePrice < 1800 && x.Goods.Name == "Гайка М 3 ЦБ")
				.Select(x => x.Goods));

		//Продавцы с заданным значением процента комиссионных.
		public void Query04A() =>
			ShowSellers(from s in _store.Sellers
						where s.Interest.Equals(9)
						select s);

		public void Query04B() =>
			ShowSellers(_store.Sellers.Where(s => s.Interest.Equals(9)));

		//Все зафиксированные факты продажи товаров, с ценой продажи в заданных границах. 
		public void Query05A() =>
					  (from s in _store.Sales
					  where s.Price >= 300 && s.Price <= 600
					  select new
					  {
						  Title = s.Purchases.Goods.Name,
						  s.Purchases.PurchasePrice,
						  SellPrice = s.Price,
						  s.SellDate
					  }).ToList()
					  .ForEach(x =>
						  Console.WriteLine($"  │ {x.Title,-55} │ {x.PurchasePrice,5} │ {x.SellPrice,5}  │ {x.SellDate,10:dd/MM/yy} │"));
			

		public void Query05B() =>
			_store.Sales.Where(s => s.Price >= 300 && s.Price <= 600)
					.Select(s => new
					{
						Title = s.Purchases.Goods.Name,
						s.Purchases.PurchasePrice,
						SellPrice = s.Price,
						s.SellDate
					})
					.ToList()
					.ForEach(x => 
						Console.WriteLine($"  │ {x.Title, -55} │ {x.PurchasePrice, 5} │ {x.SellPrice, 5}  │ {x.SellDate,10:dd/MM/yy} │"));

		// Прибыль от продажи за каждый проданный товар.Сортировка по полю Наименование товара
		public void Query06A() =>
			(from s in _store.Sales
				select new
				{
					s.Purchases.Goods.Name,
					s.SellDate,
					s.Purchases.PurchasePrice,
					s.Price,
					s.Amount,
					Profit = (s.Price - s.Purchases.PurchasePrice) * s.Amount
				}).ToList()
			.ForEach(x =>
				Console.WriteLine($"  │ {x.Name,-55} │ {x.SellDate,10:dd/MM/yy} │ {x.PurchasePrice,5}  │ {x.Price,5} │ {x.Amount,5} │ {x.Profit,5} │"));

		public void Query06B() =>
			_store.Sales.Select(s => new
			{
				s.Purchases.Goods.Name,
				s.SellDate,
				s.Purchases.PurchasePrice,
				s.Price,
				s.Amount,
				Profit = (s.Price - s.Purchases.PurchasePrice) * s.Amount
			}).ToList()
				.ForEach(x =>
					Console.WriteLine($"  │ {x.Name,-55} │ {x.SellDate,10:dd/MM/yy} │ {x.PurchasePrice,5}  │ {x.Price,5} │ {x.Amount,5} │ {x.Profit,5} │"));

		// Отображающие методы

		public void ShowGoods(IQueryable<Goods> query)
		{
			foreach (var goods in query)
				Console.WriteLine($"  │ {goods.Id,2} │ {goods.Name,-55} │");
		}

		public void ShowSellers(IQueryable<Sellers> query)
		{
			foreach (var sellers in query)
				Console.WriteLine($"  │ {sellers.Id,2} │ {sellers.Surname,-15} │ {sellers.Name,- 15} │ {sellers.Patronymic,-15} │ {sellers.Interest,2} │");
		}

		public void ShowSales(IQueryable<Sales> query)
		{
			foreach (var sales in query)
				Console.WriteLine($"  │ {sales.Id,2} │ {sales.SellDate,10:dd/MM/yy} │ {sales.IdSeller,2} │ {sales.IdPurchase,2} │ {sales.Amount,4} │ {sales.IdUnit,2} │ {sales.Price,5} │");
		}

		public void ShowPurchases(IQueryable<Purchases> query)
		{
			foreach (var purchases in query)
				Console.WriteLine($"  │ {purchases.Id,2} │ {purchases.IdGood,2} │ {purchases.IdUnit,2} │ {purchases.PurchasePrice,6} │ {purchases.Amount,6} │ {purchases.PurchaseDate,10:dd/MM/yy} │");
		}
	}
}
