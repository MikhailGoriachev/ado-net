﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LINQ_Practice.Utilities;

namespace LINQ_Practice.Model
{
    public class Goods
    {
        //нименование 
        public string Name
        {
            get => Name;

            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Название товара не может быть пустым!");
            }
        }

        //цена
        public int Price { 
            get => Price;
            set
            {
                if (value < 0)
                    throw new Exception($"Значение стоимости {value} отрицательное!");
            } 
        }

        //Количество
        public int Amount { 
            get => Amount;
            set
            {
                if (value < 0)
                    throw new Exception($"Значение количества товара {value} отрицательное!");
            } 
        }
        //Год выпуска
        public int Manufactured { 
            get => Manufactured;
            set
            {
                if (value < 1970 || value > 2022)
                    throw new Exception($"Год призводства {value} - некорректен!");
            } 
        }

        //Текущий год 
        private int CurrYear = 0;

        public Goods():this(Utils.GoodsCars[Utils.GetRandom(0,Utils.GoodsNamesCount)],Utils.GetRandom(10000,50000),Utils.GetRandom(1,100),2017)
        {
            
        }

        public Goods(string name, int price,int count, int year)
        {
            Name = name;
            Price = price;
            Amount = count;
            Manufactured = year;

            CurrYear = DateTime.Now.Year;
        }

       //Перевормировать товар 
       public void Reform()
        {
            Name = Utils.GoodsCars[Utils.GetRandom(0, Utils.GoodsNamesCount)];
            Price = Utils.GetRandom(10000, 50000);
            Amount = Utils.GetRandom(1, 100);
            Manufactured = Utils.GetRandom(1990, CurrYear);
        }

        public override string ToString()
            => $" Название: {Name}\n Стоимость: {Price}$\n Кол-во: {Amount}\n Год проиводства: {Manufactured}\n";
    }
}
