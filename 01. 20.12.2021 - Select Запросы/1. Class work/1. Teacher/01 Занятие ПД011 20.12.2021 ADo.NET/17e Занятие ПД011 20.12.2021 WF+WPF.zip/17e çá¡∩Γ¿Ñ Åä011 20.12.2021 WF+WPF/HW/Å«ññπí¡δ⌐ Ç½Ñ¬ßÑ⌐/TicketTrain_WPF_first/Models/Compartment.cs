﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TicketTrain_WPF_first.Models
{
    [Serializable]
    [DataContract]
    // класс, описующий купе поезда
    public class Compartment
    {
        [DataMember]
        // тип купе 
        private string _typeCompartment;
        public string TypeCompartment
        {
            get { return _typeCompartment; }
            set { _typeCompartment = value; }
        }

        [DataMember]
        // номер купе
        private int _numb;
        public int Numb
        {
            get { return _numb; }
            set
            {
                if (value > 1 || value > 9)
                    throw new Exception("Compartment: ошибка номера купе");
                _numb = value;
            }
        }

        [DataMember]
        // Массив мест пассажиров
        private Seat[] _seats;
        public Seat[] Seats
        {
            get { return _seats; }
            set { _seats = value; }
        }

        [DataMember]
        // количесвто мест в купе
        private int _countSeats;
        public int CountSeats
        {
            get { return _countSeats; }
            private set
            {
                if (value == 2 || value == 4 || value == 6)
                    _countSeats = value;
                else
                    throw new Exception("Compartment: ошибка количества мест в купе");
            }
        }



        // конструктор
        public Compartment(int countSeats, int numberCompartment)
        {

            CountSeats = countSeats;
            _numb = numberCompartment;
            _seats = new Seat[_countSeats];


            switch (countSeats)
            {
                case 2:
                    _typeCompartment = "СВ";
                    break;

                case 4:
                    _typeCompartment = "Купе";
                    break;

                case 6:
                    _typeCompartment = "Плацкарт";
                    break;

                default:
                    break;
            }

            // нумерация мест в купе по номеру купе
            for (int i = 0; i < _countSeats; i++)
            {
                _seats[i] = new Seat(_countSeats * numberCompartment - _countSeats + i + 1, Utils.Utils.GetRandomState());
            }

        }

        // конструктор по умолчанию
        public Compartment() : this(2, 1) { }

    }
}
