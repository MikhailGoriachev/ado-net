﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models
{
    // для хранения результата запроса 6
    // Включает поля:
    // Дата продажи, Наименование товара, Цена закупки, Цена продажи, Количество проданных единиц, Прибыль
    internal class ResultQuery06 {
        // дата продажи
        public DateTime SaleDate { get; set; } // SaleDate

        // наименование товара
        public string Good { get; set; } // Good

        // цена продажи единицы товара
        public int SalePrice { get; set; } // SalePrice

        // цена закупки единицы товара
        public int PurchasePrice { get; set; } // PurchasePrice

        // количество продаваемого товара
        public int Amount { get; set; } // Amount

        // Прибыль
        public int Profit => (SalePrice - PurchasePrice) * Amount; // Profit

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {Good,-25} │  {SaleDate,10:dd.MM.yyyy}  │ {PurchasePrice,12:f2} │ {SalePrice,12:f2} │ {Amount,6} │ {Profit,11:f2} │";

        // статический метод для вывода шапки таблицы
        public static string Header() =>
                $"  ┌───────────────────────────┬──────────────┬──────────────┬──────────────┬────────┬─────────────┐\n" +
                $"  │ Наименование товара       │ Дата продажи │ Цена закупки │ Цена продажи │ Кол-во │   Прибыль   │\n" +
                $"  ├───────────────────────────┼──────────────┼──────────────┼──────────────┼────────┼─────────────┤";

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └───────────────────────────┴──────────────┴──────────────┴──────────────┴────────┴─────────────┘\n";
    } // ResultQuery06
}
