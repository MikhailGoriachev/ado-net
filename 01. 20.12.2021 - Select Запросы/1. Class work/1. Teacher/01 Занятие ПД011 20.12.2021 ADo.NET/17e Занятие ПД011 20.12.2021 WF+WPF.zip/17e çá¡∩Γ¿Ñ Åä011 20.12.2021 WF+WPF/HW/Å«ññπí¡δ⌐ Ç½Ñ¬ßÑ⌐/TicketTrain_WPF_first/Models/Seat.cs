﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TicketTrain_WPF_first.Models
{
    [Serializable]
    [DataContract]
    //класс, оипсующий место
    public class Seat
    {

        [DataMember]
        // номер места
        private int _number;
        public int Number
        {
            get { return _number; }
            set
            {
                if (value <= 0)
                    throw new Exception("Seat: неверный номер места");
                _number = value;
            }
        }

        [DataMember]
        //состояние места
        private bool _state;
        public bool State
        {
            get { return _state; }
            set { _state = value; }
        }

        // ансамбль конструкторов
        public Seat() : this(1, Utils.Utils.GetRandom(0, 1) == 1 ? true : false) { }

        public Seat(int numb, bool state)
        {
            Number = numb;
            State = state;
        }


    }
}
