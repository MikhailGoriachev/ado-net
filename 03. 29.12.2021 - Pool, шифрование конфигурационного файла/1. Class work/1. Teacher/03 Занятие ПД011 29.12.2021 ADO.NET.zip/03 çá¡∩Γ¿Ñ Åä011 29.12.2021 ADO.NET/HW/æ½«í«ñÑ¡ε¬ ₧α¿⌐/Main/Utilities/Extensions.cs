﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;


namespace Main.Utilities
{
	public static class Extensions
	{
		public static bool IsEndOfFile(this FileStream file) =>
			file.Position >= file.Length;


		public static bool IsEndOfFile(this StreamWriter writer) =>
			writer.BaseStream.Position >= writer.BaseStream.Length;


		public static void Fill<T>(this IList<T> list, Func<T> createItem)
		{
			for (int i = 0; i < list.Count; i++)
				list[i] = createItem.Invoke();
		}


		public static void Fill<T>(this IList<T> list, Func<T> createItem, int size)
		{
			for (int i = 0; i < size; i++)
				list.Add(createItem.Invoke());
		}


		public static T Random<T>(this IList<T> collection) => collection[General.Rand.Next(collection.Count)];


		public static void ColoredLine(this string message, Color color)
		{
			message.Colored(color);
			Console.WriteLine();
		}


		public static void Colored(this string message, Color color)
		{
			Color old = Color.Instantiate();

			color.AsCurrent();

			Console.Write(message);

			old.AsCurrent();
		}


		public static string Center(this string message, int width)
		{
			if (message is null)
				return string.Empty;

			int leftPadding = (width - message.Length) / 2;
			int rightPadding = width - message.Length - leftPadding;

			if (leftPadding < 0 || rightPadding < 0)
			{
				throw new ArgumentOutOfRangeException
					($"Строка для центрирования должна вмещаться в {nameof(width)}");
			}

			return $"{" ".PadLeft(leftPadding)}{message}{"".PadRight(rightPadding)}";
		}


		public static void ReplaceLast(this StringBuilder builder, char newSymbol) =>
			builder[builder.Length - 1] = newSymbol;


		public static void ReplaceLast(this StringBuilder builder, string newString)
		{
			builder.RemoveLast();
			builder.Append(newString);
		}


		public static void RemoveLast(this StringBuilder builder) => builder.Remove(builder.Length - 1, 1);


		public static void Output(this Exception exception)
		{
			if (exception is null)
				return;

			Palette.Error.AsCurrent();
			Console.Clear();

			Console.SetCursorPosition(0, Console.WindowHeight / 5);
			Console.WriteLine(exception);
			Console.ReadKey(true);

			Palette.Default.AsCurrent();
			Console.Clear();
		}


		public static bool IsEven(this int target) => (target & 1) == 0;

		public static bool IsOdd(this int target) => (target & 1) != 0;


		public static double RealNextDouble(this Random rand, double min, double max) =>
			rand.NextDouble() * (max - min) + min;


		public static DateTime NextDate(this Random rand)
		{
			GregorianCalendar calendar = new();

			int year = rand.Next(1900, DateTime.Now.Year);
			int month = rand.Next(1, calendar.GetMonthsInYear(year) + 1);
			int day = rand.Next(1, calendar.GetDaysInMonth(year, month) + 1);

			return new(year, month, day);
		}
	}
}