﻿using System;

namespace LinqIntro.Helpers
{
    
    // пункт меню
    public class MenuItem {
        public ConsoleKey HotKey { get; set; }  // горячая клавиша пункта меню
        public string Text { get; set; }        // текст пункта меню
    } // class MenuItem
}