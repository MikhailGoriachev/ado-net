﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using H_W6AdoLINQtoSQL.Views;
using H_W6AdoLINQtoSQL.Controllers;

namespace H_W6AdoLINQtoSQL
{
    public partial class MainForm : Form
    {

        private QueriesController _queriesController;

        public MainForm() : this(new QueriesController()) { }
        public MainForm(QueriesController queriesController)
        {
            InitializeComponent();

            _queriesController = queriesController;

            
        } // MainForm


        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e) =>
            new AboutForm().ShowDialog();

        private void MainForm_Load(object sender, EventArgs e)
        {
            Query01();
            Query02();
            Query03();
            Query04();
            Query05();
            Query06();
            Query07();
            Query08();
           
        }// MainForm_Load

        // вывод к первому запросу в DataGridView
        private void Query01()
        {
            DgvQuery01.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQuery01.DataSource = _queriesController.Query01();

            DgvQuery01.ClearSelection();
            LblDgv1.Text = "Выбирает из таблицы ТОВАРЫ информацию о товарах," +
                " единицей измерения которых является «шт» (штуки) и цена закупки составляет меньше 100 руб.";
        }// Query01

        // вывод ко второму запросу в DataGridView
        private void Query02()
        {
            DgvQuery02.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQuery02.DataSource = _queriesController.Query02();

            DgvQuery02.ClearSelection();

            LblDgv2.Text = "Выбирает из таблицы ТОВАРЫ информацию о товарах," +
                " цена закупки которых больше 140 руб. за единицу товара";
        }// Query02


        // вывод к третьему запросу в DataGridView
        private void Query03()
        {
            DgvQeury03.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQeury03.DataSource = _queriesController.Query03();

            DgvQeury03.ClearSelection();

            LblDgv3.Text = "Выбирает из таблицы ТОВАРЫ информацию о товарах с заданным наименованием (например, «чехол защитный»)," +
                " для которых цена закупки меньше 200 руб.";
        }// Query03


        // вывод к четвёртому запросу в DataGridView
        private void Query04()
        {
            DgvQuery04.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQuery04.DataSource = _queriesController.Query04();

            DgvQuery04.ClearSelection();

            LblDgv4.Text = "Выбирает из таблицы ПРОДАВЦЫ информацию о продавцах с заданным значением процента комиссионных. ";
        }// Query04


        // вывод к пятому запросу в DataGridView
        private void Query05()
        {
            DgvQuery05.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQuery05.DataSource = _queriesController.Query05();

            DgvQuery05.ClearSelection();

            LblDgv5.Text = "Выбирает из таблиц ТОВАРЫ, ПРОДАВЦЫ и ПРОДАЖИ информацию обо всех зафиксированных фактах продажи товаров" +
                " (Наименование товара, Цена закупки, Цена продажи, дата продажи), для которых Цена продажи оказалась в некоторых заданных границах. ";
        }// Query05


        // вывод к шестому запросу в DataGridView
        private void Query06()
        {
            DgvQuery06.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQuery06.DataSource = _queriesController.Query06();

            DgvQuery06.ClearSelection();

            LblDgv6.Text = "Вычисляет прибыль от продажи за каждый проданный товар." +
                " Включает поля Дата продажи, Наименование товара, Цена закупки," +
                " Цена продажи, Количество проданных единиц, Прибыль." +
                " Сортировка по полю Наименование товара";
        }// Query06


        // вывод к судьмому запросу в DataGridView
        private void Query07()
        {
            DgvQuery07.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQuery07.DataSource = _queriesController.Query07();

            DgvQuery07.ClearSelection();

            LblDgv7.Text = "Выполняет группировку по полю Наименование товара." +
                " Для каждого наименования вычисляет среднюю цену закупки товара, количество закупок.";
        }// Query07


        // вывод к восьмому запросу в DataGridView
        private void Query08()
        {
            DgvQuery08.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            DgvQuery08.DataSource = _queriesController.Query08();

            DgvQuery08.ClearSelection();

            LblDgv8.Text = "Выполняет группировку по полю Код продавца из таблицы ПРОДАЖИ. Для каждого продавца вычисляет среднее значение по полю Цена продажи единицы товара, количество продаж.";
        }// Query08

        #region Обработка кнопок
        // команда запрос 1
        private void Query01_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = Tbc01;
            Query01();
        }// Query01_Command


        // команда запрос 2
        private void Query02_Comman(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = Tbc02;
            Query02();
        }// Query02_Command


        // команда запрос 3
        private void Query03_Comman(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = Tbc03;
            Query03();
        }// Query03_Command


        // команда запрос 4
        private void Query04_Comman(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = Tbc04;
            Query04();
        }// Query04_Command


        // команда запрос 5
        private void Query05_Comman(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = Tbc05;
            Query05();
        }// Query05_Command


        // команда запрос 6
        private void Query06_Comman(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = Tbc06;
            Query06();
        }// Query06_Command


        // команда запрос 7
        private void Query07_Comman(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = Tbc07;
            Query07();
        }// Query07_Command


        // команда запрос 8
        private void Query08_Comman(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = Tbc08;
            Query08();
        }// Query08_Command

        #endregion


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e)
        {
            this.Hide();
            NtiMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e)
        {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command

    }// class MainForm
}
