﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Task01
{
    // для хранения результата запроса 7 из задачи 1
    // фамилия И.О. автора и средний возраст книг этого автора
    internal class ResultQuery07 {
        // фамилия И.О. автора
        public string FullName { get; set; } // FullName


        // средний возраст книг этого автора
        public double AvgAge { get; set; } // AvgAge

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {FullName,-15} │ {AvgAge,16:f2} │";

        // статический метод для вывода шапки таблицы
        public static string Header()
        {
            return
                $"  ┌─────────────────┬──────────────────┐\n" +
                $"  │ Автор           │ Cр. возраст книг │\n" +
                $"  ├─────────────────┼──────────────────┤";
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────────────────┴──────────────────┘\n";
    } // ResultQuery07
}
