﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W5AdoLINQtoSQL.Models.Task1
{
    // Класс Книга имеет следующие поля:
    // *идентификатор,
    // *идентификатор автора,
    // *название книги,
    // *год издания,
    // *цена
    public class Book
    {
        // идентификатор
        private int _id;
        public int Id {
            get => _id;
            set
            {
                if (value < 0)
                    throw new ArgumentException($"Book: Недопустимое значение индентификатора книги: {value}");
                _id = value;
            }
        }// Id


        // идентификатор автора
        private int _idAuthor;
        public int IdAuthor
        {
            get => _idAuthor;
            set
            {
                if (value < 0)
                    throw new ArgumentException($"Book: Недопустимое значение индентификатора автора: {value}");
                _idAuthor = value;
            }
        }// IdAuthor


        // название книги
        private string _nameBook;
        public string NameBook
        {
            get => _nameBook;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Book: Не верно задано наименование книги или задано пустой строкой");
                _nameBook = value;
            }
        }// NameBook


        // год издания
        private int _yearPublishing;
        public int YearPublishing
        {
            get => _yearPublishing;
            set
            {
                if (value > DateTime.Now.Year)
                    throw new ArgumentException($"Book: Недопустимое значение года издания книги: {value}");
                _yearPublishing = value;
            }
        }// YearPublishing


        // цена
        private double _price;
        public double Price
        {
            get => _price;
            set
            {
                if (value <= 0)
                    throw new ArgumentException($"Book: Недопустимое значение цены книги: {value}");
                _price = value;
            }
        }// Price


        // конструкторы
        public Book(): this(0, 3, "Несломленный", 2010, 954.20) { }
        public Book(int id, int idAuthor, string name, int year, double price)
        {
            Id             = id;
            IdAuthor       = idAuthor;
            NameBook       = name;
            YearPublishing = year;
            Price          = price;
        }// Book


        // для вывода данных о книге в строковом формате
        public override string ToString() =>
            $"{Id, 5} : автор {IdAuthor,-12}, название {NameBook,-25} ; {YearPublishing,8}год издания , цена {Price,10 :n2}p. ";

    }// class Book
}
