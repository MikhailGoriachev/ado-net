﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConfigSecurityModels.Helpers;

namespace ConfigSecurityModels.Application
{
    /*
     * Конструкторы для соддания контроллера решения задачи
     */
    public partial class App
    {

        // Запрос 1. Издания со стоимостью экземпляра ниже заданной
        public void ExecQuery01() {
            Utils.ShowNavBarTask("   Запрос 1. Издания со стоимостью экземпляра ниже заданной");

            _task1Controller.Query01("журнал", 1500);
        } // ExecQuery01
        

        // Запрос 2. Подписчики заданного издания, проживающие по заданному адресу
        public void ExecQuery02() {
            Utils.ShowNavBarTask("   Запрос 2. Подписчики заданного издания, проживающие по заданному адресу");

            _task1Controller.Query02("ул. Садовая", "118", "Юный техник");
        } // ExecQuery02


        // Запрос 3. Издания с ценой в заданом диапазоне
        public void ExecQuery03() {
            Utils.ShowNavBarTask("   Запрос 3. Издания с ценой в заданом диапазоне");

            // генерация диапазона цены одного экземпляра
            int lo = Utils.GetRandom(1, 10);
            int hi = lo + Utils.GetRandom(3, 7);   

            // собственно выполнение запроса
            _task1Controller.Query03(lo*100, hi*100);
        } // ExecQuery03


        // Запрос 4. Подписчики, подписавшиеся на заданный тип издания
        public void ExecQuery04() {
            Utils.ShowNavBarTask("   Запрос 4. Подписчики, подписавшиеся на заданный тип издания");

            Utils.ShowUnderConstruction();
        } // ExecQuery04


        // Запрос 5. Подписки, оформленные на срок из заданного диапазона
        public void ExecQuery05() {
            Utils.ShowNavBarTask("   Запрос 5. Подписки, оформленные на срок из заданного диапазона");

            Utils.ShowUnderConstruction();
        } // ExecQuery05


        // Запрос 6. Стоимость оформленных подписок с доставкой, без НДС
        public void ExecQuery06() {
            Utils.ShowNavBarTask("   Запрос 6. Стоимость оформленных подписок с доставкой, без НДС");

            Utils.ShowUnderConstruction();
        } // ExecQuery06


        // Запрос 7. Минимальная и максимальная цена одного экземпляра по видам изданий
        public void ExecQuery07() {
            Utils.ShowNavBarTask("   Запрос 7. Минимальная и максимальная цена одного экземпляра по видам изданий");

            Utils.ShowUnderConstruction();
        } // ExecQuery07


        // Запрос 8. Количество подписчиков по улицам
        public void ExecQuery08() {
            Utils.ShowNavBarTask("   Запрос 8. Количество подписчиков по улицам");

            Utils.ShowUnderConstruction();
        } // ExecQuery08


        // Запрос 9. Количество оформленных подписок по видам изданий
        public void ExecQuery09() {
            Utils.ShowNavBarTask("   Запрос 9. Количество оформленных подписок по видам изданий");

            Utils.ShowUnderConstruction();
        } // ExecQuery09


        // Шифрование конфигурационного файла
        public void EncodeConfigFile() {
            Utils.ShowNavBarTask("   Шифрование конфигурационного файла");

            _task1Controller.EncodeConfigFile();
            Console.WriteLine("\n\n\n    Шифрование конфигурационного файла выполнено\n");

            // прочитать конфигурационный файл, вывести его в консоль
            string[] configList = File.ReadAllLines("ConfigSecurityModels.exe.config", Encoding.UTF8);
            Array.ForEach(configList, line => 
                Console.WriteLine($"    {(line.Length > 89?line.Substring(0, 89)+"...":line)}"));
        } // EncodeConfigFile


        // Расшифровка когфигурационного файлай
        public void decodeConfigFile() {
            Utils.ShowNavBarTask("   Расшифровка конфигурационного файла");

           _task1Controller.DecodeConfigFile();
           Console.WriteLine("\n\n\n    Расшифровка конфигурационного файла выполнена\n");

           // прочитать конфигурационный файл, вывести его в консоль
           string[] configList = File.ReadAllLines("ConfigSecurityModels.exe.config", Encoding.UTF8);
           Array.ForEach(configList, line =>
               Console.WriteLine($"    {(line.Length > 89 ? line.Substring(0, 89) + "..." : line)}"));
        } // decodeConfigFile


    } // class App
}
