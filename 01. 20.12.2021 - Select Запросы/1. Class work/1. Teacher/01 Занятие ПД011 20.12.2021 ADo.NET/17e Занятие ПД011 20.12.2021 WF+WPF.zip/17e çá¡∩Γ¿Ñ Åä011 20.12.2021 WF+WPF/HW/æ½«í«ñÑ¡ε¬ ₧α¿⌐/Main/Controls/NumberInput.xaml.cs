﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Main.Controls
{
	/// <summary>
	/// Interaction logic for NumberInput.xaml
	/// </summary>
	public sealed partial class NumberInput : UserControl
	{
		public static readonly DependencyProperty HeaderProperty = DependencyProperty.Register(
			"Header", typeof(string), typeof(NumberInput), new PropertyMetadata(default(string)));

		public string Header { get { return (string)GetValue(HeaderProperty); } set { SetValue(HeaderProperty, value); } }

		public static readonly DependencyProperty SharedFontSizeProperty = DependencyProperty.Register(
			"SharedFontSize", typeof(double), typeof(NumberInput), new PropertyMetadata(default(double)));

		public double SharedFontSize { get { return (double)GetValue(SharedFontSizeProperty); } set { SetValue(SharedFontSizeProperty, value); } }

		public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
			"Value", typeof(string), typeof(NumberInput), new PropertyMetadata(default(string)));

		public string Value { get { return (string)GetValue(ValueProperty); } set { SetValue(ValueProperty, value); } }

		public NumberInput()
		{
			InitializeComponent();
		}
	}
}
