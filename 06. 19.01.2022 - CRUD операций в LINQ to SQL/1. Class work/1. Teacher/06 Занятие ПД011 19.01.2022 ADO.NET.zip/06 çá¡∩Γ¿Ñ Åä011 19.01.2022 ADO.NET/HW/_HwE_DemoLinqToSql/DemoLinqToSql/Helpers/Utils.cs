﻿using System;
using System.Collections.Generic;
using System.Text;
using DemoLinqToSql.Models;
using DemoLinqToSql.Models.Task1;

namespace DemoLinqToSql.Helpers
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {

        // объект для получения случайных чисел
        public static readonly Random Random = new Random(Environment.TickCount);

        // Получение случайного числа
        // краткая форма записи метода - это не лямбда выражение
        public static int GetRandom(int lo, int hi) => Random.Next(lo, hi + 1);

        public static double GetRandom(double lo, double hi) {
            double t = lo + (hi - lo) * Random.NextDouble();
            return Math.Abs(t) < 1.9 ? 0 : t;
        }

        // формирование случайных целых чисел в заданном диапазоне (lo, hi),
        // исключая указанное параметром exclude число
        public static int GetRandomExclude(int lo, int hi, int exclude) {
            int number = 0;
            do
                number = Random.Next(lo, hi);
            while (number == exclude);

            return number;
        } // GetRandomExclude


        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line) {
            // сохранить цвет фона
            (ConsoleColor oldBg, ConsoleColor oldFg) = (Console.BackgroundColor, Console.ForegroundColor);

            // при выводе немного используем методы класса string :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            (Console.BackgroundColor, Console.ForegroundColor) = (oldBg, oldFg);
        } // ShowNavBarTask
        
        
        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color) {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY


        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, List<MenuItem> menu) {
            WriteXY(x, y, title, ConsoleColor.Gray);
            int offsetY = 2;

            foreach (var menuItem in menu) {
                // если текст пункта меню Separator, просто увеличить смещение по вертикали
                // что приведет к образованию пустой строки
                if (menuItem.Text != "Separator") {
                    WriteXY(x, y + offsetY, menuItem.HotKey.ToString(), ConsoleColor.Cyan);
                    WriteXY(x + 2, y + offsetY, menuItem.Text, ConsoleColor.Gray);
                } // if

                ++offsetY;
            } // foreach menuItem
        } // ShowMenu


        // Вывод сообщения "Метод в разработке" по центру экрана
        public static void ShowUnderConstruction() {
            (ConsoleColor fg, ConsoleColor bg) = (Console.ForegroundColor, Console.BackgroundColor); 
            (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);

            string[] lines = { 
                 " ".PadRight(40),
                 " ".PadRight(40),
                 "     [К сведению]".PadRight(40),
                 " ".PadRight(40),
                 "     Метод в разработке".PadRight(40),
                 " ".PadRight(40),
                 " ".PadRight(40),
            };

            int x = (Console.WindowWidth - 40) / 2;
            int y = (Console.WindowHeight - lines.Length) / 2;
            foreach(var line in lines)
                WriteXY(x, y++, line, ConsoleColor.DarkGray);

            (Console.ForegroundColor, Console.BackgroundColor) = (fg, bg);
            Console.SetCursorPosition(0, Console.WindowHeight-1);
        } // ShowUnderConstruction

        // ------------------------------------------------------------------------------

        // Установить текущий цвет символов и фона с сохранением
        // текущего цвета символов и фона
        private static (ConsoleColor Fore,  ConsoleColor Back) _storeColor;
        public static void SetColor(ConsoleColor fore, ConsoleColor back) {
            _storeColor = (Console.ForegroundColor, Console.BackgroundColor);
            Console.ForegroundColor = fore;
            Console.BackgroundColor = back;
        } // SetColor

        // Сохранить цвет
        public static void SaveColor() =>
            _storeColor = (Console.ForegroundColor, Console.BackgroundColor);

        // Восстановить сохраненный цвет
        public static void RestoreColor() =>
            (Console.ForegroundColor, Console.BackgroundColor) = _storeColor;

        // ------------------------------------------------------------------------------


        // вернуть имя из массива имен - работает с учетом пола
        // массивы имен вынесены из методов - для ускорения работы
        // методов, не требуется инициализация массива при каждом вызове метода
        private static readonly string[] MaleNames = {
            "Ерофей", "Агафон", "Спиридон", "Тимофей", "Сергей",
            "Павел", "Федор", "Тарас", "Николай", "Валерий",
            "Юрий", "Алексей"
        };

        private static readonly string[] FemaleNames = {
            "Марфа", "Оксана", "Анна", "Лидия", "Евлампия", "Наталья", "Полина",
            "Фекла", "Тамара", "Яся", "Татьяна"
        };

        public static string GetName(bool gender) => gender
            ? MaleNames[GetRandom(0, MaleNames.Length - 1)]
            : FemaleNames[GetRandom(0, FemaleNames.Length - 1)];

        // вернуть фамилию из массива имен - очень примитивный 
        // алгоритм формирования женских фамилий
        private static readonly string[] Surnames = {
            "Огородников", "Иванов", "Семенов", "Охрименков", "Васильев", "Ларин",
            "Тяглов", "Тимофеев", "Сергеев", "Елизаветин", "Шматков", "Луков", "Федоров",
            "Туркин"
        };
        public static string GetSurname(bool gender) {
            string surname = Surnames[GetRandom(0, Surnames.Length - 1)];
            return gender ? surname : surname + "а";
        } // GetSurname


        // формирование знака зодиака по дате 
        private static readonly (string Sign, DateTime From, DateTime To)[] Zodiacs = {
            ("Козерог",  new DateTime(1999, 12, 22), new DateTime(2000,  1, 20)),
            ("Водолей",  new DateTime(2000,  1, 21), new DateTime(2000,  2, 18)),
            ("Рыбы",     new DateTime(2000,  2, 19), new DateTime(2000,  3, 20)),
            ("Овен",     new DateTime(2000,  3, 21), new DateTime(2000,  4, 20)),
            ("Телец",    new DateTime(2000,  4, 21), new DateTime(2000,  5, 21)),
            ("Близнецы", new DateTime(2000,  5, 22), new DateTime(2000,  6, 21)),
            ("Рак",      new DateTime(2000,  6, 22), new DateTime(2000,  7, 22)),
            ("Лев",      new DateTime(2000,  7, 23), new DateTime(2000,  8, 23)),
            ("Дева",     new DateTime(2000,  8, 24), new DateTime(2000,  9, 22)),
            ("Весы",     new DateTime(2000,  9, 23), new DateTime(2000, 10, 23)),
            ("Скорпион", new DateTime(2000, 10, 24), new DateTime(2000, 11, 22)),
            ("Стрелец",  new DateTime(2000, 11, 23), new DateTime(2000, 12, 21))
        };
        public static string GetZodiac(DateTime date) {
            // создать дату для сравнения с границами знаков Зодиака
            DateTime temp = new DateTime(2000, date.Month, date.Day);

            string result = Array.Find(Zodiacs, d => d.From <= temp && temp <= d.To).Sign;
            return string.IsNullOrEmpty(result) ? "Козерог" : result;
        } // GetZodiac

        // формирование коллекции авторов для задачи 1
        public static List<Author> GetAuthorsList() => new List<Author>(new [] {
            new Author {Id =  1, FullName = "Гриффитс М.",     BornYear = 1956},
            new Author {Id =  2, FullName = "Григорьев Р.И.",  BornYear = 1971},
            new Author {Id =  3, FullName = "Абрамян М.Э.",    BornYear = 1964},
            new Author {Id =  4, FullName = "Бизли Д.",        BornYear = 1987},
            new Author {Id =  5, FullName = "Спрол А.",        BornYear = 1991},
            new Author {Id =  6, FullName = "Дашнер С.",       BornYear = 1973},
            new Author {Id =  7, FullName = "Борисова Р.К.",   BornYear = 1976},
            new Author {Id =  8, FullName = "Уоллс К.",        BornYear = 1982},
            new Author {Id =  9, FullName = "Павловская Т.А.", BornYear = 1963},
            new Author {Id = 10, FullName = "Шилдт Г.",        BornYear = 1958}
        }); // GetAuthorsList

        // формирование коллекции книг для задачи 1
        public static List<Book> GetBooksList() => new List<Book>(new [] {
            new Book { Id =  1, IdAuthor = 10, Title = "C# 4.0 полное руководство",          PubYear = 2011, Price =  720},
            new Book { Id =  2, IdAuthor =  1, Title = "Программируем на С# 8.0",            PubYear = 2021, Price = 1100},
            new Book { Id =  3, IdAuthor =  2, Title = "Задачник по PHP с решениями",        PubYear = 2018, Price =  650},
            new Book { Id =  4, IdAuthor =  3, Title = "1000 задач по программированию",     PubYear = 2002, Price =  100},
            new Book { Id =  6, IdAuthor =  4, Title = "Python - книга рецептов",            PubYear = 2019, Price = 1100},
            new Book { Id =  7, IdAuthor =  3, Title = "Технология LINQ",                    PubYear = 2011, Price =  460},
            new Book { Id =  8, IdAuthor =  5, Title = "Думай, как программист",             PubYear = 2018, Price =  300},
            new Book { Id =  9, IdAuthor =  6, Title = " Изучаем Java EE",                   PubYear = 2016, Price =  800},
            new Book { Id = 10, IdAuthor =  7, Title = "Практикум STL для C++17",            PubYear = 2018, Price =  700},
            new Book { Id = 11, IdAuthor =  8, Title = "Spring в действии",                  PubYear = 2018, Price = 1100},
            new Book { Id = 12, IdAuthor =  9, Title = "Практикум по программированию на C", PubYear = 2012, Price =  540},
            new Book { Id = 13, IdAuthor = 10, Title = "Java 8 - полное руководство",        PubYear = 2015, Price =  780}
        }); // GetBooksList

        // вывод коллекции книг в строку, в формате таблицы, с расшифровкой поля автора
        public static string ToTable(List<BookViewModel> booksList, string caption = "\n\t\tТовары в магазине\n") {
            // вывод заголовка таблицы
            StringBuilder sb = new StringBuilder($"{caption}{BookViewModel.Header}");

            // вывод коллекции - тело таблицы
            booksList.ForEach(g => sb.Append(g.ToTableRow()));

            // вывод подвала таблицы
            sb.Append(BookViewModel.Footer);
            return sb.ToString();
        } // ToTable
    } // class Utils
}