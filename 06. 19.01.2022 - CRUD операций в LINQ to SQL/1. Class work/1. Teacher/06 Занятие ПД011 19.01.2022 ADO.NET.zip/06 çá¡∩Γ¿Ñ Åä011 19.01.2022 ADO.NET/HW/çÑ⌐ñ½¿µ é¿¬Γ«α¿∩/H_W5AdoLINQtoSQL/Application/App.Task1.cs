﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W5AdoLINQtoSQL.Application
{
    internal partial class App
    {
        // Вывести все книги коллекции, выводить фамилии и инициалы автора
        public void ShowBooks()
        {
            Utils.ShowNavBarTask("   Все книги в коллекции.");


            _collectionBooks.Query01Ext();
            _collectionBooks.Query01Linq();
        } // ShowBooks


        // Вывести книги авторов, год рождения которых принадлежит заданном диапазону 
        public void AuthorBirthDiapazone()
        {
            Utils.ShowNavBarTask("   Вывести книги авторов, год рождения которых принадлежит заданном диапазону.");

            int loYear = 1917;
            int hiYear = 1930;

            Console.Write($"\n  Книги авторов, год рождения которых принадлежит диапазону  от {loYear}г.р. до {hiYear}г.р.\n");
            _collectionBooks.Query02Ext(loYear, hiYear);
            _collectionBooks.Query02Linq(loYear, hiYear);
        }// AuthorBirthDiapazone


        // Вывести книги, в которых содержится подстрока и цена не превышает заданного значения
        public void BooksPrice()
        {
            Utils.ShowUnderConstruction();
        }// BooksPrice


        // Список авторов и количество их книг в коллекции
        public void AutorsAndBook()
        {
            Utils.ShowNavBarTask("   Список авторов и количество их книг в коллекции.");


            _collectionBooks.Query04Ext();
            _collectionBooks.Query04Linq();
        }// AutorsAndBook


        // Средняя цена книг по годам издания
        public void AvgBooksInYear()
        {
            Utils.ShowNavBarTask("   Средняя цена книг по годам издания.");


            _collectionBooks.Query05Ext();
            _collectionBooks.Query05Linq();
        }// AvgBooksInYear


        // Список авторов по убыванию количества их книг в коллекции 
        public void AutorsAndBookSort()
        {
            Utils.ShowNavBarTask("   Список авторов по убыванию количества их книг в коллекции.");


            _collectionBooks.Query06Ext();
            _collectionBooks.Query06Linq();
        }// AutorsAndBookSort


        // Средний возраст книг по авторам,
        // выводить список с упорядочиванием фамилий и инициалов авторов по алфавиту
        public void AvgYearBookOrderAuthor()
        {
            Utils.ShowNavBarTask("   Средний возраст книг по авторам, выводить список с упорядочиванием по ФИО.");


            _collectionBooks.Query07Ext();
            _collectionBooks.Query07Linq();
        }// AvgYearBookOrderAuthor

    }// class App
}
