﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADoNET_6__LinqToSqlWinForms_.Models {
    internal class Purchase {
        // идентификатор
        public int Id { get; set; } // Id

        // наименование товара
        public string Good { get; set; } // Good

        // краткое наименование единицы измерения
        public string Unit { get; set; } // Unit

        // дата закупки
        public DateTime PurchaseDate { get; set; } // PurchaseDate

        // цена закупки единицы товара
        public int Price { get; set; } // Price

        // количество закупаемого товара
        public int Amount { get; set; } // Amount

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {Id,3} │ {(Good.Length > 31 ? $"{Good.Substring(0, 28)}..." : $"{Good,-31}")} │ {Unit,-11} │  {PurchaseDate,10:dd.MM.yyyy}  │ {Price,15:f2} │ {Amount,6} │";

        // статический метод для вывода шапки таблицы
        public static string Header() {
            return
                $"  ┌─────┬─────────────────────────────────┬─────────────┬──────────────┬─────────────────┬────────┐\n" +
                $"  │ ID  │ Наименование товара             │ Единица изм.│ Дата закупки │ Цена ед. товара │ Кол-во │\n" +
                $"  ├─────┼─────────────────────────────────┼─────────────┼──────────────┼─────────────────┼────────┤";
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────┴─────────────────────────────────┴─────────────┴──────────────┴─────────────────┴────────┘\n";
    }
}
