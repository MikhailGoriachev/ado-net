﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqIntro.Controllers;

namespace LinqIntro.Application
{
    /*
     * Конструкторы для создания контроллера решения задачи
     */
    public partial class App
    {
        // контроллер для выполнения задач
        private Task1Controller _task1Controller;
        private Task2Controller _task2Controller;
        private Task3Controller _task3Controller;

        // конструктор по умолчанию
        public App() : this(new Task1Controller(), new Task2Controller(), new Task3Controller()) { }

        public App(Task1Controller task1Controller, Task2Controller task2Controller, Task3Controller task3Controller) {
            _task1Controller = task1Controller;
            _task2Controller = task2Controller;
            _task3Controller = task3Controller;
        } // App

    } // class App
}
