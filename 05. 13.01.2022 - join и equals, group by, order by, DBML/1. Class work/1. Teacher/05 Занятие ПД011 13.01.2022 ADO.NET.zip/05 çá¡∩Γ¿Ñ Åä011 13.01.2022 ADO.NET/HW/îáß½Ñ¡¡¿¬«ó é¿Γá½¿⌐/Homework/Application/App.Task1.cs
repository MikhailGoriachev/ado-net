﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Application
{
	internal partial class App
	{
		private void Task1Item1()
		{
			Utilities.ShowNavBar("  Демонстрация работы расширяющего метода.");

			Console.WriteLine("\n\n  Вычисление скидки с помощью расширяющего метода:\n");

			_task1Controller.ExtensionDemo();
		}
	}
}
