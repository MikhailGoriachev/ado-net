﻿--1 Хранимая процедура
--Выбирает информацию о 3-комнатных квартирах, расположенных на
--улице «Садовая». Значения задавать параметрами запроса
drop proc if exists ShowByStreetsAndRooms
go
create proc ShowByStreetsAndRooms
	@street nvarchar(80)
	,@rooms int
as
select
	Street
	,Apartments.NumHouse
	,Apartments.NumApartment
	,Apartments.[Square]
	,Apartments.Rooms
	,Apartments.Cost
from 
	Apartments join Streets on Apartments.idStreet = Streets.Id
where
	Street = @street and Apartments.Rooms = @rooms
go
--2 Хранимая процедура
--Выбирает информацию о риэлторах, фамилия которых начинается с 
--буквы «И» и процент вознаграждения больше 10%. Значения задавать параметрами запроса
drop proc if exists ShowBySurnameAndPercent
go
create proc ShowBySurnameAndPercent
	@surname nvarchar(1)
	,@percent int
as
select
	PSurname
	,PName
	,PPatronymic
	,Realtors.Percnt
from Realtors join PSurnames on Realtors.idSurname = PSurnames.Id
				join PNames on Realtors.idName = PNames.Id
				join PPatronymics on Realtors.idPatronymic = PPatronymics.Id
where
	PSurname like (@surname + '%')	and Realtors.Percnt > @percent;
go
--3 Хранимая процедура
--Выбирает информацию об 1-комнатных квартирах, цена на которые 
--находится в диапазоне от 900 000 руб. до 1000 000 руб. Значения задавать параметрами запроса
drop proc if exists ShowByRoomsAndCost
go
create proc ShowByRoomsAndCost
	@rooms int
	,@lo int
	,@hi int
as
select
	Street
	,Apartments.NumHouse
	,Apartments.NumApartment
	,Apartments.Rooms
	,Apartments.[Square]
	,Apartments.Cost
from 
	Apartments join Streets on Apartments.idStreet = Streets.Id
where
	Rooms = @rooms
	and Cost  between @lo and @hi
go
--4 Хранимая процедура
--Выбирает информацию о квартирах с заданным числом комнат. 
--Значения задавать параметрами запроса
drop proc if exists ShowByRooms
go
create proc ShowByRooms
	@rooms int
as
select
	Street
	,Apartments.NumHouse
	,Apartments.NumApartment
	,Apartments.Rooms
	,Apartments.[Square]
	,Apartments.Cost
from 
	Apartments join Streets on Apartments.idStreet = Streets.Id
where
	Rooms = @rooms
go
--5 Хранимая процедура
--Выбирает информацию обо всех 2-комнатных квартирах, площадь
--которых есть значение из некоторого диапазона. Значения задавать 
--параметрами запроса
drop proc if exists ShowByRoomsAndSquare
go
create proc ShowByRoomsAndSquare
	@rooms int
	,@lo int
	,@hi int
as
select
	Street
	,Apartments.NumHouse
	,Apartments.NumApartment
	,Apartments.Rooms
	,Apartments.[Square]
	,Apartments.Cost
from 
	Apartments join Streets on Apartments.idStreet = Streets.Id
where
	Rooms = @rooms and Apartments.[Square] between @lo and @hi
go
--6 Хранимая процедура
--Вычисляет для каждой оформленной сделки размер комиссионного 
--вознаграждения риэлтора. Включает поля Фамилия риэлтора, Имя 
--риэлтора, Отчество риэлтора, Дата сделки, Цена квартиры, Комиссионные. 
--Сортировка по полю Дата сделки
drop proc if exists ShowByCom
go
create proc ShowByCom
as
select 
	PSurname
	,PName
	,PPatronymic
	,Buyers.DateOfDeal
	,Apartments.Cost
	,[Cost] * Realtors.Percnt as Комиссионные
from 
	Deals join (Realtors join  PSurnames on Realtors.idSurname = PSurnames.Id
				join PNames on Realtors.idName = PNames.Id
				join PPatronymics on Realtors.idPatronymic = PPatronymics.Id)
					on Deals.idRealtor = Realtors.Id
		  join Buyers on Deals.idBuyer = Buyers.Id
		  join (Apartments join Streets on Apartments.idStreet = Streets.Id)
					on Deals.idApartment = Apartments.Id
order by DateOfDeal
go
--7 Хранимая процедура
--Выбрать всех риэлторов, количество клиентов, оформивших с ним
--сделки и сумму сделок риэлтора. Упорядочить выборку по убыванию суммы сделок.
drop proc if exists ShowRealtorsStatistic
go
create proc ShowRealtorsStatistic
as
select 
	PSurname
	,COUNT(Deals.idBuyer) as [Клиенты]
	,SUM(Apartments.Cost) as [Сумма сделок]
from
	Psurnames left join (Realtors join (Deals join Apartments on Deals.idApartment = Apartments.Id)
		on Realtors.Id = Deals.idRealtor)
		on PSurnames.Id = Realtors.idSurname
group by PSurname
go
--8 Хранимая процедура
--Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
drop proc if exists ShowBySumOfCost
go
create proc ShowBySumOfCost
as
select
	Streets.Street
	,SUM(Apartments.Cost) as [Сумма сделки]
from
	Streets left join Apartments on Streets.Id = Apartments.idStreet
group by Street
go
--9 Хранимая процедура
--Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку
--по убыванию суммы сделки. Диапазон задавать параметрами запроса
drop proc if exists ShowByDateOfDeal
go
create proc ShowByDateOfDeal
	@lo date
	,@hi date
as
select
	Streets.Street
	,SUM(Apartments.Cost) as [Сумма сделки]
from 
	Streets left join (Apartments left join 
								(Deals join Buyers on Deals.idBuyer = Buyers.Id)
								on Apartments.Id = Deals.idApartment)
						on Streets.Id = Apartments.idStreet
where Buyers.DateOfDeal between @lo and @hi
group by Street
go