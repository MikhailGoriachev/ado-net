﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;  
using System.Configuration;  
using Realestate.Helpers;
using Realestate.Application;

namespace Realestate
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создание экземпляра класса приложения
            App app = new App(ConfigurationManager.ConnectionStrings["RealEstateConnection"].ConnectionString,
                ConfigurationManager.ConnectionStrings["CarHireConnection"].ConnectionString);


            Console.Title = "Задание на 29.12.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. 3-комнатные квартиры, расположенные на улице \"Садовая\"" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Риэлторы, фамилия которых начинается с буквы \"И\" и процент вознаграждения больше 10%" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. 1-комнатные квартиры, цена которых от 900 000 руб. до 1000 000 руб" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Задача 1. Квартиры с заданным числом комнат" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Задача 1. 2-комнатные квартиры, площадь которых есть значение из некоторого диапазона" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Задача 1. Вычислить для каждой оформленной сделки размер комиссионного вознаграждения риэлтора" },
                new MenuItem { HotKey = ConsoleKey.U, Text = "Задача 1. Все риэлторы, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора" },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Задача 1. Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки" },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Задача 1. Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Все факты проката автомобиля с заданным госномером" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Все факты проката автомобиля с заданной моделью/брендом" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Информация о автомобиле с заданным госномером" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Информация о клиентах по серии и номеру паспорта" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Задача 2. Информация о фактах проката в заданный интервал времени" },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Задача 2. Вычислить для каждого факта проката стоимость проката" },
                new MenuItem { HotKey = ConsoleKey.J, Text = "Задача 2. Вычислить для клиентов кол-во фактов проката и суммарное кол-во дней проката" },
                new MenuItem { HotKey = ConsoleKey.K, Text = "Задача 2. Информация о фактах проката: кол-во фактов проката, сумма за прокаты, суммарная длительность прокатов" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            
            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 29.12.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Запрос 1. 3-комнатные квартиры, расположенные на улице "Садовая"
                        case ConsoleKey.Q:
                            app.Task1ExecQuery01();
                            break;

                        // Запрос 2. Риэлторы, фамилия которых начинается с буквы "И" и процент вознаграждения больше 10%"
                        case ConsoleKey.W:
                            app.Task1ExecQuery02();
                            break;

                        // Запрос 3. 1-комнатные квартиры, цена которых от 900 000 руб. до 1000 000 руб
                        case ConsoleKey.E:
                            app.Task1ExecQuery03();
                            break;

                        // Запрос 4. Квартиры с заданным числом комнат
                        case ConsoleKey.R:
                            app.Task1ExecQuery04();
                            break;

                        // Запрос 5. 2-комнатные квартиры, площадь которых есть значение из некоторого диапазона
                        case ConsoleKey.T:
                            app.Task1ExecQuery05();
                            break;

                        // Запрос 6. Вычислить для каждой оформленной сделки размер комиссионного вознаграждения риэлтора
                        case ConsoleKey.Y:
                            app.Task1ExecQuery06();
                            break;

                        // Запрос 7. Все риэлторы, количество клиентов, оформивших с ним сделки и сумму сделок риэлтора
                        case ConsoleKey.U:
                            app.Task1ExecQuery07();
                            break;

                        // Запрос 8. Для всех улиц вывести сумму сделок, упорядочить выборку по убыванию суммы сделки
                        case ConsoleKey.I:
                            app.Task1ExecQuery08();
                            break;

                        // Запрос 9. Для всех улиц вывести сумму сделок за заданный период, упорядочить выборку по убыванию суммы сделки
                        case ConsoleKey.O:
                            app.Task1ExecQuery09();
                            break;
                        // --------------------------------------------------------------------------------------------------------

                        // Запрос 1. Все факты проката автомобиля с заданным госномером
                        case ConsoleKey.A:
                            app.Task2ExecQuery01();
                            break;

                        // Запрос 2. Все факты проката автомобиля с заданной моделью/брендом
                        case ConsoleKey.S:
                            app.Task2ExecQuery02();
                            break;

                        // Запрос 3. Информация о автомобиле с заданным госномером
                        case ConsoleKey.D:
                            app.Task2ExecQuery03();
                            break;

                        // Запрос 4. Информация о клиентах по серии и номеру паспорта
                        case ConsoleKey.F:
                            app.Task2ExecQuery04();
                            break;

                        // Запрос 5. Информация о фактах проката в заданный интервал времени
                        case ConsoleKey.G:
                            app.Task2ExecQuery05();
                            break;

                        // Запрос 6. Вычислить для каждого факта проката стоимость проката
                        case ConsoleKey.H:
                            app.Task2ExecQuery06();
                            break;

                        // Запрос 7. Вычислить для клиентов кол-во фактов проката и суммарное кол-во дней проката
                        case ConsoleKey.J:
                            app.Task2ExecQuery07();
                            break;

                        // Запрос 8. Информация о фактах проката: кол-во фактов проката, сумма за прокаты, суммарная длительность прокатов
                        case ConsoleKey.K:
                            app.Task2ExecQuery08();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
