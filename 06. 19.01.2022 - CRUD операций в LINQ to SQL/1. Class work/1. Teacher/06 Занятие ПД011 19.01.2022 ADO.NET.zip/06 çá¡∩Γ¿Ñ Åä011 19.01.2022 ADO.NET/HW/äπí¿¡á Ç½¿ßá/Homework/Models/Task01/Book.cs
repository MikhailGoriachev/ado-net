﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Task01
{
    /* Объект класса Книга имеет следующие поля: идентификатор, 
                                               идентификатор автора, 
                                               название книги, 
                                               год издания, 
                                               цена. 
     */
    public class Book {
        // идентификатор
        private int _id;
        public int Id {
            get => _id;
            set => _id = value;
        } // Id


        // идентификатор автора
        private int _idAuthor;
        public int IdAuthor {
            get => _idAuthor;
            set => _idAuthor = value;
        } // IdAuthor


        // название книги
        string _title;
        public string Title {
            get => _title;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Book: Некорректное название книги!"); _title = value; }
        } // Name


        // год издания
        private int _year;
        public int Year {
            get => _year;
            set { if (value > DateTime.Now.Year) throw new Exception("Book: Некорректное значение года издания книги!"); _year = value; }
        } // Year


        // цена
        int _price;
        public int Price {
            get => _price;
            set { if (value <= 0) throw new Exception("Book: Некорректное значение цены книги!"); _price = value; }
        } // Price

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {Id,3} │ {(Title.Length > 31 ? $"{Title.Substring(0, 28)}..." : $"{Title,-31}")} │ {Year,11} │ {Price,15:f2}  │";

        // статический метод для вывода шапки таблицы
        public static string Header()
        {
            return
                $"  ┌─────┬─────────────────────────────────┬─────────────┬──────────────────┐\n" +
                $"  │ ID  │ Название книги                  │ Год издания │ Cтоимость 1 ед.  │\n" +
                $"  ├─────┼─────────────────────────────────┼─────────────┼──────────────────┤";
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────┴─────────────────────────────────┴─────────────┴──────────────────┘\n";
    } // Book
}
