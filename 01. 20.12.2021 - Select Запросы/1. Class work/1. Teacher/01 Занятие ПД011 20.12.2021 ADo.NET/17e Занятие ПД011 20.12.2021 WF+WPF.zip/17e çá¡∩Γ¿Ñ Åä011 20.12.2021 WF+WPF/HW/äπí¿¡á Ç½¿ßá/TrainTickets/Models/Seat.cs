﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace TrainTickets.Models
{
    // Класс места: номер, состояние(занято, свободно).
    [DataContract]
    public class Seat {
        // номер
        private int _number;
        [DataMember]
        public int Number { 
            get => _number;
            set {
                if (value <= 0)
                    throw new Exception("Seat: Некорректный номер места!");
                _number = value;
            } // set 
        } // Number

        // состояние(занято - false, свободно - true)
        private bool _state;
        [DataMember]
        public bool State { 
            get => _state;
            set => _state = value;
        } // State

        public Seat(int number, bool state) {
            _number = number;
            _state = state;
        } // Train
    } // Seat
}
