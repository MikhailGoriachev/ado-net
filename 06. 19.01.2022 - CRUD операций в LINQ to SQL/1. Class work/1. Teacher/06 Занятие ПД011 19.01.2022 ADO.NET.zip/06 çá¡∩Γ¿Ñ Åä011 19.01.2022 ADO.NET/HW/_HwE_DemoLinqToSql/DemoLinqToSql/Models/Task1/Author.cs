﻿namespace DemoLinqToSql.Models.Task1
{
    // Автор описывается полями: идентификатор, фамилия и инициалы,
    // год рождения
    public class Author
    {
        // идентификатор автора
        private int _id;

        public int Id
        {
            get => _id;
            set { _id = value; }
        }

        // фамилия и инициалы
        private string _fullName;

        public string FullName
        {
            get => _fullName;
            set { _fullName = value; }
        }

        // год рождения
        private int _bornYear;

        public int BornYear
        {
            get => _bornYear;
            set { _bornYear = value; }
        }

    } // class Author
}
