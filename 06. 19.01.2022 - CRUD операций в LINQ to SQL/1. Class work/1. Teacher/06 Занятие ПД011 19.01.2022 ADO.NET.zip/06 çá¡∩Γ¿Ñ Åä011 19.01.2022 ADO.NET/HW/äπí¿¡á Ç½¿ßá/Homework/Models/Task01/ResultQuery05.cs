﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Task01
{
    // для хранения результата запроса 5 из задачи 1
    // Средняя цена книг и год их издания.
    internal class ResultQuery05 {
        // год издания
        public int Year { get; set; }

        // Средняя цена книг
        public double AvgPrice { get; set; }

        // представление объекта в виде строки таблицы
        public string ToTableRow() =>
            $"  │ {Year,9}   │ {AvgPrice,11:f2}   │";

        // статический метод для вывода шапки таблицы
        public static string Header()
        {
            return
                $"  ┌─────────────┬───────────────┐\n" +
                $"  │ Год издания │ Ср. цена книг │\n" +
                $"  ├─────────────┼───────────────┤";
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer() =>
            $"  └─────────────┴───────────────┘\n";
    }
}
